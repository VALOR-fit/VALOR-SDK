/*

oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo
oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo
oo                                                                                  oo 
oo      oooooo     oooo       .o.       ooooo          .oooooo.   ooooooooo.        oo
oo       `888.     .8'       .888.      `888'         d8P'  `Y8b  `888   `Y88.      oo 
oo        `888.   .8'       .8"888.      888         888      888  888   .d88'      oo
oo         `888. .8'       .8' `888.     888         888      888  888ooo88P'       oo
oo          `888.8'       .88ooo8888.    888         888      888  888`88b.         oo
oo           `888'       .8'     `888.   888       o `88b    d88'  888  `88b.       oo
oo            `8'       o88o     o8888o o888ooooood8  `Y8bood8P'  o888o  o888o      oo
oo                                                                                  oo                                                                   
oo                                                   https://valor.pp.rl.ac.uk      oo      
oo                                                                                  oo      
oo                                                                                  oo      
oo       Costas Andreopoulos [1,2], Christopher Barry [1], Francis Bench [1]        oo
oo           Thomas Dealtry [3], Steve Dennis [1], Lorena Escudero [4],             oo
oo               Rhiannon Jones [1]. Nick Grant [5], Marco Roda [1]                 oo
oo                     Davide Sgalaberna [6], and Raj Shah [7]                      oo
oo                                                                                  oo
oo                                (The VALOR group)                                 oo
oo                                                                                  oo
oo                          [1] University of Liverpool                             oo
oo                    [2] STFC Rutherford Appleton Laboratory                       oo
oo                           [3] University of Lancaster                            oo
oo                           [4] University of Cambridge                            oo
oo                            [5] University of Warwick                             oo
oo                            [6] University of Geneva                              oo
oo                            [7] University of Oxford                              oo
oo                                                                                  oo
oo          Copyright (c) 2010-2017, The VALOR group, All rights reserved           oo
oo                                                                                  oo      
oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo
oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo



LICENSE AGREEMENT
--------------------------------------------------------------------------------------

* PREAMBLE

The VALOR Group has been developing a well-established T2K oscillation analysis 
since 2010 and it contributed to nearly all published T2K oscillation papers. 
The T2K analysis code produced by the VALOR Group has evolved into a general 
oscillation analysis and framework which, amongst other activities, supports 
a) physics  exploitation in the Fermilab short-baseline (SBN) programme, 
b) oscillation physics-driven Near Detector design efforts for DUNE, and 
c) efforts for the development of global LBL oscillation fits. 

Considerable resources were invested in the development of the VALOR analysis 
procedures. The VALOR Fit is a technology that takes centre stage in the near and 
long-term physics exploitation plans of several VALOR Group members. This license 
lays a framework that maintains the exclusivity of the VALOR Group in the 
exploitation of the VALO IP, but provides the T2K Collaboration with sufficient 
access to the VALOR Fit and enables independent cross-checks of the VALOR analysis 
procedures.


* TERMS AND CONDITIONS

This License grants a time-limited, non-exclusive, non-transferable and royalty-free 
permission to use a VALOR T2K Release, in accordance to the Terms & Conditions.
All rights not explicitly granted by this License are reserved by the VALOR Group.

By installing, copying or otherwise using the Work, you agree to the terms of this 
License Agreement.

Derivative Works are allowed strictly for the purpose of performing independent 
cross-checks of results included in T2K physics publications. 

Use of the VALOR T2K Release as a general T2K analysis framework is prohibited. 
No parts of the VALOR T2K Release shall be included in other T2K analysis codes. 

Use of the VALOR T2K Release outside of T2K is strictly prohibited.

Authorised Users have no right to further distribute a VALOR T2K Release, or 
Derivative Works, and will not copy it except as necessary for use on a single 
personal computer. VALOR T2K Releases shall not be stored or installed by the 
Authorised Users in a manner that provides non-Authorised Users the right to copy, 
read or execute.

The VALOR Group accepts no responsibility for maintaining VALOR T2K Releases, 
and no responsibility for providing support, training or documentation beyond 
what is available. There will be no VALOR documentation or tutorial developed 
by T2K aiming to encourage general use of VALOR.

Any Derivative Work shall be reported within the VALOR Group first. An explicit 
agreement by the VALOR Group is required before any Derivative Work is presented 
to the T2K Collaboration.

Any suspected error will be reported to the VALOR Group first for detailed 
investigation before reporting to the T2K Collaboration.

Changes to the VALOR Fit will be submitted for consideration to the VALOR Group. 
There shall be no independent fork of the VALOR Fit.

This License Agreement can be revoked by the VALOR Group at any point, removing 
any right granted under this License with immediate effect.


Definitions
———————————————————

"Source" form shall mean the preferred form for making modifications, 
including but not limited to software source code, documentation source, 
and configuration files.

"Object" form shall mean any form resulting from mechanical transformation 
or translation of a Source form, including but not limited to compiled 
object code, generated documentation, and conversions to other media types.

"Data" form shall mean computer and human readable digital data and 
configuration files required for running the analysis code.

“VALOR Fit” encompasses all Source, Object and Data forms of this product.

“VALOR T2K Release” is a frozen version of selected VALOR Fit components 
required for reproducing the results included in a T2K physics publication.
This is a specially prepared and amalgamated code release produced by an 
automated procedure running over the extended VALOR source tree. 
The full source tree can not be distributed due to complex 

“VALOR Group” is the group of T2K and non-T2K authors listed in 
https://valor.pp.rl.ac.uk

"Authorised Users" shall mean the named individuals (T2K Collaborators) 
exercising permissions granted by this License Agreement.

"Work" shall mean the work of authorship, whether in Source, Object or Data 
form, made available under this License Agreement.

"Derivative Works" shall mean any work, whether in Source, Object or Data form, 
that is based on (or derived from) the Work and which represents, as a whole, 
an original work of authorship. 

*/

#include <cassert>
#include <fstream>
#include <cctype>
#include <cstdlib>
#include <string>
#include <map>
#include <vector>
#include <complex>
#include <deque>
#include <thread>
#include <numeric>
#include <functional>
#include <iostream>
#include <iomanip>
#include <sstream>
#include "log4cpp/Category.hh"
#include "log4cpp/Appender.hh"
#include "log4cpp/OstreamAppender.hh"
#include "log4cpp/BasicLayout.hh"
#include "log4cpp/Priority.hh"
#include "log4cpp/SimpleLayout.hh"
#include <TROOT.h>
#include <TApplication.h>
#include <TSystem.h>
#include <TMath.h>
#include <TString.h>
#include <TStyle.h>
#include <TColor.h>
#include <TGraph.h>
#include <TF1.h>
#include <TH1.h>
#include <TH2.h>
#include <TH3.h>
#include <TAxis.h>
#include <TCanvas.h>
#include <TLine.h>
#include <TLegend.h>
#include <TVectorD.h>
#include <TMatrixD.h>
#include <TRandom3.h>
#include <TXMLEngine.h>
#include <TPrincipal.h>
#include <TFile.h>
#include <TTree.h>
#include <TChain.h>
#include <TSystem.h>
#include <TDecompSVD.h>
#include <TMinuit.h>
#include <TFitter.h>
#include <TMatrixDSym.h>
#include <TObjArray.h>
#include <TPRegexp.h>
#include <TSpline.h>
#include <TRandom3.h>
#include <TStopwatch.h>
#include <TTimeStamp.h>
#include <TVirtualFitter.h>
#include <Minuit2/FumiliFCNBase.h>
#include <Math/IFunction.h>
#include <Math/FitMethodFunction.h>
#include <Math/Minimizer.h>
#include <Math/Interpolator.h>
#include <HFitInterface.h>
#include <Minuit2/MnUserCovariance.h>
#include <Minuit2/FunctionMinimum.h>
#include <Minuit2/MnUserParameters.h>
#include <Minuit2/MnUserCovariance.h>
#include <Minuit2/FunctionMinimum.h>
#include <Minuit2/MnApplication.h>
#include <Minuit2/MnMigrad.h>
#include <Minuit2/MnFumiliMinimize.h>
#include <Minuit2/MnHesse.h>
#include <Minuit2/MnMinos.h>
#include <Minuit2/MnPrint.h>
#include <Fit/Fitter.h>
using std::cout;
using std::cerr;
using std::endl;
using std::setw;
using std::setfill;
using std::ios;
using std::setprecision;
using std::fixed;
using std::string;
using std::complex;
using std::vector;
using std::map;
using std::pair;
using std::deque;
using std::thread;
using std::ostream;
using std::ofstream;
using std::ifstream;
using std::ostringstream;
#ifndef _VALOR_FMWK_BUILD_H_
#define _VALOR_FMWK_BUILD_H_
#define __VALOR_FMWK_GSL_ENABLED__
#define __VALOR_FMWK_USES_LOG4CPP_VERSION__ 101
#endif
#ifndef _VALOR_FMWK_VERSION_H_
#define _VALOR_FMWK_VERSION_H_
#define VALOR_FMWK_RELEASE_CODE_BUILDER(a,b,c) (((a) << 16) + ((b) << 8) + (c))
#define __VALOR_FMWK_RELEASE__ "1.1.1"
#define __VALOR_FMWK_RELEASE_CODE__ VALOR_FMWK_RELEASE_CODE_BUILDER(1,1,1)
#endif
#ifndef _VALOR_MESSENGER_H_
#define _VALOR_MESSENGER_H_
#define pFATAL log4cpp::Priority::FATAL
#define pALERT log4cpp::Priority::ALERT
#define pCRIT log4cpp::Priority::CRIT
#define pERROR log4cpp::Priority::ERROR
#define pWARN log4cpp::Priority::WARN
#define pNOTICE log4cpp::Priority::NOTICE
#define pINFO log4cpp::Priority::INFO
#define pDEBUG log4cpp::Priority::DEBUG
#ifdef __VALOR_FMWK_USES_LOG4CPP_VERSION__
#if __VALOR_FMWK_USES_LOG4CPP_VERSION__==0
#define ENDL log4cpp::CategoryStream::ENDLINE
#else
#define ENDL std::endl
#endif
#else
#define ENDL std::endl
#endif
#ifndef SLOG
#define SLOG(stream, priority) \
(*valor::Messenger::Instance())(stream) \
<< priority << "[s] <" \
<< __FUNCTION__ << " (" << __LINE__ << ")> : "
#endif
#ifndef LOG
#define LOG(stream, priority) \
(*valor::Messenger::Instance())(stream) \
<< priority << "[n] <" \
<< __FILE__ << "::" << __FUNCTION__ << " (" << __LINE__ << ")> : "
#endif
#define VSLOG(stream, priority) \
(*valor::Messenger::Instance())(stream) \
<< priority << "[s] <" \
<< __FUNCTION__ << " (" << __LINE__ << ")> : "
#define VLOG(stream, priority) \
(*valor::Messenger::Instance())(stream) \
<< priority << "[s] <" \
<< __FUNCTION__ << " (" << __LINE__ << ")> : "
#ifndef LOG_FATAL
#define LOG_FATAL(stream) \
(*valor::Messenger::Instance())(stream) \
<< log4cpp::Priority::FATAL << "[n] <" \
<< __FILE__ << "::" << __FUNCTION__ << " (" << __LINE__ << ")> : "
#define LOG_ALERT(stream) \
(*valor::Messenger::Instance())(stream) \
<< log4cpp::Priority::ALERT << "[n] <" \
<< __FILE__ << "::" << __FUNCTION__ << " (" << __LINE__ << ")> : "
#define LOG_CRIT(stream) \
(*valor::Messenger::Instance())(stream) \
<< log4cpp::Priority::CRIT << "[n] <" \
<< __FILE__ << "::" << __FUNCTION__ << " (" << __LINE__ << ")> : "
#define LOG_ERROR(stream) \
(*valor::Messenger::Instance())(stream) \
<< log4cpp::Priority::ERROR << "[n] <" \
<< __FILE__ << "::" << __FUNCTION__ << " (" << __LINE__ << ")> : "
#define LOG_WARN(stream) \
(*valor::Messenger::Instance())(stream) \
<< log4cpp::Priority::WARN << "[n] <" \
<< __FILE__ << "::" << __FUNCTION__ << " (" << __LINE__ << ")> : "
#define LOG_NOTICE(stream) \
(*valor::Messenger::Instance())(stream) \
<< log4cpp::Priority::NOTICE << "[n] <" \
<< __FILE__ << "::" << __FUNCTION__ << " (" << __LINE__ << ")> : "
#define LOG_INFO(stream) \
(*valor::Messenger::Instance())(stream) \
<< log4cpp::Priority::INFO << "[n] <" \
<< __FILE__ << "::" << __FUNCTION__ << " (" << __LINE__ << ")> : "
#define LOG_DEBUG(stream) \
(*valor::Messenger::Instance())(stream) \
<< log4cpp::Priority::DEBUG << "[n] <" \
<< __FILE__ << "::" << __FUNCTION__ << " (" << __LINE__ << ")> : "
#define LLOG(stream, priority) \
(*valor::Messenger::Instance())(stream) \
<< priority << "[l] <" \
<< __PRETTY_FUNCTION__ << " (" << __LINE__ << ")> : "
#define LLOG_FATAL(stream) \
(*valor::Messenger::Instance())(stream) \
<< log4cpp::Priority::FATAL << "[l] <" \
<< __PRETTY_FUNCTION__ << " (" << __LINE__ << ")> : "
#define LLOG_ALERT(stream) \
(*valor::Messenger::Instance())(stream) \
<< log4cpp::Priority::ALERT << "[l] <" \
<< __PRETTY_FUNCTION__ << " (" << __LINE__ << ")> : "
#define LLOG_CRIT(stream) \
(*valor::Messenger::Instance())(stream) \
<< log4cpp::Priority::CRIT << "[l] <" \
<< __PRETTY_FUNCTION__ << " (" << __LINE__ << ")> : "
#define LLOG_ERROR(stream) \
(*valor::Messenger::Instance())(stream) \
<< log4cpp::Priority::ERROR << "[l] <" \
<< __PRETTY_FUNCTION__ << " (" << __LINE__ << ")> : "
#define LLOG_WARN(stream) \
(*valor::Messenger::Instance())(stream) \
<< log4cpp::Priority::WARN << "'[l] <" \
<< __PRETTY_FUNCTION__ << " (" << __LINE__ << ")> : "
#define LLOG_NOTICE(stream) \
(*valor::Messenger::Instance())(stream) \
<< log4cpp::Priority::NOTICE << "[l] <" \
<< __PRETTY_FUNCTION__ << " (" << __LINE__ << ")> : "
#define LLOG_INFO(stream) \
(*valor::Messenger::Instance())(stream) \
<< log4cpp::Priority::INFO << "[l] <" \
<< __PRETTY_FUNCTION__ << " (" << __LINE__ << ")> : "
#define LLOG_DEBUG(stream) \
(*valor::Messenger::Instance())(stream) \
<< log4cpp::Priority::DEBUG << "[l] <" \
<< __PRETTY_FUNCTION__ << " (" << __LINE__ << ")> : "
#define BLOG(stream, priority) \
 (*valor::Messenger::Instance())(stream) << priority
#endif
namespace valor {
class Messenger
{
public:
static Messenger * Instance(void);
log4cpp::Category & operator () (const char * stream);
void SetPriorityLevel(const char * stream, log4cpp::Priority::Value p);
void SetPriorityLevel(std::string stream, std::string priority);
bool Configure(std::string filename);
private:
Messenger();
Messenger(const Messenger & m);
virtual ~Messenger();
static Messenger * fInstance;
log4cpp::Priority::Value PriorityFromString(std::string priority);
struct Cleaner {
void DummyMethodAndSilentCompiler() { }
~Cleaner() {
if (Messenger::fInstance !=0) {
delete Messenger::fInstance;
Messenger::fInstance = 0;
}
}
};
friend struct Cleaner;
};
}
#endif
#ifndef _valor_registry_item_type_def_h_
#define _valor_registry_item_type_def_h_
typedef string RgKey;
typedef int RgInt;
typedef bool RgBool;
typedef double RgDbl;
typedef string RgStr;
typedef const char * RgCChAr;
typedef TH1F * RgH1F;
typedef TH2F * RgH2F;
typedef TTree * RgTree;
typedef TObject * RgObject;
#endif
#ifndef _valor_registry_item_type_id_h_
#define _valor_registry_item_type_id_h_
namespace valor {
typedef enum ERgType {
kRgUndefined = 0,
kRgBool,
kRgInt,
kRgDbl,
kRgStr,
kRgH1F,
kRgH2F,
kRgTree,
kRgObject
} RgType_t;
class RgType {
public:
static string AsString(RgType_t rt)
{
switch (rt) {
case (kRgUndefined) : return "undefined"; break;
case (kRgBool) : return "bool"; break;
case (kRgInt) : return "int"; break;
case (kRgDbl) : return "double"; break;
case (kRgStr) : return "string"; break;
case (kRgH1F) : return "h1f"; break;
case (kRgH2F) : return "h2f"; break;
case (kRgTree) : return "tree"; break;
case (kRgObject) : return "object"; break;
default : return "undefined";
}
}
};
}
#endif
#ifndef _valor_registry_item_pabc_h_
#define _valor_registry_item_pabc_h_
namespace valor {
class RegistryItemI
{
public:
virtual ~RegistryItemI() { }
virtual RegistryItemI * Clone (void) const = 0;
virtual RgType_t TypeInfo (void) const = 0;
virtual bool IsLocked (void) const = 0;
virtual void Lock (void) = 0;
virtual void UnLock (void) = 0;
virtual bool IsLocal (void) const = 0;
virtual void SetLocal (bool) = 0;
virtual void Print (ostream &) const = 0;
protected:
RegistryItemI() { }
};
}
#endif
#ifndef _valor_registry_item_h_
#define _valor_registry_item_h_
namespace valor {
template<typename T> class RegistryItem;
template<typename T>
ostream & operator << (ostream & stream, const RegistryItem<T> & rec);
template<typename T> class RegistryItem : public RegistryItemI {
public:
RegistryItem() { };
RegistryItem(T item, bool locked=false, bool local=true);
RegistryItem(const RegistryItem * ri);
~RegistryItem();
RegistryItemI * Clone (void) const;
RgType_t TypeInfo (void) const;
const T & Data (void) const { return fItem; }
bool IsLocked (void) const { return fIsLocked; }
void Lock (void) { fIsLocked = true; }
void UnLock (void) { fIsLocked = false; }
bool IsLocal (void) const { return fIsLocal; }
void SetLocal (bool isloc) { fIsLocal = isloc; }
void Print(ostream& stream) const;
friend ostream & operator <<
<T>(ostream & stream, const RegistryItem<T> & rec);
private:
T fItem;
bool fIsLocked;
bool fIsLocal;
};
}
#endif
#ifndef _valor_registry_h_
#define _valor_registry_h_
class TH1F;
class TH2F;
class TTree;
class TFolder;
namespace valor {
typedef map <RgKey, RegistryItemI *> RgIMap;
typedef pair<RgKey, RegistryItemI *> RgIMapPair;
typedef map <RgKey, RegistryItemI *>::size_type RgIMapSizeType;
typedef map <RgKey, RegistryItemI *>::iterator RgIMapIter;
typedef map <RgKey, RegistryItemI *>::const_iterator RgIMapConstIter;
typedef vector<RgKey> RgKeyList;
class Registry;
template<class T>
void SetRegistryItem(Registry * r, RgKey key, T item);
template<class T>
T GetValueOrUseDefault(
Registry * r, RgKey key, T def, bool set_def=true);
ostream & operator << (ostream & stream, const Registry & registry);
class Registry {
public:
Registry();
Registry(string name, bool isReadOnly = true);
Registry(const Registry &);
virtual ~Registry();
friend ostream & operator << (ostream & stream, const Registry & registry);
Registry & operator = (const Registry & reg);
Registry & operator += (const Registry & reg);
void operator () (RgKey key, int item);
void operator () (RgKey key, bool item);
void operator () (RgKey key, double item);
void operator () (RgKey key, const char * item);
void operator () (RgKey key, string item);
void Lock (void);
void UnLock (void);
bool IsLocked (void) const;
void InhibitItemLocks (void);
void RestoreItemLocks (void);
bool ItemLocksAreActive (void) const;
void LockItem (RgKey key);
void UnLockItem (RgKey key);
bool ItemIsLocked (RgKey key) const;
bool ItemIsLocal (RgKey key) const;
void OverrideGlobalDef (RgKey key);
void LinkToGlobalDef (RgKey key);
void Set (RgIMapPair entry);
void Set (RgKey key, RgBool item);
void Set (RgKey key, RgInt item);
void Set (RgKey key, RgDbl item);
void Set (RgKey key, RgStr item);
void Set (RgKey key, RgCChAr item);
void Set (RgKey key, RgH1F item);
void Set (RgKey key, RgH2F item);
void Set (RgKey key, RgTree item);
void Set (RgKey key, RgObject item);
void Get (RgKey key, const RegistryItemI * & item) const;
void Get (RgKey key, RgBool & item) const;
void Get (RgKey key, RgInt & item) const;
void Get (RgKey key, RgDbl & item) const;
void Get (RgKey key, RgStr & item) const;
void Get (RgKey key, RgH1F & item) const;
void Get (RgKey key, RgH2F & item) const;
void Get (RgKey key, RgTree & item) const;
void Get (RgKey key, RgObject & item) const;
RgBool GetBool (RgKey key) const;
RgInt GetInt (RgKey key) const;
RgDbl GetDouble (RgKey key) const;
RgStr GetString (RgKey key) const;
RgH1F GetH1F (RgKey key) const;
RgH2F GetH2F (RgKey key) const;
RgTree GetTree (RgKey key) const;
RgObject GetObject (RgKey key) const;
RgBool GetBoolDef (RgKey key, RgBool def_opt, bool set_def=true);
RgInt GetIntDef (RgKey key, RgInt def_opt, bool set_def=true);
RgDbl GetDoubleDef (RgKey key, RgDbl def_opt, bool set_def=true);
RgStr GetStringDef (RgKey key, RgStr def_opt, bool set_def=true);
RgIMapConstIter SafeFind (RgKey key) const;
int NEntries (void) const;
bool Exists (RgKey key) const;
bool CanSetItem (RgKey key) const;
bool DeleteEntry (RgKey key);
void SetName (string name);
string Name (void) const;
void Print (ostream & stream) const;
void Copy (const Registry &);
void Append (const Registry &, RgKey pfx="");
void Clear (bool force = false);
void Init (void);
RgType_t ItemType (RgKey key) const;
RgKeyList FindKeys (RgKey key_part) const;
const RgIMap & GetItemMap(void) const { return fRegistry; }
void AssertExistence (RgKey key0) const;
void AssertExistence (RgKey key0, RgKey key1) const;
void AssertExistence (RgKey key0, RgKey key1, RgKey key2) const;
private:
string fName;
bool fIsReadOnly;
bool fInhibitItemLocks;
RgIMap fRegistry;
};
}
#endif
#ifndef constants_h
#define constants_h
namespace valor {
namespace conv {
static const double kT2KBestFitDmsq12 = 7.5E-5;
static const double kT2KBestFitSinsqTheta12 = 0.306;
static const double kT2KBestFitSinsq2Theta12 = 0.8495;
static const double kT2KBestFitDeltaCP_NH = 1.91;
static const double kT2KBestFitDeltaCP_IH = 1.01;
static const double kT2KBestFitDmsq23_NH = 2.51E-3;
static const double kT2KBestFitDmsq23_IH = 2.49E-3;
static const double kT2KBestFitSinsqTheta13_NH = 0.0422;
static const double kT2KBestFitSinsqTheta13_IH = 0.0491;
static const double kT2KBestFitSinsqTheta23_NH = 0.524;
static const double kT2KBestFitSinsqTheta23_IH = 0.523;
static const double kT2KBestFitSinsq2Theta13_NH = 0.1617;
static const double kT2KBestFitSinsq2Theta13_IH = 0.1868;
static const double kT2KBestFitSinsq2Theta23_NH = 0.998;
static const double kT2KBestFitSinsq2Theta23_IH = 0.998;
static const double kT2KReacBestFitDmsq12 = 7.5E-5;
static const double kT2KReacBestFitSinsqTheta12 = 0.306;
static const double kT2KReacBestFitSinsq2Theta12 = 0.8495;
static const double kT2KReacBestFitDeltaCP_NH = -1.55;
static const double kT2KReacBestFitDeltaCP_IH = -1.56;
static const double kT2KReacBestFitDmsq23_NH = 2.51E-3;
static const double kT2KReacBestFitDmsq23_IH = 2.48E-3;
static const double kT2KReacBestFitSinsqTheta13_NH = 0.0248;
static const double kT2KReacBestFitSinsqTheta13_IH = 0.0252;
static const double kT2KReacBestFitSinsqTheta23_NH = 0.527;
static const double kT2KReacBestFitSinsqTheta23_IH = 0.533;
static const double kT2KReacBestFitSinsq2Theta13_NH = 0.0967;
static const double kT2KReacBestFitSinsq2Theta13_IH = 0.0983;
static const double kT2KReacBestFitSinsq2Theta23_NH = 0.997;
static const double kT2KReacBestFitSinsq2Theta23_IH = 0.996;
static const double kT2KReacMostProbDmsq12 = 7.5E-5;
static const double kT2KReacMostProbSinsqTheta12 = 0.306;
static const double kT2KReacMostProbSinsq2Theta12 = 0.8495;
static const double kT2KReacMostProbDeltaCP_Mach3_NH = -1.601;
static const double kT2KReacMostProbDmsq23_Mach3_NH = 2.509E-3;
static const double kT2KReacMostProbSinsqTheta13_Mach3_NH = 0.0243;
static const double kT2KReacMostProbSinsqTheta23_Mach3_NH = 0.528;
static const double kT2KReacMostProbSinsq2Theta23_Mach3_NH = 0.996864;
static const double kGlobFitDm12sq = 7.53E-5;
static const double kGlobFitDm23sq = kT2KReacMostProbDmsq23_Mach3_NH;
static const double kGlobFitDmsqFL = 2.36E-3;
static const double kGlobFitErrDm23sq = 0.04;
static const double kGlobFitErrDm12sq = 0.024;
static const double kGlobFitDeltaCP = kT2KReacMostProbDeltaCP_Mach3_NH;
static const double kGlobFitErrDeltaCP = 0.10;
static const double kGlobFitSinsq2Theta23 = kT2KReacBestFitSinsq2Theta23_NH;
static const double kGlobFitSinsq2Theta13 = 0.085;
static const double kGlobFitSinsq2Theta12 = 0.8463;
static const double kGlobFitErrSinsq2Theta23 = 0.109;
static const double kGlobFitErrSinsq2Theta12 = 0.025;
static const double kGlobFitErrSinsq2Theta13 = 0.324;
static const double kGlobFitSinsqTheta23 = kT2KReacMostProbSinsqTheta23_Mach3_NH;
static const double kGlobFitSinsqTheta13 = 0.0217;
static const double kGlobFitSinsqTheta12 = 0.304;
static const double kGlobFitErrSinsqTheta23 = 0.109;
static const double kGlobFitErrSinsqTheta12 = 0.025;
static const double kGlobFitErrSinsqTheta13 = 0.324;
static const double kGlobFitBetaBar = 1.;
static const double kGlobFitErrBetaBar = 1.;
static const double kFutureAbsErrSinsqTheta23 = 0.05;
static const double kFutureAbsErrSinsq2Theta23 = 0.19;
static const double kFutureAbsErrDm23sq = 0.045E-3;
static const double kFutureAbsErrSinsqTheta13 = 0.0013858;
static const double kFutureAbsErrSinsq2Theta13 = 0.005;
static const double kFutureAbsErrSinsqTheta12 = 0.0;
static const double kFutureAbsErrSinsq2Theta12 = 0.0;
static const double kFutureAbsErrDm12sq = 0.0;
static const double kInitFitDm23sq = kGlobFitDm23sq;
static const double kMinFitDm23sq = 1.0E-3;
static const double kMaxFitDm23sq = 6.0E-3;
static const double kStepDm23sq = 1.0E-4;
static const double kInitFitDm12sq = kGlobFitDm12sq;
static const double kMinFitDm12sq = 6.0E-5;
static const double kMaxFitDm12sq = 9.0E-5;
static const double kStepDm12sq = 2.0E-6;
static const double kInitFitDm23sqBar = kGlobFitDm23sq;
static const double kMinFitDm23sqBar = 1.0E-5;
static const double kMaxFitDm23sqBar = 2.0E-2;
static const double kStepDm23sqBar = 1.0E-4;
static const double kInitFitDm12sqBar = kGlobFitDm12sq;
static const double kMinFitDm12sqBar = 6.0E-5;
static const double kMaxFitDm12sqBar = 9.0E-5;
static const double kStepDm12sqBar = 2.0E-6;
static const double kInitFitSinsq2Theta23 = kGlobFitSinsq2Theta23;
static const double kMinFitSinsq2Theta23 = 0.00;
static const double kMaxFitSinsq2Theta23 = 1.00;
static const double kStepSinsq2Theta23 = 5.0E-3;
static const double kInitFitSinsq2Theta13 = kGlobFitSinsq2Theta13;
static const double kMinFitSinsq2Theta13 = 0.00;
static const double kMaxFitSinsq2Theta13 = 1.00;
static const double kStepSinsq2Theta13 = 1.0E-3;
static const double kInitFitSinsq2Theta12 = kGlobFitSinsq2Theta12;
static const double kMinFitSinsq2Theta12 = 0.00;
static const double kMaxFitSinsq2Theta12 = 1.00;
static const double kStepSinsq2Theta12 = 1.0E-2;
static const double kInitFitSinsq2Theta23Bar = kGlobFitSinsq2Theta23;
static const double kMinFitSinsq2Theta23Bar = 0.00;
static const double kMaxFitSinsq2Theta23Bar = 1.00;
static const double kStepSinsq2Theta23Bar = 5.0E-3;
static const double kInitFitSinsq2Theta13Bar = kGlobFitSinsq2Theta13;
static const double kMinFitSinsq2Theta13Bar = 0.00;
static const double kMaxFitSinsq2Theta13Bar = 1.00;
static const double kStepSinsq2Theta13Bar = 1.0E-3;
static const double kInitFitSinsq2Theta12Bar = kGlobFitSinsq2Theta12;
static const double kMinFitSinsq2Theta12Bar = 0.00;
static const double kMaxFitSinsq2Theta12Bar = 1.00;
static const double kStepSinsq2Theta12Bar = 1.0E-2;
static const double kInitFitSinsqTheta23 = kGlobFitSinsqTheta23;
static const double kMinFitSinsqTheta23 = 0.00;
static const double kMaxFitSinsqTheta23 = 1.00;
static const double kStepSinsqTheta23 = 5.0E-3;
static const double kInitFitSinsqTheta13 = kGlobFitSinsqTheta13;
static const double kMinFitSinsqTheta13 = 0.00;
static const double kMaxFitSinsqTheta13 = 1.00;
static const double kStepSinsqTheta13 = 1.0E-3;
static const double kInitFitSinsqTheta12 = kGlobFitSinsqTheta12;
static const double kMinFitSinsqTheta12 = 0.00;
static const double kMaxFitSinsqTheta12 = 1.00;
static const double kStepSinsqTheta12 = 1.0E-2;
static const double kInitFitSinsqTheta23Bar = kGlobFitSinsqTheta23;
static const double kMinFitSinsqTheta23Bar = 0.00;
static const double kMaxFitSinsqTheta23Bar = 1.00;
static const double kStepSinsqTheta23Bar = 5.0E-3;
static const double kInitFitSinsqTheta13Bar = kGlobFitSinsqTheta13;
static const double kMinFitSinsqTheta13Bar = 0.00;
static const double kMaxFitSinsqTheta13Bar = 1.00;
static const double kStepSinsqTheta13Bar = 1.0E-3;
static const double kInitFitSinsqTheta12Bar = kGlobFitSinsqTheta12;
static const double kMinFitSinsqTheta12Bar = 0.00;
static const double kMaxFitSinsqTheta12Bar = 1.00;
static const double kStepSinsqTheta12Bar = 1.0E-2;
static const double kInitFitBetaBar = 1.00;
static const double kMinFitBetaBar = 0.00;
static const double kMaxFitBetaBar = 20.00;
static const double kStepBetaBar = 5.0E-3;
static const double kInitFitSinsqTheta14 = 0.00;
static const double kMinFitSinsqTheta14 = 0.00;
static const double kMaxFitSinsqTheta14 = 1.00;
static const double kStepSinsqTheta14 = 5.0E-3;
static const double kInitFitSinsqTheta15 = 0.00;
static const double kMinFitSinsqTheta15 = 0.00;
static const double kMaxFitSinsqTheta15 = 1.00;
static const double kStepSinsqTheta15 = 5.0E-3;
static const double kInitFitSinsqTheta24 = 0.00;
static const double kMinFitSinsqTheta24 = 0.00;
static const double kMaxFitSinsqTheta24 = 1.00;
static const double kStepSinsqTheta24 = 5.0E-3;
static const double kInitFitSinsqTheta25 = 0.00;
static const double kMinFitSinsqTheta25 = 0.00;
static const double kMaxFitSinsqTheta25 = 1.00;
static const double kStepSinsqTheta25 = 5.0E-3;
static const double kInitFitSinsqTheta34 = 0.00;
static const double kMinFitSinsqTheta34 = 0.00;
static const double kMaxFitSinsqTheta34 = 1.00;
static const double kStepSinsqTheta34 = 5.0E-3;
static const double kInitFitSinsqTheta35 = 0.00;
static const double kMinFitSinsqTheta35 = 0.00;
static const double kMaxFitSinsqTheta35 = 1.00;
static const double kStepSinsqTheta35 = 5.0E-3;
static const double kInitFitSinsq2Theta14 = 0.00;
static const double kMinFitSinsq2Theta14 = 0.00;
static const double kMaxFitSinsq2Theta14 = 1.00;
static const double kStepSinsq2Theta14 = 5.0E-3;
static const double kInitFitSinsq2Theta15 = 0.00;
static const double kMinFitSinsq2Theta15 = 0.00;
static const double kMaxFitSinsq2Theta15 = 1.00;
static const double kStepSinsq2Theta15 = 5.0E-3;
static const double kInitFitSinsq2Theta24 = 0.00;
static const double kMinFitSinsq2Theta24 = 0.00;
static const double kMaxFitSinsq2Theta24 = 1.00;
static const double kStepSinsq2Theta24 = 5.0E-3;
static const double kInitFitSinsq2Theta25 = 0.00;
static const double kMinFitSinsq2Theta25 = 0.00;
static const double kMaxFitSinsq2Theta25 = 1.00;
static const double kStepSinsq2Theta25 = 5.0E-3;
static const double kInitFitSinsq2Theta34 = 0.00;
static const double kMinFitSinsq2Theta34 = 0.00;
static const double kMaxFitSinsq2Theta34 = 1.00;
static const double kStepSinsq2Theta34 = 5.0E-3;
static const double kInitFitSinsq2Theta35 = 0.00;
static const double kMinFitSinsq2Theta35 = 0.00;
static const double kMaxFitSinsq2Theta35 = 1.00;
static const double kStepSinsq2Theta35 = 5.0E-3;
static const double kInitFitDm41sq = 3E-3;
static const double kMinFitDm41sq = kGlobFitDm23sq;
static const double kMaxFitDm41sq = 1.0E-2;
static const double kStepDm41sq = 1.0E-4;
static const double kInitFitDm51sq = 3E-3;
static const double kMinFitDm51sq = kGlobFitDm23sq;
static const double kMaxFitDm51sq = 1.0E-2;
static const double kStepDm51sq = 1.0E-4;
static const double kMinChisqSurfaceDm23sq = 1.5E-3;
static const double kMaxChisqSurfaceDm23sq = 3.3E-3;
static const double kMinChisqSurfaceSinsq2Theta23 = 0.80;
static const double kMaxChisqSurfaceSinsq2Theta23 = 1.00;
static const double kPrior_deltaCP_Flat_Low = -3.14159265358979312e+00;
static const double kPrior_deltaCP_Flat_Up = +3.14159265358979312e+00;
static const double kPrior_Sinsq2th13_Flat_Low = 0.;
static const double kPrior_Sinsq2th13_Flat_Up = 0.4;
static const double kPrior_Sinsq2th23_Flat_Low = 0.3;
static const double kPrior_Sinsq2th23_Flat_Up = 0.7;
static const double kPrior_Dm23sq_Flat_Low = 2E-3;
static const double kPrior_Dm23sq_Flat_Up = 3E-3;
static const double kPrior_Sinsq2th13_PDG2013_Mean = 0.095;
static const double kPrior_Sinsq2th13_PDG2013_RMS = 0.010;
static const double kPrior_Sinsq2th13_PDG2014_Mean = 0.093;
static const double kPrior_Sinsq2th13_PDG2014_RMS = 0.008;
static const double kPrior_Sinsq2th13_PDG2015_Mean = 0.085;
static const double kPrior_Sinsq2th13_PDG2015_RMS = 0.005;
static const double kPrior_Sinsq2th13_Used_Mean = kPrior_Sinsq2th13_PDG2015_Mean;
static const double kPrior_Sinsq2th13_Used_RMS = kPrior_Sinsq2th13_PDG2015_RMS;
static const double kPrior_Dm12sq_PDG2014_Mean = 7.53E-5;
static const double kPrior_Dm12sq_PDG2014_RMS = 0.18E-5;
static const double kPrior_Dm12sq_PDG2015_Mean = 7.53E-5;
static const double kPrior_Dm12sq_PDG2015_RMS = 0.18E-5;
static const double kPrior_Dm12sq_Used_Mean = kPrior_Dm12sq_PDG2015_Mean;
static const double kPrior_Dm12sq_Used_RMS = kPrior_Dm12sq_PDG2015_RMS;
static const double kPrior_Sinsq2th12_PDG2014_Mean = 0.846;
static const double kPrior_Sinsq2th12_PDG2014_RMS = 0.021;
static const double kPrior_Sinsq2th12_PDG2015_Mean = 0.846;
static const double kPrior_Sinsq2th12_PDG2015_RMS = 0.021;
static const double kPrior_Sinsq2th12_Used_Mean = kPrior_Sinsq2th12_PDG2015_Mean;
static const double kPrior_Sinsq2th12_Used_RMS = kPrior_Sinsq2th12_PDG2015_RMS;
static const double kPrior_MH = 0.5;
static const double kUsed_DeltaCP = kT2KReacMostProbDeltaCP_Mach3_NH;
static const double kUsed_Dm12sq = kGlobFitDm12sq;
static const double kUsed_Dm23sq = kT2KReacMostProbDmsq23_Mach3_NH;
static const double kUsed_BetaBar = 1.;
static const double kUsed_SinsqTheta12 = kGlobFitSinsqTheta12;
static const double kUsed_SinsqTheta13 = kGlobFitSinsqTheta13;
static const double kUsed_SinsqTheta23 = kT2KReacMostProbSinsqTheta23_Mach3_NH;
static const double kUsed_Sinsq2Theta12 = kGlobFitSinsq2Theta12;
static const double kUsed_Sinsq2Theta13 = kGlobFitSinsq2Theta13;
static const double kUsed_Sinsq2Theta23 = kT2KReacMostProbSinsq2Theta23_Mach3_NH;
static const double kMaxAllowedWght = 2E+3;
static const double kSetNegEventsTo = 1E-8;
static const double kASmallNum = 1E-10;
static const double kAVerySmallNum = 1E-15;
static const double kALargeNum = 999999999.;
static const int kBadResult = -999;
static const double kOneMeV = 0.001;
static const double kBaselineT2K = 295;
static const double kBeamDir[3] = {0.669764, -0.742179, 0.024223};
static const double kOscDimensFactor= 1.26693281;
static const double kCrustDensityT2K= 2.6;
static const double kpi = 3.141592653589793;
static const double khbar_SI = 6.582119e-16;
static const double kc_SI = 2.9979246e10;
static const double khbarc_SI = khbar_SI*kc_SI;
static const double khbarc3_SI = khbarc_SI*khbarc_SI*khbarc_SI;
static const double kGF = 1.16637e-5;
static const double kGF_SI = kGF*khbarc3_SI*1.0e-18;
static const double kNA = 6.022142e23;
static const double kElectronMassGeV = 0.511 / 1000.;
static const double kMuonMassGeV = 105.658 / 1000.;
static const double kNeutronMassGeV = 939.565 / 1000.;
static const double kProtonMassGeV = 938.272 / 1000.;
}
}
#endif
#ifndef conf_level_h
#define conf_level_h
namespace valor {
namespace conv {
typedef enum EConfLevel {
kCLUndefined = -1,
kCL68,
kCL90,
kCL95,
kCL99
}
ConfLevel_t;
}
namespace util {
}
}
#endif
#ifndef physics_hypotheses_h
#define physics_hypotheses_h
namespace valor {
namespace conv {
typedef enum EPhysHypothesis
{
kHypUndefined = -1,
kHypDecay,
kHypDecoh,
kHypNuMuDisapp2F,
kHypOsc3F,
kHypOsc3FBar,
kHypOsc3FBarDissap,
kHypOsc3FBarNormBar,
kHypOsc3FNormBar,
kHypOscSterile4F,
kHypOscSterile5F,
kHypOscSterileEff,
kHypNSI3F,
kHypVoid
}
PhysHypothesis_t;
}
namespace util {
string AsString (conv::PhysHypothesis_t h);
string PhysHypAsString (conv::PhysHypothesis_t h);
string AsString (conv::PhysHypothesis_t hyp, double mix12, double mix13, double mix23, double deltacp, double dm12sq, double dm23sq);
string AsString (conv::PhysHypothesis_t hyp, double mix12, double mix13, double mix23, double deltacp,
double dm12sq, double dm23sq, double betabar, double mix23bar, double dm23sqbar);
conv::PhysHypothesis_t PhysHypFromString (string h);
}
}
#endif
#ifndef _phys_param_id_h_
#define _phys_param_id_h_
namespace valor {
namespace conv {
typedef enum EPhysParamId
{
kPhypUndefined = -1,
kPhypMixing23,
kPhypMixing13,
kPhypMixing12,
kPhypCPV,
kPhypDm23sq,
kPhypDm12sq,
kPhypMixing23Bar,
kPhypMixing13Bar,
kPhypMixing12Bar,
kPhypCPVBar,
kPhypDm23sqBar,
kPhypDm12sqBar,
kPhypBetaBar,
kPhypAlphaDecay,
kPhypSinsq2ThetaDecay,
kPhypMusqDecoh,
kPhypSinsq2ThetaDecoh,
kPhypMixing14,
kPhypMixing15,
kPhypMixing24,
kPhypMixing25,
kPhypMixing34,
kPhypMixing35,
kPhypDm41sq,
kPhypDm51sq,
kPhypDelta12,
kPhypDelta13,
kPhypDelta15,
kPhypDelta34,
kPhypDelta35,
kPhypNSIepsMuTau,
kPhypMixingEE,
kPhypMixingMuMu,
kNuis000 ,
kNuis001 ,
kNuis002 ,
kNuis003 ,
kNuis004 ,
kNuis005 ,
kNuis006 ,
kNuis007 ,
kNuis008 ,
kNuis009 ,
kNuis010 ,
kNuis011 ,
kNuis012 ,
kNuis013 ,
kNuis014 ,
kNuis015 ,
kNuis016 ,
kNuis017 ,
kNuis018 ,
kNuis019 ,
kNuis020 ,
kNuis021 ,
kNuis022 ,
kNuis023 ,
kNuis024 ,
kNuis025 ,
kNuis026 ,
kNuis027 ,
kNuis028 ,
kNuis029 ,
kNuis030 ,
kNuis031 ,
kNuis032 ,
kNuis033 ,
kNuis034 ,
kNuis035 ,
kNuis036 ,
kNuis037 ,
kNuis038 ,
kNuis039 ,
kNuis040 ,
kNuis041 ,
kNuis042 ,
kNuis043 ,
kNuis044 ,
kNuis045 ,
kNuis046 ,
kNuis047 ,
kNuis048 ,
kNuis049 ,
kNuis050 ,
kNuis051 ,
kNuis052 ,
kNuis053 ,
kNuis054 ,
kNuis055 ,
kNuis056 ,
kNuis057 ,
kNuis058 ,
kNuis059 ,
kNuis060 ,
kNuis061 ,
kNuis062 ,
kNuis063 ,
kNuis064 ,
kNuis065 ,
kNuis066 ,
kNuis067 ,
kNuis068 ,
kNuis069 ,
kNuis070 ,
kNuis071 ,
kNuis072 ,
kNuis073 ,
kNuis074 ,
kNuis075 ,
kNuis076 ,
kNuis077 ,
kNuis078 ,
kNuis079 ,
kNuis080 ,
kNuis081 ,
kNuis082 ,
kNuis083 ,
kNuis084 ,
kNuis085 ,
kNuis086 ,
kNuis087 ,
kNuis088 ,
kNuis089 ,
kNuis090 ,
kNuis091 ,
kNuis092 ,
kNuis093 ,
kNuis094 ,
kNuis095 ,
kNuis096 ,
kNuis097 ,
kNuis098 ,
kNuis099 ,
kNuis100 ,
kNuis101 ,
kNuis102 ,
kNuis103 ,
kNuis104 ,
kNuis105 ,
kNuis106 ,
kNuis107 ,
kNuis108 ,
kNuis109 ,
kNuis110 ,
kNuis111 ,
kNuis112 ,
kNuis113 ,
kNuis114 ,
kNuis115 ,
kNuis116 ,
kNuis117 ,
kNuis118 ,
kNuis119 ,
kNuis120 ,
kNuis121 ,
kNuis122 ,
kNuis123 ,
kNuis124 ,
kNuis125 ,
kNuis126 ,
kNuis127 ,
kNuis128 ,
kNuis129 ,
kNuis130 ,
kNuis131 ,
kNuis132 ,
kNuis133 ,
kNuis134 ,
kNuis135 ,
kNuis136 ,
kNuis137 ,
kNuis138 ,
kNuis139 ,
kNuis140 ,
kNuis141 ,
kNuis142 ,
kNuis143 ,
kNuis144 ,
kNuis145 ,
kNuis146 ,
kNuis147 ,
kNuis148 ,
kNuis149 ,
kNuis150 ,
kNuis151 ,
kNuis152 ,
kNuis153 ,
kNuis154 ,
kNuis155 ,
kNuis156 ,
kNuis157 ,
kNuis158 ,
kNuis159 ,
kNuis160 ,
kNuis161 ,
kNuis162 ,
kNuis163 ,
kNuis164 ,
kNuis165 ,
kNuis166 ,
kNuis167 ,
kNuis168 ,
kNuis169 ,
kNuis170 ,
kNuis171 ,
kNuis172 ,
kNuis173 ,
kNuis174 ,
kNuis175 ,
kNuis176 ,
kNuis177 ,
kNuis178 ,
kNuis179 ,
kNuis180 ,
kNuis181 ,
kNuis182 ,
kNuis183 ,
kNuis184 ,
kNuis185 ,
kNuis186 ,
kNuis187 ,
kNuis188 ,
kNuis189 ,
kNuis190 ,
kNuis191 ,
kNuis192 ,
kNuis193 ,
kNuis194 ,
kNuis195 ,
kNuis196 ,
kNuis197 ,
kNuis198 ,
kNuis199 ,
kNuis200 ,
kNuis201 ,
kNuis202 ,
kNuis203 ,
kNuis204 ,
kNuis205 ,
kNuis206 ,
kNuis207 ,
kNuis208 ,
kNuis209 ,
kNuis210 ,
kNuis211 ,
kNuis212 ,
kNuis213 ,
kNuis214 ,
kNuis215 ,
kNuis216 ,
kNuis217 ,
kNuis218 ,
kNuis219 ,
kNuis220 ,
kNuis221 ,
kNuis222 ,
kNuis223 ,
kNuis224 ,
kNuis225 ,
kNuis226 ,
kNuis227 ,
kNuis228 ,
kNuis229 ,
kNuis230 ,
kNuis231 ,
kNuis232 ,
kNuis233 ,
kNuis234 ,
kNuis235 ,
kNuis236 ,
kNuis237 ,
kNuis238 ,
kNuis239 ,
kNuis240 ,
kNuis241 ,
kNuis242 ,
kNuis243 ,
kNuis244 ,
kNuis245 ,
kNuis246 ,
kNuis247 ,
kNuis248 ,
kNuis249 ,
kNuis250 ,
kNuis251 ,
kNuis252 ,
kNuis253 ,
kNuis254 ,
kNuis255 ,
kNuis256 ,
kNuis257 ,
kNuis258 ,
kNuis259 ,
kNuis260 ,
kNuis261 ,
kNuis262 ,
kNuis263 ,
kNuis264 ,
kNuis265 ,
kNuis266 ,
kNuis267 ,
kNuis268 ,
kNuis269 ,
kNuis270 ,
kNuis271 ,
kNuis272 ,
kNuis273 ,
kNuis274 ,
kNuis275 ,
kNuis276 ,
kNuis277 ,
kNuis278 ,
kNuis279 ,
kNuis280 ,
kNuis281 ,
kNuis282 ,
kNuis283 ,
kNuis284 ,
kNuis285 ,
kNuis286 ,
kNuis287 ,
kNuis288 ,
kNuis289 ,
kNuis290 ,
kNuis291 ,
kNuis292 ,
kNuis293 ,
kNuis294 ,
kNuis295 ,
kNuis296 ,
kNuis297 ,
kNuis298 ,
kNuis299 ,
kNuis300 ,
kNuis301 ,
kNuis302 ,
kNuis303 ,
kNuis304 ,
kNuis305 ,
kNuis306 ,
kNuis307 ,
kNuis308 ,
kNuis309 ,
kNuis310 ,
kNuis311 ,
kNuis312 ,
kNuis313 ,
kNuis314 ,
kNuis315 ,
kNuis316 ,
kNuis317 ,
kNuis318 ,
kNuis319 ,
kNuis320 ,
kNuis321 ,
kNuis322 ,
kNuis323 ,
kNuis324 ,
kNuis325 ,
kNuis326 ,
kNuis327 ,
kNuis328 ,
kNuis329 ,
kNuis330 ,
kNuis331 ,
kNuis332 ,
kNuis333 ,
kNuis334 ,
kNuis335 ,
kNuis336 ,
kNuis337 ,
kNuis338 ,
kNuis339 ,
kNuis340 ,
kNuis341 ,
kNuis342 ,
kNuis343 ,
kNuis344 ,
kNuis345 ,
kNuis346 ,
kNuis347 ,
kNuis348 ,
kNuis349 ,
kNuis350 ,
kNuis351 ,
kNuis352 ,
kNuis353 ,
kNuis354 ,
kNuis355 ,
kNuis356 ,
kNuis357 ,
kNuis358 ,
kNuis359 ,
kNuis360 ,
kNuis361 ,
kNuis362 ,
kNuis363 ,
kNuis364 ,
kNuis365 ,
kNuis366 ,
kNuis367 ,
kNuis368 ,
kNuis369 ,
kNuis370 ,
kNuis371 ,
kNuis372 ,
kNuis373 ,
kNuis374 ,
kNuis375 ,
kNuis376 ,
kNuis377 ,
kNuis378 ,
kNuis379 ,
kNuis380 ,
kNuis381 ,
kNuis382 ,
kNuis383 ,
kNuis384 ,
kNuis385 ,
kNuis386 ,
kNuis387 ,
kNuis388 ,
kNuis389 ,
kNuis390 ,
kNuis391 ,
kNuis392 ,
kNuis393 ,
kNuis394 ,
kNuis395 ,
kNuis396 ,
kNuis397 ,
kNuis398 ,
kNuis399 ,
kNuis400 ,
kNuis401 ,
kNuis402 ,
kNuis403 ,
kNuis404 ,
kNuis405 ,
kNuis406 ,
kNuis407 ,
kNuis408 ,
kNuis409 ,
kNuis410 ,
kNuis411 ,
kNuis412 ,
kNuis413 ,
kNuis414 ,
kNuis415 ,
kNuis416 ,
kNuis417 ,
kNuis418 ,
kNuis419 ,
kNuis420 ,
kNuis421 ,
kNuis422 ,
kNuis423 ,
kNuis424 ,
kNuis425 ,
kNuis426 ,
kNuis427 ,
kNuis428 ,
kNuis429 ,
kNuis430 ,
kNuis431 ,
kNuis432 ,
kNuis433 ,
kNuis434 ,
kNuis435 ,
kNuis436 ,
kNuis437 ,
kNuis438 ,
kNuis439 ,
kNuis440 ,
kNuis441 ,
kNuis442 ,
kNuis443 ,
kNuis444 ,
kNuis445 ,
kNuis446 ,
kNuis447 ,
kNuis448 ,
kNuis449 ,
kNuis450 ,
kNuis451 ,
kNuis452 ,
kNuis453 ,
kNuis454 ,
kNuis455 ,
kNuis456 ,
kNuis457 ,
kNuis458 ,
kNuis459 ,
kNuis460 ,
kNuis461 ,
kNuis462 ,
kNuis463 ,
kNuis464 ,
kNuis465 ,
kNuis466 ,
kNuis467 ,
kNuis468 ,
kNuis469 ,
kNuis470 ,
kNuis471 ,
kNuis472 ,
kNuis473 ,
kNuis474 ,
kNuis475 ,
kNuis476 ,
kNuis477 ,
kNuis478 ,
kNuis479 ,
kNuis480 ,
kNuis481 ,
kNuis482 ,
kNuis483 ,
kNuis484 ,
kNuis485 ,
kNuis486 ,
kNuis487 ,
kNuis488 ,
kNuis489 ,
kNuis490 ,
kNuis491 ,
kNuis492 ,
kNuis493 ,
kNuis494 ,
kNuis495 ,
kNuis496 ,
kNuis497 ,
kNuis498 ,
kNuis499 ,
kNuis500 ,
kNuis501 ,
kNuis502 ,
kNuis503 ,
kNuis504 ,
kNuis505 ,
kNuis506 ,
kNuis507 ,
kNuis508 ,
kNuis509 ,
kNuis510 ,
kNuis511 ,
kNuis512 ,
kNuis513 ,
kNuis514 ,
kNuis515 ,
kNuis516 ,
kNuis517 ,
kNuis518 ,
kNuis519 ,
kNuis520 ,
kNuis521 ,
kNuis522 ,
kNuis523 ,
kNuis524 ,
kNuis525 ,
kNuis526 ,
kNuis527 ,
kNuis528 ,
kNuis529 ,
kNuis530 ,
kNuis531 ,
kNuis532 ,
kNuis533 ,
kNuis534 ,
kNuis535 ,
kNuis536 ,
kNuis537 ,
kNuis538 ,
kNuis539 ,
kNuis540 ,
kNuis541 ,
kNuis542 ,
kNuis543 ,
kNuis544 ,
kNuis545 ,
kNuis546 ,
kNuis547 ,
kNuis548 ,
kNuis549 ,
kNuis550 ,
kNuis551 ,
kNuis552 ,
kNuis553 ,
kNuis554 ,
kNuis555 ,
kNuis556 ,
kNuis557 ,
kNuis558 ,
kNuis559 ,
kNuis560 ,
kNuis561 ,
kNuis562 ,
kNuis563 ,
kNuis564 ,
kNuis565 ,
kNuis566 ,
kNuis567 ,
kNuis568 ,
kNuis569 ,
kNuis570 ,
kNuis571 ,
kNuis572 ,
kNuis573 ,
kNuis574 ,
kNuis575 ,
kNuis576 ,
kNuis577 ,
kNuis578 ,
kNuis579 ,
kNuis580 ,
kNuis581 ,
kNuis582 ,
kNuis583 ,
kNuis584 ,
kNuis585 ,
kNuis586 ,
kNuis587 ,
kNuis588 ,
kNuis589 ,
kNuis590 ,
kNuis591 ,
kNuis592 ,
kNuis593 ,
kNuis594 ,
kNuis595 ,
kNuis596 ,
kNuis597 ,
kNuis598 ,
kNuis599 ,
kNuis600 ,
kNuis601 ,
kNuis602 ,
kNuis603 ,
kNuis604 ,
kNuis605 ,
kNuis606 ,
kNuis607 ,
kNuis608 ,
kNuis609 ,
kNuis610 ,
kNuis611 ,
kNuis612 ,
kNuis613 ,
kNuis614 ,
kNuis615 ,
kNuis616 ,
kNuis617 ,
kNuis618 ,
kNuis619 ,
kNuis620 ,
kNuis621 ,
kNuis622 ,
kNuis623 ,
kNuis624 ,
kNuis625 ,
kNuis626 ,
kNuis627 ,
kNuis628 ,
kNuis629 ,
kNuis630 ,
kNuis631 ,
kNuis632 ,
kNuis633 ,
kNuis634 ,
kNuis635 ,
kNuis636 ,
kNuis637 ,
kNuis638 ,
kNuis639 ,
kNuis640 ,
kNuis641 ,
kNuis642 ,
kNuis643 ,
kNuis644 ,
kNuis645 ,
kNuis646 ,
kNuis647 ,
kNuis648 ,
kNuis649 ,
kNuis650 ,
kNuis651 ,
kNuis652 ,
kNuis653 ,
kNuis654 ,
kNuis655 ,
kNuis656 ,
kNuis657 ,
kNuis658 ,
kNuis659 ,
kNuis660 ,
kNuis661 ,
kNuis662 ,
kNuis663 ,
kNuis664 ,
kNuis665 ,
kNuis666 ,
kNuis667 ,
kNuis668 ,
kNuis669 ,
kNuis670 ,
kNuis671 ,
kNuis672 ,
kNuis673 ,
kNuis674 ,
kNuis675 ,
kNuis676 ,
kNuis677 ,
kNuis678 ,
kNuis679 ,
kNuis680 ,
kNuis681 ,
kNuis682 ,
kNuis683 ,
kNuis684 ,
kNuis685 ,
kNuis686 ,
kNuis687 ,
kNuis688 ,
kNuis689 ,
kNuis690 ,
kNuis691 ,
kNuis692 ,
kNuis693 ,
kNuis694 ,
kNuis695 ,
kNuis696 ,
kNuis697 ,
kNuis698 ,
kNuis699 ,
kNuis700 ,
kNuis701 ,
kNuis702 ,
kNuis703 ,
kNuis704 ,
kNuis705 ,
kNuis706 ,
kNuis707 ,
kNuis708 ,
kNuis709 ,
kNuis710 ,
kNuis711 ,
kNuis712 ,
kNuis713 ,
kNuis714 ,
kNuis715 ,
kNuis716 ,
kNuis717 ,
kNuis718 ,
kNuis719 ,
kNuis720 ,
kNuis721 ,
kNuis722 ,
kNuis723 ,
kNuis724 ,
kNuis725 ,
kNuis726 ,
kNuis727 ,
kNuis728 ,
kNuis729 ,
kNuis730 ,
kNuis731 ,
kNuis732 ,
kNuis733 ,
kNuis734 ,
kNuis735 ,
kNuis736 ,
kNuis737 ,
kNuis738 ,
kNuis739 ,
kNuis740 ,
kNuis741 ,
kNuis742 ,
kNuis743 ,
kNuis744 ,
kNuis745 ,
kNuis746 ,
kNuis747 ,
kNuis748 ,
kNuis749 ,
kNuis750 ,
kNuis751 ,
kNuis752 ,
kNuis753 ,
kNuis754 ,
kNuis755 ,
kNuis756 ,
kNuis757 ,
kNuis758 ,
kNuis759 ,
kNuis760 ,
kNuis761 ,
kNuis762 ,
kNuis763 ,
kNuis764 ,
kNuis765 ,
kNuis766 ,
kNuis767 ,
kNuis768 ,
kNuis769 ,
kNuis770 ,
kNuis771 ,
kNuis772 ,
kNuis773 ,
kNuis774 ,
kNuis775 ,
kNuis776 ,
kNuis777 ,
kNuis778 ,
kNuis779 ,
kNuis780 ,
kNuis781 ,
kNuis782 ,
kNuis783 ,
kNuis784 ,
kNuis785 ,
kNuis786 ,
kNuis787 ,
kNuis788 ,
kNuis789 ,
kNuis790 ,
kNuis791 ,
kNuis792 ,
kNuis793 ,
kNuis794 ,
kNuis795 ,
kNuis796 ,
kNuis797 ,
kNuis798 ,
kNuis799 ,
kNuis800 ,
kNuis801 ,
kNuis802 ,
kNuis803 ,
kNuis804 ,
kNuis805 ,
kNuis806 ,
kNuis807 ,
kNuis808 ,
kNuis809 ,
kNuis810 ,
kNuis811 ,
kNuis812 ,
kNuis813 ,
kNuis814 ,
kNuis815 ,
kNuis816 ,
kNuis817 ,
kNuis818 ,
kNuis819 ,
kNuis820 ,
kNuis821 ,
kNuis822 ,
kNuis823 ,
kNuis824 ,
kNuis825 ,
kNuis826 ,
kNuis827 ,
kNuis828 ,
kNuis829 ,
kNuis830 ,
kNuis831 ,
kNuis832 ,
kNuis833 ,
kNuis834 ,
kNuis835 ,
kNuis836 ,
kNuis837 ,
kNuis838 ,
kNuis839 ,
kNuis840 ,
kNuis841 ,
kNuis842 ,
kNuis843 ,
kNuis844 ,
kNuis845 ,
kNuis846 ,
kNuis847 ,
kNuis848 ,
kNuis849 ,
kNuis850 ,
kNuis851 ,
kNuis852 ,
kNuis853 ,
kNuis854 ,
kNuis855 ,
kNuis856 ,
kNuis857 ,
kNuis858 ,
kNuis859 ,
kNuis860 ,
kNuis861 ,
kNuis862 ,
kNuis863 ,
kNuis864 ,
kNuis865 ,
kNuis866 ,
kNuis867 ,
kNuis868 ,
kNuis869 ,
kNuis870 ,
kNuis871 ,
kNuis872 ,
kNuis873 ,
kNuis874 ,
kNuis875 ,
kNuis876 ,
kNuis877 ,
kNuis878 ,
kNuis879 ,
kNuis880 ,
kNuis881 ,
kNuis882 ,
kNuis883 ,
kNuis884 ,
kNuis885 ,
kNuis886 ,
kNuis887 ,
kNuis888 ,
kNuis889 ,
kNuis890 ,
kNuis891 ,
kNuis892 ,
kNuis893 ,
kNuis894 ,
kNuis895 ,
kNuis896 ,
kNuis897 ,
kNuis898 ,
kNuis899 ,
kNuis900 ,
kNuis901 ,
kNuis902 ,
kNuis903 ,
kNuis904 ,
kNuis905 ,
kNuis906 ,
kNuis907 ,
kNuis908 ,
kNuis909 ,
kNuis910 ,
kNuis911 ,
kNuis912 ,
kNuis913 ,
kNuis914 ,
kNuis915 ,
kNuis916 ,
kNuis917 ,
kNuis918 ,
kNuis919 ,
kNuis920 ,
kNuis921 ,
kNuis922 ,
kNuis923 ,
kNuis924 ,
kNuis925 ,
kNuis926 ,
kNuis927 ,
kNuis928 ,
kNuis929 ,
kNuis930 ,
kNuis931 ,
kNuis932 ,
kNuis933 ,
kNuis934 ,
kNuis935 ,
kNuis936 ,
kNuis937 ,
kNuis938 ,
kNuis939 ,
kNuis940 ,
kNuis941 ,
kNuis942 ,
kNuis943 ,
kNuis944 ,
kNuis945 ,
kNuis946 ,
kNuis947 ,
kNuis948 ,
kNuis949 ,
kNuis950 ,
kNuis951 ,
kNuis952 ,
kNuis953 ,
kNuis954 ,
kNuis955 ,
kNuis956 ,
kNuis957 ,
kNuis958 ,
kNuis959 ,
kNuis960 ,
kNuis961 ,
kNuis962 ,
kNuis963 ,
kNuis964 ,
kNuis965 ,
kNuis966 ,
kNuis967 ,
kNuis968 ,
kNuis969 ,
kNuis970 ,
kNuis971 ,
kNuis972 ,
kNuis973 ,
kNuis974 ,
kNuis975 ,
kNuis976 ,
kNuis977 ,
kNuis978 ,
kNuis979 ,
kNuis980 ,
kNuis981 ,
kNuis982 ,
kNuis983 ,
kNuis984 ,
kNuis985 ,
kNuis986 ,
kNuis987 ,
kNuis988 ,
kNuis989 ,
kNuis990 ,
kNuis991 ,
kNuis992 ,
kNuis993 ,
kNuis994 ,
kNuis995 ,
kNuis996 ,
kNuis997 ,
kNuis998 ,
kNuis999 ,
kNuis1000 ,
kNuis1001 ,
kNuis1002 ,
kNuis1003 ,
kNuis1004 ,
kNuis1005 ,
kNuis1006 ,
kNuis1007 ,
kNuis1008 ,
kNuis1009 ,
kNuis1010 ,
kNuis1011 ,
kNuis1012 ,
kNuis1013 ,
kNuis1014 ,
kNuis1015 ,
kNuis1016 ,
kNuis1017 ,
kNuis1018 ,
kNuis1019 ,
kNuis1020 ,
kNuis1021 ,
kNuis1022 ,
kNuis1023 ,
kNuis1024 ,
kNuis1025 ,
kNuis1026 ,
kNuis1027 ,
kNuis1028 ,
kNuis1029 ,
kNuis1030 ,
kNuis1031 ,
kNuis1032 ,
kNuis1033 ,
kNuis1034 ,
kNuis1035 ,
kNuis1036 ,
kNuis1037 ,
kNuis1038 ,
kNuis1039 ,
kNuis1040 ,
kNuis1041 ,
kNuis1042 ,
kNuis1043 ,
kNuis1044 ,
kNuis1045 ,
kNuis1046 ,
kNuis1047 ,
kNuis1048 ,
kNuis1049 ,
kNuis1050 ,
kNuis1051 ,
kNuis1052 ,
kNuis1053 ,
kNuis1054 ,
kNuis1055 ,
kNuis1056 ,
kNuis1057 ,
kNuis1058 ,
kNuis1059 ,
kNuis1060 ,
kNuis1061 ,
kNuis1062 ,
kNuis1063 ,
kNuis1064 ,
kNuis1065 ,
kNuis1066 ,
kNuis1067 ,
kNuis1068 ,
kNuis1069 ,
kNuis1070 ,
kNuis1071 ,
kNuis1072 ,
kNuis1073 ,
kNuis1074 ,
kNuis1075 ,
kNuis1076 ,
kNuis1077 ,
kNuis1078 ,
kNuis1079 ,
kNuis1080 ,
kNuis1081 ,
kNuis1082 ,
kNuis1083 ,
kNuis1084 ,
kNuis1085 ,
kNuis1086 ,
kNuis1087 ,
kNuis1088 ,
kNuis1089 ,
kNuis1090 ,
kNuis1091 ,
kNuis1092 ,
kNuis1093 ,
kNuis1094 ,
kNuis1095 ,
kNuis1096 ,
kNuis1097 ,
kNuis1098 ,
kNuis1099 ,
kNuis1100 ,
kNuis1101 ,
kNuis1102 ,
kNuis1103 ,
kNuis1104 ,
kNuis1105 ,
kNuis1106 ,
kNuis1107 ,
kNuis1108 ,
kNuis1109 ,
kNuis1110 ,
kNuis1111 ,
kNuis1112 ,
kNuis1113 ,
kNuis1114 ,
kNuis1115 ,
kNuis1116 ,
kNuis1117 ,
kNuis1118 ,
kNuis1119 ,
kNuis1120 ,
kNuis1121 ,
kNuis1122 ,
kNuis1123 ,
kNuis1124 ,
kNuis1125 ,
kNuis1126 ,
kNuis1127 ,
kNuis1128 ,
kNuis1129 ,
kNuis1130 ,
kNuis1131 ,
kNuis1132 ,
kNuis1133 ,
kNuis1134 ,
kNuis1135 ,
kNuis1136 ,
kNuis1137 ,
kNuis1138 ,
kNuis1139 ,
kNuis1140 ,
kNuis1141 ,
kNuis1142 ,
kNuis1143 ,
kNuis1144 ,
kNuis1145 ,
kNuis1146 ,
kNuis1147 ,
kNuis1148 ,
kNuis1149 ,
kNuis1150 ,
kNuis1151 ,
kNuis1152 ,
kNuis1153 ,
kNuis1154 ,
kNuis1155 ,
kNuis1156 ,
kNuis1157 ,
kNuis1158 ,
kNuis1159 ,
kNuis1160 ,
kNuis1161 ,
kNuis1162 ,
kNuis1163 ,
kNuis1164 ,
kNuis1165 ,
kNuis1166 ,
kNuis1167 ,
kNuis1168 ,
kNuis1169 ,
kNuis1170 ,
kNuis1171 ,
kNuis1172 ,
kNuis1173 ,
kNuis1174 ,
kNuis1175 ,
kNuis1176 ,
kNuis1177 ,
kNuis1178 ,
kNuis1179 ,
kNuis1180 ,
kNuis1181 ,
kNuis1182 ,
kNuis1183 ,
kNuis1184 ,
kNuis1185 ,
kNuis1186 ,
kNuis1187 ,
kNuis1188 ,
kNuis1189 ,
kNuis1190 ,
kNuis1191 ,
kNuis1192 ,
kNuis1193 ,
kNuis1194 ,
kNuis1195 ,
kNuis1196 ,
kNuis1197 ,
kNuis1198 ,
kNuis1199 ,
kNuis1200 ,
kNuis1201 ,
kNuis1202 ,
kNuis1203 ,
kNuis1204 ,
kNuis1205 ,
kNuis1206 ,
kNuis1207 ,
kNuis1208 ,
kNuis1209 ,
kNuis1210 ,
kNuis1211 ,
kNuis1212 ,
kNuis1213 ,
kNuis1214 ,
kNuis1215 ,
kNuis1216 ,
kNuis1217 ,
kNuis1218 ,
kNuis1219 ,
kNuis1220 ,
kNuis1221 ,
kNuis1222 ,
kNuis1223 ,
kNuis1224 ,
kNuis1225 ,
kNuis1226 ,
kNuis1227 ,
kNuis1228 ,
kNuis1229 ,
kNuis1230 ,
kNuis1231 ,
kNuis1232 ,
kNuis1233 ,
kNuis1234 ,
kNuis1235 ,
kNuis1236 ,
kNuis1237 ,
kNuis1238 ,
kNuis1239 ,
kNuis1240 ,
kNuis1241 ,
kNuis1242 ,
kNuis1243 ,
kNuis1244 ,
kNuis1245 ,
kNuis1246 ,
kNuis1247 ,
kNuis1248 ,
kNuis1249 ,
kNuis1250 ,
kNuis1251 ,
kNuis1252 ,
kNuis1253 ,
kNuis1254 ,
kNuis1255 ,
kNuis1256 ,
kNuis1257 ,
kNuis1258 ,
kNuis1259 ,
kNuis1260 ,
kNuis1261 ,
kNuis1262 ,
kNuis1263 ,
kNuis1264 ,
kNuis1265 ,
kNuis1266 ,
kNuis1267 ,
kNuis1268 ,
kNuis1269 ,
kNuis1270 ,
kNuis1271 ,
kNuis1272 ,
kNuis1273 ,
kNuis1274 ,
kNuis1275 ,
kNuis1276 ,
kNuis1277 ,
kNuis1278 ,
kNuis1279 ,
kNuis1280 ,
kNuis1281 ,
kNuis1282 ,
kNuis1283 ,
kNuis1284 ,
kNuis1285 ,
kNuis1286 ,
kNuis1287 ,
kNuis1288 ,
kNuis1289 ,
kNuis1290 ,
kNuis1291 ,
kNuis1292 ,
kNuis1293 ,
kNuis1294 ,
kNuis1295 ,
kNuis1296 ,
kNuis1297 ,
kNuis1298 ,
kNuis1299 ,
kNuis1300 ,
kNuis1301 ,
kNuis1302 ,
kNuis1303 ,
kNuis1304 ,
kNuis1305 ,
kNuis1306 ,
kNuis1307 ,
kNuis1308 ,
kNuis1309 ,
kNuis1310 ,
kNuis1311 ,
kNuis1312 ,
kNuis1313 ,
kNuis1314 ,
kNuis1315 ,
kNuis1316 ,
kNuis1317 ,
kNuis1318 ,
kNuis1319 ,
kNuis1320 ,
kNuis1321 ,
kNuis1322 ,
kNuis1323 ,
kNuis1324 ,
kNuis1325 ,
kNuis1326 ,
kNuis1327 ,
kNuis1328 ,
kNuis1329 ,
kNuis1330 ,
kNuis1331 ,
kNuis1332 ,
kNuis1333 ,
kNuis1334 ,
kNuis1335 ,
kNuis1336 ,
kNuis1337 ,
kNuis1338 ,
kNuis1339 ,
kNuis1340 ,
kNuis1341 ,
kNuis1342 ,
kNuis1343 ,
kNuis1344 ,
kNuis1345 ,
kNuis1346 ,
kNuis1347 ,
kNuis1348 ,
kNuis1349 ,
kNuis1350 ,
kNuis1351 ,
kNuis1352 ,
kNuis1353 ,
kNuis1354 ,
kNuis1355 ,
kNuis1356 ,
kNuis1357 ,
kNuis1358 ,
kNuis1359 ,
kNuis1360 ,
kNuis1361 ,
kNuis1362 ,
kNuis1363 ,
kNuis1364 ,
kNuis1365 ,
kNuis1366 ,
kNuis1367 ,
kNuis1368 ,
kNuis1369 ,
kNuis1370 ,
kNuis1371 ,
kNuis1372 ,
kNuis1373 ,
kNuis1374 ,
kNuis1375 ,
kNuis1376 ,
kNuis1377 ,
kNuis1378 ,
kNuis1379 ,
kNuis1380 ,
kNuis1381 ,
kNuis1382 ,
kNuis1383 ,
kNuis1384 ,
kNuis1385 ,
kNuis1386 ,
kNuis1387 ,
kNuis1388 ,
kNuis1389 ,
kNuis1390 ,
kNuis1391 ,
kNuis1392 ,
kNuis1393 ,
kNuis1394 ,
kNuis1395 ,
kNuis1396 ,
kNuis1397 ,
kNuis1398 ,
kNuis1399 ,
kNuis1400 ,
kNuis1401 ,
kNuis1402 ,
kNuis1403 ,
kNuis1404 ,
kNuis1405 ,
kNuis1406 ,
kNuis1407 ,
kNuis1408 ,
kNuis1409 ,
kNuis1410 ,
kNuis1411 ,
kNuis1412 ,
kNuis1413 ,
kNuis1414 ,
kNuis1415 ,
kNuis1416 ,
kNuis1417 ,
kNuis1418 ,
kNuis1419 ,
kNuis1420 ,
kNuis1421 ,
kNuis1422 ,
kNuis1423 ,
kNuis1424 ,
kNuis1425 ,
kNuis1426 ,
kNuis1427 ,
kNuis1428 ,
kNuis1429 ,
kNuis1430 ,
kNuis1431 ,
kNuis1432 ,
kNuis1433 ,
kNuis1434 ,
kNuis1435 ,
kNuis1436 ,
kNuis1437 ,
kNuis1438 ,
kNuis1439 ,
kNuis1440 ,
kNuis1441 ,
kNuis1442 ,
kNuis1443 ,
kNuis1444 ,
kNuis1445 ,
kNuis1446 ,
kNuis1447 ,
kNuis1448 ,
kNuis1449 ,
kNuis1450 ,
kNuis1451 ,
kNuis1452 ,
kNuis1453 ,
kNuis1454 ,
kNuis1455 ,
kNuis1456 ,
kNuis1457 ,
kNuis1458 ,
kNuis1459 ,
kNuis1460 ,
kNuis1461 ,
kNuis1462 ,
kNuis1463 ,
kNuis1464 ,
kNuis1465 ,
kNuis1466 ,
kNuis1467 ,
kNuis1468 ,
kNuis1469 ,
kNuis1470 ,
kNuis1471 ,
kNuis1472 ,
kNuis1473 ,
kNuis1474 ,
kNuis1475 ,
kNuis1476 ,
kNuis1477 ,
kNuis1478 ,
kNuis1479 ,
kNuis1480 ,
kNuis1481 ,
kNuis1482 ,
kNuis1483 ,
kNuis1484 ,
kNuis1485 ,
kNuis1486 ,
kNuis1487 ,
kNuis1488 ,
kNuis1489 ,
kNuis1490 ,
kNuis1491 ,
kNuis1492 ,
kNuis1493 ,
kNuis1494 ,
kNuis1495 ,
kNuis1496 ,
kNuis1497 ,
kNuis1498 ,
kNuis1499 ,
kLastNuisParam
}
PhysParamId_t;
static const int knppmax = kLastNuisParam;
}
namespace util {
string RawParamAsStringRaw (conv::PhysParamId_t p);
string RawParamAsString (conv::PhysParamId_t p);
string RawParamAsStringTex (conv::PhysParamId_t p);
string RawParamAsStringRooTex (conv::PhysParamId_t p);
conv::PhysParamId_t PhysParamIdFromRawString(string sh);
bool IsSystematic (conv::PhysParamId_t p);
bool IsMixingAngle (conv::PhysParamId_t p);
bool IsMassSplitting(conv::PhysParamId_t p);
bool IsPhase (conv::PhysParamId_t p);
bool IsNormalization(conv::PhysParamId_t p);
}
}
#endif
#ifndef _valor_fmwk_kine_var_h_
#define _valor_fmwk_kine_var_h_
namespace valor {
namespace conv {
typedef enum EKineVar
{
kvUndefined = -1,
kvEtrue,
kvQ2true,
kvEreco,
kvEvis,
kvYreco,
kvThetareco,
kvq0reco,
kvq3reco,
kvmodqreco
}
KineVar_t;
const int kNKineVarMax = conv::kvmodqreco+1;
}
namespace util {
string AsString (conv::KineVar_t kv);
string AsStringTeX (conv::KineVar_t kv, bool root);
bool IsReco (conv::KineVar_t kv);
bool IsTrue (conv::KineVar_t kv);
}
}
#endif
#ifndef _valor_fmwk_kine_space_h_
#define _valor_fmwk_kine_space_h_
namespace valor {
namespace conv {
static const int kMaxKineSpaces = 11;
typedef enum EKineSpace
{
kspUndefined = -1,
kspEtrue,
kspEreco,
kspEvis,
kspYreco,
kspThetareco,
kspErecoYreco,
kspEtrueQ2true,
kspErecoThetareco,
kspq0recoq3reco,
kspq0recomodqreco,
kspErecoEvis
}
KineSpace_t;
}
namespace util {
std::string AsString (conv::KineSpace_t ks);
std::string AsStringTeX (conv::KineSpace_t ks, bool root);
bool IsPureReco (conv::KineSpace_t ks);
bool IsPureTrue (conv::KineSpace_t ks);
bool IsMixedRecoTrue (conv::KineSpace_t ks);
int NDim (conv::KineSpace_t ks);
int NDimReco (conv::KineSpace_t ks);
int NDimTrue (conv::KineSpace_t ks);
conv::KineSpace_t SubSpaceReco (conv::KineSpace_t ks);
conv::KineSpace_t SubSpaceTrue (conv::KineSpace_t ks);
std::vector<valor::conv::KineVar_t> KineVarSubset(conv::KineSpace_t original,
conv::KineSpace_t target);
std::vector<valor::conv::KineVar_t> KineVar (conv::KineSpace_t ks);
std::vector<valor::conv::KineVar_t> KineVarReco (conv::KineSpace_t ks);
std::vector<valor::conv::KineVar_t> KineVarTrue (conv::KineSpace_t ks);
conv::KineSpace_t KineSpaceFromInt (int is);
conv::KineSpace_t KineSpaceFromString (string s);
string KineSpaceAsString (conv::KineSpace_t ks);
string KineSpaceAsStringTeX (conv::KineSpace_t ks, bool root);
}
}
#endif
#ifndef nuflav_h
#define nuflav_h
namespace valor {
namespace conv {
typedef enum ENuFlavour
{
kNuFlavourUndefined = -1,
kNuE,
kNuMu,
kNuTau,
kNuEBar,
kNuMuBar,
kNuTauBar
}
NuFlavour_t;
static const int kNNuFlavour = 6;
}
namespace util {
std::string AsString(conv::NuFlavour_t p);
std::string FlavourAsString(conv::NuFlavour_t p);
conv::NuFlavour_t FlavourFromString(std::string h);
conv::NuFlavour_t FlavourFromPDG(int nu_pdg);
}
}
#endif
#ifndef nu_mass_hierarchy_h
#define nu_mass_hierarchy_h
namespace valor {
namespace conv {
typedef enum ENuMassHierarchy
{
kNmhUndefined = -1,
kNmhNormal,
kNmhInverted
}
NuMassHierarchy_t;
}
namespace util {
string AsString (conv::NuMassHierarchy_t m);
string HierarchyAsString (conv::NuMassHierarchy_t m);
conv::NuMassHierarchy_t HierarchyFromString (string h);
}
}
#endif
#ifndef cpv_parameter_h
#define cpv_parameter_h
namespace valor {
namespace conv {
typedef enum ENuOscDeltaCP
{
kNuDeltaCPUndefined = -1,
kNuDeltaCPPhase,
kNuDeltaCPSin
}
NuOscDeltaCP_t;
}
namespace util {
string AsString (conv::NuOscDeltaCP_t d);
string CPVChoiceAsString (conv::NuOscDeltaCP_t d);
conv::NuOscDeltaCP_t CPVChoiceFromString (string d);
}
}
#endif
#ifndef nuosc_dmsq_scheme_h
#define nuosc_dmsq_scheme_h
namespace valor {
namespace conv {
typedef enum ENuOscDmsqScheme
{
kNuDmsqUndefined = -1,
kNuDmsq12andAbs23,
kNuDmsqFogliLisi,
kNuDmsq12andAbs31,
kNuDmsqAuto
}
NuOscDmsqScheme_t;
}
namespace util {
string AsString(conv::NuOscDmsqScheme_t dmsqs);
string DmsqSchemeAsString(conv::NuOscDmsqScheme_t dmsqs);
conv::NuOscDmsqScheme_t DmsqSchemeFromString (string h);
conv::NuOscDmsqScheme_t GetAutoDmsqSchemeFromHierarchy(conv::NuMassHierarchy_t hierarchy = conv::kNmhUndefined);
}
}
#endif
#ifndef nuosc_mixing_parameter_h
#define nuosc_mixing_parameter_h
namespace valor {
namespace conv {
typedef enum ENuOscMixParam
{
kNuMixUndefined = -1,
kNuMixSinsq2Theta,
kNuMixSinsqTheta
}
NuOscMixParam_t;
}
namespace util {
string AsString (conv::NuOscMixParam_t o);
string MixingTypeAsString (conv::NuOscMixParam_t o);
conv::NuOscMixParam_t MixingTypeFromString (string h);
}
}
#endif
#ifndef nuosc_octant_h
#define nuosc_octant_h
namespace valor {
namespace conv {
typedef enum ENuOscOctant
{
kNuOctantUndefined = -1,
kNuOctantOne,
kNuOctantTwo
}
NuOscOctant_t;
}
namespace util {
string AsString(conv::NuOscOctant_t p);
string OctantAsString(conv::NuOscOctant_t p);
conv::NuOscOctant_t OctantFromString(string h);
}
}
#endif
#ifndef __valor_opt__
#define __valor_opt__
namespace valor {
class Opt {
public:
class Persistable;
static Opt * Instance();
void SetDefaultParameterValues(void);
conv::NuMassHierarchy_t gMassHierarchyAssumed;
conv::NuOscMixParam_t gOscMixingParamChoice;
conv::NuOscOctant_t gOscOctantChoice;
conv::NuOscDmsqScheme_t gOscDmsqScheme;
conv::NuOscDmsqScheme_t GetEffectiveDmsqScheme(void);
conv::NuOscDeltaCP_t gOscDeltaCP;
void SetValues(const char * dmsqscheme, const char * hierarchy,
 const char * mixparamchoice, const char * mixparamoctant,
 const char * cpvchoice, bool print = true);
void Print(ostream & stream) const;
friend ostream & operator << (ostream & stream, const Opt & opt);
double GetGlobalBestFit (conv::PhysParamId_t p) const;
double GetGlobalFitError (conv::PhysParamId_t p) const;
void SetGlobalBestFit (conv::PhysParamId_t p, double value);
void SetGlobalFitError (conv::PhysParamId_t p, double value);
bool Undefined(void);
void WriteTo (Persistable & optp);
void ReadFrom (Persistable & optp);
bool gDoNotDie;
Registry & MutableGlobalRegistry();
const Registry & GlobalRegistry() const;
class Persistable: public TNamed {
public:
Persistable() :
TNamed()
{
mh = conv::kNmhNormal;
mixp = conv::kNuMixSinsq2Theta;
oct = conv::kNuOctantOne;
dmsqs = conv::kNuDmsq12andAbs23;
dcp = conv::kNuDeltaCPPhase;
}
Persistable(const Persistable & p) :
TNamed()
{
mh = p.mh;
mixp = p.mixp;
oct = p.oct;
dmsqs = p.dmsqs;
dcp = p.dcp;
}
~Persistable() { }
conv::NuMassHierarchy_t mh;
conv::NuOscMixParam_t mixp;
conv::NuOscOctant_t oct;
conv::NuOscDmsqScheme_t dmsqs;
conv::NuOscDeltaCP_t dcp;
ClassDef(Persistable,1);
};
private:
Opt();
Opt(const Opt &);
~Opt();
static Opt * fInstance;
void SetDefaults(void);
double fGlobalBestFit [conv::knppmax];
double fGlobalFitError [conv::knppmax];
Registry fRegistry;
struct Cleaner {
void DummyMethodAndSilentCompiler() { }
~Cleaner() {
if (Opt::fInstance !=0) {
delete Opt::fInstance;
Opt::fInstance = 0;
}
}
};
friend struct Cleaner;
};
ostream & operator<< (ostream & stream, const Opt & plst);
}
#endif
#ifndef osc_channel_id_h
#define osc_channel_id_h
namespace valor {
namespace conv {
typedef enum EOscChannelId
{
kOscUndefined = -1,
kOscNuE2NuE,
kOscNuE2NuMu,
kOscNuE2NuTau,
kOscNuMu2NuE,
kOscNuMu2NuMu,
kOscNuMu2NuTau,
kOscNuTau2NuE,
kOscNuTau2NuMu,
kOscNuTau2NuTau,
kOscNuEBar2NuEBar,
kOscNuEBar2NuMuBar,
kOscNuEBar2NuTauBar,
kOscNuMuBar2NuEBar,
kOscNuMuBar2NuMuBar,
kOscNuMuBar2NuTauBar,
kOscNuTauBar2NuEBar,
kOscNuTauBar2NuMuBar,
kOscNuTauBar2NuTauBar,
kOscNuE2NuS4,
kOscNuE2NuS5,
kOscNuMu2NuS4,
kOscNuMu2NuS5,
kOscNuTau2NuS4,
kOscNuTau2NuS5,
kOscNuS42NuE,
kOscNuS52NuE,
kOscNuS42NuMu,
kOscNuS52NuMu,
kOscNuS42NuTau,
kOscNuS52NuTau,
kOscNuEBar2NuS4Bar,
kOscNuEBar2NuS5Bar,
kOscNuMuBar2NuS4Bar,
kOscNuMuBar2NuS5Bar,
kOscNuTauBar2NuS4Bar,
kOscNuTauBar2NuS5Bar,
kOscNuS4Bar2NuEBar,
kOscNuS5Bar2NuEBar,
kOscNuS4Bar2NuMuBar,
kOscNuS5Bar2NuMuBar,
kOscNuS4Bar2NuTauBar,
kOscNuS5Bar2NuTauBar
}
OscChannelId_t;
}
namespace util {
string AsString (conv::OscChannelId_t o);
string OscChannelAsString (conv::OscChannelId_t o);
conv::OscChannelId_t GetOscChannel(int nu_start, int nu_end);
}
}
#endif
#ifndef pdg_h
#define pdg_h
namespace valor {
namespace conv {
static const int kPdgNuE = 12;
static const int kPdgNuMu = 14;
static const int kPdgNuTau = 16;
static const int kPdgNuEBar = -12;
static const int kPdgNuMuBar = -14;
static const int kPdgNuTauBar = -16;
static const int kPdgNuS4 = 80;
static const int kPdgNuS5 = 100;
static const int kPdgNuS4Bar = -80;
static const int kPdgNuS5Bar = -100;
static const int kPdgNuFlavs[kNNuFlavour] = {
12,
14,
16,
-12,
-14,
-16
};
}
namespace util {
bool IsNeutrino (int pdg_code);
bool IsAntiNeutrino (int pdg_code);
string Pdg2String (int pdg_code);
string Pdg2StringTex (int pdg_code);
}
}
#endif
#ifndef _valor_cmd_line_arg_list_h_
#define _valor_cmd_line_arg_list_h_
namespace valor {
class CmdLnArgList: public Registry {
public:
CmdLnArgList();
~CmdLnArgList();
bool Read (int argc, const char* const* argv, string arg_spec_files);
};
}
#endif
#ifndef _CMD_LINE_ARG_PARSER_H_
#define _CMD_LINE_ARG_PARSER_H_
namespace valor {
class CmdLnArgParser {
public:
CmdLnArgParser(int argc, const char* const* argv);
~CmdLnArgParser();
bool OptionExists (char opt, bool set_used = true) const;
std::string ArgAsString (char opt) const;
std::vector<std::string> ArgAsStringTokens (char opt, std::string delimeter) const;
std::vector<std::string> ArgAsStringTokens (std::string opt, std::string delimeter) const;
double ArgAsDouble (char opt) const;
std::vector<double> ArgAsDoubleTokens (char opt, std::string delimeter) const;
int ArgAsInt (char opt) const;
std::vector<int> ArgAsIntTokens (char opt, std::string delimeter) const;
unsigned int ArgAsUInt (char opt) const;
std::vector<unsigned int> ArgAsUIntTokens (char opt, std::string delimeter) const;
long ArgAsLong (char opt) const;
std::vector<long> ArgAsLongTokens (char opt, std::string delimeter) const;
bool OptionExists (std::string opt, bool set_used = true) const;
std::string ArgAsString (std::string opt) const;
double ArgAsDouble (std::string opt) const;
int ArgAsInt (std::string opt) const;
unsigned int ArgAsUInt (std::string opt) const;
long ArgAsLong (std::string opt) const;
bool RecognisedAllArgs() const;
private:
int fArgc;
const char* const* fArgv;
mutable std::vector<bool> fArgUsed;
};
}
#endif
#ifndef _RUN_OPT_H_
#define _RUN_OPT_H_
namespace valor {
typedef enum EParseType
{
kParseUndefined = (1 << 0),
kParseCommon = (1 << 1),
kParseToys = (1 << 2),
kParseGlobal = (1 << 3),
kParse3FOscParams = (1 << 4),
kParseFitMarg = (1 << 5)
}
ParseType_t;
class RunOpt
{
public:
RunOpt();
RunOpt(int argc, char ** argv, int parseopt);
virtual ~RunOpt();
virtual void ReadFromCommandLine(int argc, char ** argv, int parseopt);
string ConfigFile () const { if(fParseType & kParseCommon) return fConfigFile; cerr << "kParseCommon not set" << endl; exit(-1); }
string VerbosityFile () const { if(fParseType & kParseCommon) return fVerbosityFile; cerr << "kParseCommon not set" << endl; exit(-1); }
string FileTag () const { if(fParseType & kParseCommon) return fFileTag; cerr << "kParseCommon not set" << endl; exit(-1); }
int Run () const { if(fParseType & kParseCommon) return fRun; cerr << "kParseCommon not set" << endl; exit(-1); }
string PathFileData () const { if(fParseType & kParseCommon) return fPathFileData; cerr << "kParseCommon not set" << endl; exit(-1); }
bool UseFileData () const { if(fParseType & kParseCommon) return fUseFileData; cerr << "kParseCommon not set" << endl; exit(-1); }
UInt_t RndSeedToyMCstat() const {return fSeedToyMCstat;}
UInt_t RndSeedToyMCsyst() const {return fSeedToyMCsyst;}
UInt_t RndSeedToyMCosc () const {return fSeedToyMCosc; }
UInt_t RndSeedFitter () const {return fSeedFitter; }
UInt_t RndSeedOther () const {return fSeedOther; }
string GlobalDmsqScheme () const { if(fParseType & kParseGlobal) return fGlobalDmsqScheme; cerr << "kParseGlobal not set" << endl; exit(-1); }
string GlobalMassHierarchy () const { if(fParseType & kParseGlobal) return fGlobalMassHierarchy; cerr << "kParseGlobal not set" << endl; exit(-1); }
string GlobalMixParamScheme() const { if(fParseType & kParseGlobal) return fGlobalMixParamScheme; cerr << "kParseGlobal not set" << endl; exit(-1); }
string GlobalMixParamOctant() const { if(fParseType & kParseGlobal) return fGlobalMixParamOctant; cerr << "kParseGlobal not set" << endl; exit(-1); }
string GlobalCPVPhaseScheme() const { if(fParseType & kParseGlobal) return fGlobalCPVPhaseScheme; cerr << "kParseGlobal not set" << endl; exit(-1); }
 
string Hypothesis () const { if(fParseType & kParse3FOscParams ) return fHypothesis; cerr << "kParse3FOscParams or kParse3FOscBarParams not set" << endl; exit(-1); }
 
int FirstExperiment () const { if(fParseType & (kParseToys | kParseFitMarg)) return fFirstExperiment; cerr << "kParseToys or kParseFitMarg not set" << endl; exit(-1); }
int LastExperiment () const { if(fParseType & (kParseToys | kParseFitMarg)) return fLastExperiment; cerr << "kParseToys or kParseFitMarg not set" << endl; exit(-1); }
int NExperiments () const { if(fParseType & (kParseToys | kParseFitMarg)) return fNExperiments; cerr << "kParseToys or kParseFitMarg not set" << endl; exit(-1); }
bool StatFluctuations () const { if(fParseType & (kParseToys | kParseFitMarg)) return fStatFluctuations; cerr << "kParseToys or kParseFitMarg not set" << endl; exit(-1); }
int SystTweakMode () const { if(fParseType & (kParseToys | kParseFitMarg)) return fSystTweakMode; cerr << "kParseToys or kParseFitMarg not set" << endl; exit(-1); }
bool RethrowIfUnphysical () const { if(fParseType & (kParseToys | kParseFitMarg)) return fRethrowIfUnphysical; cerr << "kParseToys or kParseFitMarg not set" << endl; exit(-1); }
bool VerboseSystThrows () const { if(fParseType & (kParseToys | kParseFitMarg)) return fVerboseSystThrows; cerr << "kParseToys or kParseFitMarg not set" << endl; exit(-1); }
bool VerboseFit () const { if(fParseType & (kParseToys | kParseFitMarg)) return fVerboseFit ; cerr << "kParseToys or kParseFitMarg not set" << endl; exit(-1); }
string Xmlfile () const { if(fParseType & kParseFitMarg) return fXmlfile; cerr << "kParseFitMarg not set" << endl; exit(-1); }
string Rootfile () const { if(fParseType & kParseFitMarg) return fRootfile; cerr << "kParseFitMarg not set" << endl; exit(-1); }
bool Using_xml_file () const { if(fParseType & kParseFitMarg) return fUsing_xml_file; cerr << "kParseFitMarg not set" << endl; exit(-1); }
bool DoToys () const { if(fParseType & kParseFitMarg) return fDoToys; cerr << "kParseFitMarg not set" << endl; exit(-1); }
bool ReadSKExp() const { if(fParseType & kParseFitMarg) return fReadSKExp; cerr << "kParseFitMarg not set" << endl; exit(-1); }
string Fit_param_list () const { if(fParseType & kParseFitMarg) return fFit_param_list; cerr << "kParseFitMarg not set" << endl; exit(-1); }
bool DoFC () const { if(fParseType & kParseFitMarg) return fDoFC; cerr << "kParseFitMarg not set" << endl; exit(-1); }
string Infilename () const { if(fParseType & kParseFitMarg) return fInfilename; cerr << "kParseFitMarg not set" << endl; exit(-1); }
string Infilename_nh () const { if(fParseType & kParseFitMarg) return fInfilename_nh; cerr << "kParseFitMarg not set" << endl; exit(-1); }
string Infilename_ih () const { if(fParseType & kParseFitMarg) return fInfilename_ih; cerr << "kParseFitMarg not set" << endl; exit(-1); }
int Nfiles () const { if(fParseType & kParseFitMarg) return fNfiles; cerr << "kParseFitMarg not set" << endl; exit(-1); }
int NtoysMarg () const { if(fParseType & kParseFitMarg) return fNtoysMarg; cerr << "kParseFitMarg not set" << endl; exit(-1); }
string Freeparname0 () const { if(fParseType & kParseFitMarg) return fFreeparname0; cerr << "kParseFitMarg not set" << endl; exit(-1); }
double Freeparmin0 () const { if(fParseType & kParseFitMarg) return fFreeparmin0; cerr << "kParseFitMarg not set" << endl; exit(-1); }
double Freeparmax0 () const { if(fParseType & kParseFitMarg) return fFreeparmax0; cerr << "kParseFitMarg not set" << endl; exit(-1); }
int NptScan0 () const { if(fParseType & kParseFitMarg) return fNptScan0; cerr << "kParseFitMarg not set" << endl; exit(-1); }
string Freeparname1 () const { if(fParseType & kParseFitMarg) return fFreeparname1; cerr << "kParseFitMarg not set" << endl; exit(-1); }
double Freeparmin1 () const { if(fParseType & kParseFitMarg) return fFreeparmin1; cerr << "kParseFitMarg not set" << endl; exit(-1); }
double Freeparmax1 () const { if(fParseType & kParseFitMarg) return fFreeparmax1; cerr << "kParseFitMarg not set" << endl; exit(-1); }
int NptScan1 () const { if(fParseType & kParseFitMarg) return fNptScan1; cerr << "kParseFitMarg not set" << endl; exit(-1); }
bool DoMargMH () const { if(fParseType & kParseFitMarg) return fDoMargMH; cerr << "kParseFitMarg not set" << endl; exit(-1); }
string Hierarchy_marg () const { if(fParseType & kParseFitMarg) return fHierarchy_marg; cerr << "kParseFitMarg not set" << endl; exit(-1); }
bool DoMinimize () const { if(fParseType & kParseFitMarg) return fDoMinimize; cerr << "kParseFitMarg not set" << endl; exit(-1); }
TString TypeError () const { if(fParseType & kParseFitMarg) return fTypeError; cerr << "kParseFitMarg not set" << endl; exit(-1); }
bool DrawFullChisq () const { if(fParseType & kParseFitMarg) return fDrawFullChisq; cerr << "kParseFitMarg not set" << endl; exit(-1); }
string Teststat () const { if(fParseType & kParseFitMarg) return fTeststat; cerr << "kParseFitMarg not set" << endl; exit(-1); }
bool StoreLikeWeights () const { if(fParseType & kParseFitMarg) return fStoreLikeWeights; cerr << "kParseFitMarg not set" << endl; exit(-1); }
bool PenaltyTerm0 () const { if(fParseType & kParseFitMarg) return fPenaltyTerm0; cerr << "kParseFitMarg not set" << endl; exit(-1); }
bool PenaltyTerm1 () const { if(fParseType & kParseFitMarg) return fPenaltyTerm1; cerr << "kParseFitMarg not set" << endl; exit(-1); }
bool Scale_toys_based_on_samples () const { if(fParseType & kParseFitMarg) return kScale_toys_based_on_samples; cerr << "kScale_toys_based_on_samples not set" << endl; exit(-1); }
double Scale_toys_based_on_samples_scale () const { if(fParseType & kParseFitMarg) return fScale_toys_based_on_samples_scale; cerr << "fScale_toys_based_on_samples_scale not set" << endl; exit(-1); }
virtual void Print (ostream & stream, const int w = 30) const;
friend ostream & operator << (ostream & stream, const RunOpt & opt);
protected:
virtual void Usage(const int w = 40);
virtual void Init (void);
void InitOscParams(double value = -99);
void ReadCommonOptions();
void ReadToyOptions();
void ReadGlobalOptions();
void Read3FOscParamsOptions();
void ReadFitMargOptions();
CmdLnArgParser * fParser;
int fParseType;
string fHierStr[2];
string fConfigFile;
string fVerbosityFile;
string fFileTag;
int fRun;
bool fUseFileData;
string fPathFileData;
int fFirstExperiment;
int fLastExperiment;
int fNExperiments;
bool fStatFluctuations;
int fSystTweakMode;
bool fRethrowIfUnphysical;
bool fVerboseSystThrows;
bool fVerboseFit;
string fGlobalDmsqScheme;
string fGlobalMassHierarchy;
string fGlobalMixParamScheme;
string fGlobalMixParamOctant;
string fGlobalCPVPhaseScheme;
UInt_t fSeedToyMCstat;
UInt_t fSeedToyMCsyst;
UInt_t fSeedToyMCosc;
UInt_t fSeedFitter;
UInt_t fSeedOther;
string fHypothesis;
double fMix12 [2];
double fMix13 [2];
double fMix23 [2];
double fCPV [2];
double fDm12sq[2];
double fDm23sq[2];
double fMix12Bar [2];
double fMix13Bar [2];
double fMix23Bar [2];
double fCPVBar [2];
double fDm12sqBar[2];
double fDm23sqBar[2];
bool fSynchronizeIHtoNH;
double fBetaBar;
double fPriorProbNH;
bool fThrowMH;
string fPriorsFile;
bool fMargMixing12;
bool fMargMixing13;
bool fMargMixing23;
bool fMargDm12sq;
bool fMargDm23sq;
bool fMargDeltaCP;
string fMixModeMixing12;
string fMixModeMixing23;
string fMixModeMixing13;
string fPriorMixing12;
string fPriorMixing13;
string fPriorMixing23;
string fPriorDm12sq;
string fPriorDm23sq;
string fPriorDeltaCP;
double fPriorParMixing12[2];
double fPriorParMixing13[2];
double fPriorParMixing23[2];
double fPriorParDm12sq[2];
double fPriorParDm23sq[2];
double fPriorParDeltaCP[2];
string fXmlfile;
string fRootfile;
bool fUsing_xml_file;
bool fDoToys;
bool fReadSKExp;
string fFit_param_list;
string fInfilename;
string fInfilename_nh;
string fInfilename_ih;
bool fDoFC;
int fNfiles;
int fNtoysMarg;
string fFreeparname0;
double fFreeparmin0;
double fFreeparmax0;
int fNptScan0;
string fFreeparname1;
double fFreeparmin1;
double fFreeparmax1;
int fNptScan1;
bool fDoMargMH;
string fHierarchy_marg;
bool fDoMinimize;
TString fTypeError;
bool fDrawFullChisq;
string fTeststat;
int fPriorId;
bool fStoreLikeWeights;
bool fPenaltyTerm0;
bool fPenaltyTerm1;
bool kScale_toys_based_on_samples;
double fScale_toys_based_on_samples_scale;
};
ostream & operator << (ostream & stream, const RunOpt & opt);
}
#endif
#ifndef _valor_array_bin_h_
#define _valor_array_bin_h_
namespace valor {
struct VALORArrayBin
{
public:
VALORArrayBin();
VALORArrayBin(int b1 ,int b2, int b3, int b4, int b5, int b6);
VALORArrayBin(const int * bin_numbers);
int bin1;
int bin2;
int bin3;
int bin4;
int bin5;
int bin6;
};
bool operator==(const VALORArrayBin & lhs, const VALORArrayBin & rhs);
}
#endif
#ifndef _valor_array_double_h_
#define _valor_array_double_h_
#endif
#ifndef _valor_array_float_h_
#define _valor_array_float_h_
#endif
#ifndef _valor_array_header_h_
#define _valor_array_header_h_
namespace valor {
class VALORArrayHeader
{
public:
static const std::size_t kSize = 128;
static const unsigned int kArrayVersion = 1;
typedef enum EVArrayType {
kVATUndefined = -1,
kVATDouble = 0,
kVATFloat = 1,
kVATInt = 2,
kVATUInt = 3,
kVATInt64 = 4,
kVATUInt64 = 5,
} kVArrayType;
VALORArrayHeader(void);
VALORArrayHeader(kVArrayType type, UInt_t ndims, Int_t * dimensions, UInt_t compressed_size, UInt_t compression_level);
void Write(std::ostream & stream_to_write_to) const;
int Read (std::istream & stream_to_read_from);
UInt_t GetVersion() const;
UInt_t GetCompressionLevel() const;
UInt_t GetCompressedSize () const;
UInt_t GetNDimensions() const;
const Int_t * GetDimensions() const;
kVArrayType GetDataType() const;
private:
char fBlock[kSize];
Int_t * fBlockAsInt;
UInt_t * fBlockAsUInt;
static const char kIDString[];
};
namespace conv {
static const int kDefaultCompressionLevel = 3;
}
}
#endif
#ifndef _valor_array_int_h_
#define _valor_array_int_h_
#endif
#ifndef _valor_array_template_h_
#define _valor_array_template_h_
namespace valor {
template <typename numtype> class VALORArrayT: public TNamed
{
public:
VALORArrayT();
VALORArrayT(const std::vector<int> dimensions);
VALORArrayT(int nd, const int * dimensions);
VALORArrayT(int dim1, int dim2=-1, int dim3=-1, int dim4=-1, int dim5=-1, int dim6=-1);
VALORArrayT(std::string file_to_read);
VALORArrayT(const VALORArrayT<numtype> & arr);
template <typename fromtype> VALORArrayT(const VALORArrayT<fromtype> & arr);
~VALORArrayT();
int GetSize(int dim = -1) const;
numtype GetEntry (int ind1, int ind2=-1, int ind3=-1, int ind4=-1, int ind5=-1, int ind6=-1) const;
numtype & GetEntryRef (int ind1, int ind2=-1, int ind3=-1, int ind4=-1, int ind5=-1, int ind6=-1);
const numtype & GetEntryRef(int ind1, int ind2=-1, int ind3=-1, int ind4=-1, int ind5=-1, int ind6=-1) const;
void SetEntry(numtype value, int ind1, int ind2=-1, int ind3=-1, int ind4=-1, int ind5=-1, int ind6=-1);
void AddToEntry(numtype value, int ind1, int ind2=-1, int ind3=-1, int ind4=-1, int ind5=-1, int ind6=-1);
int Address(int ind1, int ind2=-1, int ind3=-1, int ind4=-1, int ind5=-1, int ind6=-1) const;
void InverseAddress(int address, int * return_indices) const;
numtype GetEntry (const VALORArrayBin & bin) const;
numtype & GetEntryRef (const VALORArrayBin & bin);
const numtype & GetEntryRef(const VALORArrayBin & bin) const;
void SetEntry(numtype value, const VALORArrayBin & bin);
void AddToEntry(numtype value, const VALORArrayBin & bin);
int Address(const VALORArrayBin & bin) const;
VALORArrayBin InverseAddress(int address) const;
int GetNDim() const;
const numtype * GetArray(void) const;
numtype * GetArray(void);
const int * GetDimensions(void) const;
VALORArrayBin GetDimensionSizes(void) const;
void SetAll(numtype value);
void SetDimensionName(int dimension, const std::string & name);
std::string GetDimensionName(int dimension) const;
VALORArrayT GetSlice(int dimension, int min_bin = -1, int max_bin = -1) const;
numtype Integral() const;
numtype Integral(int min_dim1 , int max_dim1=-1, int min_dim2=-1, int max_dim2=-1,
int min_dim3 = -1, int max_dim3=-1, int min_dim4=-1, int max_dim4=-1,
int min_dim5 = -1, int max_dim5=-1, int min_dim6=-1, int max_dim6=-1 ) const;
void Scale(numtype factor);
void ScaleBins(numtype factor,
int bin1 = -1, int bin2 =-1, int bin3 =-1,
int bin4 = -1, int bin5 =-1, int bin6 =-1);
void ScaleBinRange (numtype factor,
int min_dim1 , int max_dim1=-1, int min_dim2=-1, int max_dim2=-1,
int min_dim3 = -1, int max_dim3=-1, int min_dim4=-1, int max_dim4=-1,
int min_dim5 = -1, int max_dim5=-1, int min_dim6=-1, int max_dim6=-1 );
void ReadFile (std::string file_to_read);
void WriteFile(std::string file_to_write);
void Resize(const std::vector<int> dimensions);
void Resize(int nd, const int * dimensions);
void Resize(int dim1, int dim2=-1, int dim3=-1, int dim4=-1, int dim5=-1, int dim6=-1);
void CopyFrom(const VALORArrayT<numtype> & arr);
void CopyDataOnlyFrom(const VALORArrayT<numtype> & arr);
void SetCompressionLevel(int level);
void PrintEntries(std::ostream & str = std::cout);
void PrintDimensions(std::ostream & str = std::cout);
private:
int fNDim;
int fSize;
Int_t fDimensions[6];
int fIncrement [6];
numtype * fArray;
std::string fNames[6];
void Construct (int nd, const int * dimensions);
void ConstructT(int nd, const Int_t * dimensions);
void Cleanup();
int fCompressionLevel;
VALORArrayHeader::kVArrayType GetHeaderType(void);
ClassDef(VALORArrayT, 1)
};
namespace util {
template<typename typefrom, typename typeto>
VALORArrayT<typeto> ConvertVALORArray(const VALORArrayT<typefrom> & input)
{
VALORArrayT<typeto> output (input.GetNDim(),input.GetDimensions());
typeto * output_arr = output.GetArray();
const typefrom * input_arr = input.GetArray();
for (int i = 0 ; i < output.GetSize() ; i++) {
output_arr[i] = (typeto) input_arr[i];
}
for (int i = 0 ; i < output.GetNDim(); i++) {
output.SetDimensionName(i,input.GetDimensionName(i));
}
return output;
}
}
typedef VALORArrayT<double > VALORArray;
typedef VALORArrayT<double > VALORArrayD;
typedef VALORArrayT<float > VALORArrayF;
typedef VALORArrayT<int > VALORArrayI;
typedef VALORArrayT<Long64_t > VALORArrayL;
typedef VALORArrayT<ULong64_t > VALORArrayUL;
}
#endif
#ifndef _valor_array_orig_h_
#define _valor_array_orig_h_
#endif
#ifndef valor_phys_params
#define valor_phys_params
namespace valor
{
class PhysParams
{
public:
static PhysParams* Instance();
void Read(const std::string& filename);
void Select(const std::string& filename);
double Bestfit(const std::string& param) const;
double Initial(const std::string& param) const;
double Minimum(const std::string& param) const;
double Maximum(const std::string& param) const;
double StepSize(const std::string& param) const;
double Scaling(const std::string& param) const;
bool IsMarginalised (const std::string& param) const;
double GaussianPriorMean(const std::string& param) const;
double GaussianPriorSigma(const std::string& param) const;
double FlatPriorMinimum(const std::string& param) const;
double FlatPriorMaximum(const std::string& param) const;
const std::string& UserPriorFilename(const std::string& param) const;
bool IsFixed(const std::string& param) const;
bool IsNuisance(const std::string& param) const;
bool IsMigradErrorSet(const std::string& param) const;
double MigradError(const std::string& param) const;
bool IsHesseErrorSet(const std::string& param) const;
double HesseError(const std::string& param) const;
bool IsMinosErrorSet(const std::string& param) const;
double MinosLowError(const std::string& param) const;
double MinosHighError(const std::string& param) const;
conv::PhysParamId_t GetParamId(const std::string& param) const;
conv::PhysParamId_t operator[](const std::string& param) const;
int NParams() const { return _nextId; }
void Clear() { _nextId = 0; _parameters.clear(); }
~PhysParams();
private:
PhysParams();
void AddParameter(const std::string& param);
void ProcessParameters(const std::string& parameterList);
void SetParameterValue(double& value, TXMLEngine* xml, XMLNodePointer_t node,
const std::string& path, const double def);
void SetParameterValue(bool& value, TXMLEngine* xml, XMLNodePointer_t node,
const std::string& path, const bool def);
void SetParameterValue(std::string& value, TXMLEngine* xml, XMLNodePointer_t node,
const std::string& path, const std::string& def);
void ProcessParameter(TXMLEngine* xml, XMLNodePointer_t node);
void ProcessDefaults(TXMLEngine* xml, XMLNodePointer_t node);
void StrictCheck(const std::string& param, const std::string& value) const;
PhysParams(const PhysParams& obj){ (void)obj; }
PhysParams(const PhysParams&& obj){ (void)obj; }
PhysParams& operator=(const PhysParams& obj)
{
return const_cast<PhysParams&>(obj);
}
PhysParams& operator=(const PhysParams&& obj)
{
return const_cast<PhysParams&>(obj);
}
private:
struct Param
{
Param(const std::string& name, conv::PhysParamId_t id):
_name{name}, _id{id}, _bestfit{0.0}, _initial{0.0}, _minimum{0.0},
_maximum{0.0}, _stepsize{0.0}, _scaling{0.0}, _isMarginalised{false},
_gausMean{0.0}, _gausSigma{0.0}, _flatMinimum{0.0}, _flatMaximum{0.0},
_userFilename{""}, _isFixed{false}, _isNuisance{false},
_hasMigradError{false}, _migradError{0.0}, _hasHesseError{false},
_hesseError{0.0}, _hasMinosError{false}, _minosLowError{0.0},
_minosHighError{0.0}
{
}
std::string _name;
conv::PhysParamId_t _id;
double _bestfit;
double _initial;
double _minimum;
double _maximum;
double _stepsize;
double _scaling;
bool _isMarginalised;
double _gausMean;
double _gausSigma;
double _flatMinimum;
double _flatMaximum;
std::string _userFilename;
bool _isFixed;
bool _isNuisance;
bool _hasMigradError;
double _migradError;
bool _hasHesseError;
double _hesseError;
bool _hasMinosError;
double _minosLowError;
double _minosHighError;
};
public:
static const conv::PhysParamId_t Undefined = conv::kPhypUndefined;
private:
static PhysParams* _instance;
std::map<std::string, Param*> _parameters;
Param* _defaults;
int _nextId;
};
}
#endif
#ifndef _valor_phys_param_list_h_
#define _valor_phys_param_list_h_
namespace valor {
class CorrelatedSystematics;
class PhysParamList: public TNamed
{
public:
PhysParamList();
PhysParamList(const PhysParamList & pl);
~PhysParamList();
int NParams (void) const;
double Value (conv::PhysParamId_t p) const;
void SetValue (conv::PhysParamId_t p, double v);
void Clear (Option_t * option = "");
void Append (const PhysParamList & pl);
using TNamed::Print;
void Print (ostream & stream) const;
bool Contains (conv::PhysParamId_t p) const;
void Remove (conv::PhysParamId_t p);
double operator () (conv::PhysParamId_t p) const;
friend ostream & operator << (ostream & stream, const PhysParamList & pl);
const map<int,double> & Map(void) const { return fParams; }
void CopyFrom(const PhysParamList & ppl);
void MergeFrom(const PhysParamList & ppl, Option_t * opt = 0);
TVectorD AsTVector(const CorrelatedSystematics * ordering);
private:
map<int,double> fParams;
ClassDef(PhysParamList,1)
};
ostream & operator<< (ostream & stream, const PhysParamList & plst);
}
#endif
#ifndef _valor_fit_param_list_h_
#define _valor_fit_param_list_h_
namespace valor {
class PhysParamList;
class FitParamList: public TNamed {
public:
FitParamList();
FitParamList(int nparams);
FitParamList(const FitParamList & plst);
~FitParamList();
int Size (void) const { return fNParams; }
string Name (valor::conv::PhysParamId_t p) const { return fName[this->Id(p)].GetString().Data(); }
double BestFitValue (valor::conv::PhysParamId_t p) const { return fBestFitValue [this->Id(p)]; }
double CurrValue (valor::conv::PhysParamId_t p) const { return fCurrValue [this->Id(p)]; }
double InitValue (valor::conv::PhysParamId_t p) const { return fInitValue [this->Id(p)]; }
double MinValue (valor::conv::PhysParamId_t p) const { return fMinValue [this->Id(p)]; }
double MaxValue (valor::conv::PhysParamId_t p) const { return fMaxValue [this->Id(p)]; }
double StepSize (valor::conv::PhysParamId_t p) const { return fStepSize [this->Id(p)]; }
bool IsFixed (valor::conv::PhysParamId_t p) const { return fIsFixed [this->Id(p)]; }
bool IsNuisance (valor::conv::PhysParamId_t p) const { return fIsNuisance [this->Id(p)]; }
double MigradError (valor::conv::PhysParamId_t p) const { return fMigradError [this->Id(p)]; }
double HesseError (valor::conv::PhysParamId_t p) const { return fHesseError [this->Id(p)]; }
double PlusError (valor::conv::PhysParamId_t p) const { return fPlusError [this->Id(p)]; }
double MinusError (valor::conv::PhysParamId_t p) const { return fMinusError [this->Id(p)]; }
double ParameterScaling (valor::conv::PhysParamId_t p) const { return fParameterScaling[this->Id(p)]; }
string NameByIndex (int i) const { return fName[i].GetString().Data(); }
double BestFitValueByIndex (int i) const { return fBestFitValue [i]; }
double CurrValueByIndex (int i) const { return fCurrValue [i]; }
double InitValueByIndex (int i) const { return fInitValue [i]; }
double MinValueByIndex (int i) const { return fMinValue [i]; }
double MaxValueByIndex (int i) const { return fMaxValue [i]; }
double StepSizeByIndex (int i) const { return fStepSize [i]; }
bool IsFixedByIndex (int i) const { return fIsFixed [i]; }
bool IsNuisanceByIndex (int i) const { return fIsNuisance [i]; }
double MigradErrorByIndex (int i) const { return fMigradError [i]; }
double HesseErrorByIndex (int i) const { return fHesseError [i]; }
double PlusErrorByIndex (int i) const { return fPlusError [i]; }
double MinusErrorByIndex (int i) const { return fMinusError [i]; }
double ParameterScalingByIndex(int i) const { return fParameterScaling[i]; }
bool AddParam (
int ip, valor::conv::PhysParamId_t p, double init,
double min, double max, double step, bool fix=false, bool nuisance=false, string name="");
bool Exists (valor::conv::PhysParamId_t p) const;
void Update(valor::conv::PhysParamId_t p, double v, bool scaled = false);
void SetInitValue (valor::conv::PhysParamId_t p, double v);
void SetCurrentValue(valor::conv::PhysParamId_t p, double v);
void SetInitValueByIndex (int i, double v);
void SetCurrentValueByIndex (int i, double v);
void SetMinValue (valor::conv::PhysParamId_t p, double min) { fMinValue [this->Id(p)] = min; }
void SetMaxValue (valor::conv::PhysParamId_t p, double max) { fMaxValue [this->Id(p)] = max; }
void SetMinValueByIndex (int i, double min) { fMinValue [i] = min; }
void SetMaxValueByIndex (int i, double max) { fMaxValue [i] = max; }
void SetParameterScaling(conv::PhysParamId_t p, double scaling) { fParameterScaling[this->Id(p)] = scaling;}
void SetParameterScalingByIndex(int i , double scaling) { fParameterScaling[i] = scaling;}
void ResetCurrToInitValues (void);
void CopyCurrToBestFitValues (void);
void CopyCurrToInitValues (void);
void CopyBestFitToCurrValues (void);
void CopyBestFitToInitValues (void);
void CopyBestFitToInitValues (const FitParamList & plst);
using TNamed::Copy;
void Copy (const FitParamList & plst);
void SetCovMatrix(TMatrixDSym & covmatrix, unsigned int start_at = 0);
void SetErrors(double * errplus, double * errminus, double * errmigrad);
void SetMigradErrors(std::vector<double> err);
void SetHesseErrors (std::vector<double> err);
void SetMinosErrors (std::vector<double> plus, std::vector<double> minus);
void FixParameter (valor::conv::PhysParamId_t p);
void FixParameterByIndex (int ip);
void FreeParameter (valor::conv::PhysParamId_t p);
void FreeParameterByIndex (int ip);
void SetNuisance (valor::conv::PhysParamId_t p, bool tf);
FitParamList * FreeParameterSubset(void);
void SetTo (TVirtualFitter * fitter);
void SetTo (ROOT::Minuit2::MnUserParameters & params);
void SetTo (ROOT::Math::Minimizer * minimizer);
void SetTo (ROOT::Fit::Fitter * fitter);
void Sync (const double * par, bool scaling = false);
void Sync (std::vector<double> par, bool scaling = false);
valor::PhysParamList AsPhysParamList(Option_t * option = "current") const;
void FromPhysParamList(valor::PhysParamList pl, Option_t * option, bool skip_osc_params = false);
TVectorD AsTVector(Option_t * option = "current") const;
int GetNumberFreeParameters(void) const;
int GetNumberParameters (void) const;
void ClearStatusCodes (void);
void SetStatusCode (std::string st , int code);
void SetStatusCode (const char * st, int code);
int GetStatusCode (std::string st) const;
int GetStatusCode (const char * st) const;
void SetBestFitStatistic (double stat_bf) { fBestFitStatistic = stat_bf; }
double GetBestFitStatistic (void) const { return fBestFitStatistic; }
void SetCurrStatistic (double stat_curr) { fCurrStatistic = stat_curr; }
double GetCurrStatistic (void) const { return fCurrStatistic; }
void SetFitTime (double fit_time) { fFitTime = fit_time; }
double GetFitTime (void) const { return fFitTime; }
void SetFitTries (int fit_tries) { fFitTries = fit_tries; }
int GetFitTries (void) const { return fFitTries; }
void SetBestFitStatisticContributions (const std::map<std::string,double> & stat_bf) { fBestFitStatisticContributions = stat_bf; }
const std::map<std::string,double> & GetBestFitStatisticContributions (void) const { return fBestFitStatisticContributions; }
bool IsComplete();
TMatrixDSym * GetCovMatrix(void) { return fCovMatrix; }
const TMatrixDSym * GetCovMatrix(void) const { return fCovMatrix; }
double HypothesisFitStatisticPenalty(Option_t * opt = 0) const;
void Print (std::ostream & stream) const;
void Print (Option_t * option = "") const;
friend std::ostream & operator << (std::ostream & stream, const FitParamList & plst);
void ShowOnlyCurrValuesInNextPrint (void) const { fShowCurrValuesOnly = true; }
void ShowOnlyBestFitValuesInNextPrint(void) const { fShowBestFitValuesOnly = true; }
static FitParamList * NamedParameterList (string name);
string GetParListName (void) const { return fParListName; }
int GetSystMode (void) const { return fSystMode; }
conv::PhysHypothesis_t PhysicsHypothesis(void) const;
bool MigradErrorsSet (void) const { return fMigradErrorsSet; }
bool HesseErrorsSet (void) const { return fHesseErrorsSet; }
bool MinosErrorsSet (void) const { return fMinosErrorsSet; }
int Id (valor::conv::PhysParamId_t p) const;
valor::conv::PhysParamId_t WhichParam(int id) const;
void SetDoMarg(valor::conv::PhysParamId_t p,bool domarg);
void SetPriorMode(valor::conv::PhysParamId_t p,int priormode);
void SetPriorMode(valor::conv::PhysParamId_t p,string priormodename);
void SetMeanGaus(valor::conv::PhysParamId_t p,double mean);
void SetSigmaGaus(valor::conv::PhysParamId_t p,double sigma);
void SetMinValueFlat(valor::conv::PhysParamId_t p,double minvalmarg);
void SetMaxValueFlat(valor::conv::PhysParamId_t p,double maxvalmarg);
void SetPriorHisto(valor::conv::PhysParamId_t p,TH1D *hprior);
void SetPriorHisto2D(valor::conv::PhysParamId_t p,TH2D *hprior);
void SetToyHisto(valor::conv::PhysParamId_t p,TH1D *hprior);
void SetToyHisto2D(valor::conv::PhysParamId_t p,TH2D *hprior);
void SetPriorDimension2D(valor::conv::PhysParamId_t p, bool isprior2d);
bool IsMarginalized (valor::conv::PhysParamId_t p) const { return fDoMarg [this->Id(p)]; }
int GetPriorMode (valor::conv::PhysParamId_t p) const { return fPriorMode [this->Id(p)]; }
string GetPriorModeName (valor::conv::PhysParamId_t p) const;
double GetMeanGaus (valor::conv::PhysParamId_t p) const { return fMeanGaus [this->Id(p)]; }
double GetSigmaGaus (valor::conv::PhysParamId_t p) const { return fSigmaGaus [this->Id(p)]; }
double GetMinValueFlat (valor::conv::PhysParamId_t p) const { return fMinValueFlat [this->Id(p)]; }
double GetMaxValueFlat (valor::conv::PhysParamId_t p) const { return fMaxValueFlat [this->Id(p)]; }
TH1D * GetPriorHisto (valor::conv::PhysParamId_t p) const { return fPriorHisto [this->Id(p)]; }
TH2D * GetPriorHisto2D (valor::conv::PhysParamId_t p) const { return fPriorHisto2D [this->Id(p)]; }
TH1D * GetToyHisto (valor::conv::PhysParamId_t p) const { return fToyHisto [this->Id(p)]; }
TH2D * GetToyHisto2D (valor::conv::PhysParamId_t p) const { return fToyHisto2D [this->Id(p)]; }
bool IsPrior2D (valor::conv::PhysParamId_t p) const { return fIsPrior2D [this->Id(p)]; }
static FitParamList * NuOsc3FlavourFit (int nuisance = 0);
static FitParamList * NuOsc3FlavourBarFit (int nuisance = 0);
static FitParamList * NuOsc3FlavourBarDissapFit (int nuisance = 0);
static FitParamList * NuOsc3FlavourNormBarFit (int nuisance = 0);
static FitParamList * NuOsc3FlavourBarNormBarFit (int nuisance = 0);
static FitParamList * NumuDisapFit (int nuisance = 0);
static FitParamList * NumuDecayFit (int nuisance = 0);
static FitParamList * NumuDecohFit (int nuisance = 0);
static FitParamList * NuOscSterile4FlavourFit (int nuisance = 0);
static FitParamList * NuOscSterile5FlavourFit (int nuisance = 0);
static FitParamList * NuOscSterileEffectiveFit (int nuisance = 0);
static void Append3FlavourOscillation (FitParamList * fp, int start);
static void Append3FlavourOscillationBar (FitParamList * fp, int start);
static void Append3Flavour23BarOscillation (FitParamList * fp, int start);
static void AppendNormBar (FitParamList * fp, int start);
static void Append2FlavourOscillation (FitParamList * fp, int start);
static void Append4FlavourSterileOscillation (FitParamList * fp, int start);
static void Append5FlavourSterileOscillation (FitParamList * fp, int start);
static void AppendEffectiveSterileOscillation (FitParamList * fp, int start);
static void AppendAllSystematics (FitParamList * fp, int start);
void SetParListName (string s) { fParListName = s; }
void SetSystMode (int m) { fSystMode = m; }
private:
void CleanUp (void);
void Init (int nparams);
int FirstEmptyEntry();
map<valor::conv::PhysParamId_t, int> fIdMap;
string fParListName;
int fSystMode;
int fNParams;
TObjString * fName;
double * fBestFitValue;
double * fCurrValue;
double * fInitValue;
double * fMinValue;
double * fMaxValue;
double * fStepSize;
bool * fIsFixed;
bool * fIsNuisance;
double * fMigradError;
double * fHesseError;
double * fPlusError;
double * fMinusError;
double * fParameterScaling;
TMatrixDSym* fCovMatrix;
double fBestFitStatistic;
double fCurrStatistic;
double fFitTime;
int fFitTries;
bool fMigradErrorsSet;
bool fHesseErrorsSet;
bool fMinosErrorsSet;
std::map<std::string, int> fStatusCodes;
std::map<std::string, double> fBestFitStatisticContributions;
mutable bool fShowCurrValuesOnly;
mutable bool fShowBestFitValuesOnly;
bool *fDoMarg;
int *fPriorMode;
TObjString *fPriorModeName;
double *fMeanGaus;
double *fSigmaGaus;
double *fMinValueFlat;
double *fMaxValueFlat;
TH1D **fPriorHisto;
TH1D **fToyHisto;
TH2D **fPriorHisto2D;
TH2D **fToyHisto2D;
bool *fIsPrior2D;
ClassDef(FitParamList,3)
};
std::ostream & operator<< (std::ostream & stream, const FitParamList & plst);
}
#endif
#ifndef _valor_phys_hypothesis_h_
#define _valor_phys_hypothesis_h_
namespace valor {
class PhysHypothesis
{
public:
PhysHypothesis(conv::PhysHypothesis_t hypothesis = conv::kHypUndefined);
PhysHypothesis(string hypothesis);
PhysHypothesis(const PhysHypothesis & ph);
PhysHypothesis(const FitParamList & fp);
~PhysHypothesis();
void Init (conv::PhysHypothesis_t h);
void Copy (const PhysHypothesis & ph);
conv::PhysHypothesis_t Hypothesis (void) const { return fHypothesis; }
bool Contains (conv::PhysParamId_t p) const;
double CurrValue (conv::PhysParamId_t p) const;
void SetCurrValue (conv::PhysParamId_t p, double v);
void SetNuisance(conv::PhysParamId_t p, bool isNuisance);
bool IsNuisance (conv::PhysParamId_t p) const;
void Print (ostream & stream) const;
friend ostream & operator << (ostream & stream, const PhysHypothesis & ph);
valor::PhysParamList AsPhysParamList(void) const;
void CopyToPhysParamList(valor::PhysParamList & pl) const;
private:
conv::PhysHypothesis_t fHypothesis;
map<int,double> fParams;
map<int,bool> fIsNuisance;
};
ostream & operator<< (ostream & stream, const PhysHypothesis & plst);
}
#endif
#ifndef _valor_fit_data_abc_h_
#define _valor_fit_data_abc_h_
class TObjArray;
namespace valor {
class FitModelABC;
class FitParamList;
class PhysHypothesis;
class FitDataABC
{
public:
virtual ~FitDataABC();
virtual string Name(void) const = 0;
virtual bool Read(string file, Option_t * opt = 0) = 0;
virtual bool Generate (FitModelABC * model, const FitParamList & fp, bool fluctuate=true) = 0;
virtual bool Generate (FitModelABC * model, const PhysHypothesis & ph, bool fluctuate=true) = 0;
virtual bool Generate (FitModelABC * model, bool fluctuate=true) = 0;
virtual bool Write (TObjArray * collection, const char * tag = "data", Option_t * write_opt = 0) = 0;
virtual bool Write (const char * filename, const char * tag = "data", Option_t * write_opt = 0, Option_t * file_opt = 0) = 0;
virtual int NumOfBins (Option_t * opt = 0) const = 0;
virtual double GetFitStatistic (FitModelABC * pred, const FitParamList & fp, Option_t * stat_opt = "likelihood-ratio", std::map<std::string,double> * likelihood_components = 0) = 0;
virtual double GetFitStatistic (FitModelABC * pred, const PhysHypothesis & ph, Option_t * stat_opt = "likelihood-ratio", std::map<std::string,double> * likelihood_components = 0) = 0;
virtual double GetFitStatistic (FitModelABC * pred, Option_t * stat_opt = "likelihood-ratio", std::map<std::string,double> * likelihood_components = 0) = 0;
protected:
FitDataABC();
};
}
#endif
#ifndef _valor_fit_inputs_h_
#define _valor_fit_inputs_h_
namespace valor {
class FitDataABC;
class FitModelABC;
class FitInputs;
class FitFunctor: public ROOT::Math::IMultiGenFunction
{
public:
FitFunctor(FitInputs * inputs);
~FitFunctor();
double operator() (const double * x) const;
double DoEval(const double * x) const;
ROOT::Math::IMultiGenFunction * Clone(void) const;
unsigned int NDim(void) const;
private:
FitInputs * fFitInputs;
};
class FitMethodFunc : public ROOT::Math::FitMethodFunction
{
public:
FitMethodFunc( int dim, int npoints, FitInputs * inputs) :
ROOT::Math::FitMethodFunction(dim,npoints),
fFitInputs(inputs) {}
~FitMethodFunc();
double operator() (const double * x) const;
ROOT::Math::IMultiGenFunction * Clone(void) const{
return new FitMethodFunc(*this);
}
double DataElement(const double* x, unsigned int i, double* g = 0) const;
virtual ROOT::Math::BasicFitMethodFunction<ROOT::Math::IBaseFunctionMultiDim>::Type_t Type(void) const ;
private:
mutable FitInputs * fFitInputs;
virtual double DoEval(const double * x) const;
};
class FitInputs: public ROOT::Minuit2::FCNBase, public TObject
{
public :
FitInputs(FitDataABC * o, FitModelABC * e, FitParamList * p, string opt = "poisson", double errdef = 1, bool goodnessoffit = false);
~FitInputs();
FitDataABC & Observation (void);
FitModelABC & Expectation (void);
FitParamList & FitParams (void);
void UpdateParamList(FitParamList * fpar);
double Statistic(Option_t * stat_opt = "likelihood-ratio", std::map<std::string,double> * likelihood_components = 0) const;
void SetChisqDefinition (bool goodnessoffit) { fGoodnessOfFit = goodnessoffit; }
bool GetChisqDefinition (void) { return fGoodnessOfFit; }
void IncludePenaltyHyp(bool use_penalty);
void IncludePenaltySyst(bool use_penalty);
void SetChisquareFitOption(Option_t * opt) { fOpt = opt; }
double Up (void) const { return fErrDef; }
double ErrorDef (void) const { return Up(); }
void SetErrorDef (double errdef) { fErrDef = errdef; }
double operator() (const std::vector<double>& x) const;
ROOT::Math::IMultiGenFunction * AsFunctor(void) { return new FitFunctor(this); }
ROOT::Math::FitMethodFunction * AsFitMethodFunction(void) { return new FitMethodFunc(this->GetNDim(),this->GetNPoints(),this); }
int GetNDim(void) const {return fNDim;}
int GetNPoints (void) const {return fNPoints;}
private:
FitDataABC * fObs;
mutable FitModelABC * fExp;
mutable FitParamList * fFitParams;
string fOpt;
int fMode;
double fErrDef;
bool fGoodnessOfFit;
int fNPoints;
int fNDim;
bool fIncludePenaltySyst;
bool fIncludePenaltyHyp;
ClassDef(FitInputs, 4)
};
void FitFunc (Int_t &, Double_t *, Double_t &f, Double_t *par, Int_t iflag);
}
#endif
#ifndef _valor_fit_model_abc_h_
#define _valor_fit_model_abc_h_
class TObjArray;
namespace valor {
class FitModelABC
{
public:
virtual ~FitModelABC();
virtual std::string Name(void) const = 0;
virtual bool Read(std::string file, Option_t * opt = 0) = 0;
virtual bool Generate (const PhysHypothesis & ph, Option_t * opt = 0) = 0;
virtual void RandomizeSystematics (Option_t * opt = 0) = 0;
virtual void RandomizeSystematics (bool (*should_randomize)(conv::PhysParamId_t), Option_t * opt = 0) = 0;
virtual void RandomizeSystematics (std::map<valor::conv::PhysParamId_t, bool> should_randomize, Option_t * opt = 0) = 0;
virtual void TweakSystematic (std::string syst_name, double twkdial=0., Option_t * opt = 0) = 0;
virtual void TweakSystematic (conv::PhysParamId_t syst, double twkdial=0., Option_t * opt = 0) = 0;
virtual void ResetSystematics (Option_t * opt = 0) = 0;
virtual void PrintSystematics (std::ostream & stream = std::cout, Option_t * opt = 0) const = 0;
virtual PhysParamList Tweaks(Option_t * opt = 0) const = 0;
virtual bool Generate (const FitParamList & fp, Option_t * opt = 0) = 0;
virtual bool Write (TObjArray* collection, const char * tag = "model", Option_t * write_opt = 0) = 0;
virtual bool Write (const char * filename, const char * tag = "model", Option_t * write_opt = 0, Option_t * file_opt = 0) = 0;
virtual double GetFitStatisticPenalty(Option_t * opt = 0) const = 0;
virtual void SetSystConf(CorrelatedSystematics * syst, Option_t * opt = "") = 0;
virtual CorrelatedSystematics * GetSystematics(Option_t * opt = "") = 0;
virtual const CorrelatedSystematics * GetSystematics(Option_t * opt = "") const = 0;
protected:
FitModelABC();
};
}
#endif
#ifndef _valor_fitter_abc_h_
#define _valor_fitter_abc_h_
namespace valor {
class FitterABC
{
public:
virtual ~FitterABC();
virtual bool Configure (const Registry & conf) = 0;
virtual bool DoTheFit (void) = 0;
virtual int FitStatusCode (Option_t * option = "") const = 0;
virtual double FitTime (void) const = 0;
virtual int FitNTries (void) const = 0;
virtual int NDOF (void) const = 0;
virtual int NBinsInFit (void) const = 0;
virtual int NFitParams (void) const = 0;
virtual void SetTol (double tol) = 0;
virtual void SetStr (int str ) = 0;
protected:
FitterABC();
};
}
#endif
#ifndef _valor_corr_syst_h_
#define _valor_corr_syst_h_
namespace valor {
class FitParamList;
class PhysParamList;
class CorrelatedSystematics : public TNamed
{
public:
CorrelatedSystematics(unsigned int n_syst, const conv::PhysParamId_t * syst_params, const std::string & xml_node_name = "syst");
CorrelatedSystematics(const CorrelatedSystematics & c);
virtual ~CorrelatedSystematics();
bool Read (TXMLEngine* xml, XMLNodePointer_t root_node);
const TMatrixD & CovMatrix (void) const { return *fCovMtrx; }
const TMatrixD & CovMatrixInv (void) const { return *fCovMtrxInv; }
const TMatrixD & CovMatrixCholesky (void) const { return *fCovMtrxChoL; }
const TMatrixD & CovMatrixCholeskyInv(void) const { return *fCovMtrxChoLInv; }
const TVectorD & UntunedValues (void) const { return *fUntunedValues; }
const TVectorD & InitialValues (void) const { return *fInitialValues; }
const TVectorD & CurrentValues (void) const { return *fCurrentValues; }
double OneSigmaError(conv::PhysParamId_t p) const;
double OneSigmaErrorByIndex(int idx) const;
double CovMatrixElement(conv::PhysParamId_t p1, conv::PhysParamId_t p2) const;
double CovMatrixElementByIndex(int idx1, int idx2) const;
double FitStatisticPenalty (Option_t * opt = 0) const;
double ChisqPenalty (bool all_syst = true) const;
void Tweak(bool force_inputs, const TVectorD * input_vec, Option_t * opt = 0);
void Tweak(bool force_inputs, const TVectorD * input_vec, const std::map<valor::conv::PhysParamId_t,bool> & should_tweak, Option_t * opt = 0);
void Tweak(bool force_inputs, const TVectorD * input_vec, bool (* use_twk_param)(conv::PhysParamId_t), Option_t * opt = 0);
double CurrentValueByIndex(int idx) const;
double CurrentValue(conv::PhysParamId_t p) const;
double UntunedValueByIndex(int idx) const;
double UntunedValue(conv::PhysParamId_t p) const;
double InitialValueByIndex(int idx) const;
double InitialValue(conv::PhysParamId_t p) const;
void SetCurrentValueByIndex(int idx, double value);
void SetCurrentValue(conv::PhysParamId_t p, double value);
void SetCovMatrix(const TMatrixD & matr);
bool Contains(conv::PhysParamId_t p) const;
unsigned int Size(void) const;
conv::PhysParamId_t WhichParam(int idx) const;
const conv::PhysParamId_t * GetParameters() const {return fSystParameters;}
bool IsTweaked (void) const { return fIsTweaked; }
bool IsConfigured(void) const { return fIsConfigured;}
void PrintSystematicVariations (std::ostream & stream = std::cout) const;
void UpdateFrom (const valor::FitParamList & fpl);
void UpdateFrom (const valor::PhysParamList & ppl);
void UpdateCentralValuesAndCovarianceFromFPL(const valor::FitParamList & fpl);
bool AppendParamsTo (valor::FitParamList & fpl ) const;
void CopyTweaksTo (valor::FitParamList & fpl ) const;
void CopyTweaksTo (valor::PhysParamList & ppl ) const;
void CopyOneSigmaErrorsTo(valor::PhysParamList & ppl ) const;
using TObject::Read;
using TObject::Draw;
void SetXMLNodeName(std::string xml_node_name);
std::string GetXMLNodeName(void) const;
int Param2Idx (conv::PhysParamId_t p) const;
conv::PhysParamId_t Idx2Param (int index) const;
protected:
CorrelatedSystematics();
void Init (unsigned int n_syst, const conv::PhysParamId_t * syst_params, const std::string & xml_node_name = "syst");
void CleanUp (void);
void FillParam2Idx(void);
void CholeskyDecomposeMatrix (void);
void InvertMatrices (void);
TVectorD * fDefaultValues;
TVectorD * fUntunedValues;
TVectorD * fInitialValues;
TVectorD * fCurrentValues;
TMatrixD * fCovMtrx;
TMatrixD * fCovMtrxInv;
TMatrixD * fCovMtrxChoL;
TMatrixD * fCovMtrxChoLInv;
bool fIsTweaked;
double * fUntunedArray;
double * fInitialArray;
double * fCurrentArray;
int fParam2Idx[conv::knppmax];
unsigned int fNSystParameters;
conv::PhysParamId_t * fSystParameters;
std::string fXMLNodeName;
bool fIsConfigured;
ClassDef(CorrelatedSystematics, 1)
};
}
#endif
#ifndef _valor_compound_syst_h_
#define _valor_compound_syst_h_
namespace valor {
class CompoundCorrelatedSystematics: public CorrelatedSystematics
{
public:
CompoundCorrelatedSystematics(const std::vector<const valor::CorrelatedSystematics*> & vec,
std::string xml_node_name = "syst",std::string name = "Systematics");
CompoundCorrelatedSystematics(unsigned int n_cov_matrices,
const CorrelatedSystematics * const * syst_objs,
std::string xml_node_name = "syst",std::string name = "Systematics");
virtual ~CompoundCorrelatedSystematics();
private:
void CompoundInit(unsigned int n_cov_matrices,
const CorrelatedSystematics * const * syst_objs,
std::string xml_node_name = "syst");
ClassDef(CompoundCorrelatedSystematics, 1)
};
}
#endif
#ifndef _valor_compound_fit_data_h_
#define _valor_compound_fit_data_h_
namespace valor {
class FitModelABC;
class FitParamList;
class PhysHypothesis;
class CompoundFitData : public FitDataABC
{
public:
CompoundFitData();
~CompoundFitData();
virtual string Name(void) const;
virtual bool Read(string file, Option_t * opt = 0);
virtual bool Generate (FitModelABC * model, const FitParamList & fp, bool fluctuate=true);
virtual bool Generate (FitModelABC * model, const PhysHypothesis & ph, bool fluctuate=true);
virtual bool Generate (FitModelABC * model, bool fluctuate=true);
virtual bool Write (TObjArray * collection, const char * tag = "data", Option_t * write_opt = 0);
virtual bool Write (const char * filename, const char * tag = "data", Option_t * write_opt = 0, Option_t * file_opt = 0);
virtual int NumOfBins (Option_t * opt = 0) const;
virtual double GetFitStatistic (FitModelABC * pred, const FitParamList & fp, Option_t * stat_opt = "likelihood-ratio", std::map<std::string,double> * likelihood_components = 0);
virtual double GetFitStatistic (FitModelABC * pred, const PhysHypothesis & ph, Option_t * stat_opt = "likelihood-ratio", std::map<std::string,double> * likelihood_components = 0);
virtual double GetFitStatistic (FitModelABC * pred, Option_t * stat_opt = "likelihood-ratio", std::map<std::string,double> * likelihood_components = 0);
virtual void AddSubData(FitDataABC * data, Option_t * opt = 0);
virtual const FitDataABC * GetSubData(int data_idx, Option_t * opt = 0) const;
virtual FitDataABC * GetSubData(int data_idx, Option_t * opt = 0);
virtual unsigned int GetNSubData(Option_t * opt = 0) const;
void SetName(std::string name);
protected:
std::string fName;
std::vector<FitDataABC *> fSubData;
};
}
#endif
#ifndef _valor_compound_fit_model_h_
#define _valor_compound_fit_model_h_
class TObjArray;
namespace valor {
class CompoundFitModel : public FitModelABC
{
public:
CompoundFitModel();
~CompoundFitModel();
virtual std::string Name(void) const ;
virtual bool Read(std::string file, Option_t * opt = 0) ;
virtual bool Generate (const PhysHypothesis & ph, Option_t * opt = 0) ;
virtual void RandomizeSystematics (Option_t * opt = 0);
virtual void RandomizeSystematics (bool (*should_randomize)(conv::PhysParamId_t), Option_t * opt = 0);
virtual void RandomizeSystematics (std::map<valor::conv::PhysParamId_t, bool> should_randomize, Option_t * opt = 0);
virtual void TweakSystematic (std::string syst_name, double twkdial=0., Option_t * opt = 0) ;
virtual void TweakSystematic (conv::PhysParamId_t syst, double twkdial=0., Option_t * opt = 0) ;
virtual void ResetSystematics (Option_t * opt = 0) ;
virtual void PrintSystematics (std::ostream & stream = std::cout, Option_t * opt = 0) const ;
virtual PhysParamList Tweaks(Option_t * opt = 0) const ;
virtual bool Generate (const FitParamList & fp, Option_t * opt = 0) ;
virtual bool Write (TObjArray* collection, const char * tag = "model", Option_t * write_opt = 0) ;
virtual bool Write (const char * filename, const char * tag = "model", Option_t * write_opt = 0, Option_t * file_opt = 0) ;
virtual double GetFitStatisticPenalty(Option_t * opt = 0) const ;
virtual void AddSubModel(FitModelABC * model, Option_t * opt = 0);
virtual const FitModelABC * GetSubModel(int model_idx, Option_t * opt = 0) const;
virtual FitModelABC * GetSubModel(int model_idx, Option_t * opt = 0);
virtual unsigned int GetNSubModels(Option_t * opt = 0) const;
virtual void SetSystConf(CorrelatedSystematics * syst, Option_t * opt = "");
virtual CorrelatedSystematics * GetSystematics(Option_t * opt = "");
virtual const CorrelatedSystematics * GetSystematics(Option_t * opt = "") const;
void SetName(std::string name);
protected:
std::string fName;
std::vector<FitModelABC *> fSubModels;
CorrelatedSystematics * fSystematics;
bool fOwnerOfSystematics;
};
}
#endif
#ifndef _valor_fitter_minuit_h_
#define _valor_fitter_minuit_h_
namespace valor {
class FitInputs;
class FitterMinuit: public FitterABC
{
public:
FitterMinuit();
FitterMinuit(FitInputs * inputs, Option_t * option = "minuit");
virtual ~FitterMinuit();
virtual bool Configure (const Registry & conf);
virtual bool DoTheFit (void);
virtual int FitStatusCode (Option_t * option = "") const;
virtual double FitTime (void) const { return fFitTime; }
virtual int FitNTries (void) const { return fFitTries; }
virtual int NDOF (void) const { return fNFitBins - fNFreeFitParams; }
virtual int NBinsInFit (void) const { return fNFitBins; }
virtual int NFitParams (void) const { return fNFreeFitParams; }
virtual void SetTol (double tol) { fTol = tol ; }
virtual void SetStr (int str ) { fStr = str ; }
virtual void SetMaxCalls (int ncalls) { fMaxNumCalls = ncalls ; }
protected:
void Init (void);
void Init (FitInputs * fit_inputs, Option_t * option = "minuit");
bool RunOnce (bool use_simplex);
FitInputs* fFitInputs;
TString fOption;
int fMigradMinStatusCode;
int fMigradErrStatusCode;
int fHesseErrStatusCode;
int fMinosErrStatusCode;
double fFitTime;
int fFitTries;
int fNFitBins;
int fNFreeFitParams;
bool fCalcHesseErrors;
bool fCalcMinosErrors;
double fTol;
int fStr;
int fPrintLevel;
int fMaxNumCalls;
};
}
#endif
#ifndef _valor_fitter_minuit2_h_
#define _valor_fitter_minuit2_h_
namespace valor {
class FitInputs;
class FitterMinuit2: public FitterABC
{
public:
FitterMinuit2();
FitterMinuit2(FitInputs * inputs, Option_t * option = "minuit2");
virtual ~FitterMinuit2();
virtual bool Configure (const Registry & conf);
virtual bool DoTheFit (void);
virtual int FitStatusCode (Option_t * option = "") const;
virtual double FitTime (void) const { return fFitTime; }
virtual int FitNTries (void) const { return fFitTries; }
virtual int NDOF (void) const;
virtual int NBinsInFit (void) const { return fNFitBins; }
virtual int NFitParams (void) const;
virtual void SetTol (double tol) { fTol = tol ; }
virtual void SetStr (int str ) { fStr = str ; }
virtual void SetMaxCalls (int ncalls) { fMaxNumCalls = ncalls ; }
protected:
void Init (void);
void Init (FitInputs * fit_inputs, Option_t * option = "minuit2");
bool RunOnce (void);
void FillPriorCovMatrix(Option_t * opt = "");
void CopyCovarianceToFPL(const ROOT::Minuit2::MnUserCovariance & mncov);
FitInputs* fFitInputs;
TString fOption;
int fMigradMinStatusCode;
int fMigradErrStatusCode;
int fHesseErrStatusCode;
int fMinosErrStatusCode;
double fFitTime;
int fFitTries;
int fNFitBins;
bool fCalcHesseErrors;
bool fCalcMinosErrors;
double fTol;
int fMaxNumCalls;
int fStr;
TMatrixD fCovMtrx;
ROOT::Minuit2::MnUserParameters fUserParams;
bool fUseFumili;
};
}
#endif
#ifndef _valor_fitter_utilities_h_
#define _valor_fitter_utilities_h_
namespace valor {
namespace util {
FitterABC * GetFitter (FitInputs * inputs, Option_t * option);
double RandomiseParametersByAcceptance(FitInputs & fi, const TMatrixD * cholesky_for_throws = 0,
int max_attempts = 100000, double scaling_factor = 1.);
bool AttemptMCMCStep(FitInputs & fitinputs, double & current_chisq, int & n_attempts_out,
double step_size_factor, const TMatrixD * cholesky_for_throws = NULL, int max_attempts = 1000);
TMatrixDSym CalculateCovariance(std::vector<valor::PhysParamList> param_sets,
const CorrelatedSystematics & example_format);
}
}
#endif
#ifndef _valor_kinematical_binning_cuboid_honeycomb_edge_to_edge_h_
#define _valor_kinematical_binning_cuboid_honeycomb_edge_to_edge_h_
namespace valor {
class KBCubHcmbEdge2Edge: public TNamed
{
public:
KBCubHcmbEdge2Edge();
KBCubHcmbEdge2Edge(string name, string title);
virtual ~KBCubHcmbEdge2Edge();
bool Read(string file);
using TObject::Read;
KBCubHcmbEdge2Edge* Contract(conv::KineSpace_t ks) const;
conv::KineSpace_t KineSpace(void) const { return fKineSpace; }
unsigned int NDimensions (void) const { return fNDimensions; }
const std::vector<valor::conv::KineVar_t> & KineVars (void) const { return fKineVars; }
conv::KineVar_t KineVar(unsigned int dimension);
unsigned int Dimension(conv::KineVar_t kv) const;
bool Contains(conv::KineVar_t kv) const;
unsigned int NBins (unsigned int dimension ) const;
unsigned int NBins (conv::KineVar_t kv ) const;
unsigned int NBins (void) const;
bool FixedWidth (unsigned int dimension ) const;
bool FixedWidth (conv::KineVar_t kv ) const;
bool VariableWidth (unsigned int dimension ) const;
bool VariableWidth (conv::KineVar_t kv ) const;
double Minimum (unsigned int dimension ) const;
double Minimum (conv::KineVar_t kv ) const;
double Maximum (unsigned int dimension ) const;
double Maximum (conv::KineVar_t kv ) const;
double BinMinimum (unsigned int linearized_bin, unsigned int dimension ) const;
double BinMinimum (unsigned int linearized_bin, conv::KineVar_t kv ) const;
double BinMaximum (unsigned int linearized_bin, unsigned int dimension ) const;
double BinMaximum (unsigned int linearized_bin, conv::KineVar_t kv ) const;
std::vector<double> BinRange (unsigned int linearized_bin, unsigned int dimension ) const;
std::vector<double> BinRange (unsigned int linearized_bin, conv::KineVar_t kv ) const;
double BinWidth (unsigned int linearized_bin, unsigned int dimension ) const;
double BinWidth (unsigned int linearized_bin, conv::KineVar_t kv ) const;
std::vector<double> BinWidth (unsigned int linearized_bin ) const;
double BinCentre (unsigned int linearized_bin, unsigned int dimension ) const;
double BinCentre (unsigned int linearized_bin, conv::KineVar_t kv ) const;
std::vector<double> BinCentre (unsigned int linearized_bin ) const;
const double * BinEdgeArr (unsigned int dimension ) const;
const double * BinEdgeArr (conv::KineVar_t kv ) const;
const VALORArray * BinEdgeVArr (unsigned int dimension ) const;
const VALORArray * BinEdgeVArr (conv::KineVar_t kv ) const;
unsigned int FindBin (double x, unsigned int dimension) const;
unsigned int FindBin (double x, conv::KineVar_t kv) const;
unsigned int FindBin (std::vector<double>& xarr) const;
std::vector<unsigned int> FindBinArr (std::vector<double> & xarr) const;
unsigned int FindLinearizedBin (std::vector<double> & xarr) const;
unsigned int LinearizedBin (std::vector<unsigned int> & binarr) const;
std::vector<unsigned int> BinArr (unsigned int linearized_bin) const;
unsigned int Bin (unsigned int linearized_bin, unsigned int dimension) const;
protected:
void Init (void);
void CleanUp (void);
conv::KineSpace_t fKineSpace;
unsigned int fNDimensions;
std::vector<conv::KineVar_t> fKineVars;
std::map<conv::KineVar_t, unsigned int> fKineVar2Dim;
std::vector<bool> fFixedWidth;
std::vector<double> fMinimum;
std::vector<double> fMaximum;
std::vector<VALORArray*> fBinEdges;
ClassDef(KBCubHcmbEdge2Edge, 1)
};
}
#endif
#ifndef _valor_kinematical_binning_cuboid_honeycomb_mondrian_h_
#define _valor_kinematical_binning_cuboid_honeycomb_mondrian_h_
namespace valor {
class KBCubHcmbEdge2Edge;
class KBCubHcmbMondrian: public TNamed
{
public:
KBCubHcmbMondrian();
KBCubHcmbMondrian(string name, string title);
virtual ~KBCubHcmbMondrian();
using TObject::Read;
bool Read(string file);
conv::KineSpace_t KineSpace(void) const { return fKineSpace; }
unsigned int NDimensions (void) const { return fNDimensions; }
const std::vector<valor::conv::KineVar_t> & KineVars (void) const { return fKineVars; }
conv::KineVar_t KineVar(unsigned int dimension);
unsigned int Dimension(conv::KineVar_t kv) const;
bool Contains(conv::KineVar_t kv) const;
int NBins (void) const { return fNBins; }
KBCubHcmbMondrian* Contract(conv::KineSpace_t ks) const;
double Minimum (unsigned int dimension ) const;
double Minimum (conv::KineVar_t kv ) const;
double Maximum (unsigned int dimension ) const;
double Maximum (conv::KineVar_t kv ) const;
double BinMinimum (unsigned int bin, unsigned int dimension ) const;
double BinMinimum (unsigned int bin, conv::KineVar_t kv ) const;
double BinMaximum (unsigned int bin, unsigned int dimension ) const;
double BinMaximum (unsigned int bin, conv::KineVar_t kv ) const;
std::vector<double> BinRange (unsigned int bin, unsigned int dimension ) const;
std::vector<double> BinRange (unsigned int bin, conv::KineVar_t kv ) const;
double BinWidth (unsigned int bin, unsigned int dimension ) const;
double BinWidth (unsigned int bin, conv::KineVar_t kv ) const;
std::vector<double> BinWidth (unsigned int bin ) const;
double BinCentre (unsigned int bin, unsigned int dimension ) const;
double BinCentre (unsigned int bin, conv::KineVar_t kv ) const;
std::vector<double> BinCentre (unsigned int bin ) const;
unsigned int FindBin (std::vector<double> & xarr) const;
void UseEdge2EdgeBinning(const KBCubHcmbEdge2Edge * kbe2e);
unsigned int MapFromLinearizedE2E(unsigned int e2e_linearized_bin) const;
std::vector<TLine> GetBinningTLines(void) const;
TH2D* ToTH2D(conv::KineVar_t kv1 = conv::kvUndefined,
conv::KineVar_t kv2 = conv::kvUndefined) const;
protected:
void Init (void);
void CleanUp (void);
conv::KineSpace_t fKineSpace;
unsigned int fNDimensions;
std::vector<conv::KineVar_t> fKineVars;
std::map<conv::KineVar_t, unsigned int> fKineVar2Dim;
unsigned int fNBins;
std::vector<double> fBinEdges;
std::vector<double> fMinimum;
std::vector<double> fMaximum;
const KBCubHcmbEdge2Edge * fKBE2E;
std::map<unsigned int, unsigned int> fBinMondrianFromE2E;
std::multimap<unsigned int, unsigned int> fBinMondrianToE2E;
ClassDef(KBCubHcmbMondrian, 1)
};
}
#endif
#ifndef _valor_standard_output_fit_ntuple_h_
#define _valor_standard_output_fit_ntuple_h_
class TFile;
class TTree;
class TObjArray;
namespace valor {
class PhysParamList;
class FitParamList;
class StdFitNtp
{
public:
StdFitNtp();
virtual ~StdFitNtp();
void Create (const char* file_name, const char* ntp_name = "valor_ntp", const char* ntp_label = "");
void Fill (void);
void Reset (void);
void Save (void);
TFile * OutputFile (void) const { return fOutFile; }
TTree * OutputValorResultTree (void) const { return fVTree; }
PhysParamList * TrueParamArr (void) const { return fTrueParamArr; }
FitParamList * BestFitParamArr (void) const { return fBestFitParamArr; }
TObjArray * BestFitModelArr (void) const { return fBestFitModelArr; }
TObjArray * DataArr (void) const { return fDataArr; }
protected:
void Init (void);
void Clean (void);
TFile * fOutFile;
TTree * fVTree;
PhysParamList * fTrueParamArr;
FitParamList * fBestFitParamArr;
TObjArray * fBestFitModelArr;
TObjArray * fDataArr;
};
}
#endif
#ifndef _NuOsc3Flavour_
#define _NuOsc3Flavour_
namespace valor {
class NuOsc3Flavour
{
public:
NuOsc3Flavour();
~NuOsc3Flavour();
static int const nFlav = 3;
void SetBaseline (double length);
void SetDensity (double density);
void SetMassHierarchy (valor::conv::NuMassHierarchy_t h);
void SetOscParameters (double sinsq2theta12,
double sinsq2theta13,
double sinsq2theta23,
double dmsq12,
double dmsq23,
double deltaCP
);
void SetOscParametersSinSqTAll (double sinsqtheta12,
double sinsqtheta13,
double sinsqtheta23,
double dmsq12,
double dmsq23,
double deltaCP
);
void SetOscParametersSinSqTAllSinDeltaCP(double sinsqtheta12,
double sinsqtheta13,
double sinsqtheta23,
double dmsq12,
double dmsq23,
double sindeltaCP
);
void SetOscParametersSSq2TDmAtmSol (double sinsq2theta12,
double sinsq2theta13,
double sinsq2theta23,
double dmsq12,
double dmsqAtm,
double deltaCP
);
void SetOscParametersDmsqAtmSol(double sinsqtheta12,
double sinsqtheta13,
double sinsqtheta23,
double dmsq12,
double dmsqAtm,
double deltaCP
);
void SetOscParametersDmsqAtmSolSinDeltaCP(double sinsqtheta12,
double sinsqtheta13,
double sinsqtheta23,
double dmsq12,
double dmsqAtm,
double sindeltaCP
);
void SetOscParametersSSq2TDmsq13(double sinsq2theta12,
double sinsq2theta13,
double sinsq2theta23,
double dmsq12,
double dmsq13,
double deltaCP);
void SetOscParametersDmsq13(double sinsqtheta12,
double sinsqtheta13,
double sinsqtheta23,
 double dmsq12,
double dmsq13,
 double deltaCP);
void SetOscParametersDmsq13SinDeltaCP(double sinsqtheta12,
 double sinsqtheta13,
 double sinsqtheta23,
 double dmsq12,
 double dmsq13,
 double sindeltaCP);
double CalcVacuumOscProb (int nu_start, int nu_end, double energy);
double CalcVacuumOscProbPDG (int nu_start, int nu_end, double energy);
double CalcMatterOscProb (int nu_start, int nu_end, double energy);
double Calc2FlavMatterOscProb (int nu_start, int nu_end, double energy, int index);
void CalcMatterOscProbAll(bool isAntineutrino, double energy, double osc_probs_out[3][3]);
double GetBaseline (void) const;
double GetDensity (void) const;
valor::conv::NuMassHierarchy_t GetMassHierarchy(void) const;
void CalcPMNSElements(double s12, double c12, double s13, double c13, double s23, double c23, double dmsq21, double dmsq31, double deltaCP);
std::complex<double> GetPMNSElement(int row, int column);
private:
enum {
re,
im
};
void Init(void);
valor::conv::NuMassHierarchy_t fMassHierarchy;
double fBaseline;
double fNe;
double dmsq23;
double dmsq12;
double dmsq13;
double dmsqAtm;
double PMNSVacuum[3][3][2];
double modUe1sq;
double modUe2sq;
double modUe3sq;
double modUmu1sq;
double modUmu2sq;
double modUmu3sq;
double modUtau1sq;
double modUtau2sq;
double modUtau3sq;
double Re12;
double Im12;
double arg12;
double Re13;
double Im13;
double arg13;
double Re23;
double Im23;
double arg23;
double UMassUdaggerVacuum[3][3][2];
bool useEquations12;
int nFlavourIndex;
};
}
#endif
#ifndef _NuOscSterile_
#define _NuOscSterile_
namespace valor {
class NuOscSterile
{
public:
NuOscSterile();
~NuOscSterile();
static int const nFlav = 5;
void SetBaseline (double length);
void SetDensity (double density);
void SetMassHierarchy (valor::conv::NuMassHierarchy_t h);
void SetSterileMassHierarchy(int h);
void SetMixingAngles (double sinsqtheta12,
double sinsqtheta13,
double sinsqtheta14,
 double sinsqtheta15,
double sinsqtheta23,
double sinsqtheta24,
 double sinsqtheta25,
double sinsqtheta34,
double sinsqtheta35
 );
void SetMixingDoubleAnglesOct1(double sinsq2theta12,
double sinsq2theta13,
double sinsq2theta14,
double sinsq2theta15,
double sinsq2theta23,
double sinsq2theta24,
double sinsq2theta25,
double sinsq2theta34,
double sinsq2theta35);
void SetMixingDoubleAnglesOct2(double sinsq2theta12,
double sinsq2theta13,
double sinsq2theta14,
double sinsq2theta15,
 double sinsq2theta23,
double sinsq2theta24,
double sinsq2theta25,
double sinsq2theta34,
double sinsq2theta35);
void SetDmsq (double dm21sq,
 double dm31sq,
 double dm41sq,
 double dm51sq
 );
void SetDeltaCP (double dcp12,
 double dcp13,
 double dcp15,
 double dcp34,
 double dcp35
 );
void SetVacuumPMNSReal(double Ue1, double Ue2, double Ue3, double Ue4, double Ue5,
double Umu1, double Umu2, double Umu3, double Umu4, double Umu5,
double Utau1, double Utau2, double Utau3, double Utau4, double Utau5,
double U41, double U42, double U43, double U44, double U45,
double U51, double U52, double U53, double U54, double U55
);
void SetVacuumPMNSIm (double Ue1, double Ue2, double Ue3, double Ue4, double Ue5,
double Umu1, double Umu2, double Umu3, double Umu4, double Umu5,
double Utau1, double Utau2, double Utau3, double Utau4, double Utau5,
double U41, double U42, double U43, double U44, double U45,
double U51, double U52, double U53, double U54, double U55
 );
void SetVacuumPMNSImToZero();
void SetVacuumPMNSElementByIndex(int iflav , int imass, double real, double imag);
void SetVacuumPMNSElementByType (int nu_pdg, int nmass, double real, double imag);
void CalcVacuumPMNS ();
bool Check3FlavPMNS ();
void CalcMEProduct (int nu_start,
int nu_end,
int mass1,
int mass2
 );
double CalcVacuumOscProb(int nu_start,
 int nu_end,
double energy);
double CalcMatterOscProb(int nu_start,
int nu_end,
double energy);
 
void CalcMatterOscProbAll(bool isAntineutrino, double energy, double * osc_probs_out);
valor::conv::NuMassHierarchy_t GetMassHierarchy(void) const;
private:
enum {
re,
im
};
void Init(void);
valor::conv::NuMassHierarchy_t fMassHierarchy;
int fSterileMassHierarchy;
double fBaseline;
double fNe;
bool usingOscParams;
double sinMixingAngle[nFlav][nFlav];
double cosMixingAngle[nFlav][nFlav];
double dmsq[nFlav][nFlav];
double deltaCP[nFlav][nFlav];
double rotationMatrix[nFlav][nFlav][nFlav][nFlav][2];
double UVacuum[nFlav][nFlav][2];
double MEProduct[2];
};
}
#endif
#ifndef _valor_osc_params_h_
#define _valor_osc_params_h_
namespace valor {
namespace util {
class OscParams {
public:
static OscParams * Instance(void);
void SetValues(double input_mixing12_nh, double input_mixing13_nh, double input_mixing23_nh,
double input_deltacp_nh, double input_dm12sq_nh, double input_dm23sq_nh,
double input_beta_bar,
double input_mixing12_ih, double input_mixing13_ih, double input_mixing23_ih,
double input_deltacp_ih, double input_dm12sq_ih, double input_dm23sq_ih,
double mh_nh_prior, bool marginalize_MH,
double input_mixing12bar_nh, double input_mixing13bar_nh, double input_mixing23bar_nh,
double input_dcpbar_nh, double input_dm12sqbar_nh, double input_dm23sqbar_nh,
double input_mixing12bar_ih, double input_mixing13bar_ih, double input_mixing23bar_ih,
double input_dcpbar_ih, double input_dm12sqbar_ih, double input_dm23sqbar_ih
);
void Randomize();
void UpdatePhysHypothesis(PhysHypothesis & ph, bool print = true);
void UpdateFitParamList (FitParamList * fparm, bool set_init, bool print = false);
void FillOscToyHisto(PhysHypothesis &ph);
TH1D *GetToyHisto(string oscparam,string MH="normal");
void Write(TFile * f);
void Print (ostream & stream) const;
void Print_Toys (ostream & stream) const;
friend ostream & operator << (ostream & stream, const OscParams & oscparams);
void SetPrior(conv::PhysParamId_t physpar,string mode,double par1,double par2, string mixmode="");
double ExtractParam(conv::PhysParamId_t physpar,string mode,double par1,double par2,string mixmode="");
string mixmode_mixing12;
string mixmode_mixing13;
string mixmode_mixing23;
string priormode_mixing12;
string priormode_mixing13;
string priormode_mixing23;
string priormode_dcp;
string priormode_dm12sq;
string priormode_dm23sq;
double params_mixing12[2];
double params_mixing13[2];
double params_mixing23[2];
double params_dcp[2];
double params_dm12sq[2];
double params_dm23sq[2];
double mixing12_nh;
double mixing13_nh;
double mixing23_nh;
double dcp_nh;
double dm12sq_nh;
double dm23sq_nh;
double mixing12_ih;
double mixing13_ih;
double mixing23_ih;
double dcp_ih;
double dm12sq_ih;
double dm23sq_ih;
double mixing12bar_nh;
double mixing13bar_nh;
double mixing23bar_nh;
double dcpbar_nh;
double dm12sqbar_nh;
double dm23sqbar_nh;
double mixing12bar_ih;
double mixing13bar_ih;
double mixing23bar_ih;
double dcpbar_ih;
double dm12sqbar_ih;
double dm23sqbar_ih;
double beta_bar;
bool randomize_mixing12_nh;
bool randomize_mixing13_nh;
bool randomize_mixing23_nh;
bool randomize_dcp_nh;
bool randomize_dm12sq_nh;
bool randomize_dm23sq_nh;
bool randomize_mixing12_ih;
bool randomize_mixing13_ih;
bool randomize_mixing23_ih;
bool randomize_dcp_ih;
bool randomize_dm12sq_ih;
bool randomize_dm23sq_ih;
bool randomize_mixing12bar_nh;
bool randomize_mixing13bar_nh;
bool randomize_mixing23bar_nh;
bool randomize_dcpbar_nh;
bool randomize_dm12sqbar_nh;
bool randomize_dm23sqbar_nh;
bool randomize_mixing12bar_ih;
bool randomize_mixing13bar_ih;
bool randomize_mixing23bar_ih;
bool randomize_dcpbar_ih;
bool randomize_dm12sqbar_ih;
bool randomize_dm23sqbar_ih;
bool randomize_beta_bar;
double mh_nh_prior;
int iMH;
conv::NuMassHierarchy_t MH;
bool marginalize_mh;
std::string priors_file;
TH2D * hPrior_th13_dcp_nh;
TH2D * hPrior_th13_dcp_ih;
TH2D * hPrior_23_nh;
TH2D * hPrior_23_ih;
TH1D *hToyHisto_dcp_nh;
TH1D *hToyHisto_Mix13_nh;
TH1D *hToyHisto_Mix23_nh;
TH1D *hToyHisto_Dm23_nh;
TH1D *hToyHisto_Mix12_nh;
TH1D *hToyHisto_Dm12_nh;
TH1D *hToyHisto_dcp_ih;
TH1D *hToyHisto_Mix13_ih;
TH1D *hToyHisto_Mix23_ih;
TH1D *hToyHisto_Dm23_ih;
TH1D *hToyHisto_Mix12_ih;
TH1D *hToyHisto_Dm12_ih;
TH1D *hToyHisto_MH;
TH1D *hToyHisto_dcpBar_nh;
TH1D *hToyHisto_Mix13Bar_nh;
TH1D *hToyHisto_Mix23Bar_nh;
TH1D *hToyHisto_Dm23Bar_nh;
TH1D *hToyHisto_Mix12Bar_nh;
TH1D *hToyHisto_Dm12Bar_nh;
TH1D *hToyHisto_dcpBar_ih;
TH1D *hToyHisto_Mix13Bar_ih;
TH1D *hToyHisto_Mix23Bar_ih;
TH1D *hToyHisto_Dm23Bar_ih;
TH1D *hToyHisto_Mix12Bar_ih;
TH1D *hToyHisto_Dm12Bar_ih;
private:
static OscParams * fInstance;
void Init();
void Cleanup();
OscParams();
OscParams(const OscParams & opt);
virtual ~OscParams();
struct Cleaner {
void DummyMethodAndSilentCompiler() { }
~Cleaner() {
if (OscParams::fInstance != 0) {
delete OscParams::fInstance;
OscParams::fInstance = 0;
}
}
};
friend struct Cleaner;
};
ostream & operator << (ostream & stream, const OscParams & oscparams);
}
}
#endif
#ifndef valor_osc_simple_h
#define valor_osc_simple_h
namespace valor {
namespace util {
double Calculate2FSterileOsc(int init_pdg, int final_pdg, double lOverE, double sinsq2thee, double sinsqthmumu, double dmsq);
double FlipOctantAroundMaxDisap(double sinsqth23, double sinsqth13);
}
}
#endif
#ifndef _valor_confidence_interval_h_
#define _valor_confidence_interval_h_
namespace valor {
class ConfidenceInterval;
class ConfidenceInterval: public TNamed {
public:
ConfidenceInterval(string in_file_name, string confidence, conv::PhysParamId_t par_x, conv::PhysParamId_t par_y, bool avg_or_min_delta_chi2, bool find_delta_chi2);
~ConfidenceInterval();
double *GetBestFitPoint() {return best_fit_point;}
double *GetLimits() {return hist_limits;}
TObjArray *GetConfidenceInterval() const {return output_graphs;}
TH2D *GetChi2Data_2D() const {return chi2_2D;}
TH1D *GetChi2Data_1D() const {return chi2_1D;}
ClassDef(ConfidenceInterval,1);
private:
ConfidenceInterval();
void Generate(string in_file_name, string confidence, bool avg_or_min_delta_chi2, bool find_delta_chi2);
void GetBinningAndData(TChain* chain);
void FillHists(bool avg_or_min_delta_chi2);
void Checks();
void FindDelta();
double FindCriticalChi2(string confidence, bool find_delta_chi2);
void FixFailure(double chi2_crit);
void GenerateContour(double chi2_crit);
double Sign(double num);
conv::PhysParamId_t param_x;
conv::PhysParamId_t param_y;
unsigned int n_bins_x, n_bins_y, n_bins;
double min_chi2, bin_low_x, bin_high_x, bin_low_y, bin_high_y;
double scale_limits;
std::vector<double> x_vals, y_vals, chi2_vals;
double best_fit_point[3];
double hist_limits[4]; 
TObjArray *output_graphs;
TH2D *chi2_2D;
TH2D *n_entries_2D;
TH1D * chi2_1D;
};
}
#endif
#ifndef _valor_confidence_interval_plotter_h_
#define _valor_confidence_interval_plotter_h_
namespace valor {
class ConfidenceIntervalPlotter;
class ConfidenceIntervalPlotter: public TNamed {
public:
ConfidenceIntervalPlotter(conv::PhysParamId_t par_x, conv::PhysParamId_t par_y, bool avg_or_min_delta_chi2, bool find_delta_chi2, string input_titles);
~ConfidenceIntervalPlotter();
void Add(string data_file, string confidence);
void Draw(TCanvas *canvas);
void SetRangeManually(double x_low, double y_low, double x_high, double y_high);
void SetChiSqLineColor(short int col) {line_colour = col;}
void SetChiSqLineStyle(Style_t sty) {line_style = sty;}
void SetChiSqLineLabel(string lab) {label = lab;}
void SetBestFitColor(short int col) {bf_colour = col;} 
void SetBestFitStyle(Style_t sty) {bf_style = sty;} 
void SetBestFitSize(Size_t siz) {bf_size = siz;} 
void SetDataLineColor(short int col) {hist_colour = col;} 
void SetDataLineStyle(Style_t sty) {hist_style = sty;} 
void SetDataLineLabel(string lab) {hist_label = lab;} 
TH1F *frame;
TLegend *leg;
ClassDef(ConfidenceIntervalPlotter,1);
private:
ConfidenceIntervalPlotter();
bool CheckLegendLabel(std::vector<string> vec, string label);
bool bf_marker_added, manual_range;
double limits[4];
std::vector<string> line_labels, hist_labels;
TObjArray *graphs_to_draw, *bfp_to_draw, *hists_to_draw;
string titles; 
short int line_colour, bf_colour, hist_colour;
Style_t line_style, bf_style, hist_style;
Size_t bf_size;
string label, hist_label;
conv::PhysParamId_t param_x;
conv::PhysParamId_t param_y;
bool avg_delta_chi2;
bool find_delta;
};
}
#endif
#ifndef valor_util_configuration
#define valor_util_configuration
namespace valor
{
namespace util
{
class Configuration : public Registry
{
public:
static Configuration* Instance();
~Configuration();
private:
Configuration();
private:
static Configuration* _instance;
};
}
}
#endif
#ifndef valor_util_configuration_handler
#define valor_util_configuration_handler
namespace valor
{
namespace util
{
class ConfigurationHandler
{
public:
ConfigurationHandler();
~ConfigurationHandler();
void ReadAnalysis(const std::string& filename);
private:
void ReadSampleList(const std::string& filename);
void ProcessSamples(XMLNodePointer_t rootNode);
void ReadMC(const std::string& filename);
void ReadBinning(const std::string& filename);
void ReadOptimisedBinning(const std::string& filename,
const std::string& key);
void ReadSimpleBinning(const std::string& filename, const std::string& key);
void ReadParameterList(const std::string& filename);
void ProcessDefaults(XMLNodePointer_t rootNode);
void ProcessOscillationParameters(XMLNodePointer_t rootNode);
void ProcessSystematicParameters(XMLNodePointer_t rootNode,
const std::string& type);
void ReadParameters(const std::string& filename);
void ProcessParameters(XMLNodePointer_t rootNode);
void ProcessErrors(XMLNodePointer_t rootNode);
void ReadSplines(const std::string& filename);
std::string BuildString(const std::string& prefix, const int id,
const std::string& suffix);
std::string BuildString(const std::string& prefix, const std::string& infix,
const std::string& suffix);
private:
TXMLEngine* _engine;
int _nextParamId;
};
}
}
#endif
#ifndef __valor_env__
#define __valor_env__
namespace valor {
class Env {
public:
static Env * Instance();
string TopLevelDir (void) { return fTopLevelDir; }
string TopLevelDataDir (void) { return fTopLevelDataDir; }
string TopLevelConfDir (void) { return fTopLevelConfDir; }
string AppName (void) { return fAppName; }
string Banner (void) { return fBanner; }
void AutoSet (const char* valor_application);
void SetTopLevelDir (string dir) { fTopLevelDir = dir; }
void SetTopLevelDataDir (string dir) { fTopLevelDataDir = dir; }
void SetTopLevelConfDir (string dir) { fTopLevelConfDir = dir; }
void SetAppName (string app) { fAppName = app; }
void Print(ostream & stream) const;
friend ostream & operator << (ostream & stream, const Env & env);
private:
Env();
Env(const Env &);
~Env();
static Env * fInstance;
string fTopLevelDir;
string fTopLevelDataDir;
string fTopLevelConfDir;
string fAppName;
string fBanner;
struct Cleaner {
void DummyMethodAndSilentCompiler() { }
~Cleaner() {
if (Env::fInstance !=0) {
delete Env::fInstance;
Env::fInstance = 0;
}
}
};
friend struct Cleaner;
};
ostream & operator<< (ostream & stream, const Env & env);
}
#endif
#ifndef valor_util_fit_param_list_factory
#define valor_util_fit_param_list_factory
namespace valor
{
namespace util
{
class FitParamListFactory
{
public:
FitParamListFactory(){ }
FitParamList* MakeParamList(const std::string& filename) const;
FitParamList* MakeOscillationParamList(const std::string& filename) const;
FitParamList* MakeSystematicParamList(const std::string& filename) const;
};
}
}
#endif
#ifndef valor_interpolator_h
#define valor_interpolator_h
#ifdef __VALOR_FMWK_GSL_ENABLED__
#endif
namespace valor {
namespace util {
#ifdef __VALOR_FMWK_GSL_ENABLED__
class Interpolator : public ROOT::Math::Interpolator {
public:
Interpolator(const TSpline * spl = 0, ROOT::Math::Interpolation::Type type = ROOT::Math::Interpolation::kCSPLINE);
Interpolator(const TSpline & spl, ROOT::Math::Interpolation::Type type = ROOT::Math::Interpolation::kCSPLINE);
double Xmin() const;
double Xmax() const;
double EvalWithLimits(double x) const;
private:
double fXmin;
double fXmax;
};
#else
class Interpolator : public TObject {};
#endif
}
}
#endif
#ifndef valor_name_registry
#define valor_name_registry
namespace valor {
namespace util {
class NameRegistry {
public:
static const NameRegistry * Instance();
static NameRegistry * MutableInstance();
std::string ParamAsString (valor::conv::PhysParamId_t p) const;
std::string ParamAsStringSimple(valor::conv::PhysParamId_t p) const;
std::string AsString (valor::conv::PhysParamId_t p) const;
std::string AsStringSimple(valor::conv::PhysParamId_t p) const;
std::map<valor::conv::PhysParamId_t, std::string> fParamNames;
std::map<valor::conv::PhysParamId_t, std::string> fParamNamesSimple;
private:
NameRegistry();
NameRegistry(const NameRegistry &) {}
~NameRegistry() {}
void Init();
static NameRegistry * fInstance;
struct Cleaner {
void DummyMethodAndSilentCompiler() { }
~Cleaner() {
if (NameRegistry::fInstance !=0) {
delete NameRegistry::fInstance;
NameRegistry::fInstance = 0;
}
}
};
friend struct Cleaner;
};
}
}
#endif
#ifndef __valor_rnd__
#define __valor_rnd__
namespace valor {
class CmdLnArgList;
class Rnd {
public:
static Rnd * Instance();
void SetSeeds(UInt_t toymcstat = 0, UInt_t toymcsyst = 0, UInt_t toymcosc = 0, UInt_t fitter = 0, UInt_t other = 0);
void SetSeeds(const CmdLnArgList & arg);
TRandom3 & RndToyMCstat (void) { return fRndToyMCstat; }
TRandom3 & RndToyMCsyst (void) { return fRndToyMCsyst; }
TRandom3 & RndToyMCosc (void) { return fRndToyMCosc; }
TRandom3 & RndFitter (void) { return fRndFitter; }
TRandom3 & RndOther (void) { return fRndOther; }
void Print(ostream & stream) const;
friend ostream & operator << (ostream & stream, const Rnd & rnd);
private:
Rnd();
Rnd(const Rnd &) {}
~Rnd();
TRandom3 fRndToyMCstat;
TRandom3 fRndToyMCsyst;
TRandom3 fRndToyMCosc;
TRandom3 fRndFitter;
TRandom3 fRndOther;
UInt_t fSeedToyMCstat;
UInt_t fSeedToyMCsyst;
UInt_t fSeedToyMCosc;
UInt_t fSeedFitter;
UInt_t fSeedOther;
static Rnd * fInstance;
struct Cleaner {
void DummyMethodAndSilentCompiler() { }
~Cleaner() {
if (Rnd::fInstance !=0) {
delete Rnd::fInstance;
Rnd::fInstance = 0;
}
}
};
friend struct Cleaner;
};
ostream & operator<< (ostream & stream, const Rnd & plst);
}
#endif
#ifndef valor_util_utl_file
#define valor_util_utl_file
namespace valor
{
namespace util
{
namespace file
{
std::string GetConfigurationFilename(const std::string& filename);
std::string GetDataFilename(const std::string& filename);
std::string GetFilename(const std::string& filename);
}
}
}
#endif
#ifndef _valor_macros_utils_h_
#define _valor_macros_utils_h_
namespace valor {
class PhysHypothesis;
namespace util {
std::string SysThrowIdToString(unsigned int tweak_systematics);
std::string FormFilePath(const char * file, const char * dir);
TH2D * GetTH2DFromTFile(TFile * f, const char * name);
}
}
#endif
#ifndef _valor_hist_utils_h_
#define _valor_hist_utils_h_
namespace ROOT{ namespace Math { class Interpolator;}}
namespace valor {
namespace util {
TH1D Make1DHistogramFromArray(const VALORArray & va, const double * bin_edges, int dimension = 0);
TH2D Make2DHistogramFromArray(const VALORArray & va, double * const bin_edges_x, const double * bin_edges_y, int dimension_x=0, int dimension_y=1);
TObjArray * MakeHistogramsOfParameterValues(int n_entries, const PhysParamList * const * pparms, int nbins=-1, const FitParamList * get_limits_from = 0);
TH1 * MakeFittedHistogramShowingFittedValues(const TH1* hist, const TF1* func, int npoints = 1000);
TH1D MakeHistFromGSLSpline(const ROOT::Math::Interpolator * spl, int n_points = 1000, double min_x = 0 , double max_x = 2);
TMatrixD TH2ToTMatrix(const TH2 * hist);
int CreateRedToBlueColorPalette(int n_shades = 100);
TObjArray GetHistsFromCanvas(TVirtualPad * canv, const char * name = "TH1");
}
}
#endif
#ifndef valor_util_utl_init
#define valor_util_utl_init
namespace valor
{
namespace util
{
namespace init
{
CmdLnArgList Init(const std::string& environment, const std::string& appArgs,
const std::string& seedArgs, const int argc, const char* argv[]);
}
}
}
#endif
#ifndef _valor_utils_numstat_h_
#define _valor_utils_numstat_h_
class TH2D;
namespace ROOT{ namespace Math { class Interpolator;}}
namespace valor {
namespace util {
double DeltaChisquare (conv::ConfLevel_t cl, int nfitparams);
double ChisqGauss (double ndata, double nmc);
double ChisqPoisson (double ndata, double nmc);
double Chisq_Penalty_TH2D (TH2D* hobs, TH2D* hexp);
double ChisqMeanLikelihood(std::vector<double> chisqs);
TAxis EstimateOptimalBinning(int npoints, double * points);
int EstimateOptimalNumberOfBinsForGaussian(int npoints, double nsigma);
TMatrixD CholeskyDecomposition (const TMatrixD& cov);
TMatrixD CholeskyDecomposition (const TMatrixDSym& cov);
TVectorD CholeskyGenerateCorrelatedParams (const TMatrixD& Lch, TVectorD& mean);
TVectorD CholeskyGenerateCorrelatedParams (const TMatrixD& Lch, TVectorD& mean, TVectorD& g_uncorrelated);
TVectorD CholeskyGenerateCorrelatedParamVariations (const TMatrixD& Lch);
TVectorD CholeskyCalculateCorrelatedParamVariations(const TMatrixD& Lch, TVectorD& g);
double SingleAngleToDoubleAngle(double sinsqtheta);
double DoubleAngleToSingleAngle(double sinsq2theta);
TMatrixD CovarianceMatrixToCorrelationMatrix(const TMatrixD & cov_m);
TVectorD CovarianceMatrixToErrorVector(const TMatrixD & cov_m);
TMatrixD CorrelationAndErrorToCovarianceMatrix(const TMatrixD & corr, const TVectorD & one_sigma);
TMatrixD MatrixPseudoInverted(const TMatrixD & m);
TMatrixDSym MatrixToSymMatrix(const TMatrixD & m);
TMatrixDSym LowerTriangularMatrixToSymMatrix(const TMatrixD & m);
TVectorD ConcatenateTVectors (const std::vector<const TVectorD *> & tvecs );
TMatrixD ConcatenateTMatrices (const std::vector<const TMatrixD *> & tmats );
void ReorderMatrixAndVector (TVectorD & sort_by, TMatrixD & matr, bool descending = false, bool reorder_rows = true, bool reorder_cols = true);
double RandomizeParameter(conv::PhysParamId_t p);
double RandomizeMixing23 (void);
double RandomizeMixing12 (void);
double RandomizeMixing13 (void);
double RandomizeCPV (void);
double RandomizeDm12sq (void);
double RandomizeDm23sq (void);
double RandomizeMixing23Bar (void);
double RandomizeMixing12Bar (void);
double RandomizeMixing13Bar (void);
double RandomizeCPVBar (void);
double RandomizeDm12sqBar (void);
double RandomizeDm23sqBar (void);
double RandomizeUser (TH1D *hPrior);
int RandomizeMH (const double probNH);
double RandomizeBetaBar (void);
double FromSinsq2thToSinsqth(const double sinsq2th);
double FromSinsqthToSinsq2th(const double sinsqth);
int DiagonaliseGSL(int ndim, double * matrix_in, double * eigenvectors_out, double * eigenvalues_out);
int Sign(double x);
double Logistic(double x);
double Logit(double p);
double FractionOfBinContained(double min1, double max1, double min2, double max2);
bool SplineIsFlat(const TSpline * spl);
bool SplineIsFlat(const ROOT::Math::Interpolator * spl);
ROOT::Math::Interpolator * ConvertTSplineToGSL(const TSpline & spl, Option_t * opt = "");
ROOT::Math::Interpolator * ConvertTSplineToGSL(const TSpline & spl, double xmin, double xmax, Option_t * opt = "");
}
}
#endif
#ifndef valor_util_utl_plotting
#define valor_util_utl_plotting
namespace valor
{
namespace util
{
namespace plotting
{
void Plot(TH2D* histogram, const std::string& title,
const std::string& xTitle, const std::string yTitle,
const std::string& filename);
void Plot(TH1D* histogram, const std::string& title,
const std::string& xTitle, const std::string yTitle,
const std::string& filename);
}
}
}
#endif
#ifndef _valor_print_utils_h_
#define _valor_print_utils_h_
namespace valor {
namespace util {
void PrintVector (const TVectorD & v, int w=15, int prec=9, Option_t * opt="", std::ostream & stream = std::cout);
void PrintVectorPair(const TVectorD & current, const TVectorD & nominal, int w=15, int prec=9, Option_t * option="", std::ostream & stream = std::cout);
void PrintMatrix (const TMatrixD & m, int w=15, int prec=9, std::ostream & stream = std::cout);
void PrintVector (const TVectorD & v, const conv::PhysParamId_t * params, int w=15, int prec=9, Option_t * opt="", std::ostream & stream = std::cout);
void PrintVectorPair (const TVectorD & current, const TVectorD & nominal, const conv::PhysParamId_t * params,
int w, int prec, Option_t * option = "", std::ostream & stream = std::cout);
void NotifySlack (std::string message, std::string channel, std::string username);
}
}
#endif
#ifndef _valor_str_utils_h_
#define _valor_str_utils_h_
namespace valor {
namespace util {
string TrimSpaces (string input);
vector<string> Tokens (string input, string delimiter);
string ToLowerCase (string data);
string ReplaceAll (string data,string from, string to);
string PadToLength (string data, unsigned int length, char pad_with = ' ');
string PadToLengthFromLeft(string data, unsigned int length, char pad_with = ' ');
}
}
template<class T> std::ostream& operator<<(std::ostream& os, const std::vector<T> & v)
{
for (unsigned int i = 0; i < v.size() ; i++) {
os<<(i?",":"[")<<v[i];
}
return os<<"]";
}
template<typename Key,typename Val> std::ostream& operator<<(std::ostream& os, const std::map<Key,Val> & m)
{
unsigned int i = 0;
for (typename std::map<Key,Val>::const_iterator it = m.begin() ; it != m.end() ; ++it) {
os<<(i?",":"{")<<"\n ("<<it->first<<": "<<it->second<<")";
i++;
}
return os<<"\n}";
}
#endif
#ifndef _valor_style_utils_h_
#define _valor_style_utils_h_
class TGraph;
class TH1;
namespace valor {
namespace util {
void SetDefaultStyle(bool black_n_white=false);
void Format(TGraph* gr,
int lcol, int lsty, int lwid, int mcol, int msty, double msiz);
void Format(TH1* hst,
int lcol, int lsty, int lwid, int mcol, int msty, double msiz);
void PrintBanner(string filename, UInt_t wait_msec);
void Verbosity(string filename);
}
}
#endif
#ifndef valor_system_utils_h
#define valor_system_utils_h
namespace valor {
namespace util {
void Die(int status_code);
void ChangeInterpreterPrompt(std::string new_prompt = "VALOR: [%d] ");
std::vector<std::string> GetLinkedLibraries(std::string executable_path, std::string pattern);
std::string CompleteConfigPath(std::string config_file);
}
}
#endif
#ifndef _valor_xml_utils_h_
#define _valor_xml_utils_h_
class TGraph;
class TH1;
class TH1F;
class TH1D;
class TH2D;
class TH3D;
class TAxis;
namespace valor {
namespace util {
XMLNodePointer_t FindNode (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path);
vector<XMLNodePointer_t> FindNodes(TXMLEngine* xml_eng,
XMLNodePointer_t top_node, const string& tag);
bool NodeExists (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path);
bool XML2Bool (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path);
int XML2Int (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path);
double XML2Dbl (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path);
vector<double> XML2DblArray (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path);
string XML2String (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path);
pair<double,double> XML2DblDblPair (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path);
string XML2RootFileName (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path);
string XML2RootObjName (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path);
string XML2RootObjType (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path);
TFile * XML2TFile (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir = "<env>");
TH1F * XML2TH1F (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir = "<env>");
TGraph * XML2TGraph (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir = "<env>");
TH1D * XML2TH1D (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir = "<env>");
TH2D * XML2TH2D (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir = "<env>");
TH3D * XML2TH3D (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir = "<env>");
TTree * XML2TTree (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir = "<env>");
TVectorD * XML2TVectorD (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir = "<env>");
TMatrixDSym * XML2TMatrixDSym (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir = "<env>");
TMatrixD * XML2TMatrixD (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir = "<env>");
TMatrixD * XML2TH2D2TMatrixD (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir = "<env>");
TSpline3 * XML2TSpline3 (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir = "<env>");
TAxis * XML2BinInfo (TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path);
}
}
#endif
#ifndef VALOR_THREADPOOL_H
#define VALOR_THREADPOOL_H
#if __cplusplus > 199711L
namespace valor{
namespace util{
class VThreadPool {
public:
static VThreadPool * Instance();
void SetNThreads(unsigned int n);
unsigned int GetNThreads(void) const;
void Wait(bool finish = true);
void AddTask(std::function<void(void)> work);
void AddTasks(std::vector<std::function<void(void)> > work);
void DoTasks (std::vector<std::function<void(void)> > work);
unsigned int GetNTasksInQueue(void);
~VThreadPool();
private:
VThreadPool();
void AddThread(void);
void ThreadBody();
std::vector<std::thread> fThreads;
std::deque<std::function<void(void)>> fQueue;
unsigned int fNThreads;
std::atomic_bool fAbort;
std::atomic_int fNQueuedJobs;
std::atomic_int fNRunningJobs;
std::condition_variable fJobAvailable;
std::condition_variable fWaitVar;
std::mutex fWaitMutex;
std::mutex fQueueMutex;
std::function<void(void)> GetTask();
static VThreadPool * fInstance;
struct Cleaner {
void DummyMethodAndSilentCompiler() { }
~Cleaner() {
if (VThreadPool::fInstance !=0) {
delete VThreadPool::fInstance;
VThreadPool::fInstance = 0;
}
}
};
friend struct Cleaner;
};
}
}
#else
namespace valor{
namespace util{
class VThreadPool
{
public:
static VThreadPool * Instance();
void SetNThreads(unsigned int){};
private:
static VThreadPool * fInstance;
struct Cleaner {
void DummyMethodAndSilentCompiler() { }
~Cleaner() {
if (VThreadPool::fInstance !=0) {
delete VThreadPool::fInstance;
VThreadPool::fInstance = 0;
}
}
};
friend struct Cleaner;
};
}
}
#endif
#endif
 
#ifdef __VALOR_FMWK_GSL_ENABLED__ 
#include <gsl/gsl_complex.h> 
#include <gsl/gsl_complex_math.h> 
#include <gsl/gsl_matrix.h> 
#include <gsl/gsl_linalg.h> 
#include <gsl/gsl_blas.h> 
#include <gsl/gsl_eigen.h> 
#include <gsl/gsl_errno.h> 
#endif 
using namespace valor; 
using namespace valor::conv; 
using namespace valor::util; 
Messenger * Messenger::fInstance = 0; 
Messenger::Messenger() { 
fInstance = 0; 
} 
Messenger::~Messenger() { 
fInstance = 0; 
} 
Messenger * Messenger::Instance() { 
if(fInstance == 0) { 
static Messenger::Cleaner cleaner; 
cleaner.DummyMethodAndSilentCompiler(); 
fInstance = new Messenger; 
log4cpp::Category & MSG = log4cpp::Category::getRoot(); 
log4cpp::Appender * appender = MSG.getAppender(); 
if (!appender) { 
appender = new log4cpp::OstreamAppender("default", &cout); 
const char* layoutenv = gSystem->Getenv("VALOR_MSG_LAYOUT"); 
std::string layoutstr = (layoutenv) ? string(layoutenv) : "BASIC"; 
if ( layoutstr == "SIMPLE" ) { 
appender->setLayout(new log4cpp::SimpleLayout()); 
} else { 
appender->setLayout(new log4cpp::BasicLayout()); 
} 
MSG.setAdditivity(false); 
MSG.addAppender(appender); 
} 
} 
return fInstance; 
} 
log4cpp::Category & Messenger::operator () (const char * stream) { 
log4cpp::Category & MSG = log4cpp::Category::getInstance(stream); 
return MSG; 
} 
void Messenger::SetPriorityLevel( const char * stream, log4cpp::Priority::Value priority) { 
log4cpp::Category & MSG = log4cpp::Category::getInstance(stream); 
MSG.setPriority(priority); 
} 
void Messenger::SetPriorityLevel( std::string stream, std::string priority_name) { 
log4cpp::Priority::Value priority = this->PriorityFromString(priority_name); 
log4cpp::Category & MSG = log4cpp::Category::getInstance(stream.c_str()); 
MSG.setPriority(priority); 
} 
bool Messenger::Configure(string filename) { 
TXMLEngine* xml = new TXMLEngine; 
XMLDocPointer_t xmldoc = xml->ParseFile(filename.c_str()); 
if (xmldoc==0) { 
assert(1); 
delete xml; 
return false; 
} 
XMLNodePointer_t root_node = xml->DocGetRootElement(xmldoc); 
XMLNodePointer_t curr_node = xml->GetChild(root_node); 
while(curr_node) { 
string curr_node_name = xml->GetNodeName(curr_node); 
if(curr_node_name == "priority") { 
string stream = xml->GetAttr(curr_node,"msgstream"); 
string priority = xml->GetNodeContent(curr_node); 
log4cpp::Priority::Value pv = this->PriorityFromString(priority); 
this->SetPriorityLevel(stream.c_str(), pv); 
assert(1); 
} 
curr_node = xml->GetNext(curr_node); 
} 
xml->FreeDoc(xmldoc); 
delete xml; 
assert(1); 
return true; 
} 
log4cpp::Priority::Value Messenger::PriorityFromString(string p) { 
if ( p.find("DEBUG") != string::npos ) return log4cpp::Priority::DEBUG; 
if ( p.find("INFO") != string::npos ) return log4cpp::Priority::INFO; 
if ( p.find("NOTICE") != string::npos ) return log4cpp::Priority::NOTICE; 
if ( p.find("WARN") != string::npos ) return log4cpp::Priority::WARN; 
if ( p.find("ERROR") != string::npos ) return log4cpp::Priority::ERROR; 
if ( p.find("CRIT") != string::npos ) return log4cpp::Priority::CRIT; 
if ( p.find("ALERT") != string::npos ) return log4cpp::Priority::ALERT; 
if ( p.find("FATAL") != string::npos ) return log4cpp::Priority::FATAL; 
assert(1); 
return log4cpp::Priority::INFO; 
} 
namespace valor { 
template ostream & operator << (ostream & stream, const RegistryItem<RgBool> & r); 
template ostream & operator << (ostream & stream, const RegistryItem<RgInt> & r); 
template ostream & operator << (ostream & stream, const RegistryItem<RgDbl> & r); 
template ostream & operator << (ostream & stream, const RegistryItem<RgStr> & r); 
template ostream & operator << (ostream & stream, const RegistryItem<RgH1F> & r); 
template ostream & operator << (ostream & stream, const RegistryItem<RgH2F> & r); 
template ostream & operator << (ostream & stream, const RegistryItem<RgTree> & r); 
template ostream & operator << (ostream & stream, const RegistryItem<RgObject> & r); 
template <typename T> ostream & operator << (ostream & stream, const RegistryItem<T> & rec) { 
rec.Print(stream); 
return stream; 
} 
template<typename T> RegistryItem<T>::RegistryItem(T item, bool locked, bool local) { 
fItem = item; 
fIsLocked = locked; 
fIsLocal = local; 
} 
template<typename T> RegistryItem<T>::RegistryItem(const RegistryItem * ri) { 
fItem = ri->fItem; 
fIsLocked = ri->fIsLocked; 
fIsLocal = ri->fIsLocal; 
} 
template<typename T> RegistryItem<T>::~RegistryItem() { 
} 
template<> RegistryItem<RgH1F>::~RegistryItem() { 
if (fItem) delete fItem; 
} 
template<> RegistryItem<RgH2F>::~RegistryItem() { 
if (fItem) delete fItem; 
} 
template<> RegistryItem<RgTree>::~RegistryItem() { 
if (fItem) delete fItem; 
} 
template<typename T> RegistryItemI * RegistryItem<T>::Clone(void) const { 
RegistryItemI * item = new RegistryItem<T>(fItem,fIsLocked); 
return item; 
} 
template<> RgType_t RegistryItem<RgBool>::TypeInfo(void) const { 
return kRgBool; 
} 
template<> RgType_t RegistryItem<RgInt>::TypeInfo (void) const { 
return kRgInt; 
} 
template<> RgType_t RegistryItem<RgDbl>::TypeInfo (void) const { 
return kRgDbl; 
} 
template<> RgType_t RegistryItem<RgStr>::TypeInfo (void) const { 
return kRgStr; 
} 
template<> RgType_t RegistryItem<RgH1F>::TypeInfo (void) const { 
return kRgH1F; 
} 
template<> RgType_t RegistryItem<RgH2F>::TypeInfo (void) const { 
return kRgH2F; 
} 
template<> RgType_t RegistryItem<RgTree>::TypeInfo(void) const { 
return kRgTree; 
} 
template<> RgType_t RegistryItem<RgObject>::TypeInfo(void) const { 
return kRgObject; 
} 
template<typename T> void RegistryItem<T>::Print(ostream & stream) const { 
stream << ((fIsLocked) ? "[ locked]" : "[unlocked]") << " " << ((fIsLocal) ? "[l]" : "[g]") << " : " << (fItem); 
} 
template<> void RegistryItem<RgH1F>::Print(ostream & stream) const { 
TH1F * histo = dynamic_cast<TH1F *>(fItem); 
if(!histo) stream << "*** NULL RgH1F ***"; 
stream << ((fIsLocked) ? "[ locked]" : "[unlocked]") << " " << ((fIsLocal) ? "[l]" : "[g]") << " : " << fItem->GetName(); 
} 
template<> void RegistryItem<RgH2F>::Print(ostream & stream) const { 
TH2F * histo = dynamic_cast<TH2F *>(fItem); 
if(!histo) stream << "*** NULL RgH2F ***"; 
stream << ((fIsLocked) ? "[ locked]" : "[unlocked]") << " " << ((fIsLocal) ? "[l]" : "[g]") << " : " << fItem->GetName(); 
} 
template<> void RegistryItem<RgTree>::Print(ostream & stream) const { 
TTree * tree = dynamic_cast<TTree *>(fItem); 
if(!tree) stream << "*** NULL RgTree ***"; 
stream << ((fIsLocked) ? "[ locked]" : "[unlocked]") << " " << ((fIsLocal) ? "[l]" : "[g]") << " : " << fItem->GetName(); 
} 
template class RegistryItem<RgBool>; 
template class RegistryItem<RgInt>; 
template class RegistryItem<RgDbl>; 
template class RegistryItem<RgStr>; 
template class RegistryItem<RgH1F>; 
template class RegistryItem<RgH2F>; 
template class RegistryItem<RgTree>; 
template class RegistryItem<RgObject>; 
} 
namespace valor { 
template<class T> void SetRegistryItem(Registry * r, RgKey key, T item) { 
string itemtype = typeid(item).name(); 
assert(1); 
bool lock = r->ItemIsLocked(key); 
RegistryItem<T> * reg_item = new RegistryItem<T>(item,lock); 
RgIMapPair config_entry(key, reg_item); 
r->Set(config_entry); 
} 
template<class T> T GetValueOrUseDefault( Registry * r, RgKey key, T def, bool set_def) { 
T value; 
if(r->Exists(key)) { 
if(r->ItemIsLocal(key)) { 
 r->Get(key,value); 
return value; 
} 
} 
value = def; 
bool was_locked = r->IsLocked(); 
if(was_locked) r->UnLock(); 
if(set_def) { 
 r->Set(key, value); 
 r->LinkToGlobalDef(key); 
} 
if(was_locked) r->Lock(); 
return value; 
} 
ostream & operator << (ostream & stream, const Registry & registry) { 
registry.Print(stream); 
return stream; 
} 
} 
Registry::Registry() { 
this->Init(); 
} 
Registry::Registry(string name, bool isReadOnly) : fName ( name ), fIsReadOnly ( isReadOnly ), fInhibitItemLocks ( false ) { 
} 
Registry::Registry(const Registry & registry) : fIsReadOnly(false) { 
this->Copy(registry); 
} 
Registry::~Registry() { 
this->Clear(true); 
} 
void Registry::operator() (RgKey key, RgInt item) { 
this->Set(key, item); 
} 
void Registry::operator() (RgKey key, RgBool item) { 
this->Set(key, item); 
} 
void Registry::operator() (RgKey key, RgDbl item) { 
this->Set(key, item); 
} 
void Registry::operator() (RgKey key, RgCChAr item) { 
RgStr item2 = RgStr(item); 
this->Set(key,item2); 
} 
void Registry::operator() (RgKey key, RgStr item) { 
this->Set(key, item); 
} 
Registry & Registry::operator = (const Registry & reg) { 
this->Copy(reg); 
return (*this); 
} 
Registry & Registry::operator += (const Registry & reg) { 
this->Append(reg); 
return (*this); 
} 
void Registry::Lock(void) { 
fIsReadOnly = true; 
} 
void Registry::UnLock(void) { 
fIsReadOnly = false; 
} 
bool Registry::IsLocked(void) const { 
return fIsReadOnly; 
} 
void Registry::InhibitItemLocks(void) { 
fInhibitItemLocks = true; 
} 
void Registry::RestoreItemLocks(void) { 
fInhibitItemLocks = false; 
} 
bool Registry::ItemLocksAreActive(void) const { 
return !fInhibitItemLocks; 
} 
bool Registry::ItemIsLocal(RgKey key) const { 
if( this->Exists(key) ) { 
RgIMapConstIter entry = fRegistry.find(key); 
bool is_local = entry->second->IsLocal(); 
return is_local; 
} 
return false; 
} 
void Registry::OverrideGlobalDef(RgKey key) { 
if( this->Exists(key) ) { 
RgIMapConstIter entry = fRegistry.find(key); 
entry->second->SetLocal(true); 
} else { 
assert(1); 
} 
} 
void Registry::LinkToGlobalDef(RgKey key) { 
if( this->Exists(key) ) { 
RgIMapConstIter entry = fRegistry.find(key); 
entry->second->SetLocal(false); 
} else { 
assert(1); 
} 
} 
bool Registry::ItemIsLocked(RgKey key) const { 
if( this->Exists(key) ) { 
RgIMapConstIter entry = fRegistry.find(key); 
bool is_locked = entry->second->IsLocked(); 
return is_locked; 
} 
return false; 
} 
void Registry::LockItem(RgKey key) { 
if( this->Exists(key) ) { 
RgIMapConstIter entry = fRegistry.find(key); 
entry->second->Lock(); 
} else { 
assert(1); 
} 
} 
void Registry::UnLockItem(RgKey key) { 
if( this->Exists(key) ) { 
RgIMapConstIter entry = fRegistry.find(key); 
entry->second->UnLock(); 
} else { 
assert(1); 
} 
} 
bool Registry::CanSetItem(RgKey key) const { 
bool locked_item = this->ItemIsLocked(key); 
bool active_item_locks = this->ItemLocksAreActive(); 
bool locked_registry = this->IsLocked(); 
bool can_set = !locked_registry && ( !locked_item || !active_item_locks ); 
return can_set; 
} 
void Registry::Set(RgIMapPair entry) { 
RgKey key = entry.first; 
if( this->CanSetItem(key) ) { 
this->DeleteEntry(key); 
fRegistry.insert(entry); 
} else { 
assert(1); 
} 
} 
void Registry::Set(RgKey key, RgBool item) { 
SetRegistryItem(this, key, item); 
} 
void Registry::Set(RgKey key, RgInt item) { 
SetRegistryItem(this, key, item); 
} 
void Registry::Set(RgKey key, RgDbl item) { 
SetRegistryItem(this, key, item); 
} 
void Registry::Set(RgKey key, RgCChAr item) { 
RgStr item2 = RgStr(item); 
this->Set(key, item2); 
} 
void Registry::Set(RgKey key, RgStr item) { 
SetRegistryItem(this, key, item); 
} 
void Registry::Set(RgKey key, RgH1F item) { 
SetRegistryItem(this, key, item); 
} 
void Registry::Set(RgKey key, RgH2F item) { 
SetRegistryItem(this, key, item); 
} 
void Registry::Set(RgKey key, RgTree item) { 
SetRegistryItem(this, key, item); 
} 
void Registry::Set(RgKey key, RgObject item) { 
SetRegistryItem(this, key, item); 
} 
void Registry::Get(RgKey key, const RegistryItemI * & item) const { 
RgIMapConstIter entry = this->SafeFind(key); 
item = entry->second; 
} 
void Registry::Get(RgKey key, RgBool & item) const { 
RgIMapConstIter entry = this->SafeFind(key); 
RegistryItemI * rib = entry->second; 
RegistryItem<RgBool> * ri = dynamic_cast<RegistryItem<RgBool>*> (rib); 
item = ri->Data(); 
} 
void Registry::Get(RgKey key, RgInt & item) const { 
RgIMapConstIter entry = this->SafeFind(key); 
RegistryItemI * rib = entry->second; 
RegistryItem<RgInt> * ri = dynamic_cast< RegistryItem<RgInt> * > (rib); 
item = ri->Data(); 
} 
void Registry::Get(RgKey key, RgDbl & item) const { 
RgIMapConstIter entry = this->SafeFind(key); 
RegistryItemI * rib = entry->second; 
RegistryItem<RgDbl> * ri = dynamic_cast<RegistryItem<RgDbl>*> (rib); 
item = ri->Data(); 
} 
void Registry::Get(RgKey key, RgStr & item) const { 
RgIMapConstIter entry = this->SafeFind(key); 
RegistryItemI * rib = entry->second; 
RegistryItem<RgStr> * ri = dynamic_cast<RegistryItem<RgStr>*> (rib); 
item = ri->Data(); 
} 
void Registry::Get(RgKey key, RgH1F & item) const { 
RgIMapConstIter entry = this->SafeFind(key); 
RegistryItemI * rib = entry->second; 
RegistryItem<RgH1F> *ri = dynamic_cast<RegistryItem<RgH1F>*> (rib); 
item = ri->Data(); 
if(!item) { 
assert(1); 
} 
} 
void Registry::Get(RgKey key, RgH2F & item) const { 
RgIMapConstIter entry = this->SafeFind(key); 
RegistryItemI * rib = entry->second; 
RegistryItem<RgH2F> *ri = dynamic_cast<RegistryItem<RgH2F>*> (rib); 
item = ri->Data(); 
if(!item) { 
assert(1); 
} 
} 
void Registry::Get(RgKey key, RgTree & item) const { 
RgIMapConstIter entry = this->SafeFind(key); 
RegistryItemI * rib = entry->second; 
RegistryItem<RgTree> *ri = dynamic_cast<RegistryItem<RgTree>*> (rib); 
item = ri->Data(); 
if(!item) { 
assert(1); 
} 
} 
void Registry::Get(RgKey key, RgObject & item) const { 
RgIMapConstIter entry = this->SafeFind(key); 
RegistryItemI * rib = entry->second; 
RegistryItem<RgObject> *ri = dynamic_cast<RegistryItem<RgObject>*> (rib); 
item = ri->Data(); 
if(!item) { 
assert(1); 
} 
} 
RgBool Registry::GetBool(RgKey key) const { 
RgBool value; 
this->Get(key, value); 
return value; 
} 
RgInt Registry::GetInt(RgKey key) const { 
RgInt value; 
this->Get(key, value); 
return value; 
} 
RgDbl Registry::GetDouble(RgKey key) const { 
RgDbl value; 
this->Get(key, value); 
return value; 
} 
RgStr Registry::GetString(RgKey key) const { 
RgStr value; 
this->Get(key, value); 
return value; 
} 
RgH1F Registry::GetH1F(RgKey key) const { 
RgIMapConstIter entry = this->SafeFind(key); 
RegistryItemI * rib = entry->second; 
RegistryItem<RgH1F> *ri = dynamic_cast<RegistryItem<RgH1F>*> (rib); 
RgH1F item = ri->Data(); 
return item; 
} 
RgH2F Registry::GetH2F(RgKey key) const { 
RgIMapConstIter entry = this->SafeFind(key); 
RegistryItemI * rib = entry->second; 
RegistryItem<RgH2F> *ri = dynamic_cast<RegistryItem<RgH2F>*> (rib); 
RgH2F item = ri->Data(); 
return item; 
} 
RgTree Registry::GetTree(RgKey key) const { 
RgIMapConstIter entry = this->SafeFind(key); 
RegistryItemI * rib = entry->second; 
RegistryItem<RgTree> *ri = dynamic_cast<RegistryItem<RgTree>*> (rib); 
RgTree item = ri->Data(); 
return item; 
} 
RgObject Registry::GetObject(RgKey key) const { 
RgIMapConstIter entry = this->SafeFind(key); 
RegistryItemI * rib = entry->second; 
RegistryItem<RgObject> *ri = dynamic_cast<RegistryItem<RgObject>*> (rib); 
RgObject item = ri->Data(); 
return item; 
} 
RgBool Registry::GetBoolDef(RgKey key, RgBool def_opt, bool set_def) { 
return GetValueOrUseDefault(this, key, def_opt, set_def); 
} 
int Registry::GetIntDef(RgKey key, int def_opt, bool set_def) { 
return GetValueOrUseDefault(this, key, def_opt, set_def); 
} 
double Registry::GetDoubleDef(RgKey key, double def_opt, bool set_def) { 
return GetValueOrUseDefault(this, key, def_opt, set_def); 
} 
string Registry::GetStringDef(RgKey key, string def_opt, bool set_def) { 
return GetValueOrUseDefault(this, key, def_opt, set_def); 
} 
RgIMapConstIter Registry::SafeFind(RgKey key) const { 
RgIMapConstIter entry = fRegistry.find(key); 
if (entry!=fRegistry.end()) { 
return entry; 
} 
assert(1); 
exit(1); 
} 
bool Registry::Exists(RgKey key) const { 
RgIMapConstIter entry = fRegistry.find(key); 
return (entry!=fRegistry.end()); 
} 
bool Registry::DeleteEntry(RgKey key) { 
if(!fIsReadOnly && Exists(key)) { 
RgIMapIter entry = fRegistry.find(key); 
RegistryItemI * item = entry->second; 
delete item; 
item = 0; 
fRegistry.erase(entry); 
return true; 
} 
return false; 
} 
int Registry::NEntries(void) const { 
RgIMapSizeType reg_size = fRegistry.size(); 
return (const int) reg_size; 
} 
void Registry::SetName(string name) { 
if(! fIsReadOnly) fName = name; 
else { 
assert(1); 
} 
} 
string Registry::Name(void) const { 
return fName; 
} 
void Registry::AssertExistence(RgKey key0) const { 
if ( ! this->Exists(key0) ) { 
assert(1); 
assert(1); 
exit(1); 
} 
} 
void Registry::AssertExistence(RgKey key0, RgKey key1) const { 
this->AssertExistence(key0); 
this->AssertExistence(key1); 
} 
void Registry::AssertExistence(RgKey key0, RgKey key1, RgKey key2) const { 
this->AssertExistence(key0); 
this->AssertExistence(key1); 
this->AssertExistence(key2); 
} 
void Registry::Print(ostream & stream) const { 
stream << endl; 
stream << "[-] Registry name: [" << Name() << "]"; 
stream << " - Write Status: "; 
if(fIsReadOnly) { stream << "[locked]"; } 
else { stream << "[unlocked]"; } 
stream << " - Inhibited Item Locking: "; 
if(fInhibitItemLocks) { stream << "[on]"; } 
else { stream << "[off]"; } 
stream << " - # entries: " << setfill(' ') << setw(3) << fRegistry.size() << endl; 
RgIMapConstIter rcit = fRegistry.begin(); 
for( ; rcit != fRegistry.end(); rcit++) { 
RgKey key = rcit->first; 
RegistryItemI * ritem = rcit->second; 
if(ritem) { 
RgType_t type = ritem->TypeInfo(); 
string stype = RgType::AsString(type); 
string key_lbl = string("> ") + key; 
string type_lbl = string("[") + stype + string("] "); 
stream << " |" << setfill('-') << setw(50) << key_lbl << setfill(' ') << setw(10) << type_lbl; 
ritem->Print(stream); 
stream << endl; 
} else { 
assert(1); 
} 
} 
} 
void Registry::Copy(const Registry & registry) { 
assert(1); 
if(this->IsLocked()) { 
assert(1); 
return; 
} 
this->Init(); 
this->Clear(); 
this->Append(registry); 
fName = registry.fName; 
fIsReadOnly = registry.fIsReadOnly; 
fInhibitItemLocks = registry.fInhibitItemLocks; 
} 
void Registry::Append(const Registry & registry, RgKey prefix) { 
assert(1); 
if(this->IsLocked()) { 
assert(1); 
return; 
} 
this->InhibitItemLocks(); 
RgIMapConstIter reg_iter; 
for(reg_iter = registry.fRegistry.begin(); 
reg_iter != registry.fRegistry.end(); reg_iter++) { 
RgKey name = reg_iter->first; 
RgKey new_name = prefix + name; 
RegistryItemI * ri = reg_iter->second; 
bool ilk = ri->IsLocked(); 
RgType_t type = ri->TypeInfo(); 
string stype = RgType::AsString(type); 
assert(1); 
RegistryItemI * cri = 0; 
if (type == kRgBool) cri = new RegistryItem<RgBool>(registry.GetBool(name),ilk); 
else if (type == kRgDbl) cri = new RegistryItem<RgDbl> (registry.GetDouble(name),ilk); 
else if (type == kRgInt) cri = new RegistryItem<RgInt> (registry.GetInt(name),ilk); 
else if (type == kRgStr) cri = new RegistryItem<RgStr> (registry.GetString(name),ilk); 
else if (type == kRgH1F) { 
RgH1F histo = registry.GetH1F(name); 
if(histo) { 
RgH1F chisto = new TH1F(*histo); 
assert(1); 
cri = new RegistryItem<RgH1F>(chisto,ilk); 
} else { 
assert(1); 
} 
} else if (type == kRgH2F) { 
RgH2F histo = registry.GetH2F(name); 
if(histo) { 
RgH2F chisto = new TH2F(*histo); 
assert(1); 
cri = new RegistryItem<RgH2F>(chisto,ilk); 
} else { 
assert(1); 
} 
} else if (type == kRgTree) { 
RgTree tree = registry.GetTree(name); 
if(tree) { 
TTree * ctree = tree->CopyTree("1"); 
assert(1); 
cri = new RegistryItem<RgTree>(ctree,ilk); 
} else { 
assert(1); 
} 
} else if (type == kRgObject) { 
RgObject obj = registry.GetObject(name); 
if(obj) { 
TObject * cobj = obj->Clone(); 
assert(1); 
cri = new RegistryItem<RgObject>(cobj,ilk); 
} else { 
assert(1); 
} 
} else {} 
RgIMapPair reg_entry(new_name, cri); 
fRegistry.insert(reg_entry); 
} 
} 
RgType_t Registry::ItemType(RgKey key) const { 
RgIMapConstIter reg_iter = fRegistry.find(key); 
if(reg_iter != fRegistry.end()) { 
RegistryItemI * ri = reg_iter->second; 
RgType_t type = ri->TypeInfo(); 
return type; 
} 
return kRgUndefined; 
} 
RgKeyList Registry::FindKeys(RgKey key_part) const { 
RgKeyList klist; 
RgIMapConstIter reg_iter = fRegistry.begin(); 
for( ; reg_iter != fRegistry.end(); reg_iter++) { 
RgKey key = reg_iter->first; 
if (key.find(key_part) != string::npos) { 
klist.push_back(key); 
} 
} 
return klist; 
} 
void Registry::Init(void) { 
fName = "NoName"; 
fIsReadOnly = false; 
fInhibitItemLocks = false; 
} 
void Registry::Clear(bool force) { 
if(!force) { 
if(this->IsLocked()) { 
assert(1); 
return; 
} 
} 
RgIMapIter rit; 
for(rit = fRegistry.begin(); rit != fRegistry.end(); rit++) { 
RgKey name = rit->first; 
RegistryItemI * item = rit->second; 
if(!item) { 
assert(1); 
} 
delete item; 
item = 0; 
} 
fRegistry.clear(); 
} 
  string util::AsString(PhysHypothesis_t h) { 
switch(h) { 
case (kHypDecay) : return "<Neutrino Decay>"; 
break; 
case (kHypDecoh) : return "<Neutrino Decoherence>"; 
break; 
case (kHypNuMuDisapp2F) : return "<2-Flavour Neutrino Oscillations: nu_mu disappearance>"; 
break; 
case (kHypOsc3F) : return "<3-flavour Neutrino Oscillations>"; 
break; 
case (kHypOsc3FBar) : return "<3-flavour Neutrino Oscillations, split nu and nubar>"; 
break; 
case (kHypOsc3FBarDissap) : return "<3-flavour Neutrino Oscillations, split 23 sector nu and nubar>"; 
break; 
case (kHypOsc3FBarNormBar) : return "<3-flavour Neutrino Oscillations, split nu and nubar, normalization numubar->nuebar>"; 
break; 
case (kHypOsc3FNormBar) : return "<3-flavour Neutrino Oscillations, normalization numubar->nuebar>"; 
break; 
case (kHypOscSterile4F) : return "<3+1 Sterile Neutrino Oscillations>"; 
break; 
case (kHypOscSterile5F) : return "<3+2 Sterile Neutrino Oscillations>"; 
break; 
case (kHypOscSterileEff) : return "<Effective 2F Sterile Neutrino Oscillations>"; 
break; 
case (kHypNSI3F) : return "<3-flavour Neutrino Oscillations plus mu-tau NSI>"; 
break; 
case (kHypVoid) : return "<Systematics Constraint>"; 
break; 
default: return "undefined"; 
break; 
} 
return ""; 
} 
string util::PhysHypAsString(PhysHypothesis_t h) { return AsString(h); } 
string util::AsString ( PhysHypothesis_t hyp, double mix12, double mix13, double mix23, double deltacp, double dm12sq, double dm23sq) { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
NuOscOctant_t oct = Opt::Instance()->gOscOctantChoice; 
string mixparam = "?"; 
switch(omp) { 
case(kNuMixSinsq2Theta): switch(oct) { 
case(kNuOctantOne): mixparam = "sinsq2theta_octantone"; 
break; 
case(kNuOctantTwo): mixparam = "sinsq2theta_octanttwo"; 
break; 
default: return ""; 
} 
break; 
case(kNuMixSinsqTheta): mixparam = "sinsqtheta"; 
break; 
default: return ""; 
} 
ostringstream out; 
if( hyp == valor::conv::kHypOsc3F ) { 
double rndmz = -900; 
bool show_mix12 = (mix12 > rndmz); 
bool show_mix13 = (mix13 > rndmz); 
bool show_mix23 = (mix23 > rndmz); 
bool show_mix = show_mix12 || show_mix13 || show_mix23; 
bool show_deltacp = (deltacp > rndmz); 
bool show_dm12sq = (dm12sq > rndmz); 
bool show_dm23sq = (dm23sq > rndmz); 
bool show_dmsq = show_dm12sq || show_dm23sq; 
if(show_mix) { 
out << mixparam << "["; 
if(show_mix12) { 
out << "12_" << TString::Format("%.3f",mix12); 
} 
if(show_mix13) { 
if(show_mix12) { 
out << ","; 
} 
out << "13_" << TString::Format("%.3f",mix13); 
} 
if(show_mix23) { 
if(show_mix13 || (!show_mix13 && show_mix12)) { 
out << ","; 
} 
out << "23_" << TString::Format("%.3f",mix23); 
} 
out << "]"; 
} 
if(show_mix && (show_deltacp || show_dmsq)) { 
out << ","; 
} 
if(show_deltacp) { 
out << "dcp_" << TString::Format("%.3f",deltacp); 
} 
if(show_deltacp && show_dmsq) { 
out << ","; 
} 
if(show_dmsq) { 
out << "dmsq_" << util::AsString(Opt::Instance()->gMassHierarchyAssumed) << "["; 
if(show_dm12sq) { 
out << "12_" << TString::Format("%.8f",dm12sq); 
} 
if(show_dm23sq) { 
if(show_dm12sq) { 
out << ","; 
} 
out << "23_" << TString::Format("%.6f",dm23sq); 
} 
out << "]eV2"; 
} 
} 
if (hyp == valor::conv::kHypOsc3FBar) { 
out<<"3f+3fbar"; 
} 
return out.str(); 
} 
string util::AsString ( PhysHypothesis_t hyp, double mix12, double mix13, double mix23, double deltacp, double dm12sq, double dm23sq, double betabar, double mix23bar, double dm23sqbar) { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
NuOscOctant_t oct = Opt::Instance()->gOscOctantChoice; 
string mixparam = "?"; 
switch(omp) { 
case(kNuMixSinsq2Theta): switch(oct) { 
case(kNuOctantOne): mixparam = "sinsq2theta_octantone"; 
break; 
case(kNuOctantTwo): mixparam = "sinsq2theta_octanttwo"; 
break; 
default: return ""; 
} 
break; 
case(kNuMixSinsqTheta): mixparam = "sinsqtheta"; 
break; 
default: return ""; 
} 
ostringstream out; 
if( hyp == valor::conv::kHypOsc3F ) { 
double rndmz = -900; 
bool show_mix12 = (mix12 > rndmz); 
bool show_mix13 = (mix13 > rndmz); 
bool show_mix23 = (mix23 > rndmz); 
bool show_mix = show_mix12 || show_mix13 || show_mix23; 
bool show_deltacp = (deltacp > rndmz); 
bool show_dm12sq = (dm12sq > rndmz); 
bool show_dm23sq = (dm23sq > rndmz); 
bool show_dmsq = show_dm12sq || show_dm23sq; 
if(show_mix) { 
out << mixparam << "["; 
if(show_mix12) { 
out << "12_" << TString::Format("%.3f",mix12); 
} 
if(show_mix13) { 
if(show_mix12) { 
out << ","; 
} 
out << "13_" << TString::Format("%.3f",mix13); 
} 
if(show_mix23) { 
if(show_mix13 || (!show_mix13 && show_mix12)) { 
out << ","; 
} 
out << "23_" << TString::Format("%.3f",mix23); 
} 
out << "]"; 
} 
if(show_mix && (show_deltacp || show_dmsq)) { 
out << ","; 
} 
if(show_deltacp) { 
out << "dcp_" << TString::Format("%.3f",deltacp); 
} 
if(show_deltacp && show_dmsq) { 
out << ","; 
} 
if(show_dmsq) { 
out << "dmsq_" << util::AsString(Opt::Instance()->gMassHierarchyAssumed) << "["; 
if(show_dm12sq) { 
out << "12_" << TString::Format("%.8f",dm12sq); 
} 
if(show_dm23sq) { 
if(show_dm12sq) { 
out << ","; 
} 
out << "23_" << TString::Format("%.6f",dm23sq); 
} 
out << "]eV2"; 
} 
} 
if (hyp == valor::conv::kHypOsc3FBar) { 
out<<"3f+3fbar"; 
} 
if (hyp == valor::conv::kHypOsc3FBarDissap) { 
double rndmz = -900; 
bool show_mix12 = (mix12 > rndmz); 
bool show_mix13 = (mix13 > rndmz); 
bool show_mix23 = (mix23 > rndmz); 
bool show_mix23bar = (mix23 > rndmz); 
bool show_mix = show_mix12 || show_mix13 || show_mix23; 
bool show_deltacp = (deltacp > rndmz); 
bool show_dm12sq = (dm12sq > rndmz); 
bool show_dm23sq = (dm23sq > rndmz); 
bool show_dm23sqbar = (dm23sqbar > rndmz); 
bool show_dmsq = show_dm12sq || show_dm23sq || show_dm23sqbar; 
if(show_mix) { 
out << mixparam << "["; 
if(show_mix12) { 
out << "12_" << TString::Format("%.3f",mix12); 
} 
if(show_mix13) { 
if(show_mix12) { 
out << ","; 
} 
out << "13_" << TString::Format("%.3f",mix13); 
} 
if(show_mix23) { 
if(show_mix13 || (!show_mix13 && show_mix12)) { 
out << ","; 
} 
out << "23_" << TString::Format("%.3f",mix23); 
} 
if(show_mix23bar) { 
if(show_mix23) { 
out << ","; 
} 
out << ",23bar_" << TString::Format("%.3f",mix23bar); 
} 
out << "]"; 
} 
if(show_mix && (show_deltacp || show_dmsq)) { 
out << ","; 
} 
if(show_deltacp) { 
out << "dcp_" << TString::Format("%.3f",deltacp); 
} 
if(show_deltacp && show_dmsq) { 
out << ","; 
} 
if(show_dmsq) { 
out << "dmsq_" << util::AsString(Opt::Instance()->gMassHierarchyAssumed) << "["; 
if(show_dm12sq) { 
out << "12_" << TString::Format("%.8f",dm12sq); 
} 
if(show_dm23sq) { 
if(show_dm12sq) { 
out << ","; 
} 
out << "23_" << TString::Format("%.6f",dm23sq); 
} 
if(show_dm23sqbar) { 
if(show_dm23sq) { 
out << ","; 
} 
out << ",23bar_" << TString::Format("%.6f",dm23sqbar); 
} 
out << "]eV2"; 
} 
if (hyp == valor::conv::kHypOsc3FBarNormBar) { 
out<<"3f+3fbar+normbar"; 
} 
if (hyp == valor::conv::kHypOsc3FNormBar) { 
out<<"3f+normbar"; 
} 
if (hyp == valor::conv::kHypOscSterile4F) { 
out<<"sterile_3+1"; 
} 
if (hyp == valor::conv::kHypOscSterile5F) { 
out<<"sterile_3+2"; 
} 
if( hyp == valor::conv::kHypNuMuDisapp2F) { 
out << mixparam << "23_" << TString::Format("%.3f",mix23) << ",dm23sq_" << TString::Format("%.5f",dm23sq) << "eV2"; 
} 
return out.str(); 
} 
if (hyp == valor::conv::kHypOsc3FNormBar) { 
double rndmz = -900; 
bool show_mix12 = (mix12 > rndmz); 
bool show_mix13 = (mix13 > rndmz); 
bool show_mix23 = (mix23 > rndmz); 
bool show_mix = show_mix12 || show_mix13 || show_mix23; 
bool show_deltacp = (deltacp > rndmz); 
bool show_dm12sq = (dm12sq > rndmz); 
bool show_dm23sq = (dm23sq > rndmz); 
bool show_dmsq = show_dm12sq || show_dm23sq; 
bool show_betabar = (betabar > rndmz); 
if(show_mix) { 
out << mixparam << "["; 
if(show_mix12) { 
out << "12_" << TString::Format("%.3f",mix12); 
} 
if(show_mix13) { 
if(show_mix12) { 
out << ","; 
} 
out << "13_" << TString::Format("%.3f",mix13); 
} 
if(show_mix23) { 
if(show_mix13 || (!show_mix13 && show_mix12)) { 
out << ","; 
} 
out << "23_" << TString::Format("%.3f",mix23); 
} 
out << "]"; 
} 
if(show_mix && (show_deltacp || show_dmsq)) { 
out << ","; 
} 
if(show_deltacp) { 
out << "dcp_" << TString::Format("%.3f",deltacp); 
} 
if(show_deltacp && show_dmsq) { 
out << ","; 
} 
if(show_dmsq) { 
out << "dmsq_" << util::AsString(Opt::Instance()->gMassHierarchyAssumed) << "["; 
if(show_dm12sq) { 
out << "12_" << TString::Format("%.8f",dm12sq); 
} 
if(show_dm23sq) { 
if(show_dm12sq) { 
out << ","; 
} 
out << "23_" << TString::Format("%.6f",dm23sq); 
} 
out << "]eV2"; 
} 
if(show_betabar) { 
out << ",betabar_" << TString::Format("%.3f",betabar); 
} 
} 
if (hyp == valor::conv::kHypOscSterile4F) { 
out<<"sterile_3+1"; 
} 
if (hyp == valor::conv::kHypOscSterile5F) { 
out<<"sterile_3+2"; 
} 
if (hyp == valor::conv::kHypOscSterileEff) { 
out<<"sterile_eff"; 
} 
if( hyp == valor::conv::kHypNuMuDisapp2F) { 
out << mixparam << "23_" << TString::Format("%.3f",mix23) << ",dm23sq_" << TString::Format("%.5f",dm23sq) << "eV2"; 
} 
return out.str(); 
} 
PhysHypothesis_t util::PhysHypFromString (string sh) { 
if(sh == "decay" ) return kHypDecay; 
if(sh == "decoh" ) return kHypDecoh; 
if(sh == "2f_numu_disap" ) return kHypNuMuDisapp2F; 
if(sh == "3f_osc" ) return kHypOsc3F; 
if(sh == "3f_oscbar" ) return kHypOsc3FBar; 
if(sh == "3f_oscbar_dissap" ) return kHypOsc3FBarDissap; 
if(sh == "3f_oscbar_normbar") return kHypOsc3FBarNormBar; 
if(sh == "3f_osc_normbar") return kHypOsc3FNormBar; 
if(sh == "3f_nsi" ) return kHypNSI3F; 
if(sh == "4f_sterile_osc" ) return kHypOscSterile4F; 
if(sh == "5f_sterile_osc" ) return kHypOscSterile5F; 
if(sh == "eff_sterile_osc") return kHypOscSterileEff; 
if(sh == "void" ) return kHypVoid; 
return kHypUndefined; 
} 
string util::RawParamAsStringRaw(PhysParamId_t p) { 
switch(p) { 
case ( kPhypMixing23 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sinsq_2th23"; break; 
case(kNuMixSinsqTheta ) : return "sinsq_th23"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing13 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sinsq_2th_13"; break; 
case(kNuMixSinsqTheta ) : return "sinsq_th13"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing12 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sinsq_2th12"; break; 
case(kNuMixSinsqTheta ) : return "sinsq_th12"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypCPV ) : { 
conv::NuOscDeltaCP_t cpv = Opt::Instance()->gOscDeltaCP; 
switch(cpv) { 
case(kNuDeltaCPPhase) : return "delta_cp"; break; 
case(kNuDeltaCPSin ) : return "sin_delta_cp"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDm23sq ) : { 
NuOscDmsqScheme_t dmscheme = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch(dmscheme) { 
case(kNuDmsq12andAbs23) : return "dmsq_32"; break; 
case(kNuDmsq12andAbs31) : return "dmsq_31"; break; 
case(kNuDmsqFogliLisi ) : return "dmsq_fl"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDm12sq ) : { 
NuOscDmsqScheme_t dmscheme = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch(dmscheme) { 
case(kNuDmsq12andAbs23) : return "dmsq_12"; break; 
case(kNuDmsq12andAbs31) : return "dmsq_12"; break; 
case(kNuDmsqFogliLisi ) : return "dmsq_fl"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing23Bar ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sinsq_2th23_bar"; break; 
case(kNuMixSinsqTheta ) : return "sinsq_th23_bar"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing13Bar ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sinsq_2th13_bar"; break; 
case(kNuMixSinsqTheta ) : return "sinsq_th13_bar"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing12Bar ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sinsq_2th12_bar"; break; 
case(kNuMixSinsqTheta ) : return "sinsq_th12_bar"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypCPVBar ) : { 
conv::NuOscDeltaCP_t cpv = Opt::Instance()->gOscDeltaCP; 
switch(cpv) { 
case(kNuDeltaCPPhase) : return "deltacp_bar"; break; 
case(kNuDeltaCPSin ) : return "sin_deltacp_bar"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDm23sqBar ) : { 
NuOscDmsqScheme_t dmscheme = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch(dmscheme) { 
case(kNuDmsq12andAbs23) : return "dmsq_32_bar"; break; 
case(kNuDmsq12andAbs31) : return "dmsq_31_bar"; break; 
case(kNuDmsqFogliLisi ) : return "dmsq_fl_bar"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDm12sqBar ) : { 
NuOscDmsqScheme_t dmscheme = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch(dmscheme) { 
case(kNuDmsq12andAbs23) : return "dmsq_12_bar"; break; 
case(kNuDmsq12andAbs31) : return "dmsq_12_bar"; break; 
case(kNuDmsqFogliLisi ) : return "dmsq_fl_bar"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypBetaBar ) : return "beta_bar"; break; 
case ( kPhypAlphaDecay ) : return "alpha_decay"; break; 
case ( kPhypSinsq2ThetaDecay ) : return "sinsq_2th_decay"; break; 
case ( kPhypMusqDecoh ) : return "musq_decoh"; break; 
case ( kPhypSinsq2ThetaDecoh ) : return "sinsq_2th_decoh"; break; 
case ( kPhypMixing14 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sinsq_2th14"; break; 
case(kNuMixSinsqTheta ) : return "sinsq_th14"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing15 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sinsq_2th15"; break; 
case(kNuMixSinsqTheta ) : return "sinsq_th15"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing24 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sinsq_2th24"; break; 
case(kNuMixSinsqTheta ) : return "sinsq_th24"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing25 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sinsq_2th25"; break; 
case(kNuMixSinsqTheta ) : return "sinsq_th25"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing34 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sinsq_2th34"; break; 
case(kNuMixSinsqTheta ) : return "sinsq_th34"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing35 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sinsq_2th35"; break; 
case(kNuMixSinsqTheta ) : return "sinsq_th35"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDelta12 ) : return "delta_12"; break; 
case ( kPhypDelta13 ) : return "delta_13"; break; 
case ( kPhypDelta15 ) : return "delta_15"; break; 
case ( kPhypDelta34 ) : return "delta_34"; break; 
case ( kPhypDelta35 ) : return "delta_35"; break; 
case ( kPhypDm41sq ) : return "dmsq_41"; break; 
case ( kPhypDm51sq ) : return "dmsq_51"; break; 
case ( kPhypNSIepsMuTau ) : return "nsi_epsilonMuTau"; break; 
case ( kPhypMixingEE ) : return "sinsq2thEE"; break; 
case ( kPhypMixingMuMu ) : return "sinsq2thMuMu"; break; 
default: { 
} 
} 
if (p >= kNuis000 && p< kLastNuisParam) { 
string out(TString::Format("nuis%03d",p-kNuis000).Data()); 
return out; 
} 
if (p == kLastNuisParam) { 
return "LastNuisanceParam"; 
} 
return "?"; 
} 
string util::RawParamAsString(PhysParamId_t p) { 
switch(p) { 
case ( kPhypMixing23 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^2(2*theta_23)"; break; 
case(kNuMixSinsqTheta ) : return "sin^2(theta_23)"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing13 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^2(2*theta_13)"; break; 
case(kNuMixSinsqTheta ) : return "sin^2(theta_13)"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing12 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^2(2*theta_12)"; break; 
case(kNuMixSinsqTheta ) : return "sin^2(theta_12)"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypCPV ) : { 
conv::NuOscDeltaCP_t cpv = Opt::Instance()->gOscDeltaCP; 
switch(cpv) { 
case(kNuDeltaCPPhase) : return "delta_cp"; break; 
case(kNuDeltaCPSin ) : return "sin(delta_cp)"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDm23sq ) : { 
NuOscDmsqScheme_t dmscheme = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch(dmscheme) { 
case(kNuDmsq12andAbs23) : return "|Dm^2_32|"; break; 
case(kNuDmsq12andAbs31) : return "|Dm^2_31|"; break; 
case(kNuDmsqFogliLisi ) : return "|Dm^2_FL|"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDm12sq ) : { 
NuOscDmsqScheme_t dmscheme = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch(dmscheme) { 
case(kNuDmsq12andAbs23) : return "Dm^2_12"; break; 
case(kNuDmsq12andAbs31) : return "Dm^2_12"; break; 
case(kNuDmsqFogliLisi ) : return "dm^2_FL"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing23Bar ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^2(2*theta_23 bar)"; break; 
case(kNuMixSinsqTheta ) : return "sin^2(theta_23 bar)"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing13Bar ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^2(2*theta_13 bar)"; break; 
case(kNuMixSinsqTheta ) : return "sin^2(theta_13 bar)"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing12Bar ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^2(2*theta_12 bar)"; break; 
case(kNuMixSinsqTheta ) : return "sin^2(theta_12 bar)"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypCPVBar ) : { 
conv::NuOscDeltaCP_t cpv = Opt::Instance()->gOscDeltaCP; 
switch(cpv) { 
case(kNuDeltaCPPhase) : return "delta_cp bar"; break; 
case(kNuDeltaCPSin ) : return "sin(delta_cp bar)"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDm23sqBar ) : { 
NuOscDmsqScheme_t dmscheme = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch(dmscheme) { 
case(kNuDmsq12andAbs23) : return "|Dm^2_32| bar"; break; 
case(kNuDmsq12andAbs31) : return "|Dm^2_31| bar"; break; 
case(kNuDmsqFogliLisi ) : return "|Dm^2_FL| bar"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDm12sqBar ) : { 
NuOscDmsqScheme_t dmscheme = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch(dmscheme) { 
case(kNuDmsq12andAbs23) : return "Dm^2_12 bar"; break; 
case(kNuDmsq12andAbs31) : return "Dm^2_12 bar"; break; 
case(kNuDmsqFogliLisi ) : return "dm^2_FL bar"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypBetaBar ) : return "beta bar"; break; 
case ( kPhypAlphaDecay ) : return "alpha_decay"; break; 
case ( kPhypSinsq2ThetaDecay ) : return "sin^2(2*theta_decay)"; break; 
case ( kPhypMusqDecoh ) : return "mu^2_decoh"; break; 
case ( kPhypSinsq2ThetaDecoh ) : return "sin^2(2*theta_decoh)"; break; 
case ( kPhypMixing14 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^2(2*theta_14)"; break; 
case(kNuMixSinsqTheta ) : return "sin^2(theta_14)"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing15 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^2(2*theta_15)"; break; 
case(kNuMixSinsqTheta ) : return "sin^2(theta_15)"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing24 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^2(2*theta_24)"; break; 
case(kNuMixSinsqTheta ) : return "sin^2(theta_24)"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing25 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^2(2*theta_25)"; break; 
case(kNuMixSinsqTheta ) : return "sin^2(theta_25)"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing34 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^2(2*theta_34)"; break; 
case(kNuMixSinsqTheta ) : return "sin^2(theta_34)"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing35 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^2(2*theta_35)"; break; 
case(kNuMixSinsqTheta ) : return "sin^2(theta_35)"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDelta12 ) : return "delta_12"; break; 
case ( kPhypDelta13 ) : return "delta_13"; break; 
case ( kPhypDelta15 ) : return "delta_15"; break; 
case ( kPhypDelta34 ) : return "delta_34"; break; 
case ( kPhypDelta35 ) : return "delta_35"; break; 
case ( kPhypDm41sq ) : return "|Dm^2_41|"; break; 
case ( kPhypDm51sq ) : return "|Dm^2_51|"; break; 
case ( kPhypNSIepsMuTau ) : return "nsi_epsilonMuTau"; break; 
case(kPhypMixingEE ) : return "sin^2(2*theta_ee)" ; break; 
case(kPhypMixingMuMu) : return "sin^2(2*theta_mumu)"; break; 
default: { 
} 
} 
if (p >= kNuis000 && p< kLastNuisParam) { 
string out(TString::Format("nuis%03d",p-kNuis000).Data()); 
return out; 
} 
if (p == kLastNuisParam) { 
return "LastNuisanceParam"; 
} 
return "?"; 
} 
string util::RawParamAsStringTex(PhysParamId_t p) { 
switch(p) { 
case ( kPhypMixing23 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "$\\sin^2(2\\theta_{23})$"; break; 
case(kNuMixSinsqTheta ) : return "$\\sin^2(\\theta_{23})$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing13 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "$\\sin^2(2\\theta_{13})$"; break; 
case(kNuMixSinsqTheta ) : return "$\\sin^2(\\theta_{13})$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing12 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "$\\sin^2(2\\theta_{12})$"; break; 
case(kNuMixSinsqTheta ) : return "$\\sin^2(\\theta_{12})$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypCPV ) : { 
conv::NuOscDeltaCP_t cpv = Opt::Instance()->gOscDeltaCP; 
switch(cpv) { 
case(kNuDeltaCPPhase) : return "$\\delta_{CP}$"; break; 
case(kNuDeltaCPSin ) : return "$sin(\\delta_{CP})$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDm12sq ) : { 
NuOscDmsqScheme_t dmscheme = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch(dmscheme) { 
case(kNuDmsq12andAbs23) : return "$\\Delta m^2_{21}$"; break; 
case(kNuDmsq12andAbs31) : return "$\\Delta m^2_{21}$"; break; 
case(kNuDmsqFogliLisi ) : return "$\\delta m^2$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDm23sq ) : { 
NuOscDmsqScheme_t dmscheme = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch(dmscheme) { 
case(kNuDmsq12andAbs23) : return "$|\\Delta m^2_{32}|$"; break; 
case(kNuDmsq12andAbs31) : return "$|\\Delta m^2_{31}|$"; break; 
case(kNuDmsqFogliLisi ) : return "$|\\Delta m^2|$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing23Bar ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "$\\sin^2(2\\bar{\\theta_{23}})$"; break; 
case(kNuMixSinsqTheta ) : return "$\\sin^2(\\bar{\\theta_{23}})$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing13Bar ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "$\\sin^2(2\\bar{\\theta_{13}})$"; break; 
case(kNuMixSinsqTheta ) : return "$\\sin^2(\\bar{\\theta_{13}})$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing12Bar ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "$\\sin^2(2\\bar{\\theta_{12}})$"; break; 
case(kNuMixSinsqTheta ) : return "$\\sin^2(\\bar{\\theta_{12}})$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypCPVBar ) : { 
conv::NuOscDeltaCP_t cpv = Opt::Instance()->gOscDeltaCP; 
switch(cpv) { 
case(kNuDeltaCPPhase) : return "$\\bar{\\delta_{CP}}$"; break; 
case(kNuDeltaCPSin ) : return "$sin(\\bar{\\delta_{CP}})$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDm12sqBar ) : { 
NuOscDmsqScheme_t dmscheme = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch(dmscheme) { 
case(kNuDmsq12andAbs23) : return "$\\bar{\\Delta m^2_{21}}$"; break; 
case(kNuDmsq12andAbs31) : return "$\\bar{\\Delta m^2_{21}}$"; break; 
case(kNuDmsqFogliLisi ) : return "$\\bar{\\delta m^2}$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDm23sqBar ) : { 
NuOscDmsqScheme_t dmscheme = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch(dmscheme) { 
case(kNuDmsq12andAbs23) : return "$|\\bar{\\Delta m^2_{32}}|$"; break; 
case(kNuDmsq12andAbs31) : return "$|\\bar{\\Delta m^2_{31}}|$"; break; 
case(kNuDmsqFogliLisi ) : return "$|\\bar{\\Delta m^2}|$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypBetaBar ) : return "$\\bar{\\beta}$"; break; 
case ( kPhypAlphaDecay ) : return "$\\alpha_{decay}$"; break; 
case ( kPhypSinsq2ThetaDecay ) : return "$\\sin^2(2\\theta_{decay})$"; break; 
case ( kPhypMusqDecoh ) : return "$\\mu^2_{decoh}$"; break; 
case ( kPhypSinsq2ThetaDecoh ) : return "$\\sin^2(2\\theta_{decoh})$"; break; 
case ( kPhypMixing14 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "$\\sin^2(2\\theta_{14})$"; break; 
case(kNuMixSinsqTheta ) : return "$\\sin^2(\\theta_{14})$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing15 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "$\\sin^2(2\\theta_{15})$"; break; 
case(kNuMixSinsqTheta ) : return "$\\sin^2(\\theta_{15})$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing24 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "$\\sin^2(2\\theta_{24})$"; break; 
case(kNuMixSinsqTheta ) : return "$\\sin^2(\\theta_{24})$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing25 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "$\\sin^2(2\\theta_{25})$"; break; 
case(kNuMixSinsqTheta ) : return "$\\sin^2(\\theta_{25})$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing34 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "$\\sin^2(2\\theta_{34})$"; break; 
case(kNuMixSinsqTheta ) : return "$\\sin^2(\\theta_{34})$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing35 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "$\\sin^2(2\\theta_{35})$"; break; 
case(kNuMixSinsqTheta ) : return "$\\sin^2(\\theta_{35})$"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDelta12 ) : return "$\\delta_{12}$"; break; 
case ( kPhypDelta13 ) : return "$\\delta_{13}$"; break; 
case ( kPhypDelta15 ) : return "$\\delta_{15}$"; break; 
case ( kPhypDelta34 ) : return "$\\delta_{34}$"; break; 
case ( kPhypDelta35 ) : return "$\\delta_{35}$"; break; 
case ( kPhypDm41sq ) : return "$|\\Delta m^2_{41}|$"; break; 
case ( kPhypDm51sq ) : return "$|\\Delta m^2_{51}|$"; break; 
case ( kPhypNSIepsMuTau ) : return "$nsi_\\epsilon_{\\mu\\tau}$"; break; 
case(kPhypMixingEE ) : return "$\\sin^2(2\\theta_{ee})$" ; break; 
case(kPhypMixingMuMu) : return "$\\sin^2(2\\theta_{\\mu\\mu})$"; break; 
default : return "--"; 
} 
return "--"; 
} 
string util::RawParamAsStringRooTex(PhysParamId_t p) { 
switch(p) { 
case ( kPhypMixing23 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^{2}(2#theta_{23})"; break; 
case(kNuMixSinsqTheta ) : return "sin^{2}(#theta_{23})"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing13 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^{2}(2#theta_{13})"; break; 
case(kNuMixSinsqTheta ) : return "sin^{2}(#theta_{13})"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing12 ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^{2}(2#theta_{12})"; break; 
case(kNuMixSinsqTheta ) : return "sin^{2}(#theta_{12})"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypCPV ) : { 
conv::NuOscDeltaCP_t cpv = Opt::Instance()->gOscDeltaCP; 
switch(cpv) { 
case(kNuDeltaCPPhase) : return "#delta_{CP}"; break; 
case(kNuDeltaCPSin ) : return "sin(#delta_{CP})"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDm23sq ) : { 
NuOscDmsqScheme_t omp = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch(omp) { 
case(kNuDmsqFogliLisi ) : return "|#Deltam^{2}|"; break; 
case(kNuDmsq12andAbs23) : return "|#Deltam^{2}_{32}|"; break; 
case(kNuDmsq12andAbs31) : return "|#Deltam^{2}_{31}|"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDm12sq ) : { 
NuOscDmsqScheme_t omp = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch(omp) { 
case(kNuDmsqFogliLisi): return "#deltam^{2}"; break; 
case(kNuDmsq12andAbs23): case(kNuDmsq12andAbs31): return "#Delta m^{2}_{21}"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing23Bar ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^{2}(#bar{2#theta_{23}})"; break; 
case(kNuMixSinsqTheta ) : return "sin^{2}(#bar{#theta_{23}})"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing13Bar ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^{2}(2#bar{#theta_{13}})"; break; 
case(kNuMixSinsqTheta ) : return "sin^{2}(#bar{#theta_{13}})"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypMixing12Bar ) : { 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta) : return "sin^{2}(2#bar{#theta_{12}})"; break; 
case(kNuMixSinsqTheta ) : return "sin^{2}(#bar{#theta_{12}})"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypCPVBar ) : { 
conv::NuOscDeltaCP_t cpv = Opt::Instance()->gOscDeltaCP; 
switch(cpv) { 
case(kNuDeltaCPPhase) : return "#bar{#delta_{CP}}"; break; 
case(kNuDeltaCPSin ) : return "sin(#bar{#delta_{CP}})"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDm23sqBar ) : { 
NuOscDmsqScheme_t omp = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch(omp) { 
case(kNuDmsqFogliLisi ) : return "|#bar{#Deltam^{2}}|"; break; 
case(kNuDmsq12andAbs23) : return "|#bar{#Deltam^{2}_{32}}|"; break; 
case(kNuDmsq12andAbs31) : return "|#bar{#Deltam^{2}_{31}}|"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypDm12sqBar ) : { 
NuOscDmsqScheme_t omp = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch(omp) { 
case(kNuDmsqFogliLisi): return "#bar{#deltam^{2}}"; break; 
case(kNuDmsq12andAbs23): case(kNuDmsq12andAbs31): return "#bar{#Delta m^{2}_{21}}"; break; 
default : return "--"; break; 
} 
} 
break; 
case ( kPhypBetaBar ) : return "#bar{#beta}"; break; 
case ( kPhypAlphaDecay ) : return "#alpha_{decay}"; break; 
case ( kPhypSinsq2ThetaDecay ) : return "sin^{2}(2#theta_{decay})"; break; 
case ( kPhypMusqDecoh ) : return "#mu^{2}_{decoh}"; break; 
case ( kPhypSinsq2ThetaDecoh ) : return "sin^{2}(2#theta_{decoh})"; break; 
case(kPhypMixingEE ) : return "$\\sin^2(2\\theta_{ee})$" ; break; 
case(kPhypMixingMuMu) : return "$\\sin^2(2\\theta_{#mu#mu})$"; break; 
default : return "--"; 
} 
return "--"; 
} 
valor::conv::PhysParamId_t valor::util::PhysParamIdFromRawString(string sh) { 
string lsh = util::ToLowerCase(sh); 
for (int i = 0 ; i < knppmax ; i++) { 
PhysParamId_t k = (PhysParamId_t) i ; 
string s = util::ToLowerCase(RawParamAsString(k)); 
if (k != kPhypUndefined && (lsh == s) ) return k; 
} 
assert(1); 
return kPhypUndefined; 
} 
bool util::IsMixingAngle(PhysParamId_t p) { 
switch(p) { 
case ( kPhypMixing23 ) : return true; break; 
case ( kPhypMixing13 ) : return true; break; 
case ( kPhypMixing12 ) : return true; break; 
case ( kPhypMixing23Bar ) : return true; break; 
case ( kPhypMixing13Bar ) : return true; break; 
case ( kPhypMixing12Bar ) : return true; break; 
case ( kPhypSinsq2ThetaDecay ) : return true; break; 
case ( kPhypSinsq2ThetaDecoh ) : return true; break; 
case ( kPhypMixing14 ) : return true; break; 
case ( kPhypMixing15 ) : return true; break; 
case ( kPhypMixing24 ) : return true; break; 
case ( kPhypMixing25 ) : return true; break; 
case ( kPhypMixing34 ) : return true; break; 
case ( kPhypMixing35 ) : return true; break; 
default : return false; 
} 
return false; 
} 
bool util::IsMassSplitting(PhysParamId_t p) { 
switch(p) { 
case ( kPhypDm23sq ) : return true; 
case ( kPhypDm12sq ) : return true; 
case ( kPhypDm23sqBar ) : return true; 
case ( kPhypDm12sqBar ) : return true; 
case ( kPhypDm41sq ) : return true; 
case ( kPhypDm51sq ) : return true; 
default : return false; 
} 
return false; 
} 
bool util::IsPhase(PhysParamId_t p) { 
switch(p) { 
case ( kPhypCPV ) : return true; 
case ( kPhypCPVBar ) : return true; 
case ( kPhypDelta12 ) : return true; 
case ( kPhypDelta13 ) : return true; 
case ( kPhypDelta15 ) : return true; 
case ( kPhypDelta34 ) : return true; 
case ( kPhypDelta35 ) : return true; 
default : return false; 
} 
return false; 
} 
bool util::IsNormalization(PhysParamId_t p) { 
switch(p) { 
case ( kPhypBetaBar ) : return true; 
default : return false; 
} 
return false; 
} 
bool util::IsSystematic(PhysParamId_t p) { 
if(p >= kNuis000) return true; 
return false; 
} 
string util::AsString(KineVar_t kv) { 
switch(kv) { 
case (kvEtrue ) : return "Etrue"; break; 
case (kvQ2true ) : return "Q2true"; break; 
case (kvEreco ) : return "Ereco"; break; 
case (kvEvis ) : return "Evis"; break; 
case (kvYreco ) : return "yreco"; break; 
case (kvThetareco ) : return "Thetareco"; break; 
case (kvq0reco ) : return "q0reco"; break; 
case (kvq3reco ) : return "|q|reco"; break; 
case (kvmodqreco ) : return "|q|reco"; break; 
default : LOG("KineVar",pERROR) << "Unrecognized kinematic variable: " << kv; 
} 
return ""; 
} 
string util::AsStringTeX(KineVar_t kv, bool root) { 
string name = ""; 
switch(kv) { 
case (kvEtrue ) : name = "E_{true} (GeV)"; break; 
case (kvQ2true ) : name = "Q^{2}_{true} (GeV^{2})"; break; 
case (kvEreco ) : name = "E_{reco} (GeV)"; break; 
case (kvEvis ) : name = "E_{vis} (GeV)"; break; 
case (kvYreco ) : name = "y_{reco}"; break; 
case (kvThetareco ) : name = "\theta_{reco}"; break; 
case (kvq0reco ) : name = "q_{0 reco}"; break; 
case (kvq3reco ) : name = "|\\overrightarrow{q}|_{reco}"; break; 
case (kvmodqreco ) : name = "|\\overrightarrow{q}|_{reco}"; break; 
default : LOG("KineVar",pERROR) << "Unrecognized kinematic variable: " << kv; 
} 
if(root) { 
replace( name.begin(), name.end(), '\\', '#' ); 
size_t ind = name.find("#sin",0); 
if (ind != string::npos) (name.replace(ind,4," sin")); 
return util::TrimSpaces(name); 
} 
return name; 
} 
bool util::IsReco(KineVar_t kv) { 
switch(kv) { 
case (kvEtrue ) : return false; 
case (kvQ2true ) : return false; 
case (kvEreco ) : return true; 
case (kvEvis ) : return true; 
case (kvYreco ) : return true; 
case (kvThetareco ) : return true; 
case (kvq0reco ) : return true; 
case (kvq3reco ) : return true; 
case (kvmodqreco ) : return true; 
default: LOG("KineVar",pERROR) << "Unrecognized kinematic variable: " << kv; 
} 
return false; 
} 
bool util::IsTrue(KineVar_t kv) { 
bool is_reco = util::IsReco(kv); 
return (!is_reco); 
} 
string util::AsString(KineSpace_t ks) { 
switch(ks) { 
case (kspEtrue) : return "Etrue"; break; 
case (kspEreco) : return "Ereco"; break; 
case (kspEvis) : return "Evis"; break; 
case (kspYreco) : return "yreco"; break; 
case (kspThetareco) : return "Thetareco"; break; 
case (kspErecoYreco) : return "Ereco,yreco"; break; 
case (kspEtrueQ2true) : return "Etrue,Q2true"; break; 
case (kspErecoThetareco) : return "Ereco,Thetareco"; break; 
case (kspq0recoq3reco) : return "q0reco,q3reco"; break; 
case (kspq0recomodqreco) : return "q0reco,|q|reco"; break; 
case (kspErecoEvis) : return "Ereco,Evis"; break; 
default : LOG("KineSpace",pERROR) << "Unrecognized kinematic space: " << ks; 
} 
return ""; 
} 
string util::AsStringTeX(KineSpace_t ks, bool root) { 
string name = ""; 
switch(ks) { 
case (kspEtrue) : name = "<E_{true}>"; break; 
case (kspEreco) : name = "<E_{reco}>"; break; 
case (kspEvis ) : name = "<E_{vis}>"; break; 
case (kspYreco) : name = "<y_{reco}>"; break; 
case (kspThetareco) : name = "\theta_{reco}"; break; 
case (kspErecoYreco) : name = "<E_{reco},y_{reco}>"; break; 
case (kspEtrueQ2true) : name = "<E_{true},Q^2_{true}>"; break; 
case (kspErecoThetareco) : name = "<E_{reco},\theta_{reco}"; break; 
case (kspq0recoq3reco) : name = "<q_{0 reco},q_{3 reco}>"; break; 
case (kspq0recomodqreco) : name = "<q_{0 reco},|\\overrightarrow{q}|_{reco}>"; break; 
case (kspErecoEvis) : name = "<E_{reco},E_{vis}>"; break; 
default : LOG("KineSpace",pERROR) << "Unrecognized kinematic space: " << ks; 
} 
if(root) return name; 
return name; 
} 
bool util::IsPureReco(KineSpace_t ks) { 
switch(ks) { 
case (kspEtrue) : return false; 
case (kspEreco) : return true; 
case (kspEvis ) : return true; 
case (kspYreco) : return true; 
case (kspThetareco) : return true; 
case (kspErecoYreco) : return true; 
case (kspEtrueQ2true) : return false; 
case (kspErecoThetareco) : return true; 
case (kspq0recoq3reco) : return true; 
case (kspq0recomodqreco) : return true; 
case (kspErecoEvis) : return true; 
default: LOG("KineVar",pERROR) << "Unrecognized kinematic space: " << ks; 
} 
return false; 
} 
bool util::IsPureTrue(KineSpace_t ks) { 
switch(ks) { 
case (kspEtrue) : return true; 
case (kspEreco) : return false; 
case (kspEvis ) : return false; 
case (kspYreco) : return false; 
case (kspThetareco) : return false; 
case (kspErecoYreco) : return false; 
case (kspEtrueQ2true) : return true; 
case (kspErecoThetareco) : return false; 
case (kspq0recoq3reco) : return false; 
case (kspq0recomodqreco) : return false; 
case (kspErecoEvis) : return false; 
default: LOG("KineVar",pERROR) << "Unrecognized kinematic space: " << ks; 
} 
return false; 
} 
bool util::IsMixedRecoTrue(KineSpace_t ks) { 
switch(ks) { 
case (kspEtrue) : return false; 
case (kspEreco) : return false; 
case (kspEvis ) : return false; 
case (kspYreco) : return false; 
case (kspThetareco) : return false; 
case (kspErecoYreco) : return false; 
case (kspEtrueQ2true) : return false; 
case (kspErecoThetareco) : return false; 
case (kspq0recoq3reco) : return false; 
case (kspq0recomodqreco) : return false; 
case (kspErecoEvis) : return false; 
default: LOG("KineVar",pERROR) << "Unrecognized kinematic space: " << ks; 
} 
return false; 
} 
int util::NDim(KineSpace_t ks) { 
switch(ks) { 
case (kspEtrue) : return 1; 
case (kspEreco) : return 1; 
case (kspEvis ) : return 1; 
case (kspYreco) : return 1; 
case (kspThetareco) : return 1; 
case (kspErecoYreco) : return 2; 
case (kspEtrueQ2true) : return 2; 
case (kspErecoThetareco) : return 2; 
case (kspq0recoq3reco) : return 2; 
case (kspq0recomodqreco) : return 2; 
case (kspErecoEvis) : return 2; 
default: LOG("KineVar",pERROR) << "Unrecognized kinematic space: " << ks; 
} 
return 0; 
} 
int util::NDimReco(KineSpace_t ks) { 
switch(ks) { 
case (kspEtrue) : return 0; 
case (kspEreco) : return 1; 
case (kspEvis ) : return 1; 
case (kspYreco) : return 1; 
case (kspThetareco) : return 1; 
case (kspErecoYreco) : return 2; 
case (kspEtrueQ2true) : return 0; 
case (kspErecoThetareco) : return 2; 
case (kspq0recoq3reco) : return 2; 
case (kspq0recomodqreco) : return 2; 
case (kspErecoEvis) : return 2; 
default: LOG("KineVar",pERROR) << "Unrecognized kinematic space: " << ks; 
} 
return 0; 
} 
int util::NDimTrue(KineSpace_t ks) { 
switch(ks) { 
case (kspEtrue) : return 1; 
case (kspEreco) : return 0; 
case (kspEvis ) : return 0; 
case (kspYreco) : return 0; 
case (kspThetareco) : return 0; 
case (kspErecoYreco) : return 0; 
case (kspEtrueQ2true) : return 2; 
case (kspErecoThetareco) : return 0; 
case (kspq0recoq3reco) : return 0; 
case (kspq0recomodqreco) : return 0; 
case (kspErecoEvis) : return 0; 
default: LOG("KineVar",pERROR) << "Unrecognized kinematic space: " << ks; 
} 
return 0; 
} 
conv::KineSpace_t util::SubSpaceReco(conv::KineSpace_t ks) { 
switch(ks) { 
case (kspEtrue) : return kspUndefined; 
case (kspEreco) : return kspEreco; 
case (kspEvis ) : return kspEvis; 
case (kspYreco) : return kspYreco; 
case (kspThetareco) : return kspThetareco; 
case (kspErecoYreco) : return kspErecoYreco; 
case (kspEtrueQ2true) : return kspUndefined; 
case (kspErecoThetareco) : return kspErecoThetareco; 
case (kspq0recoq3reco) : return kspq0recoq3reco; 
case (kspq0recomodqreco) : return kspq0recoq3reco; 
case (kspErecoEvis) : return kspErecoEvis; 
default: LOG("KineVar",pERROR) << "Unrecognized kinematic space: " << ks; 
} 
return kspUndefined; 
} 
conv::KineSpace_t util::SubSpaceTrue(conv::KineSpace_t ks) { 
switch(ks) { 
case (kspEtrue) : return kspEtrue; 
case (kspEreco) : return kspUndefined; 
case (kspEvis ) : return kspUndefined; 
case (kspYreco) : return kspUndefined; 
case (kspThetareco) : return kspUndefined; 
case (kspErecoYreco) : return kspUndefined; 
case (kspEtrueQ2true) : return kspEtrueQ2true; 
case (kspErecoThetareco) : return kspUndefined; 
case (kspq0recoq3reco) : return kspUndefined; 
case (kspq0recomodqreco) : return kspUndefined; 
case (kspErecoEvis) : return kspUndefined; 
default: LOG("KineVar",pERROR) << "Unrecognized kinematic space: " << ks; 
} 
return kspUndefined; 
} 
std::vector<valor::conv::KineVar_t> util::KineVarSubset(conv::KineSpace_t original, conv::KineSpace_t target) { 
std::vector<KineVar_t> originalKineVars = util::KineVar(original); 
std::vector<KineVar_t> targetKineVars = util::KineVar(target); 
if(targetKineVars.size() >= originalKineVars.size()) { 
assert(1); 
util::Die(-1); 
} 
else { 
for(auto kv : targetKineVars) { 
if(std::find(originalKineVars.begin(), originalKineVars.end(), kv) == originalKineVars.end()) { 
assert(1); 
util::Die(-1); 
} 
} 
} 
return targetKineVars; 
} 
vector<KineVar_t> util::KineVar(conv::KineSpace_t ks) { 
vector<KineVar_t> vv; 
switch(ks) { 
case (kspEtrue) : vv.push_back(kvEtrue); 
break; 
case (kspEreco) : vv.push_back(kvEreco); 
break; 
case (kspEvis) : vv.push_back(kvEvis); 
break; 
case (kspYreco) : vv.push_back(kvYreco); 
break; 
case (kspThetareco) : vv.push_back(kvThetareco); 
break; 
case (kspErecoYreco) : vv.push_back(kvEreco); 
vv.push_back(kvYreco); 
break; 
case (kspEtrueQ2true) : vv.push_back(kvEtrue); 
vv.push_back(kvQ2true); 
break; 
case (kspErecoThetareco) : vv.push_back(kvEreco); 
vv.push_back(kvThetareco); 
case (kspq0recoq3reco) : vv.push_back(kvq0reco); 
vv.push_back(kvq3reco); 
break; 
case (kspq0recomodqreco) : vv.push_back(kvq0reco); 
vv.push_back(kvmodqreco); 
break; 
case (kspErecoEvis): vv.push_back(kvEreco); 
vv.push_back(kvEvis); 
break; 
default: LOG("KineVar",pERROR) << "Unrecognized kinematic space: " << ks; 
} 
return vv; 
} 
vector<KineVar_t> util::KineVarReco(conv::KineSpace_t ks) { 
vector<KineVar_t> vv; 
switch(ks) { 
case (kspEtrue) : break; 
case (kspEreco) : vv.push_back(kvEreco); 
break; 
case (kspEvis) : vv.push_back(kvEvis); 
break; 
case (kspYreco) : vv.push_back(kvYreco); 
break; 
case (kspThetareco) : vv.push_back(kvThetareco); 
break; 
case (kspErecoYreco) : vv.push_back(kvEreco); 
vv.push_back(kvYreco); 
break; 
case (kspEtrueQ2true) : break; 
case (kspErecoThetareco) : vv.push_back(kvEreco); 
vv.push_back(kvThetareco); 
case (kspq0recoq3reco) : vv.push_back(kvq0reco); 
vv.push_back(kvq3reco); 
break; 
case (kspq0recomodqreco) : vv.push_back(kvq0reco); 
vv.push_back(kvmodqreco); 
break; 
case (kspErecoEvis): vv.push_back(kvEreco); 
vv.push_back(kvEvis); 
break; 
default: LOG("KineVar",pERROR) << "Unrecognized kinematic space: " << ks; 
} 
return vv; 
} 
vector<KineVar_t> util::KineVarTrue(conv::KineSpace_t ks) { 
vector<KineVar_t> vv; 
switch(ks) { 
case (kspEtrue) : vv.push_back(kvEtrue); 
break; 
case (kspEreco) : break; 
case (kspEvis) : break; 
case (kspYreco) : break; 
case (kspThetareco) : break; 
case (kspErecoYreco) : break; 
case (kspEtrueQ2true) : vv.push_back(kvEtrue); 
vv.push_back(kvQ2true); 
break; 
case (kspErecoThetareco) : break; 
case (kspq0recoq3reco) : break; 
case (kspq0recomodqreco) : break; 
case (kspErecoEvis): break; 
default: LOG("KineVar",pERROR) << "Unrecognized kinematic space: " << ks; 
} 
return vv; 
} 
conv::KineSpace_t util::KineSpaceFromInt(int i_sp) { 
if(i_sp >= (int)kspEtrue && i_sp <= (int) kspq0recomodqreco) return (KineSpace_t)i_sp; 
return kspUndefined; 
} 
conv::KineSpace_t util::KineSpaceFromString(string str_sp) { 
string lc_str_sp = util::ToLowerCase(str_sp); 
for (int i = 0 ; i < conv::kMaxKineSpaces; i++) { 
KineSpace_t sp = (KineSpace_t)i; 
string this_lc_str_sp = util::ToLowerCase(util::AsString(sp)); 
if(lc_str_sp==this_lc_str_sp && this_lc_str_sp!="") { 
return sp; 
} 
} 
return kspUndefined; 
} 
string util::KineSpaceAsString(KineSpace_t ks) { return util::AsString(ks); } 
string util::KineSpaceAsStringTeX(KineSpace_t ks, bool root) { return util::AsStringTeX(ks, root); } 
string util::AsString(NuFlavour_t f) { 
switch(f) { 
case (kNuE ) : return "NuE" ; 
case (kNuMu ) : return "NuMu"; 
case (kNuTau ) : return "NuTau"; 
case (kNuEBar ) : return "NuEBar" ; 
case (kNuMuBar ) : return "NuMuBar"; 
case (kNuTauBar) : return "NuTauBar"; 
default : return "Undefined"; 
} 
} 
string util::FlavourAsString(NuFlavour_t f) { return AsString(f);} 
NuFlavour_t util::FlavourFromString(string flavname) { 
std::transform(flavname.begin(), flavname.end(), flavname.begin(), ::tolower); 
for (int i = 0 ; i < kNNuFlavour ; i++ ) { 
NuFlavour_t f = (NuFlavour_t)i; 
string flavname2 = util::FlavourAsString(f); 
std::transform(flavname2.begin(), flavname2.end(), flavname2.begin(), ::tolower); 
if(flavname==flavname2 && flavname2!="undefined") { 
return f; 
} 
} 
return kNuFlavourUndefined; 
} 
NuFlavour_t util::FlavourFromPDG(int nu_pdg) { 
switch (nu_pdg) { 
case (conv::kPdgNuE ) : return kNuE ; 
case (conv::kPdgNuMu ) : return kNuMu ; 
case (conv::kPdgNuTau ) : return kNuTau ; 
case (conv::kPdgNuEBar ) : return kNuEBar ; 
case (conv::kPdgNuMuBar ) : return kNuMuBar ; 
case (conv::kPdgNuTauBar) : return kNuTauBar; 
default : return kNuFlavourUndefined; 
} 
return kNuFlavourUndefined; 
} 
string util::AsString(NuMassHierarchy_t m) { 
switch(m) { 
case (kNmhNormal) : return "Normal"; 
break; 
case (kNmhInverted) : return "Inverted"; 
break; 
default : return "Undefined"; 
break; 
} 
return ""; 
} 
string util::HierarchyAsString(NuMassHierarchy_t m) { return AsString(m); } 
NuMassHierarchy_t util::HierarchyFromString(string h) { 
string lh = util::ToLowerCase(h); 
if(lh == "normal" ) return kNmhNormal; 
if(lh == "inverted" ) return kNmhInverted; 
return kNmhUndefined; 
} 
string util::AsString(NuOscDeltaCP_t d) { 
switch(d) { 
case(kNuDeltaCPPhase) : return "d_{CP}"; 
break; 
case(kNuDeltaCPSin) : return "sin(d_{CP})"; 
break; 
default : return "Undefined"; 
break; 
} 
} 
string util::CPVChoiceAsString(NuOscDeltaCP_t d) { return AsString(d); } 
NuOscDeltaCP_t util::CPVChoiceFromString (string d) { 
if(d == "sindelta" ) return kNuDeltaCPSin; 
if(d == "delta" ) return kNuDeltaCPPhase; 
return kNuDeltaCPUndefined; 
} 
string util::AsString(conv::NuOscDmsqScheme_t dmsqs) { 
switch(dmsqs) { 
case(kNuDmsq12andAbs23) : return "dm^2 = Dm^2_{21}, Dm^2 = |Dm^2_{32}|"; 
break; 
case(kNuDmsq12andAbs31) : return "dm^2 = Dm^2_{21}, Dm^2 = |Dm^2_{31}|"; 
break; 
case(kNuDmsqFogliLisi ) : return "dm^2 = Dm^2_{21}, Dm^2 = |m^2_{3} - (m^2_{1} + m^2_{1})/2|"; 
break; 
case(kNuDmsqAuto ) : if (Opt::Instance()->gMassHierarchyAssumed==kNmhInverted) { 
return std::string(TString::Format("%s (auto)",util::AsString(kNuDmsq12andAbs31).c_str()).Data()); 
} 
return std::string(TString::Format("%s (auto)",util::AsString(kNuDmsq12andAbs23).c_str()).Data()); 
default : return "Undefined"; 
break; 
} 
} 
string util::DmsqSchemeAsString(conv::NuOscDmsqScheme_t dmsqs) { return AsString(dmsqs); } 
NuOscDmsqScheme_t util::DmsqSchemeFromString(string h) { 
if(h == "abs23" ) return kNuDmsq12andAbs23; 
if(h == "abs31" ) return kNuDmsq12andAbs31; 
if(h == "fogli" ) return kNuDmsqFogliLisi; 
if(h == "auto" ) return kNuDmsqAuto; 
return kNuDmsqUndefined; 
} 
conv::NuOscDmsqScheme_t util::GetAutoDmsqSchemeFromHierarchy(conv::NuMassHierarchy_t hierarchy) { 
if (hierarchy == kNmhUndefined) {hierarchy = Opt::Instance()->gMassHierarchyAssumed;} 
if (hierarchy == kNmhInverted ) {return kNuDmsq12andAbs31;} 
if (hierarchy == kNmhNormal ) {return kNuDmsq12andAbs23;} 
return kNuDmsqUndefined; 
} 
string util::AsString(conv::NuOscMixParam_t p) { 
switch(p) { 
case (kNuMixSinsq2Theta) : return "sin^2(2*theta_{ij})"; 
break; 
case (kNuMixSinsqTheta) : return "sin^2(theta_{ij})"; 
break; 
default : return "Undefined"; 
break; 
} 
return ""; 
} 
string util::MixingTypeAsString(conv::NuOscMixParam_t p) { return AsString(p);} 
NuOscMixParam_t util::MixingTypeFromString(string h) { 
if(h == "sinsq2theta") return kNuMixSinsq2Theta; 
if(h == "sinsqtheta" ) return kNuMixSinsqTheta; 
return kNuMixUndefined; 
} 
string util::AsString(NuOscOctant_t o) { 
switch(o) { 
case (kNuOctantOne) : return "sin^2(theta_{23}) <= 0.5"; 
break; 
case (kNuOctantTwo) : return "sin^2(theta_{23}) >= 0.5"; 
break; 
default : return "Undefined"; 
break; 
} 
return ""; 
} 
string util::OctantAsString(NuOscOctant_t o) { return AsString(o);} 
NuOscOctant_t util::OctantFromString(string h) { 
if(h == "one") return kNuOctantOne; 
if(h == "two") return kNuOctantTwo; 
return kNuOctantUndefined; 
} 
ClassImp(Opt::Persistable); 
namespace valor { 
ostream & operator<<(ostream & stream, const Opt & opt) { 
opt.Print(stream); 
return stream; 
} 
} 
Opt * Opt::fInstance = 0; 
Opt::Opt() : gDoNotDie(false), fRegistry("VALORRegistry",false) { 
this->SetDefaults(); 
fInstance = 0; 
} 
Opt::Opt(const Opt &) { 
} 
Opt::~Opt() { 
} 
Opt * Opt::Instance() { 
if(fInstance == 0) { 
static Opt::Cleaner cleaner; 
cleaner.DummyMethodAndSilentCompiler(); 
assert(1); 
fInstance = new Opt; 
} 
return fInstance; 
} 
void Opt::SetDefaults(void) { 
gMassHierarchyAssumed = kNmhNormal; 
gOscMixingParamChoice = kNuMixSinsqTheta; 
gOscDmsqScheme = kNuDmsq12andAbs23; 
gOscDeltaCP = kNuDeltaCPPhase; 
gOscOctantChoice = kNuOctantOne; 
this->SetDefaultParameterValues(); 
} 
void Opt::SetValues(const char * dmsqscheme, const char * hierarchy,  const char * mixparamchoice, const char * mixparamoctant,  const char * cpvchoice, bool print) { 
gMassHierarchyAssumed = util::HierarchyFromString(hierarchy); 
gOscDmsqScheme = util::DmsqSchemeFromString(dmsqscheme); 
gOscMixingParamChoice = util::MixingTypeFromString(mixparamchoice); 
gOscOctantChoice = util::OctantFromString(mixparamoctant); 
gOscDeltaCP = util::CPVChoiceFromString(cpvchoice); 
if(Undefined()) { 
assert(1); 
Print(std::cerr); 
exit(1); 
} 
if(print) Print(std::cout); 
} 
void Opt::SetDefaultParameterValues() { 
for (int ip = 0 ; ip < knppmax ; ip++ ) { 
fGlobalBestFit [ip] = conv::kBadResult; 
fGlobalFitError[ip] = conv::kBadResult; 
} 
double mean = conv::kBadResult; 
fGlobalBestFit [kPhypDm12sq] = kGlobFitDm12sq; 
fGlobalFitError [kPhypDm12sq] = kGlobFitErrDm12sq; 
switch (gOscDmsqScheme) { 
case(kNuDmsqFogliLisi): mean = kGlobFitDmsqFL; 
break; 
case(kNuDmsq12andAbs23): mean = kGlobFitDm23sq; 
break; 
case(kNuDmsq12andAbs31): if(gMassHierarchyAssumed == kNmhNormal) mean = kGlobFitDm23sq + kGlobFitDm12sq; 
else if(gMassHierarchyAssumed == kNmhInverted) mean = kGlobFitDm23sq - kGlobFitDm12sq; 
else assert(!"Should never happen"); 
break; 
default: mean = kGlobFitDm23sq; 
} 
fGlobalBestFit [kPhypDm23sq] = mean; 
fGlobalFitError [kPhypDm23sq] = kGlobFitErrDm23sq; 
switch(gOscMixingParamChoice) { 
case(kNuMixSinsq2Theta): { 
fGlobalBestFit [kPhypMixing12] = kGlobFitSinsq2Theta12; 
fGlobalFitError [kPhypMixing12] = kGlobFitErrSinsq2Theta12; 
fGlobalBestFit [kPhypMixing23] = kGlobFitSinsq2Theta23; 
fGlobalFitError [kPhypMixing23] = kGlobFitErrSinsq2Theta23; 
fGlobalBestFit [kPhypMixing13] = kGlobFitSinsq2Theta13; 
fGlobalFitError [kPhypMixing13] = kGlobFitErrSinsq2Theta13; 
break; 
} 
case(kNuMixSinsqTheta): { 
fGlobalBestFit [kPhypMixing12] = kGlobFitSinsqTheta12; 
fGlobalFitError [kPhypMixing12] = kGlobFitErrSinsqTheta12; 
fGlobalBestFit [kPhypMixing23] = kGlobFitSinsqTheta23; 
fGlobalFitError [kPhypMixing23] = kGlobFitErrSinsqTheta23; 
fGlobalBestFit [kPhypMixing13] = kGlobFitSinsqTheta13; 
fGlobalFitError [kPhypMixing13] = kGlobFitErrSinsqTheta13; 
break; 
} 
default: exit(-1); 
} 
for (int p = conv::kPhypMixing23Bar ; p <= conv::kPhypDm12sqBar; p++){ 
int nonbar = p - conv::kPhypMixing23Bar + conv::kPhypMixing23; 
fGlobalBestFit [p] = fGlobalBestFit [nonbar]; 
fGlobalFitError [p] = fGlobalFitError [nonbar]; 
} 
fGlobalBestFit [kPhypBetaBar] = kGlobFitBetaBar; 
fGlobalFitError [kPhypBetaBar] = kGlobFitErrBetaBar; 
} 
bool Opt::Undefined(void) { 
if(gMassHierarchyAssumed == kNmhUndefined) return true; 
if(gOscMixingParamChoice == kNuMixUndefined) return true; 
if(gOscDmsqScheme == kNuDmsqUndefined) return true; 
if(gOscDeltaCP == kNuDeltaCPUndefined) return true; 
if(gOscOctantChoice == kNuOctantUndefined) return true; 
return false; 
} 
void Opt::Print(ostream & stream) const { 
stream << "[Global analysis options]" << endl; 
stream << " - Hierarchy: " << util::AsString(gMassHierarchyAssumed) << endl; 
stream << " - Mixing param choice: " << util::AsString(gOscMixingParamChoice) << endl; 
stream << " - 23 octant choice: "  << util::AsString(gOscOctantChoice)  << endl; 
stream << " - Independent squared mass splittings: " << util::AsString(gOscDmsqScheme) << endl; 
stream << " - Choice for Delta CP phase: " << util::AsString(gOscDeltaCP) << endl; 
} 
void Opt::WriteTo (Opt::Persistable & optp) { 
optp.mh = gMassHierarchyAssumed; 
optp.mixp = gOscMixingParamChoice; 
optp.oct = gOscOctantChoice; 
optp.dmsqs = gOscDmsqScheme; 
optp.dcp = gOscDeltaCP; 
} 
void Opt::ReadFrom (Opt::Persistable & optp) { 
gMassHierarchyAssumed = optp.mh; 
gOscMixingParamChoice = optp.mixp; 
gOscOctantChoice = optp.oct; 
gOscDmsqScheme = optp.dmsqs; 
gOscDeltaCP = optp.dcp; 
} 
void Opt::SetGlobalBestFit(PhysParamId_t p, double value) { 
assert(p!=kPhypUndefined); 
fGlobalBestFit[p] = value; 
} 
void Opt::SetGlobalFitError(PhysParamId_t p, double value) { 
assert(p!=kPhypUndefined); 
fGlobalFitError[p] = value; 
} 
double Opt::GetGlobalBestFit(PhysParamId_t p) const { 
assert(p!=kPhypUndefined); 
return fGlobalBestFit[p]; 
} 
double Opt::GetGlobalFitError(PhysParamId_t p) const { 
assert(p!=kPhypUndefined); 
return fGlobalFitError[p]; 
} 
conv::NuOscDmsqScheme_t Opt::GetEffectiveDmsqScheme(void) { 
if (gOscDmsqScheme==conv::kNuDmsqAuto) { 
return util::GetAutoDmsqSchemeFromHierarchy(); 
} 
return gOscDmsqScheme; 
} 
Registry & Opt::MutableGlobalRegistry(void) { 
return fRegistry; 
} 
const Registry & Opt::GlobalRegistry(void) const { 
return fRegistry; 
} 
string util::AsString(OscChannelId_t osch) { 
switch(osch) { 
case ( kOscNuE2NuE ) : return "nue -> nue"; break; 
case ( kOscNuE2NuMu ) : return "nue -> numu"; break; 
case ( kOscNuE2NuTau ) : return "nue -> nutau"; break; 
case ( kOscNuMu2NuE ) : return "numu -> nue"; break; 
case ( kOscNuMu2NuMu ) : return "numu -> numu"; break; 
case ( kOscNuMu2NuTau ) : return "numu -> nutau"; break; 
case ( kOscNuTau2NuE ) : return "nutau -> nue"; break; 
case ( kOscNuTau2NuMu ) : return "nutau -> numu"; break; 
case ( kOscNuTau2NuTau ) : return "nutau -> nutau"; break; 
case ( kOscNuEBar2NuEBar ) : return "nuebar -> nuebar"; break; 
case ( kOscNuEBar2NuMuBar ) : return "nuebar -> numubar"; break; 
case ( kOscNuEBar2NuTauBar ) : return "nuebar -> nutaubar"; break; 
case ( kOscNuMuBar2NuEBar ) : return "numubar -> nuebar"; break; 
case ( kOscNuMuBar2NuMuBar ) : return "numubar -> numubar"; break; 
case ( kOscNuMuBar2NuTauBar ) : return "numubar -> nutaubar"; break; 
case ( kOscNuTauBar2NuEBar ) : return "nutaubar -> nuebar"; break; 
case ( kOscNuTauBar2NuMuBar ) : return "nutaubar -> numubar"; break; 
case ( kOscNuTauBar2NuTauBar ) : return "nutaubar -> nutaubar"; break; 
case ( kOscNuE2NuS4 ) : return "nue -> nus4"; break; 
case ( kOscNuE2NuS5 ) : return "nue -> nus5"; break; 
case ( kOscNuMu2NuS4 ) : return "numu -> nus4"; break; 
case ( kOscNuMu2NuS5 ) : return "numu -> nus5"; break; 
case ( kOscNuTau2NuS4 ) : return "nutau -> nus4"; break; 
case ( kOscNuTau2NuS5 ) : return "nutau -> nus5"; break; 
case ( kOscNuS42NuE ) : return "nus4 -> nue"; break; 
case ( kOscNuS52NuE ) : return "nus5 -> nue"; break; 
case ( kOscNuS42NuMu ) : return "nus4 -> numu"; break; 
case ( kOscNuS52NuMu ) : return "nus5 -> numu"; break; 
case ( kOscNuS42NuTau ) : return "nus4 -> nutau"; break; 
case ( kOscNuS52NuTau ) : return "nus5 -> nutau"; break; 
case ( kOscNuEBar2NuS4Bar ) : return "nuebar -> nus4bar"; break; 
case ( kOscNuEBar2NuS5Bar ) : return "nuebar -> nus5bar"; break; 
case ( kOscNuMuBar2NuS4Bar ) : return "numubar -> nus4bar"; break; 
case ( kOscNuMuBar2NuS5Bar ) : return "numubar -> nus5bar"; break; 
case ( kOscNuTauBar2NuS4Bar ) : return "nutaubar -> nus4bar"; break; 
case ( kOscNuTauBar2NuS5Bar ) : return "nutaubar -> nus5bar"; break; 
case ( kOscNuS4Bar2NuEBar ) : return "nus4bar -> nuebar"; break; 
case ( kOscNuS5Bar2NuEBar ) : return "nus5bar -> nuebar"; break; 
case ( kOscNuS4Bar2NuMuBar ) : return "nus4bar -> numubar"; break; 
case ( kOscNuS5Bar2NuMuBar ) : return "nus5bar -> numubar"; break; 
case ( kOscNuS4Bar2NuTauBar ) : return "nus4bar -> nutaubar"; break; 
case ( kOscNuS5Bar2NuTauBar ) : return "nus5bar -> nutaubar"; break; 
default : return "--"; 
} 
return "--"; 
} 
string util::OscChannelAsString(OscChannelId_t osch) { return AsString(osch); } 
OscChannelId_t util::GetOscChannel(int nu_start, int nu_end) { 
if ( nu_start == kPdgNuE && nu_end == kPdgNuE ) return kOscNuE2NuE; 
if ( nu_start == kPdgNuE && nu_end == kPdgNuMu ) return kOscNuE2NuMu; 
if ( nu_start == kPdgNuE && nu_end == kPdgNuTau ) return kOscNuE2NuTau; 
if ( nu_start == kPdgNuMu && nu_end == kPdgNuE ) return kOscNuMu2NuE; 
if ( nu_start == kPdgNuMu && nu_end == kPdgNuMu ) return kOscNuMu2NuMu; 
if ( nu_start == kPdgNuMu && nu_end == kPdgNuTau ) return kOscNuMu2NuTau; 
if ( nu_start == kPdgNuTau && nu_end == kPdgNuE ) return kOscNuTau2NuE; 
if ( nu_start == kPdgNuTau && nu_end == kPdgNuMu ) return kOscNuTau2NuMu; 
if ( nu_start == kPdgNuTau && nu_end == kPdgNuTau ) return kOscNuTau2NuTau; 
if ( nu_start == kPdgNuEBar && nu_end == kPdgNuEBar ) return kOscNuEBar2NuEBar; 
if ( nu_start == kPdgNuEBar && nu_end == kPdgNuMuBar ) return kOscNuEBar2NuMuBar; 
if ( nu_start == kPdgNuEBar && nu_end == kPdgNuTauBar ) return kOscNuEBar2NuTauBar; 
if ( nu_start == kPdgNuMuBar && nu_end == kPdgNuEBar ) return kOscNuMuBar2NuEBar; 
if ( nu_start == kPdgNuMuBar && nu_end == kPdgNuMuBar ) return kOscNuMuBar2NuMuBar; 
if ( nu_start == kPdgNuMuBar && nu_end == kPdgNuTauBar ) return kOscNuMuBar2NuTauBar; 
if ( nu_start == kPdgNuTauBar && nu_end == kPdgNuEBar ) return kOscNuTauBar2NuEBar; 
if ( nu_start == kPdgNuTauBar && nu_end == kPdgNuMuBar ) return kOscNuTauBar2NuMuBar; 
if ( nu_start == kPdgNuTauBar && nu_end == kPdgNuTauBar ) return kOscNuTauBar2NuTauBar; 
if ( nu_start == kPdgNuE && nu_end == kPdgNuS4 ) return kOscNuE2NuS4; 
if ( nu_start == kPdgNuE && nu_end == kPdgNuS5 ) return kOscNuE2NuS5; 
if ( nu_start == kPdgNuMu && nu_end == kPdgNuS4 ) return kOscNuMu2NuS4; 
if ( nu_start == kPdgNuMu && nu_end == kPdgNuS5 ) return kOscNuMu2NuS5; 
if ( nu_start == kPdgNuTau && nu_end == kPdgNuS4 ) return kOscNuTau2NuS4; 
if ( nu_start == kPdgNuTau && nu_end == kPdgNuS5 ) return kOscNuTau2NuS5; 
if ( nu_start == kPdgNuS4 && nu_end == kPdgNuE ) return kOscNuS42NuE; 
if ( nu_start == kPdgNuS5 && nu_end == kPdgNuE ) return kOscNuS52NuE; 
if ( nu_start == kPdgNuS4 && nu_end == kPdgNuMu ) return kOscNuS42NuMu; 
if ( nu_start == kPdgNuS5 && nu_end == kPdgNuMu ) return kOscNuS52NuMu; 
if ( nu_start == kPdgNuS4 && nu_end == kPdgNuTau ) return kOscNuS42NuTau; 
if ( nu_start == kPdgNuS5 && nu_end == kPdgNuTau ) return kOscNuS52NuTau; 
if ( nu_start == kPdgNuEBar && nu_end == kPdgNuS4Bar ) return kOscNuEBar2NuS4Bar; 
if ( nu_start == kPdgNuEBar && nu_end == kPdgNuS5Bar ) return kOscNuEBar2NuS5Bar; 
if ( nu_start == kPdgNuMuBar && nu_end == kPdgNuS4Bar ) return kOscNuMuBar2NuS4Bar; 
if ( nu_start == kPdgNuMuBar && nu_end == kPdgNuS5Bar ) return kOscNuMuBar2NuS5Bar; 
if ( nu_start == kPdgNuTauBar && nu_end == kPdgNuS4Bar ) return kOscNuTauBar2NuS4Bar; 
if ( nu_start == kPdgNuTauBar && nu_end == kPdgNuS5Bar ) return kOscNuTauBar2NuS5Bar; 
if ( nu_start == kPdgNuS4Bar && nu_end == kPdgNuEBar ) return kOscNuS4Bar2NuEBar; 
if ( nu_start == kPdgNuS5Bar && nu_end == kPdgNuEBar ) return kOscNuS5Bar2NuEBar; 
if ( nu_start == kPdgNuS4Bar && nu_end == kPdgNuMuBar ) return kOscNuS4Bar2NuMuBar; 
if ( nu_start == kPdgNuS5Bar && nu_end == kPdgNuMuBar ) return kOscNuS5Bar2NuMuBar; 
if ( nu_start == kPdgNuS4Bar && nu_end == kPdgNuTauBar ) return kOscNuS4Bar2NuTauBar; 
if ( nu_start == kPdgNuS5Bar && nu_end == kPdgNuTauBar ) return kOscNuS5Bar2NuTauBar; 
return kOscUndefined; 
} 
bool util::IsNeutrino(int pdg_code) { 
if ( pdg_code == kPdgNuE || pdg_code == kPdgNuMu || pdg_code == kPdgNuTau || pdg_code == kPdgNuS4 || pdg_code == kPdgNuS5 ) { 
return true; 
} 
return false; 
} 
bool util::IsAntiNeutrino(int pdg_code) { 
if ( pdg_code == kPdgNuEBar || pdg_code == kPdgNuMuBar || pdg_code == kPdgNuTauBar || pdg_code == kPdgNuS4Bar || pdg_code == kPdgNuS5Bar ) { 
return true; 
} 
return false; 
} 
string util::Pdg2String(int pdg_code) { 
switch(pdg_code) { 
case ( kPdgNuE ) : return "nue"; break; 
case ( kPdgNuMu ) : return "numu"; break; 
case ( kPdgNuTau ) : return "nutau"; break; 
case ( kPdgNuEBar ) : return "nuebar"; break; 
case ( kPdgNuMuBar ) : return "numubar"; break; 
case ( kPdgNuTauBar ) : return "nutaubar"; break; 
default : return ""; 
} 
return ""; 
} 
string util::Pdg2StringTex(int pdg_code) { 
switch(pdg_code) { 
case ( kPdgNuE ) : return "$\\nu_e$"; break; 
case ( kPdgNuMu ) : return "$\\nu_\\mu$"; break; 
case ( kPdgNuTau ) : return "$\\nu_\\tau$"; break; 
case ( kPdgNuEBar ) : return "$\\bar{\\nu_e}$"; break; 
case ( kPdgNuMuBar ) : return "$\\bar{\\nu_\\mu}$"; break; 
case ( kPdgNuTauBar ) : return "$\\bar{\\nu_\\tau}$"; break; 
default : return ""; 
} 
return ""; 
} 
CmdLnArgList::CmdLnArgList() : Registry("command_line_arg",false) { 
} 
CmdLnArgList::~CmdLnArgList() { 
} 
bool CmdLnArgList::Read(int argc, const char* const* argv, string arg_spec_files) { 
CmdLnArgParser parser(argc,argv); 
assert(1); 
bool failure = false; 
vector<string> fv; 
if(arg_spec_files.find(":") == string::npos) { 
fv.push_back(arg_spec_files); 
} else { 
fv = util::Tokens(arg_spec_files, ":"); 
} 
assert(1); 
vector<string>::const_iterator fvit = fv.begin(); 
for( ; fvit != fv.end(); ++fvit) { 
string filename = *fvit; 
assert(1); 
if(filename.find("$") != string::npos) { 
size_t start = filename.find("$",0); 
size_t end = filename.find("/", start); 
size_t length = end-start-1; 
string env_var = filename.substr(start+1,length); 
assert(1); 
const char * env_var_value = gSystem->Getenv(env_var.c_str()); 
if(!env_var_value) { 
assert(1); 
failure = true ; continue;; 
} 
string str_env_var_value = env_var_value; 
filename.replace(start,length+1,str_env_var_value); 
assert(1); 
} 
ifstream file; 
file.open(filename.c_str()); 
if (! file.is_open() ) { 
assert(1); 
continue; 
} 
while (!file.eof()) { 
string line = ""; 
std::getline(file,line); 
line = util::TrimSpaces(line); 
assert(1); 
if(line[0] == '#') { 
continue; 
} 
if(line.size() == 0) { 
continue; 
} 
assert(1); 
vector<string> line_tokens = util::Tokens(line, "|"); 
assert(line_tokens.size()==4); 
string argument = util::TrimSpaces(line_tokens[0]); 
string type = util::TrimSpaces(line_tokens[1]); 
string required = util::TrimSpaces(line_tokens[2]); 
string deflt = util::TrimSpaces(line_tokens[3]); 
assert(1); 
bool is_int = (type == "integer"); 
bool is_dbl = (type == "double"); 
bool is_str = (type == "string"); 
bool is_bln = (type == "boolean"); 
bool is_blnlst = (type == "boolean_list"); 
bool is_optional = (required == "optional"); 
bool is_mandatory = (required == "mandatory"); 
bool no_deflt = (deflt == "-"); 
bool is_found = parser.OptionExists(argument); 
bool valid_type = is_int || is_dbl || is_str || is_bln || is_blnlst; 
if (!valid_type) { 
assert(1); 
failure = true; 
util::Die(-1); return !failure; 
} 
if(is_int || is_dbl || is_str) { 
if(is_mandatory && !is_found) { 
assert(1); 
failure = true ; continue; 
} 
if(is_optional && !is_found && no_deflt) { 
assert(1); 
failure = true ; continue; 
} 
if(is_int) { 
if(is_found) { 
int ival = parser.ArgAsInt(argument); 
this->Set(argument,ival); 
} else { 
if(is_optional) { 
int ival = atoi(deflt.c_str()); 
this->Set(argument,ival); 
} 
} 
} 
if(is_dbl) { 
if(is_found) { 
double xval = parser.ArgAsDouble(argument); 
this->Set(argument,xval); 
} else { 
if(is_optional) { 
double xval = atof(deflt.c_str()); 
this->Set(argument,xval); 
} 
} 
} 
if(is_str) { 
if(is_found) { 
string sval = parser.ArgAsString(argument); 
this->Set(argument,sval); 
} else { 
if(is_optional) { 
string sval = deflt; 
this->Set(argument,sval); 
} 
} 
} 
} 
if(is_bln && !is_blnlst) { 
if(is_mandatory) { 
assert(1); 
failure = true ; continue; 
} 
this->Set(argument,is_found); 
} 
if(is_blnlst) { 
vector<string> boolarglist = util::Tokens(argument, ","); 
if(boolarglist.size() <= 1) { 
assert(1); 
failure = true ; continue; 
} 
int nfound = 0; 
vector<string>::const_iterator boolargit = boolarglist.begin(); 
for( ; boolargit != boolarglist.end(); ++boolargit) { 
string boolarg = util::TrimSpaces(*boolargit); 
if( parser.OptionExists(boolarg) ) { nfound++; } 
} 
if(is_mandatory && nfound==0) { 
assert(1); 
failure = true ; continue; 
} 
if(nfound>1) { 
assert(1); 
failure = true ; continue; 
} 
if(is_optional && nfound==0 && no_deflt) { 
assert(1); 
failure = true ; continue; 
} 
boolargit = boolarglist.begin(); 
if(is_optional && nfound==0) { 
for( ; boolargit != boolarglist.end(); ++boolargit) { 
string boolarg = util::TrimSpaces(*boolargit); 
if(boolarg==deflt) { 
this->Set(boolarg,true); 
} else { 
this->Set(boolarg,false); 
} 
} 
} 
else { 
for( ; boolargit != boolarglist.end(); ++boolargit) { 
string boolarg = util::TrimSpaces(*boolargit); 
if(parser.OptionExists(boolarg)) { 
this->Set(boolarg,true); 
} else { 
this->Set(boolarg,false); 
} 
} 
} 
} 
} 
file.close(); 
} 
if (!parser.RecognisedAllArgs()) { 
assert(1); 
util::Die(-1); 
return false; 
} 
return !failure; 
} 
CmdLnArgParser::CmdLnArgParser(int argc, const char* const* argv) : fArgc(argc), fArgv(argv), fArgUsed(fArgc,false) { 
TString conf_dir = valor::Env::Instance()->TopLevelConfDir(); 
TString verbosity = conf_dir + "/verbosity.xml"; 
valor::util::Verbosity(verbosity.Data()); 
for (int i = 1 ; i < fArgc; i++) { 
fArgUsed[i] = false; 
} 
fArgUsed[0] = true; 
} 
CmdLnArgParser::~CmdLnArgParser() { 
} 
std::string CmdLnArgParser::ArgAsString(char op) const { 
std::string argument; 
int argc = fArgc; 
const char* const* argv = fArgv; 
while(argc>2) { 
assert(1); 
assert(1); 
if (argv[1][0] == '-') { 
assert(1); 
if (argv[1][1] == op) { 
assert(1); 
if (strlen(&argv[1][2]) ) { 
argument = &argv[1][2]; 
assert(1); 
} 
else if( (argc>2) && !(argv[2][0]=='-' && isalpha(argv[2][1])) ) { 
assert(1); 
argc--; 
argv++; 
argument = &argv[1][0]; 
assert(1); 
} 
} 
} 
argc--; 
argv++; 
if(argc>2) { 
assert(1); 
} 
} 
return argument; 
} 
bool CmdLnArgParser::OptionExists(char op, bool set_used) const { 
bool set = false; 
int argc = fArgc; 
const char* const* argv = fArgv; 
while(argc>1) { 
if(argv[1][0] == '-') { 
if (argv[1][1] == op) { 
set = true; 
if (set_used) {fArgUsed[fArgc-argc+1] = true;} 
} 
} 
argc--; 
argv++; 
} 
return set; 
} 
vector<string> CmdLnArgParser::ArgAsStringTokens(char op, string delimeter) const { 
string argument = this->ArgAsString(op); 
vector<string> tokens = util::Tokens(argument, delimeter); 
return tokens; 
} 
vector<string> CmdLnArgParser::ArgAsStringTokens(string op, string delimeter) const { 
string argument = this->ArgAsString(op); 
vector<string> tokens = util::Tokens(argument, delimeter); 
return tokens; 
} 
double CmdLnArgParser::ArgAsDouble(char op) const { 
std::string argument = this->ArgAsString(op); 
double value = std::atof(argument.c_str()); 
return value; 
} 
vector<double> CmdLnArgParser::ArgAsDoubleTokens(char op, string delimeter) const { 
vector<string> strtokens = this->ArgAsStringTokens(op, delimeter); 
vector<double> tokens; 
vector<string>::const_iterator iter = strtokens.begin(); 
for( ; iter != strtokens.end(); ++iter) { 
string arg = *iter; 
tokens.push_back(std::atof(arg.c_str())); 
} 
return tokens; 
} 
int CmdLnArgParser::ArgAsInt(char op) const { 
std::string argument = this->ArgAsString(op); 
int value = std::atoi(argument.c_str()); 
if (argument.find('e') != std::string::npos || argument.find('E') != std::string::npos) { 
value = TMath::Nint(std::atof(argument.c_str())); 
} 
return value; 
} 
unsigned int CmdLnArgParser::ArgAsUInt(char op) const { 
std::string argument = this->ArgAsString(op); 
unsigned int value = std::strtoul(argument.c_str(),NULL,0); 
if (argument.find('e') != std::string::npos || argument.find('E') != std::string::npos) { 
double as_d = std::atof(argument.c_str()); 
value = TMath::Nint(as_d); 
if (as_d < 0) { LOG("Parser",pWARN) << "Warning: unsigned int argument has value "<<as_d<<" converted to "<<value;} 
} 
return value; 
} 
vector<int> CmdLnArgParser::ArgAsIntTokens(char op, string delimeter) const { 
vector<string> strtokens = this->ArgAsStringTokens(op, delimeter); 
vector<int> tokens; 
vector<string>::const_iterator iter = strtokens.begin(); 
for( ; iter != strtokens.end(); ++iter) { 
string argument = *iter; 
int value = std::atoi(argument.c_str()); 
if (argument.find('e') != std::string::npos || argument.find('E') != std::string::npos) { 
double as_d = std::atof(argument.c_str()); 
value = TMath::Nint(as_d); 
if (as_d < 0) { LOG("Parser",pWARN) << "Warning: unsigned int argument has value "<<as_d<<" converted to "<<value;} 
} 
tokens.push_back(value); 
} 
return tokens; 
} 
vector<unsigned int> CmdLnArgParser::ArgAsUIntTokens(char op, string delimeter) const { 
vector<string> strtokens = this->ArgAsStringTokens(op, delimeter); 
vector<unsigned int> tokens; 
vector<string>::const_iterator iter = strtokens.begin(); 
for( ; iter != strtokens.end(); ++iter) { 
string argument = *iter; 
unsigned int value = std::strtoul(argument.c_str(),NULL,0); 
if (argument.find('e') != std::string::npos || argument.find('E') != std::string::npos) { 
double as_d = std::atof(argument.c_str()); 
value = TMath::Nint(as_d); 
if (as_d < 0) { LOG("Parser",pWARN) << "Warning: unsigned int argument has value "<<as_d<<" converted to "<<value;} 
} 
tokens.push_back(value); 
} 
return tokens; 
} 
long CmdLnArgParser::ArgAsLong(char op) const { 
std::string argument = this->ArgAsString(op); 
long value = std::atol(argument.c_str()); 
if (argument.find('e') != std::string::npos || argument.find('E') != std::string::npos) { 
value = TMath::Nint(std::atof(argument.c_str())); 
} 
return value; 
} 
vector<long> CmdLnArgParser::ArgAsLongTokens(char op, string delimeter) const { 
vector<string> strtokens = this->ArgAsStringTokens(op, delimeter); 
vector<long> tokens; 
vector<string>::const_iterator iter = strtokens.begin(); 
for( ; iter != strtokens.end(); ++iter) { 
string argument = *iter; 
long value = std::atol(argument.c_str()); 
if (argument.find('e') != std::string::npos || argument.find('E') != std::string::npos) { 
value = TMath::Nint(std::atof(argument.c_str())); 
} 
tokens.push_back(value); 
} 
return tokens; 
} 
std::string CmdLnArgParser::ArgAsString(string op) const { 
std::string argument; 
int argc = fArgc; 
const char* const* argv = fArgv; 
while(argc>2) { 
assert(1); 
assert(1); 
if (argv[1][0] == '-' && argv[1][1] == '-') { 
const char * op_cur = &argv[1][2]; 
assert(1); 
if (strcmp(op.c_str(),op_cur)==0) { 
assert(1); 
if (strlen(&argv[2][0]) ) { 
argument = &argv[2][0]; 
assert(1); 
} 
else if( (argc>2) && !(argv[2][0]=='-' &&argv[2][1]=='-' && isalpha(argv[2][2])) ) { 
assert(1); 
argc--; 
argv++; 
argument = &argv[1][0]; 
assert(1); 
} 
fArgUsed[fArgc-argc+1] = true; 
fArgUsed[fArgc-argc+2] = true; 
} 
} 
argc--; 
argv++; 
if(argc>2) { 
assert(1); 
} 
} 
return argument; 
} 
bool CmdLnArgParser::OptionExists(string op, bool set_used) const { 
bool set = false; 
int argc = fArgc; 
const char* const* argv = fArgv; 
while(argc>1) { 
if(argv[1][0] == '-' && argv[1][1] == '-') { 
if (strcmp(op.c_str(),&argv[1][2])==0) { 
set = true; 
if (set_used) {fArgUsed[fArgc-argc+1] = true;} 
} 
} 
argc--; 
argv++; 
} 
return set; 
} 
double CmdLnArgParser::ArgAsDouble(string op) const { 
std::string argument = this->ArgAsString(op); 
double value = std::atof(argument.c_str()); 
return value; 
} 
int CmdLnArgParser::ArgAsInt(string op) const { 
std::string argument = this->ArgAsString(op); 
int value = std::atoi(argument.c_str()); 
if (argument.find('e') != std::string::npos || argument.find('E') != std::string::npos) { 
value = TMath::Nint(std::atof(argument.c_str())); 
} 
return value; 
} 
unsigned int CmdLnArgParser::ArgAsUInt(string op) const { 
std::string argument = this->ArgAsString(op); 
unsigned int value = std::strtoul(argument.c_str(),NULL,0); 
if (argument.find('e') != std::string::npos || argument.find('E') != std::string::npos) { 
double as_d = std::atof(argument.c_str()); 
value = TMath::Nint(as_d); 
if (as_d < 0) { LOG("Parser",pWARN) << "Warning: unsigned int argument has value "<<as_d<<" converted to "<<value;} 
} 
return value; 
} 
long CmdLnArgParser::ArgAsLong(string op) const { 
std::string argument = this->ArgAsString(op); 
long value = std::atol(argument.c_str()); 
if (argument.find('e') != std::string::npos || argument.find('E') != std::string::npos) { 
value = TMath::Nint(std::atof(argument.c_str())); 
} 
return value; 
} 
bool CmdLnArgParser::RecognisedAllArgs() const { 
bool status = true; 
for (int iarg = 0 ; iarg < fArgc; iarg++) { 
if (!(fArgUsed[iarg])) { 
assert(1); 
status = false; 
} 
else { 
assert(1); 
} 
} 
return status; 
} 
namespace valor { 
ostream & operator << (ostream & stream, const RunOpt & opt) { 
opt.Print(stream); 
return stream; 
} 
} 
valor::RunOpt::RunOpt() { 
Init(); 
} 
valor::RunOpt::RunOpt(int argc, char ** argv, int parseopt) { 
Init(); 
ReadFromCommandLine(argc, argv, parseopt); 
Print(cout); 
} 
valor::RunOpt::~RunOpt() { 
delete fParser; 
} 
void valor::RunOpt::Init(void) { 
fParser = 0; 
fParseType = kParseUndefined; 
fHierStr[0] = "nh"; 
fHierStr[1] = "ih"; 
fConfigFile = util::FormFilePath("", "config"); 
fVerbosityFile = util::FormFilePath("verbosity.xml", "config"); 
fFileTag = "tag"; 
fRun = 0; 
fFirstExperiment = 0; 
fLastExperiment = 0; 
fNExperiments = 1; 
fStatFluctuations = true; 
fSystTweakMode = 1; 
fRethrowIfUnphysical = true; 
fVerboseSystThrows = false; 
fVerboseFit = false; 
fGlobalDmsqScheme = "auto"; 
fGlobalMassHierarchy = "normal"; 
fGlobalMixParamScheme = "sinsqtheta"; 
fGlobalMixParamOctant = "one"; 
fGlobalCPVPhaseScheme = "delta"; 
InitOscParams(-99); 
fHypothesis = "3f_osc"; 
fSeedToyMCstat = 0; 
fSeedToyMCsyst = 0; 
fSeedToyMCosc = 0; 
fSeedFitter = 0; 
fSeedOther = 0; 
fUseFileData = false; 
fPathFileData = ""; 
fPriorId = conv::kBadResult; 
fPriorsFile = ""; 
fThrowMH = false; 
fPriorProbNH = 0.5; 
fMargMixing12 = false; 
fMargMixing13 = false; 
fMargMixing23 = false; 
fMargDm12sq = false; 
fMargDm23sq = false; 
fMargDeltaCP = false; 
fPriorMixing12 = ""; 
fPriorMixing13 = ""; 
fPriorMixing23 = ""; 
fPriorDm12sq = ""; 
fPriorDm23sq = ""; 
fPriorDeltaCP = ""; 
fMixModeMixing12 = ""; 
fMixModeMixing23 = ""; 
fMixModeMixing13 = ""; 
for(int i=0;i<2;i++){ 
fPriorParMixing12[i] = conv::kBadResult; 
fPriorParMixing13[i] = conv::kBadResult; 
fPriorParMixing23[i] = conv::kBadResult; 
fPriorParDm12sq[i] = conv::kBadResult; 
fPriorParDm23sq[i] = conv::kBadResult; 
fPriorParDeltaCP[i] = conv::kBadResult; 
} 
fSynchronizeIHtoNH = true; 
fXmlfile = ""; 
fRootfile = ""; 
fUsing_xml_file = false; 
fDoToys = true; 
fReadSKExp = false; 
fFit_param_list = "nuosc3f+nuisance"; 
fInfilename = ""; 
fInfilename_nh = ""; 
fInfilename_ih = ""; 
fDoFC = false; 
fInfilename = ""; 
fInfilename_nh = ""; 
fInfilename_ih = ""; 
fDoFC = false; 
fNfiles = 9; 
fNtoysMarg = 100; 
fFreeparname0 = "deltacp"; 
fFreeparmin0 = -3.14159265358979312e+00; 
fFreeparmax0 = +3.14159265358979312e+00; 
fNptScan0 = 9; 
fFreeparname1 = ""; 
fFreeparmin1 = 0.; 
fFreeparmax1 = 0.; 
fNptScan1 = 1; 
fDoMargMH = false; 
fHierarchy_marg = "normal"; 
fDoMinimize = true; 
fTypeError = ""; 
fDrawFullChisq = true; 
fTeststat = "rate+shape"; 
fStoreLikeWeights = false; 
fPenaltyTerm0 = false; 
fPenaltyTerm1 = false; 
kScale_toys_based_on_samples = false; 
fScale_toys_based_on_samples_scale = 1; 
} 
void valor::RunOpt::InitOscParams(double value) { 
for(int i = 0; i < 2; i++) { 
fMix12 [i] = value; 
fMix13 [i] = value; 
fMix23 [i] = value; 
fCPV [i] = value; 
fDm12sq[i] = value; 
fDm23sq[i] = value; 
fMix12Bar [i] = value; 
fMix13Bar [i] = value; 
fMix23Bar [i] = value; 
fCPVBar [i] = value; 
fDm12sqBar[i] = value; 
fDm23sqBar[i] = value; 
} 
fBetaBar = value; 
} 
void valor::RunOpt::ReadFromCommandLine(int argc, char ** argv, int parseopt) { 
fParseType = parseopt; 
if(fParseType & kParseUndefined) { 
assert(1); 
exit(-1); 
} 
fParser = new CmdLnArgParser(argc,argv); 
if(fParser->OptionExists("help") || fParser->OptionExists('h')) { 
Usage(); 
exit(1); 
} 
if(parseopt & kParseCommon) ReadCommonOptions(); 
if(parseopt & kParseToys) ReadToyOptions(); 
if(parseopt & kParseGlobal) ReadGlobalOptions(); 
if(parseopt & kParse3FOscParams) Read3FOscParamsOptions(); 
if(parseopt & kParseFitMarg) ReadFitMargOptions(); 
} 
void valor::RunOpt::ReadCommonOptions() { 
if(fParser->OptionExists("file-tag")){ 
fFileTag = fParser->ArgAsString("file-tag"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("run")){ 
fRun = fParser->ArgAsInt("run"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("config-file")){ 
fConfigFile = util::FormFilePath(fParser->ArgAsString("config-file").c_str(), "config"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("verbosity-file")){ 
fVerbosityFile = util::FormFilePath(fParser->ArgAsString("verbosity-file").c_str(), "config"); 
} 
if (fParser->OptionExists("seed-toys-stat")) { 
fSeedToyMCstat = fParser->ArgAsUInt("seed-toys-stat"); 
} 
else { 
fSeedToyMCstat = 0; 
} 
if (fParser->OptionExists("seed-toys-syst")) { 
fSeedToyMCsyst = fParser->ArgAsUInt("seed-toys-syst"); 
} 
else { 
fSeedToyMCsyst = 0; 
} 
if (fParser->OptionExists("seed-toys-osc")) { 
fSeedToyMCosc = fParser->ArgAsUInt("seed-toys-osc"); 
} 
else { 
fSeedToyMCosc = 0; 
} 
if (fParser->OptionExists("seed-fitter")) { 
fSeedFitter = fParser->ArgAsUInt("seed-fitter"); 
} 
else { 
fSeedFitter = 0; 
} 
if (fParser->OptionExists("seed-misc")) { 
fSeedOther = fParser->ArgAsUInt("seed-misc"); 
} 
else { 
fSeedOther = 0; 
} 
if (fParser->OptionExists("file-data")){ 
fPathFileData = fParser->ArgAsString("file-data"); 
fUseFileData = true; 
} 
Rnd::Instance()->SetSeeds(fSeedToyMCstat,fSeedToyMCsyst,fSeedToyMCosc,fSeedFitter,fSeedOther); 
} 
void valor::RunOpt::ReadToyOptions() { 
if( !fParser->OptionExists("first-experiment") || !fParser->OptionExists("n-experiments") ) { 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
else{ 
fNExperiments = fParser->ArgAsInt("n-experiments"); 
fFirstExperiment = fParser->ArgAsInt("first-experiment"); 
fLastExperiment = fFirstExperiment + fNExperiments - 1; 
} 
if(fParser->OptionExists("stat-fluct")) { 
int stafluct_integer = fParser->ArgAsInt("stat-fluct"); 
fStatFluctuations = (bool)stafluct_integer; 
if(stafluct_integer<0 || stafluct_integer>1){ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("syst-tweak-mode")){ 
fSystTweakMode = fParser->ArgAsInt("syst-tweak-mode"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if( fParser->OptionExists("rethrow-unphysical-toys") ){ 
fRethrowIfUnphysical = (bool) fParser->ArgAsInt("rethrow-unphysical-toys"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("verbose-syst-throws")){ 
fVerboseSystThrows = (bool) fParser->ArgAsInt("verbose-syst-throws"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("verbose-fit")){ 
fVerboseFit = (bool) fParser->ArgAsInt("verbose-fit"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("verbose-fit")){ 
fVerboseFit = (bool) fParser->ArgAsInt("verbose-fit"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
} 
void valor::RunOpt::ReadGlobalOptions() { 
if(fParser->OptionExists("dmsq-scheme")){ 
fGlobalDmsqScheme = fParser->ArgAsString("dmsq-scheme"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("mix-param-scheme")){ 
fGlobalMixParamScheme = fParser->ArgAsString("mix-param-scheme"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("cpv-phase-scheme")){ 
fGlobalCPVPhaseScheme = fParser->ArgAsString("cpv-phase-scheme"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("mass-hierarchy")){ 
fGlobalMassHierarchy = fParser->ArgAsString("mass-hierarchy"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("mix-param-octant")){ 
fGlobalMixParamOctant = fParser->ArgAsString("mix-param-octant"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
assert(1); 
Opt::Instance()->SetValues(fGlobalDmsqScheme.c_str(), fGlobalMassHierarchy.c_str(), fGlobalMixParamScheme.c_str(), fGlobalMixParamOctant.c_str(), fGlobalCPVPhaseScheme.c_str()); 
} 
void valor::RunOpt::Read3FOscParamsOptions() { 
if(fParser->OptionExists("hypothesis")){ 
fHypothesis = fParser->ArgAsString("hypothesis"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("synch-osc-ih-to-nh")){ 
fSynchronizeIHtoNH = (bool) fParser->ArgAsInt("synch-osc-ih-to-nh"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("normal-mass-hierarchy-prior")){ 
fPriorProbNH = fParser->ArgAsDouble("normal-mass-hierarchy-prior"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("throw-mass-hierarchy")){ 
fThrowMH = (bool) fParser->ArgAsInt("throw-mass-hierarchy"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if( fParser->OptionExists("prior-mode-toy") ){ 
fPriorId = fParser->ArgAsInt("prior-mode-toy"); 
assert(1); 
assert(1); 
} 
if(fPriorId == 0){ 
assert(1); 
assert(1); 
InitOscParams(-99); 
} 
else if(fPriorId == 1){ 
assert(1); 
assert(1); 
InitOscParams(-999); 
fMargMixing12 = true; 
fPriorMixing12 = "gaus"; 
fPriorParMixing12[0] = conv::kPrior_Sinsq2th12_Used_Mean; 
fPriorParMixing12[1] = conv::kPrior_Sinsq2th12_Used_RMS; 
fMixModeMixing12 = "sinsq2th"; 
fMargMixing13 = true; 
fPriorMixing13 = "gaus"; 
fPriorParMixing13[0] = conv::kPrior_Sinsq2th13_Used_Mean; 
fPriorParMixing13[1] = conv::kPrior_Sinsq2th13_Used_RMS; 
fMixModeMixing13 = "sinsq2th"; 
fMargMixing23 = true; 
fPriorMixing23 = "flat"; 
fPriorParMixing23[0] = conv::kPrior_Sinsq2th23_Flat_Low; 
fPriorParMixing23[1] = conv::kPrior_Sinsq2th23_Flat_Up; 
fMixModeMixing23 = "sinsqth"; 
fMargDm23sq = true; 
fPriorDm23sq = "flat"; 
fPriorParDm23sq[0] = conv::kPrior_Dm23sq_Flat_Low; 
fPriorParDm23sq[1] = conv::kPrior_Dm23sq_Flat_Up; 
fMargDm12sq = true; 
fPriorDm12sq = "gaus"; 
fPriorParDm12sq[0] = conv::kPrior_Dm12sq_Used_Mean; 
fPriorParDm12sq[1] = conv::kPrior_Dm12sq_Used_RMS; 
fMargDeltaCP = true; 
fPriorDeltaCP = "flat"; 
fPriorParDeltaCP[0] = conv::kPrior_deltaCP_Flat_Low; 
fPriorParDeltaCP[1] = conv::kPrior_deltaCP_Flat_Up; 
} 
else if(fPriorId == 2){ 
assert(1); 
assert(1); 
assert(1); 
InitOscParams(-999); 
fMargMixing12 = true; 
fPriorMixing12 = "gaus"; 
fPriorParMixing12[0] = conv::kPrior_Sinsq2th12_Used_Mean; 
fPriorParMixing12[1] = conv::kPrior_Sinsq2th12_Used_RMS; 
fMixModeMixing12 = "sinsq2th"; 
fMargMixing13 = true; 
fPriorMixing13 = "gaus"; 
fPriorParMixing13[0] = kPrior_Sinsq2th13_Flat_Low; 
fPriorParMixing13[1] = kPrior_Sinsq2th13_Flat_Up; 
fMixModeMixing13 = "sinsq2th"; 
fMargMixing23 = true; 
fPriorMixing23 = "flat"; 
fPriorParMixing23[0] = conv::kPrior_Sinsq2th23_Flat_Low; 
fPriorParMixing23[1] = conv::kPrior_Sinsq2th23_Flat_Up; 
fMixModeMixing23 = "sinsqth"; 
fMargDm23sq = true; 
fPriorDm23sq = "flat"; 
fPriorParDm23sq[0] = conv::kPrior_Dm23sq_Flat_Low; 
fPriorParDm23sq[1] = conv::kPrior_Dm23sq_Flat_Up; 
fMargDm12sq = true; 
fPriorDm12sq = "gaus"; 
fPriorParDm12sq[0] = conv::kPrior_Dm12sq_Used_Mean; 
fPriorParDm12sq[1] = conv::kPrior_Dm12sq_Used_RMS; 
fMargDeltaCP = true; 
fPriorDeltaCP = "flat"; 
fPriorParDeltaCP[0] = conv::kPrior_deltaCP_Flat_Low; 
fPriorParDeltaCP[1] = conv::kPrior_deltaCP_Flat_Up; 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
for(int i = 0; i < 2; i++) { 
if(fParser->OptionExists(Form("mixing12-%s", fHierStr[i].c_str()))) fMix12[i] = fParser->ArgAsDouble(Form("mixing12-%s", fHierStr[i].c_str())); 
if(fParser->OptionExists(Form("mixing13-%s", fHierStr[i].c_str()))) fMix13[i] = fParser->ArgAsDouble(Form("mixing13-%s", fHierStr[i].c_str())); 
if(fParser->OptionExists(Form("mixing23-%s", fHierStr[i].c_str()))) fMix23[i] = fParser->ArgAsDouble(Form("mixing23-%s", fHierStr[i].c_str())); 
if(fParser->OptionExists(Form("cpv-%s", fHierStr[i].c_str()))) fCPV[i] = fParser->ArgAsDouble(Form("cpv-%s", fHierStr[i].c_str())); 
if(fParser->OptionExists(Form("dm12sq-%s", fHierStr[i].c_str()))) fDm12sq[i] = fParser->ArgAsDouble(Form("dm12sq-%s", fHierStr[i].c_str())); 
if(fParser->OptionExists(Form("dm23sq-%s", fHierStr[i].c_str()))) fDm23sq[i] = fParser->ArgAsDouble(Form("dm23sq-%s", fHierStr[i].c_str())); 
if(fParser->OptionExists(Form("mixing12Bar-%s", fHierStr[i].c_str()))) fMix12Bar[i] = fParser->ArgAsDouble(Form("mixing12Bar-%s", fHierStr[i].c_str())); 
if(fParser->OptionExists(Form("mixing13Bar-%s", fHierStr[i].c_str()))) fMix13Bar[i] = fParser->ArgAsDouble(Form("mixing13Bar-%s", fHierStr[i].c_str())); 
if(fParser->OptionExists(Form("mixing23Bar-%s", fHierStr[i].c_str()))) fMix23Bar[i] = fParser->ArgAsDouble(Form("mixing23Bar-%s", fHierStr[i].c_str())); 
if(fParser->OptionExists(Form("cpvBar-%s", fHierStr[i].c_str()))) fCPVBar[i] = fParser->ArgAsDouble(Form("cpvBar-%s", fHierStr[i].c_str())); 
if(fParser->OptionExists(Form("dm12sqBar-%s", fHierStr[i].c_str()))) fDm12sqBar[i] = fParser->ArgAsDouble(Form("dm12sqBar-%s", fHierStr[i].c_str())); 
if(fParser->OptionExists(Form("dm23sqBar-%s", fHierStr[i].c_str()))) fDm23sqBar[i] = fParser->ArgAsDouble(Form("dm23sqBar-%s", fHierStr[i].c_str())); 
} 
if(fParser->OptionExists("beta-bar")){ 
fBetaBar = fParser->ArgAsDouble("beta-bar"); 
} 
if(fSynchronizeIHtoNH){ 
fMix12[1] = fMix12[0]; 
fMix13[1] = fMix13[0]; 
fMix23[1] = fMix23[0]; 
fCPV[1] = fCPV[0]; 
fDm12sq[1] = fDm12sq[0]; 
fDm23sq[1] = fDm23sq[0]; 
fMix12Bar[1] = fMix12Bar[0]; 
fMix13Bar[1] = fMix13Bar[0]; 
fMix23Bar[1] = fMix23Bar[0]; 
fCPVBar[1] = fCPVBar[0]; 
fDm12sqBar[1] = fDm12sqBar[0]; 
fDm23sqBar[1] = fDm23sqBar[0]; 
} 
util::OscParams::Instance()->SetValues(fMix12[0], fMix13[0], fMix23[0], fCPV[0], fDm12sq[0], fDm23sq[0], fBetaBar, fMix12[1], fMix13[1], fMix23[1], fCPV[1], fDm12sq[1], fDm23sq[1], fPriorProbNH, fThrowMH, fMix12Bar[0], fMix13Bar[0], fMix23Bar[0], fCPVBar[0], fDm12sqBar[0], fDm23sqBar[0], fMix12Bar[1], fMix13Bar[1], fMix23Bar[1], fCPVBar[1], fDm12sqBar[1], fDm23sqBar[1] ); 
if(fMargMixing23) util::OscParams::Instance()->SetPrior(conv::kPhypMixing23, fPriorMixing23, fPriorParMixing23[0], fPriorParMixing23[1], fMixModeMixing23); 
if(fMargDm23sq) util::OscParams::Instance()->SetPrior(conv::kPhypDm23sq, fPriorDm23sq, fPriorParDm23sq[0], fPriorParDm23sq[1], "" ); 
if(fMargMixing13) util::OscParams::Instance()->SetPrior(conv::kPhypMixing13, fPriorMixing13, fPriorParMixing13[0], fPriorParMixing13[1], fMixModeMixing13); 
if(fMargDeltaCP) util::OscParams::Instance()->SetPrior(conv::kPhypCPV, fPriorDeltaCP, fPriorParDeltaCP[0], fPriorParDeltaCP[1], "" ); 
if(fMargMixing12) util::OscParams::Instance()->SetPrior(conv::kPhypMixing12, fPriorMixing12, fPriorParMixing12[0], fPriorParMixing12[1], fMixModeMixing12); 
if(fMargDm12sq) util::OscParams::Instance()->SetPrior(conv::kPhypDm12sq, fPriorDm12sq, fPriorParDm12sq[0], fPriorParDm12sq[1], "" ); 
} 
void valor::RunOpt::ReadFitMargOptions() { 
if(fParser->OptionExists("do-toys")){ 
fDoToys = (bool)fParser->ArgAsInt("do-toys"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("read-skexp")){ 
fReadSKExp = (bool)fParser->ArgAsInt("read-skexp"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("use-xml-file")){ 
fUsing_xml_file = (bool)fParser->ArgAsInt("use-xml-file"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fUsing_xml_file){ 
if(fParser->OptionExists("fakedata-xml-file")){ 
fXmlfile = fParser->ArgAsString("fakedata-xml-file"); 
fRootfile = ""; 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
} 
else{ 
if(fParser->OptionExists("fakedata-root-file")){ 
fRootfile = fParser->ArgAsString("fakedata-root-file"); 
fXmlfile = ""; 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
} 
if(fParser->OptionExists("fit-param-list")){ 
fFit_param_list = fParser->ArgAsString("fit-param-list"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("do-fc")){ 
fDoFC = (bool)fParser->ArgAsInt("do-fc"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fDoFC==false){ 
if(fParser->OptionExists("file-margtoys")){ 
fInfilename = fParser->ArgAsString("file-margtoys"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
} 
else{ 
if(fParser->OptionExists("file-margtoys-nh")){ 
fInfilename_nh= fParser->ArgAsString("file-margtoys-nh"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("file-margtoys-ih")){ 
fInfilename_ih = fParser->ArgAsString("file-margtoys-ih"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
} 
if(fParser->OptionExists("nfiles-margtoys")){ 
fNfiles = fParser->ArgAsInt("nfiles-margtoys"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("ntoys-margtoys")){ 
fNtoysMarg = fParser->ArgAsInt("ntoys-margtoys"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("freepar0-name")){ 
fFreeparname0 = fParser->ArgAsString("freepar0-name"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("freepar1-name")){ 
fFreeparname1 = fParser->ArgAsString("freepar1-name"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("freepar0-min")){ 
fFreeparmin0 = fParser->ArgAsDouble("freepar0-min"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("freepar1-min")){ 
fFreeparmin1 = fParser->ArgAsDouble("freepar1-min"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("freepar0-max")){ 
fFreeparmax0 = fParser->ArgAsDouble("freepar0-max"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("freepar1-max")){ 
fFreeparmax1 = fParser->ArgAsDouble("freepar1-max"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("freepar0-npt")){ 
fNptScan0 = fParser->ArgAsInt("freepar0-npt"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("freepar1-npt")){ 
fNptScan1 = fParser->ArgAsInt("freepar1-npt"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("marginalize-mh-margtoys")){ 
fDoMargMH = (bool) fParser->ArgAsInt("marginalize-mh-margtoys"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("mass-hierarchy-margtoys")){ 
fHierarchy_marg = fParser->ArgAsString("mass-hierarchy-margtoys"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("do-minimize")){ 
fDoMinimize = (bool) fParser->ArgAsInt("do-minimize"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("type-error")){ 
fTypeError = fParser->ArgAsString("type-error"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("full-chisq")){ 
fDrawFullChisq = (bool) fParser->ArgAsInt("full-chisq"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("test-statistic")){ 
fTeststat = fParser->ArgAsString("test-statistic"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("store-like-weights")){ 
fStoreLikeWeights = (bool) fParser->ArgAsInt("store-like-weights"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fStoreLikeWeights){ 
if(fNExperiments>1 || fNExperiments<0){ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
} 
if(fParser->OptionExists("penalty-freepar0")){ 
fPenaltyTerm0 = (bool) fParser->ArgAsInt("penalty-freepar0"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("penalty-freepar1")){ 
fPenaltyTerm1 = (bool) fParser->ArgAsInt("penalty-freepar1"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(fParser->OptionExists("scale-gentoys")){ 
kScale_toys_based_on_samples = (bool) fParser->ArgAsInt("scale-gentoys"); 
if(fParser->OptionExists("scale-gentoys-scale")){ 
fScale_toys_based_on_samples_scale = (double) fParser->ArgAsDouble("scale-gentoys-scale"); 
} 
} 
} 
void valor::RunOpt::Usage(const int w) { 
assert(1); 
assert(1); 
std::stringstream note_stream; 
assert(1); 
if(fParseType & kParseCommon) { 
assert(1); 
} 
if(fParseType & kParseToys) { 
assert(1); 
} 
if(fParseType & kParseGlobal) { 
assert(1); 
} 
if(fParseType & kParse3FOscParams) { 
assert(1); 
note_stream << "Note: options are read in the order above, so you can randomize all then set e.g. beta-bar to something specific" << endl; 
for(int i = 0; i < 2; i++) { 
assert(1); 
} 
for(int i = 0; i < 2; i++) { 
assert(1); 
} 
assert(1); 
} 
if(fParseType & kParseFitMarg) { 
assert(1); 
} 
assert(1); 
assert(1); 
} 
void valor::RunOpt::Print(ostream & stream, const int w) const { 
assert(1); 
assert(1); 
TString seedToyMCstat ("random"); 
TString seedToyMCsyst ("random"); 
TString seedToyMCosc ("random"); 
TString seedFitter ("random"); 
TString seedOther ("random"); 
if (fSeedToyMCstat ){seedToyMCstat = TString::Format("%u",fSeedToyMCstat);} 
if (fSeedToyMCsyst ){seedToyMCsyst = TString::Format("%u",fSeedToyMCsyst);} 
if (fSeedToyMCosc ){seedToyMCosc = TString::Format("%u",fSeedToyMCosc );} 
if (fSeedFitter ){seedFitter = TString::Format("%u",fSeedFitter );} 
if (fSeedOther ){seedOther = TString::Format("%u",fSeedOther );} 
if(fParseType & kParseCommon) { 
stream << "Common running options:" << endl << " - " << setw(w) << "Config file: " << fConfigFile << endl << " - " << setw(w) << "Verbosity file:" << fVerbosityFile << endl << " - " << setw(w) << "Output file tag:" << fFileTag << endl << " - " << setw(w) << "Run number:" << fRun << endl << " - " << setw(w) << "Using data file:" << ((fUseFileData) ? "YES " : "NO") << endl; 
if(fUseFileData) cout << " - " << setw(w) << " --> " << fPathFileData; 
assert(1); 
stream << " - " << setw(w) << "Seed (stat): " << seedToyMCstat << endl << " - " << setw(w) << "Seed (syst): " << seedToyMCsyst << endl << " - " << setw(w) << "Seed (osc): " << seedToyMCosc << endl << " - " << setw(w) << "Seed (fitter): " << seedFitter << endl << " - " << setw(w) << "Seed (other): " << seedOther << endl << endl; 
} 
if(fParseType & kParseToys) { 
stream << "Toy running options:" << endl << " - " << setw(w) << "First experiment:" << fFirstExperiment << endl << " - " << setw(w) << "Last experiment:" << fLastExperiment << endl << " - " << setw(w) << "N experiments:" << fNExperiments << endl << " - " << setw(w) << "Statistical fluctuations:" << ((fStatFluctuations) ? "YES " : "NO") << endl << " - " << setw(w) << "Randomize systematics:" << util::SysThrowIdToString(fSystTweakMode) << endl << " - " << setw(w) << "Rethrow unphysical:" << ((fRethrowIfUnphysical) ? "YES " : "NO") << endl << " - " << setw(w) << "Verbose skexp::Tweak():" << ((fVerboseSystThrows) ? "YES " : "NO") << endl << " - " << setw(w) << "Verbose fit:" << ((fVerboseFit) ? "YES " : "NO") << endl << endl; 
} 
if(fParseType & kParseGlobal) { 
stream << "Global running options:" << endl << " - " << setw(w) << "Dmsq scheme:" << fGlobalDmsqScheme << endl << " - " << setw(w) << "Mixing parameters scheme:" << fGlobalMixParamScheme << endl << " - " << setw(w) << "CPV phase scheme:" << fGlobalCPVPhaseScheme << endl << " - " << setw(w) << "Mass hierarchy:" << fGlobalMassHierarchy << endl << " - " << setw(w) << "Mixing parameter octant:" << fGlobalMixParamOctant << endl << endl; 
} 
if(fParseType & kParse3FOscParams) { 
stream << "3f oscillation running options:" << endl << " - " << setw(w) << "Hypothesis:" << fHypothesis << endl << " - " << setw(w) << "Synchronize IH to NH osc params:" << ((fSynchronizeIHtoNH) ? "YES " : "NO") << endl << " - " << setw(w) << "Normal hierarchy prior prob:" << fPriorProbNH << endl << " - " << setw(w) << "Throw mass hierarchy:" << ((fThrowMH) ? "YES " : "NO") << endl << " - " << setw(w) << "Prior mode:" << fPriorId << endl; 
for(int i = 0; i < 2; i++) { 
stream << " - " << setw(w) << Form("%s_%s", util::RawParamAsString(kPhypMixing12).c_str(), fHierStr[i].c_str()) << fMix12[i] << endl << " - " << setw(w) << Form("%s_%s", util::RawParamAsString(kPhypMixing13).c_str(), fHierStr[i].c_str()) << fMix13[i] << endl << " - " << setw(w) << Form("%s_%s", util::RawParamAsString(kPhypMixing23).c_str(), fHierStr[i].c_str()) << fMix23[i] << endl << " - " << setw(w) << Form("%s_%s", util::RawParamAsString(kPhypCPV).c_str(), fHierStr[i].c_str()) << fCPV[i] << endl << " - " << setw(w) << Form("%s_%s", util::RawParamAsString(kPhypDm12sq).c_str(), fHierStr[i].c_str()) << fDm12sq[i] << endl << " - " << setw(w) << Form("%s_%s", util::RawParamAsString(kPhypDm23sq).c_str(), fHierStr[i].c_str()) << fDm23sq[i] << endl << " - " << setw(w) << Form("%s_%s", util::RawParamAsString(kPhypMixing13Bar).c_str(), fHierStr[i].c_str()) << fMix13Bar[i] << endl << " - " << setw(w) << Form("%s_%s", util::RawParamAsString(kPhypMixing23Bar).c_str(), fHierStr[i].c_str()) << fMix23Bar[i] << endl << " - " << setw(w) << Form("%s_%s", util::RawParamAsString(kPhypCPVBar).c_str(), fHierStr[i].c_str()) << fCPVBar[i] << endl << " - " << setw(w) << Form("%s_%s", util::RawParamAsString(kPhypDm12sqBar).c_str(), fHierStr[i].c_str()) << fDm12sqBar[i] << endl << " - " << setw(w) << Form("%s_%s", util::RawParamAsString(kPhypDm23sqBar).c_str(), fHierStr[i].c_str()) << fDm23sqBar[i] << endl; 
} 
stream << " - " << setw(w) << "Beta bar:" << fBetaBar << endl << endl; 
} 
if(fParseType & kParseFitMarg) { 
stream << "Fit with marginalization running options:" << endl << " - " << setw(w) << "Do toys for fake datasets on the fly:" << ((fDoToys) ? "YES " : "NO") << endl << " - " << setw(w) << "Use xml file for fakedata sets (if not use root file):" << ((fUsing_xml_file) ? "YES " : "NO") << endl << " - " << setw(w) << "Input xml file for fakedata sets:" << fXmlfile << endl << " - " << setw(w) << "Input root file for fakedata sets:" << fRootfile << endl << " - " << setw(w) << "Fit parameter list:" << fFit_param_list << endl; 
stream << " - " << setw(w) << "Running Feldman-Cousins:" << ((fDoFC) ? "YES " : "NO") << endl; 
if(fDoFC==false){ 
stream << " - " << setw(w) << "Input file for marginalization toys:" << fInfilename << endl; 
} 
else{ 
stream << " - " << setw(w) << "Input file for marginalization toys NH:" << fInfilename_nh << endl; 
stream << " - " << setw(w) << "Input file for marginalization toys IH:" << fInfilename_ih << endl; 
} 
stream << " - " << setw(w) << "Number of toys for marginalization:" << fNtoysMarg << endl << " - " << setw(w) << "Name of free parameter 0 for fit with marginalization:" << fFreeparname0 << endl << " - " << setw(w) << "Name of free parameter 1 for fit with marginalization:" << fFreeparname1 << endl << " - " << setw(w) << "Min value of free parameter 0 for fit with marginalization:" << fFreeparmin0 << endl << " - " << setw(w) << "Min value of free parameter 1 for fit with marginalization:" << fFreeparmin1 << endl << " - " << setw(w) << "Max value of free parameter 0 for fit with marginalization:" << fFreeparmax0 << endl << " - " << setw(w) << "Max value of free parameter 1 for fit with marginalization:" << fFreeparmax1 << endl << " - " << setw(w) << "Number of points of free parameter 0 for fit with marginalization:" << fNptScan0 << endl << " - " << setw(w) << "Number of points of free parameter 1 for fit with marginalization:" << fNptScan1 << endl << " - " << setw(w) << "Marginalization of mass hierarchy for input marginalization files:" << ((fDoMargMH) ? "YES " : "NO") << endl << " - " << setw(w) << "Mass hierarchy for input marginalization files:" << fHierarchy_marg << endl << " - " << setw(w) << "Use Minimization (descent-gradient):" << ((fDoMinimize) ? "YES " : "NO") << endl << " - " << setw(w) << "Error type for fit with marginalization:" << fTypeError << endl << " - " << setw(w) << "Draw fill marginalized chisq:" << ((fDrawFullChisq) ? "YES " : "NO") << endl << " - " << setw(w) << "Test statistic for fit with marginalization:" << fTeststat << endl << " - " << setw(w) << "Store likelihood weights of fit with marginalization?:" << ((fStoreLikeWeights) ? "YES " : "NO") << endl << " - " << setw(w) << "Use penalty term for free parameter 0:" << ((fPenaltyTerm0) ? "YES " : "NO") << endl << " - " << setw(w) << "Use penalty term for free parameter 1:" << ((fPenaltyTerm1) ? "YES " : "NO") << endl << endl; 
} 
} 
VALORArrayBin::VALORArrayBin() : bin1 (-1), bin2 (-1), bin3 (-1), bin4 (-1), bin5 (-1), bin6 (-1) { 
return; 
} 
VALORArrayBin::VALORArrayBin(int b1, int b2, int b3, int b4, int b5, int b6) : bin1 (b1), bin2 (b2), bin3 (b3), bin4 (b4), bin5 (b5), bin6 (b6) { 
return; 
} 
VALORArrayBin::VALORArrayBin(const int * bin_numbers) : bin1 (bin_numbers[0]), bin2 (bin_numbers[1]), bin3 (bin_numbers[2]), bin4 (bin_numbers[3]), bin5 (bin_numbers[4]), bin6 (bin_numbers[5]) { 
return; 
} 
namespace valor { 
bool operator==(const VALORArrayBin & lhs, const VALORArrayBin & rhs) { 
assert(sizeof(lhs)==6*sizeof(int)); 
return !(memcmp(&lhs,&rhs,sizeof(lhs))); 
} 
} 
const char VALORArrayHeader::kIDString[] = "\211VLR\r\n\032\n"; 
VALORArrayHeader::VALORArrayHeader(void) : fBlock(), fBlockAsInt ( ( Int_t *)fBlock ), fBlockAsUInt( (UInt_t *)fBlock ) { 
return; 
} 
VALORArrayHeader::VALORArrayHeader(kVArrayType type, UInt_t ndims, Int_t * dimensions, UInt_t compressed_size, UInt_t compression_level) : fBlock(), fBlockAsInt ( ( Int_t *)fBlock ), fBlockAsUInt( (UInt_t *)fBlock ) { 
UInt_t type_as_uint = (UInt_t) type; 
UInt_t version_as_uint = (UInt_t) kArrayVersion; 
char * block_pointer = fBlock; 
memcpy(block_pointer , kIDString ,8 ); block_pointer += 8; 
memcpy(block_pointer , &version_as_uint ,4 ); block_pointer += 4; 
memcpy(block_pointer , &type_as_uint ,4 ); block_pointer += 4; 
memcpy(block_pointer , &compression_level ,4 ); block_pointer += 4; 
memcpy(block_pointer , &compressed_size ,4 ); block_pointer += 4; 
memcpy(block_pointer , &ndims ,4 ); block_pointer += 4; 
memcpy(block_pointer , dimensions ,4*8); block_pointer += 4*8; 
return; 
} 
UInt_t VALORArrayHeader::GetVersion() const { 
return fBlockAsUInt[2]; 
} 
VALORArrayHeader::kVArrayType VALORArrayHeader::GetDataType() const { 
kVArrayType t = (kVArrayType)fBlockAsUInt[3]; 
return t; 
} 
UInt_t VALORArrayHeader::GetCompressionLevel() const { 
return fBlockAsUInt[4]; 
} 
UInt_t VALORArrayHeader::GetCompressedSize() const { 
return fBlockAsUInt[5]; 
} 
UInt_t VALORArrayHeader::GetNDimensions() const { 
return fBlockAsUInt[6]; 
} 
const Int_t * VALORArrayHeader::GetDimensions() const { 
return &fBlockAsInt[7]; 
} 
void VALORArrayHeader::Write(std::ostream & stream_to_write_to) const { 
stream_to_write_to.write(fBlock,kSize); 
} 
int VALORArrayHeader::Read(std::istream & stream_to_read_from) { 
stream_to_read_from.read(fBlock,kSize); 
if (memcmp(fBlock,kIDString,8)) { 
assert(1); 
return 1; 
} 
if (this->GetVersion()!=kArrayVersion) { 
assert(1); 
return 2; 
} 
return 0; 
} 
#ifdef __VALOR_FMWK_GSL_ENABLED__ 
#endif 
extern "C" void R__zip(int cxlevel, int *srcsize, char *src, int *tgtsize, char *tgt, int *irep); 
extern "C" void R__unzip(int *srcsize, unsigned char *src, int *tgtsize, unsigned char *tgt, int *irep); 
template<typename numtype> VALORArrayT<numtype>::VALORArrayT() : TNamed(), fNDim(0), fArray(NULL), fCompressionLevel(conv::kDefaultCompressionLevel) { 
} 
template<typename numtype> VALORArrayT<numtype>::VALORArrayT(const vector<int> dimensions) : TNamed() { 
this->Construct(dimensions.size(), &dimensions[0]); 
} 
template<typename numtype> VALORArrayT<numtype>::VALORArrayT(int nd, const int * dimensions) : TNamed() { 
this->Construct(nd,dimensions); 
} 
template<typename numtype> VALORArrayT<numtype>::VALORArrayT(std::string file_to_read) : TNamed() { 
this->ReadFile(file_to_read); 
} 
template<typename numtype> VALORArrayT<numtype>::VALORArrayT(int dim1, int dim2, int dim3, int dim4, int dim5, int dim6) : TNamed() { 
int dimensions[6] = {dim1,dim2,dim3,dim4,dim5,dim6}; 
int ndim=0; 
for (int ii = 0 ; ii < 6 ; ii++) { 
if (dimensions[ii] > 0 ) ndim+=1; 
else break; 
} 
this->Construct(ndim, dimensions); 
} 
template<typename numtype> void VALORArrayT<numtype>::Construct(int nd, const int * dimensions) { 
fCompressionLevel = conv::kDefaultCompressionLevel; 
assert(nd > 0 && nd <= 6); 
fNDim = nd; 
for (int i = 0 ; i < 6 ; i++) { 
fDimensions[i] = (i<nd ? dimensions[i] : 1); 
fNames[i] = ""; 
fIncrement[i] = 0; 
} 
fSize = 1; 
for (int i = fNDim-1 ; i >= 0 ; i--) { 
fIncrement[i] = fSize; 
fSize *= dimensions[i]; 
} 
fArray = new numtype[fSize]; 
this->SetAll(0.); 
} 
template<typename numtype> void VALORArrayT<numtype>::ConstructT(int nd, const Int_t * dimensions) { 
fCompressionLevel = conv::kDefaultCompressionLevel; 
assert(nd > 0 && nd <= 6); 
fNDim = nd; 
for (int i = 0 ; i < 6 ; i++) { 
fDimensions[i] = (i<nd ? dimensions[i] : 1); 
fNames[i] = ""; 
fIncrement[i] = 0; 
} 
fSize = 1; 
for (int i = fNDim-1 ; i >= 0 ; i--) { 
fIncrement[i] = fSize; 
fSize *= dimensions[i]; 
} 
fArray = new numtype[fSize]; 
this->SetAll(0.); 
} 
template<typename numtype> VALORArrayT<numtype>::VALORArrayT(const VALORArrayT<numtype> & arr) : TNamed(arr), fNDim(arr.fNDim), fSize(arr.fSize), fArray(NULL) { 
this->CopyFrom(arr); 
} 
template<typename numtype> void VALORArrayT<numtype>::CopyFrom(const VALORArrayT<numtype> & arr) { 
this->Cleanup(); 
arr.Copy(*this); 
this->Construct(arr.GetNDim(),arr.GetDimensions()); 
assert(this->fSize>=0); 
memcpy(fDimensions , arr.fDimensions , 6*sizeof(Int_t)); 
memcpy(fIncrement , arr.fIncrement , 6*sizeof(int)); 
memcpy(fArray , arr.fArray , fSize*sizeof(numtype)); 
for (int i = 0 ; i < 6; i++) { 
fNames[i] = arr.fNames[i]; 
} 
} 
template<typename numtype> void VALORArrayT<numtype>::CopyDataOnlyFrom(const VALORArrayT<numtype> & arr) { 
memcpy(fArray , arr.fArray , fSize*sizeof(numtype)); 
} 
template<typename numtype> void VALORArrayT<numtype>::Cleanup() { 
if (fArray) {delete[] fArray; fArray = 0;} 
for (int i = 0 ; i < 6 ; i++) { 
fDimensions[i] = 1; 
fNames[i] = ""; 
} 
} 
template<typename numtype> VALORArrayT<numtype>::~VALORArrayT() { 
this->Cleanup(); 
} 
template<typename numtype> int VALORArrayT<numtype>::GetSize(int dim) const { 
if (dim<0) return fSize; 
return fDimensions[dim]; 
} 
template<typename numtype> int VALORArrayT<numtype>:: Address(int ind1, int ind2, int ind3, int ind4, int ind5, int ind6) const { 

#ifdef CHECK_VA_ADDRESS 
int indices[6] = {ind1,ind2,ind3,ind4,ind5,ind6}; 
for (int i = 0 ; i < fNDim; i++) { 
if (indices[i]<0 || indices[i]>=fDimensions[i]) { 
assert(1); 
util::Die(-1) ; return 0; 
} 
} 
for (int i = fNDim ; i < 6 ; i++) { 
assert(indices[i]==-1); 
assert(fIncrement[i]==0); 
} 
#endif 
int address = ind1 * fIncrement[0] + ind2 * fIncrement[1] + ind3 * fIncrement[2] + ind4 * fIncrement[3] + ind5 * fIncrement[4] + ind6 * fIncrement[5]; 
return address; 
} 
template<typename numtype> void VALORArrayT<numtype>:: InverseAddress(int address, int * return_indices) const { 
for (int i = 0 ; i < fNDim; i++) { 
return_indices[i] = 0; 
while (address >= fIncrement[i]) { 
address-=fIncrement[i]; 
return_indices[i]+=1; 
} 
} 
return; 
} 
template<typename numtype> numtype & VALORArrayT<numtype>:: GetEntryRef(int ind1, int ind2, int ind3, int ind4, int ind5, int ind6) { 
int address = this->Address(ind1, ind2, ind3, ind4, ind5, ind6); 
return fArray[address]; 
} 
template<typename numtype> const numtype & VALORArrayT<numtype>:: GetEntryRef(int ind1, int ind2, int ind3, int ind4, int ind5, int ind6) const { 
int address = this->Address(ind1, ind2, ind3, ind4, ind5, ind6); 
return fArray[address]; 
} 
template<typename numtype> numtype VALORArrayT<numtype>:: GetEntry(int ind1, int ind2, int ind3, int ind4, int ind5, int ind6) const { 
int address = this->Address(ind1, ind2, ind3, ind4, ind5, ind6); 
return fArray[address]; 
} 
template<typename numtype> void VALORArrayT<numtype>:: SetEntry(numtype value, int ind1, int ind2, int ind3, int ind4, int ind5, int ind6) { 
int address = this->Address(ind1, ind2, ind3, ind4, ind5, ind6); 
fArray[address] = value; 
return; 
} 
template<typename numtype> void VALORArrayT<numtype>:: AddToEntry(numtype value, int ind1, int ind2, int ind3, int ind4, int ind5, int ind6) { 
int address = this->Address(ind1, ind2, ind3, ind4, ind5, ind6); 
fArray[address] += value; 
return; 
} 
template<typename numtype> int VALORArrayT<numtype>:: Address(const VALORArrayBin & bin) const { 

#ifdef CHECK_VA_ADDRESS 
int indices[6] = {bin.bin1,bin.bin2,bin.bin3,bin.bin4,bin.bin5,bin.bin6}; 
for (int i = 0 ; i < fNDim; i++) { 
} 
for (int i = 0 ; i < fNDim; i++) { 
assert(indices[i]>=0); 
} 
for (int i = fNDim ; i < 6 ; i++) { 
assert(indices[i]==-1); 
assert(fIncrement[i]==0); 
} 
#endif 
int address = bin.bin1 * fIncrement[0] + bin.bin2 * fIncrement[1] + bin.bin3 * fIncrement[2] + bin.bin4 * fIncrement[3] + bin.bin5 * fIncrement[4] + bin.bin6 * fIncrement[5]; 
return address; 
} 
template<typename numtype> VALORArrayBin VALORArrayT<numtype>:: InverseAddress(int address) const { 
int return_indices[6] = {-1,-1,-1,-1,-1,-1}; 
for (int i = 0 ; i < fNDim; i++) { 
return_indices[i] = 0; 
while (address >= fIncrement[i]) { 
address-=fIncrement[i]; 
return_indices[i]+=1; 
} 
} 
return VALORArrayBin( return_indices[0], return_indices[1], return_indices[2], return_indices[3], return_indices[4], return_indices[5]); 
} 
template<typename numtype> numtype & VALORArrayT<numtype>:: GetEntryRef(const VALORArrayBin & bin) { 
int address = this->Address(bin); 
return fArray[address]; 
} 
template<typename numtype> const numtype & VALORArrayT<numtype>:: GetEntryRef(const VALORArrayBin & bin) const { 
int address = this->Address(bin); 
return fArray[address]; 
} 
template<typename numtype> numtype VALORArrayT<numtype>:: GetEntry(const VALORArrayBin & bin) const { 
int address = this->Address(bin); 
return fArray[address]; 
} 
template<typename numtype> void VALORArrayT<numtype>:: SetEntry(numtype value, const VALORArrayBin & bin) { 
int address = this->Address(bin); 
fArray[address] = value; 
return; 
} 
template<typename numtype> void VALORArrayT<numtype>:: AddToEntry(numtype value, const VALORArrayBin & bin) { 
int address = this->Address(bin); 
fArray[address] += value; 
return; 
} 
template<typename numtype> int VALORArrayT<numtype>:: GetNDim() const { 
return fNDim; 
} 
template<typename numtype> const numtype * VALORArrayT<numtype>:: GetArray(void) const { 
return fArray; 
} 
template<typename numtype> numtype * VALORArrayT<numtype>:: GetArray(void) { 
return fArray; 
} 
template<typename numtype> const int * VALORArrayT<numtype>:: GetDimensions(void) const { 
return fDimensions; 
} 
template<typename numtype> VALORArrayBin VALORArrayT<numtype>:: GetDimensionSizes(void) const { 
return VALORArrayBin(fDimensions); 
} 
template<typename numtype> void VALORArrayT<numtype>:: SetAll(numtype value) { 
for (int ii = 0 ; ii < fSize ; ii++) { 
fArray[ii] = value; 
} 
} 
template<typename numtype> void VALORArrayT<numtype>:: SetDimensionName(int dimension, const std::string & name) { 
fNames[dimension] = name; 
} 
template<typename numtype> std::string VALORArrayT<numtype>:: GetDimensionName(int dimension) const { 
return fNames[dimension]; 
} 
template<typename numtype> VALORArrayT<numtype> VALORArrayT<numtype>:: GetSlice(int dimension, int min_bin, int max_bin) const { 
if (fNDim < 2) return VALORArrayT(); 
int new_ndim = fNDim-1; 
int new_dims[new_ndim]; 
int new_dim_id[6] = {6,6,6,6,6,6}; 
int i_new_dim = 0; 
for (int idim = 0 ; idim < fNDim; idim++) { 
if (idim==dimension) { 
continue; 
} 
new_dim_id[i_new_dim] = idim; 
new_dims[i_new_dim] = fDimensions[idim]; 
i_new_dim++; 
} 
VALORArrayT<numtype> slice(new_ndim,new_dims); 
i_new_dim = 0; 
for (int idim = 0 ; idim < fNDim; idim++) { 
if (idim==dimension) { 
continue; 
} 
slice.SetDimensionName(i_new_dim, fNames[idim]); 
i_new_dim++; 
} 
min_bin = (min_bin<0 ? 0 : min_bin) ; max_bin = (max_bin<0 ? fDimensions[dimension]-1 : max_bin) ; 
slice.SetAll(0); 
for (int i = 0 ; i < fSize ; i++) { 
int old_address[7] = {-1,-1,-1,-1,-1,-1,-1}; 
this->InverseAddress(i, old_address); 
for (int bin = min_bin; bin <= max_bin ; bin++) { 
if (old_address[dimension]!=bin) continue; 
slice.AddToEntry(fArray[i], old_address[new_dim_id[0]], old_address[new_dim_id[1]], old_address[new_dim_id[2]], old_address[new_dim_id[3]], old_address[new_dim_id[4]] ); 
} 
} 
return slice; 
} 
template<typename numtype> numtype VALORArrayT<numtype>:: Integral() const { 
if (fNDim) return std::accumulate(fArray,fArray+fSize, numtype(0)); 
return 0; 
} 
template<typename numtype> numtype VALORArrayT<numtype>:: Integral(int min_dim1 , int max_dim1, int min_dim2, int max_dim2, int min_dim3 , int max_dim3, int min_dim4, int max_dim4, int min_dim5 , int max_dim5, int min_dim6, int max_dim6 ) const { 
numtype integral = 0; 
min_dim1 = (min_dim1<0 ? 0 : min_dim1) ; max_dim1 = (max_dim1<0 ? fDimensions[0]-1 : max_dim1) ; 
min_dim2 = (min_dim2<0 ? 0 : min_dim2) ; max_dim2 = (max_dim2<0 ? fDimensions[1]-1 : max_dim2) ; 
min_dim3 = (min_dim3<0 ? 0 : min_dim3) ; max_dim3 = (max_dim3<0 ? fDimensions[2]-1 : max_dim3) ; 
min_dim4 = (min_dim4<0 ? 0 : min_dim4) ; max_dim4 = (max_dim4<0 ? fDimensions[3]-1 : max_dim4) ; 
min_dim5 = (min_dim5<0 ? 0 : min_dim5) ; max_dim5 = (max_dim5<0 ? fDimensions[4]-1 : max_dim5) ; 
min_dim6 = (min_dim6<0 ? 0 : min_dim6) ; max_dim6 = (max_dim6<0 ? fDimensions[5]-1 : max_dim6) ; 
for (int i1 = min_dim1 ; i1 <= max_dim1 ; i1++) { 
for (int i2 = min_dim2 ; i2 <= max_dim2 ; i2++) { 
for (int i3 = min_dim3 ; i3 <= max_dim3 ; i3++) { 
for (int i4 = min_dim4 ; i4 <= max_dim4 ; i4++) { 
for (int i5 = min_dim5 ; i5 <= max_dim5 ; i5++) { 
for (int i6 = min_dim6 ; i6 <= max_dim6 ; i6++) { 
int address = fIncrement[0]*i1+ fIncrement[1]*i2+ fIncrement[2]*i3+ fIncrement[3]*i4+ fIncrement[4]*i5+ fIncrement[5]*i6 ; 
integral+=fArray[address]; 
} 
} 
} 
} 
} 
} 
return integral; 
} 
template<typename numtype> void VALORArrayT<numtype>:: Scale(numtype factor) { 

#if defined(__VALOR_FMWK_GSL_ENABLED__) && defined(VALORARRAY_USE_GSL) 
gsl_vector_view v = gsl_vector_view_array(fArray,fSize); 
gsl_blas_dscal(factor, (&v.vector)); 
#else 
for (int i = 0 ; i < fSize; i++) { 
fArray[i] *= factor; 
} 
#endif 
} 
template<typename numtype> void VALORArrayT<numtype>:: ScaleBins(numtype factor, int ibin1, int ibin2, int ibin3, int ibin4, int ibin5, int ibin6) { 
for (int i1 = 0 ; i1 < fDimensions[0] ; i1++) { 
if (ibin1>=0 && ibin1 !=i1 ) continue; 
for (int i2 = 0 ; i2 < fDimensions[1] ; i2++) { 
if (ibin2>=0 && ibin2 !=i2 ) continue; 
for (int i3 = 0 ; i3 < fDimensions[2] ; i3++) { 
if (ibin3>=0 && ibin3 !=i3 ) continue; 
for (int i4 = 0 ; i4 < fDimensions[3] ; i4++) { 
if (ibin4>=0 && ibin4 !=i4 ) continue; 
for (int i5 = 0 ; i5 < fDimensions[4] ; i5++) { 
if (ibin5>=0 && ibin5 !=i5 ) continue; 
for (int i6 = 0 ; i6 < fDimensions[5] ; i6++) { 
if (ibin6>=0 && ibin6 !=i6 ) continue; 
int address = fIncrement[0]*i1+ fIncrement[1]*i2+ fIncrement[2]*i3+ fIncrement[3]*i4+ fIncrement[4]*i5+ fIncrement[5]*i6 ; 
fArray[address]*=factor; 
} 
} 
} 
} 
} 
} 
return; 
} 
template<typename numtype> void VALORArrayT<numtype>:: ScaleBinRange(numtype factor, int min_dim1 , int max_dim1, int min_dim2, int max_dim2, int min_dim3 , int max_dim3, int min_dim4, int max_dim4, int min_dim5 , int max_dim5, int min_dim6, int max_dim6 ) { 
min_dim1 = (min_dim1<0 ? 0 : min_dim1) ; max_dim1 = (max_dim1<0 ? fDimensions[0]-1 : max_dim1) ; 
min_dim2 = (min_dim2<0 ? 0 : min_dim2) ; max_dim2 = (max_dim2<0 ? fDimensions[1]-1 : max_dim2) ; 
min_dim3 = (min_dim3<0 ? 0 : min_dim3) ; max_dim3 = (max_dim3<0 ? fDimensions[2]-1 : max_dim3) ; 
min_dim4 = (min_dim4<0 ? 0 : min_dim4) ; max_dim4 = (max_dim4<0 ? fDimensions[3]-1 : max_dim4) ; 
min_dim5 = (min_dim5<0 ? 0 : min_dim5) ; max_dim5 = (max_dim5<0 ? fDimensions[4]-1 : max_dim5) ; 
min_dim6 = (min_dim6<0 ? 0 : min_dim6) ; max_dim6 = (max_dim6<0 ? fDimensions[5]-1 : max_dim6) ; 
for (int i1 = min_dim1 ; i1 <= max_dim1 ; i1++) { 
for (int i2 = min_dim2 ; i2 <= max_dim2 ; i2++) { 
for (int i3 = min_dim3 ; i3 <= max_dim3 ; i3++) { 
for (int i4 = min_dim4 ; i4 <= max_dim4 ; i4++) { 
for (int i5 = min_dim5 ; i5 <= max_dim5 ; i5++) { 
for (int i6 = min_dim6 ; i6 <= max_dim6 ; i6++) { 
int address = fIncrement[0]*i1+ fIncrement[1]*i2+ fIncrement[2]*i3+ fIncrement[3]*i4+ fIncrement[4]*i5+ fIncrement[5]*i6 ; 
fArray[address]*=factor; 
} 
} 
} 
} 
} 
} 
} 
template<typename numtype> void VALORArrayT<numtype>:: ReadFile(std::string file_to_read) { 
this->Cleanup(); 
ifstream is(file_to_read.c_str(),ios::binary|ios::in); 
if (not is) { 
assert(1); 
util::Die(1); return; 
} 
#ifndef USE_UNCOMPRESSED_VARRAY_FORMAT 
VALORArrayHeader header; 
int result = header.Read(is); 
if (result) { 
assert(1); 
is.close(); 
util::Die(1); return; 
} 
if (header.GetDataType() != this->GetHeaderType()) { 
assert(1); 
is.close(); 
util::Die(1); return; 
} 
this->ConstructT(header.GetNDimensions(),header.GetDimensions()); 
int compressed_data_size = header.GetCompressedSize(); 
int out_data_size = sizeof(numtype) * (fSize); 
unsigned char * compressed_buffer = new unsigned char[compressed_data_size]; 
is.read( (char*) compressed_buffer, compressed_data_size ); 
R__unzip(&compressed_data_size,compressed_buffer,&out_data_size,(unsigned char *)fArray, &result); 
assert((size_t)result==sizeof(numtype)*fSize); 
#else 
int ndim = 0; 
int dims[6] = {}; 
is.read( (char*)&ndim ,sizeof(int)); 
is.read( (char*)dims ,sizeof(int)*6); 
this->Construct(ndim,dims); 
#ifndef NDEBUG 
unsigned int startn = is.tellg(); 
is.seekg(0,is.end); 
unsigned int n = is.tellg(); 
is.seekg(0,is.beg); 
assert(n==(7*sizeof(int) + fSize*sizeof(numtype))); 
is.seekg(startn); 
#endif 
is.read( (char*)fArray,fSize*sizeof(numtype)); 
#endif 
is.close(); 
return; 
} 
template<typename numtype> void VALORArrayT<numtype>:: WriteFile(std::string file_to_write) { 
ofstream os(file_to_write.c_str(),ios::binary|ios::out); 
assert(os); 
#ifndef USE_UNCOMPRESSED_VARRAY_FORMAT 
int nbytes_compressed=-999; 
int uncompressed_buffer_size = (fSize )*sizeof(numtype); 
int compressed_buffer_size = (fSize*1.0004 )*sizeof(numtype) + 11; 
char * compressed_buffer = new char[compressed_buffer_size]; 
R__zip(fCompressionLevel, &uncompressed_buffer_size, (char*)fArray, &compressed_buffer_size, compressed_buffer, &nbytes_compressed); 
VALORArrayHeader header(this->GetHeaderType(),fNDim,fDimensions,nbytes_compressed,fCompressionLevel); 
header.Write(os); 
os.write( (char*)compressed_buffer,nbytes_compressed); 
delete[] compressed_buffer; 
#else 
os.write( (char*)&fNDim ,sizeof(int)); 
os.write( (char*)fDimensions ,sizeof(Int_t)*6); 
os.write( (char*)fArray,fSize*sizeof(numtype) ); 
#endif 
os.close(); 
return; 
} 
template<typename numtype> void VALORArrayT<numtype>:: Resize(const std::vector<int> dimensions) { 
this->Cleanup(); 
this->Construct(dimensions.size(), &dimensions[0]); 
} 
template<typename numtype> void VALORArrayT<numtype>:: Resize(int nd, const int * dimensions) { 
this->Cleanup(); 
this->Construct(nd,dimensions); 
} 
template<typename numtype> void VALORArrayT<numtype>:: Resize(int dim1, int dim2, int dim3, int dim4, int dim5, int dim6) { 
this->Cleanup(); 
int dimensions[6] = {dim1,dim2,dim3,dim4,dim5,dim6}; 
int ndim=0; 
for (int ii = 0 ; ii < 6 ; ii++) { 
if (dimensions[ii] > 0 ) ndim+=1; 
else break; 
} 
this->Construct(ndim, dimensions); 
} 
template<typename numtype> void VALORArrayT<numtype>:: SetCompressionLevel(int level) { 
fCompressionLevel = level; 
} 
template<typename numtype> void VALORArrayT<numtype>:: PrintEntries(std::ostream & stream) { 
for (int i1 = 0 ; i1 < fDimensions[0] ; i1++) { 
stream<<"{ "; 
for (int i2 = 0 ; i2 < fDimensions[1] ; i2++) { 
if (fDimensions[2]>1){ stream<<" { ";} 
for (int i3 = 0 ; i3 < fDimensions[2] ; i3++) { 
if (fDimensions[3]>1){ stream<<" { ";} 
for (int i4 = 0 ; i4 < fDimensions[3] ; i4++) { 
if (fDimensions[4]>1){ stream<<" { ";} 
for (int i5 = 0 ; i5 < fDimensions[4] ; i5++) { 
if (fDimensions[5]>1){ stream<<" { ";} 
for (int i6 = 0 ; i6 < fDimensions[5] ; i6++) { 
int address = fIncrement[0]*i1+ fIncrement[1]*i2+ fIncrement[2]*i3+ fIncrement[3]*i4+ fIncrement[4]*i5+ fIncrement[5]*i6 ; 
stream<<fArray[address]<<(fDimensions[5]-i6 > 1 ? ", ":""); 
} 
if (fDimensions[5] >1){ stream<<" }";} 
if (fDimensions[4]-i5 > 1){ stream<<", ";} 
} 
if (fDimensions[4] >1){ stream<<" }";} 
if (fDimensions[3]-i4 > 1){ stream<<", ";} 
} 
if (fDimensions[3] >1){ stream<<" }";} 
if (fDimensions[2]-i3 > 1){ stream<<", ";} 
} 
if (fDimensions[2] >1){ stream<<" }";} 
if (fDimensions[1]-i2 > 1){ stream<<", ";} 
} 
stream<<" }"; 
if (fDimensions[0]-i1 > 1){ stream<<",\n";} 
} 
stream<<std::endl; 
return; 
} 
template<typename numtype> void VALORArrayT<numtype>:: PrintDimensions(std::ostream & stream) { 
stream<<fName<<" {\n"; 
for (int i = 0 ; i < fNDim ; i++) { 
stream<<" "<<fDimensions[i]<<"\t"<<fNames[i]<<"\n"; 
} 
stream<<"} with total size "<<fSize<<std::endl; 
} 
namespace valor { 
template <typename numtype> VALORArrayHeader::kVArrayType VALORArrayT<numtype>:: GetHeaderType(void) { 
return VALORArrayHeader::kVATUndefined; 
} 
template <> VALORArrayHeader::kVArrayType VALORArrayT<double>:: GetHeaderType(void) { 
return VALORArrayHeader::kVATDouble; 
} 
template <> VALORArrayHeader::kVArrayType VALORArrayT<float>:: GetHeaderType(void) { 
return VALORArrayHeader::kVATFloat; 
} 
template <> VALORArrayHeader::kVArrayType VALORArrayT<int>:: GetHeaderType(void) { 
return VALORArrayHeader::kVATInt; 
} 
template <> VALORArrayHeader::kVArrayType VALORArrayT<Long64_t>:: GetHeaderType(void) { 
return VALORArrayHeader::kVATInt64; 
} 
template <> VALORArrayHeader::kVArrayType VALORArrayT<ULong64_t>:: GetHeaderType(void) { 
return VALORArrayHeader::kVATUInt64; 
} 
} 
template class valor::VALORArrayT<double>; 
template class valor::VALORArrayT<float>; 
template class valor::VALORArrayT<int>; 
template class valor::VALORArrayT<Long64_t>; 
template class valor::VALORArrayT<ULong64_t>; 
namespace valor { 
PhysParams* PhysParams::_instance = nullptr; 
PhysParams::PhysParams(): _defaults{new Param("default", Undefined)}, 
_nextId{0} 
{ 
} 
PhysParams::~PhysParams() { 
for(auto param : _parameters) { 
delete param.second; 
} 
_parameters.clear(); 
delete _defaults; _defaults = nullptr; 
delete _instance; _instance = nullptr; 
} 
PhysParams* PhysParams::Instance() { 
if(not(_instance)) { 
_instance = new PhysParams(); 
} 
return _instance; 
} 
void PhysParams::Read(const string& filename) { 
string fullFilename = util::file::GetConfigurationFilename(filename); 
if(fullFilename.empty()) { 
assert(1); 
util::Die(1); 
} 
TXMLEngine* xml = new TXMLEngine(); 
XMLDocPointer_t xmlDoc = xml->ParseFile(fullFilename.c_str()); 
if(xmlDoc == 0) { 
assert(1); 
delete xml; 
util::Die(1); 
} 
XMLNodePointer_t rootNode = xml->DocGetRootElement(xmlDoc); 
XMLNodePointer_t defaultsNode = util::FindNode(xml, rootNode, "defaults"); 
ProcessDefaults(xml, defaultsNode); 
vector<XMLNodePointer_t> params = util::FindNodes(xml, rootNode, "parameter"); 
for(auto node : params) { 
ProcessParameter(xml, node); 
} 
delete xml; 
} 
void PhysParams::Select(const string& filename) { 
string fullFilename = util::file::GetConfigurationFilename(filename); 
if(fullFilename.empty()) { 
assert(1); 
util::Die(1); 
} 
TXMLEngine* xml = new TXMLEngine(); 
XMLDocPointer_t xmlDoc = xml->ParseFile(fullFilename.c_str()); 
if(xmlDoc == 0) { 
assert(1); 
delete xml; 
util::Die(1); 
} 
XMLNodePointer_t rootNode = xml->DocGetRootElement(xmlDoc); 
ProcessParameters(util::XML2String(xml, rootNode, "osc_params/param_list")); 
vector<XMLNodePointer_t> sysParams = util::FindNodes(xml, rootNode, "rule"); 
for(auto node : sysParams) { 
ProcessParameters(util::XML2String(xml, node, "param_list")); 
} 
delete xml; 
} 
double PhysParams::Bestfit(const std::string& param) const { 
StrictCheck(param, "best fit"); 
return _parameters.at(param)->_bestfit; 
} 
double PhysParams::Initial(const std::string& param) const { 
StrictCheck(param, "initial value"); 
return _parameters.at(param)->_initial; 
} 
double PhysParams::Minimum(const std::string& param) const { 
StrictCheck(param, "minimum value"); 
return _parameters.at(param)->_minimum; 
} 
double PhysParams::Maximum(const std::string& param) const { 
StrictCheck(param, "maximum value"); 
return _parameters.at(param)->_maximum; 
} 
double PhysParams::StepSize(const std::string& param) const { 
StrictCheck(param, "step size"); 
return _parameters.at(param)->_stepsize; 
} 
double PhysParams::Scaling(const std::string& param) const { 
StrictCheck(param, "scaling"); 
return _parameters.at(param)->_scaling; 
} 
bool PhysParams::IsMarginalised(const std::string& param) const { 
StrictCheck(param, "marginalisation status"); 
return _parameters.at(param)->_isMarginalised; 
} 
double PhysParams::GaussianPriorMean(const std::string& param) const { 
StrictCheck(param, "Gaussian prior mean value"); 
return _parameters.at(param)->_gausMean; 
} 
double PhysParams::GaussianPriorSigma(const std::string& param) const { 
StrictCheck(param, "Gaussian prior sigma value"); 
return _parameters.at(param)->_gausSigma; 
} 
double PhysParams::FlatPriorMinimum(const std::string& param) const { 
StrictCheck(param, "Flat prior minimum value"); 
return _parameters.at(param)->_flatMinimum; 
} 
double PhysParams::FlatPriorMaximum(const std::string& param) const { 
StrictCheck(param, "Flat prior maximum value"); 
return _parameters.at(param)->_flatMaximum; 
} 
const std::string& PhysParams::UserPriorFilename(const std::string& param) const { 
StrictCheck(param, "User prior histogram"); 
return _parameters.at(param)->_userFilename; 
} 
bool PhysParams::IsFixed(const std::string& param) const { 
StrictCheck(param, "Fixed"); 
return _parameters.at(param)->_isFixed; 
} 
bool PhysParams::IsNuisance(const std::string& param) const { 
StrictCheck(param, "Nuisance"); 
return _parameters.at(param)->_isNuisance; 
} 
bool PhysParams::IsMigradErrorSet(const std::string& param) const { 
StrictCheck(param, "Migrad error set"); 
return _parameters.at(param)->_hasMigradError; 
} 
double PhysParams::MigradError(const std::string& param) const { 
StrictCheck(param, "Migrad error"); 
return _parameters.at(param)->_migradError; 
} 
bool PhysParams::IsHesseErrorSet(const std::string& param) const { 
StrictCheck(param, "Hesse error set"); 
return _parameters.at(param)->_hasHesseError; 
} 
double PhysParams::HesseError(const std::string& param) const { 
StrictCheck(param, "Hesse error"); 
return _parameters.at(param)->_hesseError; 
} 
bool PhysParams::IsMinosErrorSet(const std::string& param) const { 
StrictCheck(param, "Minos error set"); 
return _parameters.at(param)->_hasMinosError; 
} 
double PhysParams::MinosLowError(const std::string& param) const { 
StrictCheck(param, "Minos low error"); 
return _parameters.at(param)->_minosLowError; 
} 
double PhysParams::MinosHighError(const std::string& param) const { 
StrictCheck(param, "Minos high error"); 
return _parameters.at(param)->_minosHighError; 
} 
conv::PhysParamId_t PhysParams::GetParamId(const std::string& param) const { 
auto item = _parameters.find(param); 
if(item != _parameters.end()) { 
return item->second->_id; 
} 
else { 
return Undefined; 
} 
} 
conv::PhysParamId_t PhysParams::operator[](const std::string& param) const { 
return GetParamId(param); 
} 
void PhysParams::AddParameter(const string& param) { 
Param* p = new Param(param, static_cast<conv::PhysParamId_t>(_nextId)); 
auto value = _parameters.insert(std::make_pair(param, p)); 
++_nextId; 
if(not(value.second)) { 
assert(1); 
util::Die(-1); 
} 
} 
void PhysParams::ProcessParameters(const string& parameterList) { 
vector<string> tokens = util::Tokens(parameterList, ","); 
for(auto token : tokens) { 
string param = util::TrimSpaces(token); 
if(not(token.empty())) { 
AddParameter(param); 
} 
} 
} 
void PhysParams::SetParameterValue(double& value, TXMLEngine* xml, XMLNodePointer_t node, const std::string& path, const double def) { 
if(util::NodeExists(xml, node, path)) { 
value = util::XML2Dbl(xml, node, path); 
} 
else { 
value = def; 
} 
} 
void PhysParams::SetParameterValue(bool& value, TXMLEngine* xml, XMLNodePointer_t node, const std::string& path, const bool def) { 
if(util::NodeExists(xml, node, path)) { 
value = util::XML2Bool(xml, node, path); 
} 
else { 
value = def; 
} 
} 
void PhysParams::SetParameterValue(std::string& value, TXMLEngine* xml, XMLNodePointer_t node, const std::string& path, const std::string& def) { 
if(util::NodeExists(xml, node, path)) { 
value = util::XML2String(xml, node, path); 
} 
else { 
value = std::string(def); 
} 
} 
void PhysParams::ProcessParameter(TXMLEngine* xml, XMLNodePointer_t node) { 
string name = xml->GetAttr(node, "name"); 
AddParameter(name); 
SetParameterValue(_parameters[name]->_bestfit, xml, node, "values/bestfit", _defaults->_bestfit); 
SetParameterValue(_parameters[name]->_initial, xml, node, "values/init", _defaults->_initial); 
SetParameterValue(_parameters[name]->_minimum, xml, node, "values/minimum", _defaults->_minimum); 
SetParameterValue(_parameters[name]->_maximum, xml, node, "values/maximum", _defaults->_maximum); 
SetParameterValue(_parameters[name]->_stepsize, xml, node, "values/step_size", _defaults->_stepsize); 
SetParameterValue(_parameters[name]->_scaling, xml, node, "values/scaling", _defaults->_scaling); 
SetParameterValue(_parameters[name]->_isMarginalised, xml, node, "marginalisation/set", _defaults->_isMarginalised); 
SetParameterValue(_parameters[name]->_gausMean, xml, node, "marginalisation/priors/gaus/mean", _defaults->_gausMean); 
SetParameterValue(_parameters[name]->_gausSigma, xml, node, "marginalisation/priors/gaus/sigma", _defaults->_gausSigma); 
SetParameterValue(_parameters[name]->_flatMinimum, xml, node, "marginalisation/priors/flat/minimum", _defaults->_flatMinimum); 
SetParameterValue(_parameters[name]->_flatMaximum, xml, node, "marginalisation/priors/flat/maximum", _defaults->_flatMaximum); 
SetParameterValue(_parameters[name]->_userFilename, xml, node, "marginalisation/priors/user/histogram", _defaults->_userFilename); 
SetParameterValue(_parameters[name]->_isFixed, xml, node, "properties/fixed", _defaults->_isFixed); 
SetParameterValue(_parameters[name]->_isNuisance, xml, node, "properties/nuisance", _defaults->_isNuisance); 
SetParameterValue(_parameters[name]->_hasMigradError, xml, node, "errors/migrad/set", _defaults->_hasMigradError); 
SetParameterValue(_parameters[name]->_migradError, xml, node, "errors/migrad/error", _defaults->_migradError); 
SetParameterValue(_parameters[name]->_hasHesseError, xml, node, "errors/hesse/set", _defaults->_hasHesseError); 
SetParameterValue(_parameters[name]->_hesseError, xml, node, "errors/hesse/error", _defaults->_hesseError); 
SetParameterValue(_parameters[name]->_hasMinosError, xml, node, "errors/minos/set", _defaults->_hasMinosError); 
SetParameterValue(_parameters[name]->_minosLowError, xml, node, "errors/minos/low_error", _defaults->_minosLowError); 
SetParameterValue(_parameters[name]->_minosHighError, xml, node, "errors/minos/high_error", _defaults->_minosHighError); 
} 
void PhysParams::ProcessDefaults(TXMLEngine* xml, XMLNodePointer_t node) { 
_defaults->_bestfit = util::XML2Dbl(xml, node, "values/bestfit"); 
_defaults->_initial = util::XML2Dbl(xml, node, "values/init"); 
_defaults->_minimum = util::XML2Dbl(xml, node, "values/minimum"); 
_defaults->_maximum = util::XML2Dbl(xml, node, "values/maximum"); 
_defaults->_stepsize = util::XML2Dbl(xml, node, "values/step_size"); 
_defaults->_scaling = util::XML2Dbl(xml, node, "values/scaling"); 
_defaults->_isMarginalised = util::XML2Bool(xml, node, "marginalisation/set"); 
_defaults->_gausMean = util::XML2Dbl(xml, node, "marginalisation/priors/gaus/mean"); 
_defaults->_gausSigma = util::XML2Dbl(xml, node, "marginalisation/priors/gaus/sigma"); 
_defaults->_flatMinimum = util::XML2Dbl(xml, node, "marginalisation/priors/flat/minimum"); 
_defaults->_flatMaximum = util::XML2Dbl(xml, node, "marginalisation/priors/flat/maximum"); 
_defaults->_userFilename = util::XML2String(xml, node, "marginalisation/priors/user/histogram"); 
_defaults->_isFixed = util::XML2Bool(xml, node, "properties/fixed"); 
_defaults->_isNuisance = util::XML2Bool(xml, node, "properties/nuisance"); 
_defaults->_hasMigradError = util::XML2Bool(xml, node, "errors/migrad/set"); 
_defaults->_migradError = util::XML2Dbl(xml, node, "errors/migrad/error"); 
_defaults->_hasHesseError = util::XML2Bool(xml, node, "errors/hesse/set"); 
_defaults->_hesseError = util::XML2Dbl(xml, node, "errors/hesse/error"); 
_defaults->_hasMinosError = util::XML2Bool(xml, node, "errors/minos/set"); 
_defaults->_minosLowError = util::XML2Dbl(xml, node, "errors/minos/low_error"); 
_defaults->_minosHighError = util::XML2Dbl(xml, node, "errors/minos/high_error"); 
} 
void PhysParams::StrictCheck(const std::string& param, const std::string& value) const { 
if(_parameters.find(param) == _parameters.end()) { 
assert(1); 
util::Die(-1); 
} 
} 
} 
ClassImp(PhysParamList) namespace valor { 
ostream & operator << (ostream & stream, const PhysParamList & pl) { 
pl.Print(stream); 
return stream; 
} 
} 
PhysParamList::PhysParamList() : TNamed() { 
this->fParams.clear(); 
} 
PhysParamList::PhysParamList(const PhysParamList & pl) : TNamed() { 
this->fParams.clear(); 
map<int,double>::const_iterator it = pl.fParams.begin(); 
for( ; it != pl.fParams.end(); ++it) { 
PhysParamId_t p = (PhysParamId_t) it->first; 
double v = it->second; 
this->SetValue(p,v); 
} 
} 
PhysParamList::~PhysParamList() { 
fParams.clear(); 
} 
int PhysParamList::NParams(void) const { 
return (int) fParams.size(); 
} 
double PhysParamList::Value(PhysParamId_t p) const { 
map<int,double>::const_iterator it = fParams.find(p); 
if(it == fParams.end()) { 
assert(1); 
return -99999; 
} 
return it->second; 
} 
void PhysParamList::SetValue(PhysParamId_t p, double v) { 
fParams[p] = v; 
} 
void PhysParamList::Clear(Option_t *) { 
this->fParams.clear(); 
} 
void PhysParamList::Append(const PhysParamList & pl) { 
const map<int,double> & m = pl.Map(); 
map<int,double>::const_iterator iter = m.begin(); 
for( ; iter != m.end(); ++iter) { 
PhysParamId_t p = (PhysParamId_t) iter->first; 
double v = iter->second; 
this->SetValue(p,v); 
} 
} 
void PhysParamList::Print(ostream & stream) const { 
int i=0; 
stream << endl; 
map<int,double>::const_iterator it = fParams.begin(); 
for( ; it != fParams.end(); ++it) { 
PhysParamId_t p = (PhysParamId_t) it->first; 
double v = it->second; 
stream << setw(5) << i++ << setw(30) << util::NameRegistry::Instance()->AsString(p) << " = " << setprecision(8) << setw(12) << v << endl; 
} 
} 
double PhysParamList::operator () (conv::PhysParamId_t p) const { 
return this->Value(p); 
} 
bool PhysParamList::Contains(conv::PhysParamId_t p) const { 
map<int,double>::const_iterator it = fParams.find(p); 
return (it != fParams.end()); 
} 
void PhysParamList::Remove(conv::PhysParamId_t p) { 
map<int,double>::iterator it = fParams.find(p); 
if (it != fParams.end()) { 
fParams.erase(it); 
} 
} 
void PhysParamList::CopyFrom(const PhysParamList & ppl) { 
this->Clear(); 
ppl.Copy(*this); 
fParams = ppl.Map(); 
} 
void PhysParamList::MergeFrom(const PhysParamList & ppl, Option_t * opt) { 
bool no_warning = TString(opt).Contains("silent"); 
map<int,double>::const_iterator it = ppl.fParams.begin(); 
for( ; it != ppl.fParams.end(); ++it) { 
PhysParamId_t p = (PhysParamId_t) it->first; 
double v = it->second; 
if (!no_warning) { 
if (this->Contains(p)) { 
assert(1); 
} 
} 
this->SetValue(p,v); 
} 
} 
TVectorD PhysParamList::AsTVector(const CorrelatedSystematics * ordering) { 
if (!ordering) { 
assert(1); 
util::Die(-1); 
} 
int npar = ordering->Size(); 
TVectorD vec(npar); 
for (int i = 0 ; i < npar ; i++) { 
PhysParamId_t p = ordering->WhichParam(i); 
vec[i] = this->Value(p); 
} 
return vec; 
} 
#define USE_NEAREST_23_OCTANT_PENALTY 
ClassImp(FitParamList) namespace valor { 
ostream & operator << (ostream & stream, const FitParamList & plst) { 
plst.Print(stream); 
return stream; 
} 
} 
FitParamList::FitParamList() : TNamed() { 
this->Init(0); 
} 
FitParamList::FitParamList(int nparams) : TNamed() { 
this->Init(nparams); 
} 
FitParamList::FitParamList(const FitParamList & plst) : TNamed() { 
this->Init(plst.fNParams); 
this->Copy(plst); 
} 
FitParamList::~FitParamList() { 
this->CleanUp(); 
} 
bool FitParamList::AddParam (int ip, PhysParamId_t p, double init, double min, double max, double step, bool fix, bool nuis, string name) { 
if (ip < 0) { 
ip = this->FirstEmptyEntry(); 
} 
if (ip < 0 || ip >= fNParams) { 
this->Print(); 
assert(1); 
util::Die(-1);return 0; 
} 
if (this->Exists(p)) { 
this->Print(); 
assert(1); 
util::Die(-1);return 0; 
} 
fIdMap.insert(map<PhysParamId_t, int>::value_type(p,ip)); 
if(name.size()==0) { 
name = util::NameRegistry::Instance()->AsString(p); 
} 
fName [ip].SetString(name.c_str()); 
fBestFitValue [ip] = -99999999; 
fCurrValue [ip] = init; 
fInitValue [ip] = init; 
fMinValue [ip] = min; 
fMaxValue [ip] = max; 
fStepSize [ip] = step; 
fIsFixed [ip] = fix; 
fIsNuisance [ip] = nuis; 
return true; 
} 
bool FitParamList::Exists(PhysParamId_t p) const { 
map<PhysParamId_t, int>::const_iterator iter = fIdMap.find(p); 
if(iter != fIdMap.end()) return true; 
return false; 
} 
void FitParamList::Update(PhysParamId_t p, double v, bool scaled) { 
int ip = this->Id(p); 
if (scaled) { 
fCurrValue [ip] = v/fParameterScaling[ip]; 
} 
else { 
fCurrValue [ip] = v; 
} 
} 
void FitParamList::SetInitValue(PhysParamId_t p, double v) { 
fInitValue [this->Id(p)] = v; 
fCurrValue [this->Id(p)] = v; 
} 
void FitParamList::SetCurrentValue(PhysParamId_t p, double v) { 
fCurrValue [this->Id(p)] = v; 
} 
void FitParamList::SetInitValueByIndex(int i, double v) { 
fInitValue [i] = v; 
fCurrValue [i] = v; 
} 
void FitParamList::SetCurrentValueByIndex(int i, double v) { 
fCurrValue [i] = v; 
} 
void FitParamList::ResetCurrToInitValues(void) { 
for(int ip = 0; ip < fNParams; ip++) { 
fCurrValue[ip] = fInitValue[ip]; 
} 
} 
void FitParamList::CopyCurrToBestFitValues(void) { 
for(int ip = 0; ip < fNParams; ip++) { 
fBestFitValue[ip] = fCurrValue[ip]; 
} 
fBestFitStatistic = fCurrStatistic; 
} 
void FitParamList::CopyBestFitToCurrValues(void) { 
for(int ip = 0; ip < fNParams; ip++) { 
fCurrValue[ip] = fBestFitValue[ip]; 
} 
fCurrStatistic = fBestFitStatistic; 
} 
void FitParamList::CopyBestFitToInitValues(void) { 
for(int ip = 0; ip < fNParams; ip++) { 
fInitValue[ip] = fBestFitValue[ip]; 
} 
} 
void FitParamList::CopyCurrToInitValues(void) { 
for(int ip = 0; ip < fNParams; ip++) { 
fInitValue[ip] = fCurrValue[ip]; 
} 
} 
void FitParamList::CopyBestFitToInitValues(const FitParamList & plst) { 
if(plst.GetParListName() != fParListName) { 
assert(1); 
util::Die(-1);return; 
} 
for(int ip = 0; ip < fNParams; ip++) { 
fInitValue[ip] = plst.BestFitValueByIndex(ip); 
} 
} 
void FitParamList::SetCovMatrix(TMatrixDSym & covmatrix, unsigned int start_at) { 
TMatrixDSym & m = *fCovMatrix; 
int tot_rows = m.GetNrows()-start_at; 
if (tot_rows < 0) { 
assert(1); 
util::Die(-1) ; return; 
} 
if (tot_rows!=covmatrix.GetNrows()) { 
assert(1); 
util::Die(-1) ; return; 
} 
for(int ip = 0; ip < tot_rows; ip++) { 
for(int jp = 0; jp < tot_rows; jp++) { 
m[ip+start_at][jp+start_at] = covmatrix[ip][jp]; 
} 
} 
} 
void FitParamList::SetErrors(double * errplus, double * errminus, double * errmigrad) { 
for(int ip = 0; ip < fNParams; ip++) { 
fPlusError [ip] = errplus [ip]; 
fMinusError [ip] = errminus [ip]; 
fMigradError[ip] = errmigrad[ip]; 
if(errplus[ip] > kASmallNum || errminus[ip] > kASmallNum) fMinosErrorsSet = true; 
} 
fMigradErrorsSet = true; 
} 
void FitParamList::SetMigradErrors(vector<double> err) { 
if(err.size() != (unsigned int)this->Size()) { 
assert(1); 
util::Die(-1);return; 
} 
for(int ip = 0; ip < fNParams; ip++) { 
fMigradError [ip] = err[ip]; 
} 
fMigradErrorsSet = true; 
} 
void FitParamList::SetHesseErrors(vector<double> err) { 
if(err.size() != (unsigned int)this->Size()) { 
assert(1); 
util::Die(-1);return; 
} 
for(int ip = 0; ip < fNParams; ip++) { 
fHesseError [ip] = err[ip]; 
} 
fHesseErrorsSet = true; 
} 
void FitParamList::SetMinosErrors(vector<double> plus, vector<double> minus) { 
if((int)plus.size() != this->Size()) { 
assert(1); 
util::Die(-1);return; 
} 
if(plus.size() != minus.size()) { 
assert(1); 
util::Die(-1);return; 
} 
for(int ip = 0; ip < fNParams; ip++) { 
fPlusError [ip] = plus [ip]; 
fMinusError[ip] = minus[ip]; 
} 
fMinosErrorsSet = true; 
} 
void FitParamList::FixParameter(PhysParamId_t p) { 
fIsFixed [this->Id(p)] = true; 
} 
void FitParamList::FixParameterByIndex(int ip) { 
fIsFixed [ip] = true; 
} 
void FitParamList::FreeParameter(PhysParamId_t p) { 
fIsFixed [this->Id(p)] = false; 
} 
void FitParamList::FreeParameterByIndex(int ip) { 
fIsFixed [ip] = false; 
} 
void FitParamList::SetNuisance(PhysParamId_t p, bool tf) { 
fIsNuisance [this->Id(p)] = tf; 
} 
FitParamList * FitParamList::FreeParameterSubset(void) { 
int nfree = this->GetNumberFreeParameters(); 
FitParamList * fparm = new FitParamList(nfree); 
int ipc = 0; 
for(int ip = 0; ip < fNParams; ip++) { 
if(fIsFixed[ip]) continue; 
PhysParamId_t p = this->WhichParam(ip); 
double init = fInitValue[ip]; 
double min = fMinValue[ip]; 
double max = fMaxValue[ip]; 
double step = fStepSize[ip]; 
bool nuis = fIsNuisance[ip]; 
fparm->AddParam(ipc, p, init, min, max, step, false, nuis); 
fparm->fBestFitValue[ipc] = this->fBestFitValue[ip]; 
fparm->fCurrValue [ipc] = this->fCurrValue [ip]; 
fparm->fMigradError [ipc] = this->fMigradError [ip]; 
fparm->fHesseError [ipc] = this->fHesseError [ip]; 
fparm->fPlusError [ipc] = this->fPlusError [ip]; 
fparm->fMinusError [ipc] = this->fMinusError [ip]; 
ipc++; 
} 
return fparm; 
} 
void FitParamList::SetTo(TVirtualFitter * fitter) { 
if(!fitter) return; 
fitter->Clear(); 
map<valor::conv::PhysParamId_t, int>::const_iterator iter = fIdMap.begin(); 
for ( ; iter != fIdMap.end(); ++iter) { 
PhysParamId_t p = iter->first; 
int iparam = iter->second; 
double scaling = this->ParameterScaling(p); 
fitter->SetParameter( iparam, this->Name(p).c_str(), scaling*this->InitValue(p), scaling*this->StepSize(p) , scaling*this->MinValue(p) , scaling*this->MaxValue(p) ); 
if(this->IsFixed(p)) { 
fitter->FixParameter(iparam); 
} 
} 
} 
void FitParamList::SetTo(ROOT::Minuit2::MnUserParameters & params) { 
for(int ip = 0; ip < fNParams; ip++) { 
valor::conv::PhysParamId_t p = WhichParam(ip); 
if(util::IsMixingAngle(p)) { 
params.Add(this->Name(p).c_str(), this->InitValue(p), this->StepSize(p), 0, 1); 
} 
else { 
params.Add(this->Name(p).c_str(), this->InitValue(p), this->StepSize(p), this->MinValue(p), this->MaxValue(p)); 
} 
if(this->IsFixed(p)) { 
params.Fix(ip); 
} 
} 
} 
void FitParamList::SetTo(ROOT::Math::Minimizer * fitter) { 
if(!fitter) return; 
fitter->Clear(); 
for(int ip = 0; ip < fNParams; ip++) { 
PhysParamId_t p = WhichParam(ip); 
int iparam = ip; 
if(this->IsFixed(p)) { 
fitter->SetFixedVariable( iparam, this->Name(p).c_str(), this->InitValue(p)); 
} 
else{ 
fitter->SetLimitedVariable( iparam, this->Name(p).c_str(), this->InitValue(p), this->StepSize(p), this->MinValue(p), this->MaxValue(p) ); 
} 
} 
} 
void FitParamList::SetTo(ROOT::Fit::Fitter * fitter) { 
if(!fitter) return; 
double par0[fNParams]; 
for(int ip = 0; ip < fNParams; ip++) { 
PhysParamId_t p = WhichParam(ip); 
par0[ip] = this->InitValue(p); 
} 
(fitter->Config()).SetParamsSettings(fNParams,par0); 
for(int ip = 0; ip < fNParams; ip++) { 
PhysParamId_t p = WhichParam(ip); 
int iparam = ip; 
if(this->IsFixed(p)) { 
(fitter->Config()).ParSettings(iparam).Set(this->Name(p).c_str(),this->InitValue(p)); 
} 
else{ 
(fitter->Config()).ParSettings(iparam).Set(this->Name(p).c_str(),this->InitValue(p),this->StepSize(p),this->MinValue(p),this->MaxValue(p) ); 
} 
} 
} 
void FitParamList::Sync(std::vector<double> par, bool scaling) { 
if(par.size() <= 0) return; 
for(int ip = 0; ip < fNParams; ip++) { 
fCurrValue[ip] = par[ip]/ (scaling ? fParameterScaling[ip] : 1); 
} 
} 
void FitParamList::Sync(const double * par, bool scaling) { 
if(!par) return; 
for(int ip = 0; ip < fNParams; ip++) { 
fCurrValue[ip] = par[ip]/ (scaling ? fParameterScaling[ip] : 1); 
} 
} 
PhysParamList FitParamList::AsPhysParamList(Option_t * option) const { 
PhysParamList pl; 
TString opt(option); 
map<PhysParamId_t, int>::const_iterator iter = fIdMap.begin(); 
for( ; iter != fIdMap.end(); ++iter) { 
PhysParamId_t p = iter->first; 
int ip = iter->second; 
double v = 0; 
if ( opt.Contains("initial") ) v = fInitValue[ip]; 
else if ( opt.Contains("current") ) v = fCurrValue[ip]; 
else if ( opt.Contains("best-fit") ) v = fBestFitValue[ip]; 
pl.SetValue(p,v); 
} 
return pl; 
} 
TVectorD FitParamList::AsTVector(Option_t * option) const { 
TString opt(option); 
double * values; 
if ( opt.Contains("initial") ) { values = fInitValue ; } 
else if ( opt.Contains("current") ) { values = fCurrValue ; } 
else if ( opt.Contains("best-fit") ) { values = fBestFitValue ; } 
else { 
assert(1); 
return TVectorD(); 
} 
return TVectorD(fNParams,values); 
} 
void FitParamList::FromPhysParamList(valor::PhysParamList pl, Option_t * option, bool skip_osc_params) { 
TString opt(option); 
if (opt.Contains("skiposc")) {skip_osc_params = true;} 
bool silently_pass_missing_parameters = opt.Contains("silent"); 
bool type_to_update_not_found = false; 
map<PhysParamId_t, int>::const_iterator iter = fIdMap.begin(); 
for( ; iter != fIdMap.end(); ++iter) { 
PhysParamId_t p = iter->first; 
if(skip_osc_params && !util::IsSystematic(p)) {continue;} 
int ip = iter->second; 
if (pl.Contains(p)) { 
double input = pl.Value(p); 
if ( opt.Contains("initial") ) {fInitValue[ip] = input;} 
else if ( opt.Contains("current") ) {fCurrValue[ip] = input;} 
else if ( opt.Contains("best-fit") ) {fBestFitValue[ip] = input;} 
else { 
type_to_update_not_found = true; 
} 
} 
else { 
if (!silently_pass_missing_parameters) { 
assert(1); 
} 
} 
} 
if (type_to_update_not_found) { 
assert(1); 
util::Die(-1); 
} 
return; 
} 
int FitParamList::GetNumberFreeParameters(void) const { 
int nparams = 0; 
for(int ip=0; ip<fNParams; ip++) { 
bool is_fixed = fIsFixed[ip]; 
if(!is_fixed) { 
nparams++; 
} 
} 
return nparams; 
} 
int FitParamList::GetNumberParameters(void) const { 
int nparams = 0; 
for(int ip=0; ip<fNParams; ip++) { 
nparams++; 
} 
return nparams; 
} 
void FitParamList::ClearStatusCodes(void) { 
fStatusCodes.clear(); 
} 
void FitParamList::SetStatusCode(string st, int code) { 
fStatusCodes[st] = code; 
} 
void FitParamList::SetStatusCode(const char * st, int code) { 
this->SetStatusCode(std::string(st),code); 
} 
int FitParamList::GetStatusCode(string st) const { 
map<string,int>::const_iterator sciter = fStatusCodes.find(st); 
if(sciter != fStatusCodes.end()) { 
return sciter->second; 
} 
return -9876; 
} 
int FitParamList::GetStatusCode(const char * st) const { 
return this->GetStatusCode(std::string(st)); 
} 
void FitParamList::Print(ostream & stream) const { 
if(fShowBestFitValuesOnly) { 
fShowBestFitValuesOnly = false; 
stream << endl << setw(6) << "id" << setw(80) << "name" << setw(15) << "best-fit" << endl; 
for(int ip=0; ip<fNParams; ip++) { 
stream << setw(6) << ip << setw(80) << fName[ip].GetString().Data() << setprecision(6) << setw(15) << fBestFitValue[ip] << endl; 
} 
} 
else if(fShowCurrValuesOnly) { 
fShowCurrValuesOnly = false; 
stream << endl << setw(6) << "id" << setw(80) << "name" << setw(15) << "curr" << endl; 
for(int ip=0; ip<fNParams; ip++) { 
stream << setw(6) << ip << setw(80) << fName[ip].GetString().Data() << setprecision(6) << setw(15) << fCurrValue[ip] << endl; 
} 
} 
else { 
stream << endl << setw(6) << "id" << setw(35) << "name" << setw(15) << "curr" << setw(15) << "init" << setw(15) << "min" << setw(15) << "max" << setw(15) << "step" << setw(8) << "fixed?" << setw(10) << "nuisance?" << endl; 
for(int ip=0; ip<fNParams; ip++) { 
stream << setw(6) << ip << setw(35) << fName[ip].GetString().Data() << setprecision(6) << setw(15) << fCurrValue[ip] << setw(15) << fInitValue[ip] << setw(15) << fMinValue[ip] << setw(15) << fMaxValue[ip] << setw(15) << fStepSize[ip] << setw(8) << ((fIsFixed[ip]) ? "yes" : "no") << setw(8) << ((fIsNuisance[ip]) ? "yes" : "no") << endl; 
} 
} 
stream << "Status codes: " << endl; 
map<string,int>::const_iterator sciter = fStatusCodes.begin(); 
for( ; sciter != fStatusCodes.end(); ++sciter) { 
string name = sciter->first; 
int code = sciter->second; 
stream << setw(20) << name << setw(10) << code << endl; 
} 
stream << "Fit time: " << fFitTime << " sec" << ", tries: " << fFitTries << endl; 
stream << "Best-fit statistic: " << fBestFitStatistic << endl; 
} 
void FitParamList::Print(Option_t *) const { 
this->Print(cout); 
} 
FitParamList * FitParamList::NamedParameterList(string name) { 
if(name == "nuosc3f") { 
FitParamList * fp = FitParamList::NuOsc3FlavourFit(); 
fp -> SetParListName(name); 
fp -> SetSystMode(0); 
return fp; 
} 
if(name == "nuosc3f_12constrain") { 
FitParamList * fp = FitParamList::NuOsc3FlavourFit(); 
fp -> SetNuisance (kPhypMixing12, true); 
fp -> SetNuisance (kPhypDm12sq, true); 
fp -> SetParListName(name); 
fp -> SetSystMode(0); 
return fp; 
} 
if(name == "nuosc3f_12fix") { 
FitParamList * fp = FitParamList::NuOsc3FlavourFit(); 
fp -> FixParameter (kPhypMixing12); 
fp -> FixParameter (kPhypDm12sq ); 
fp -> SetParListName(name); 
fp -> SetSystMode(0); 
return fp; 
} 
if(name == "nuosc3f_dcpsensitivity_fix5") { 
FitParamList * fp = FitParamList::NuOsc3FlavourFit(); 
fp -> FixParameter (kPhypMixing13); 
fp -> FixParameter (kPhypMixing12); 
fp -> FixParameter (kPhypMixing23); 
fp -> FixParameter (kPhypDm12sq); 
fp -> FixParameter (kPhypDm23sq); 
fp -> SetParListName(name); 
fp -> SetSystMode(0); 
return fp; 
} 
if(name == "nuosc3f_dcpsensitivity_fix3") { 
FitParamList * fp = FitParamList::NuOsc3FlavourFit(); 
fp -> SetNuisance (kPhypMixing23, true); 
fp -> SetNuisance (kPhypDm23sq, true); 
fp -> FixParameter (kPhypMixing13); 
fp -> FixParameter (kPhypMixing12); 
fp -> FixParameter (kPhypDm12sq); 
fp -> SetParListName(name); 
fp -> SetSystMode(4); 
return fp; 
} 
if(name == "nuosc3f_dcpsensitivity") { 
FitParamList * fp = FitParamList::NuOsc3FlavourFit(); 
fp -> SetNuisance (kPhypMixing23, true); 
fp -> SetNuisance (kPhypDm23sq, true); 
fp -> SetNuisance (kPhypMixing13, true); 
fp -> SetNuisance (kPhypMixing12, true); 
fp -> SetNuisance (kPhypDm12sq, true); 
fp -> SetParListName(name); 
fp -> SetSystMode(3); 
return fp; 
} 
return 0; 
} 
FitParamList * FitParamList::NuOsc3FlavourFit(int nuisance) { 
FitParamList * fparm = new FitParamList(6+nuisance); 
FitParamList::Append3FlavourOscillation(fparm, 0); 
return fparm; 
} 
FitParamList * FitParamList::NuOsc3FlavourBarFit(int nuisance) { 
FitParamList * fparm = new FitParamList(12+nuisance); 
FitParamList::Append3FlavourOscillation(fparm, 0); 
FitParamList::Append3FlavourOscillationBar(fparm, 6); 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta): fparm->SetInitValue(kPhypMixing12 , conv::kGlobFitSinsq2Theta12); 
fparm->SetInitValue(kPhypMixing13 , conv::kGlobFitSinsq2Theta13); 
fparm->SetInitValue(kPhypMixing23 , conv::kGlobFitSinsq2Theta23); 
break; 
case(kNuMixSinsqTheta): fparm->SetInitValue(kPhypMixing12 , conv::kGlobFitSinsqTheta12); 
fparm->SetInitValue(kPhypMixing13 , conv::kGlobFitSinsqTheta13); 
fparm->SetInitValue(kPhypMixing23 , conv::kGlobFitSinsqTheta23); 
break; 
default: std::cerr<<"Unknown oscillation mixing parameter choice: "<<omp<<std::endl; 
util::Die(-1);return 0; 
} 
fparm->SetInitValue(kPhypCPV , conv::kGlobFitDeltaCP); 
NuOscDmsqScheme_t odmsq = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch (odmsq) { 
case(kNuDmsqFogliLisi): fparm->SetInitValue(kPhypDm23sq, conv::kGlobFitDmsqFL); 
fparm->SetInitValue(kPhypDm12sq, conv::kGlobFitDm12sq); 
break; 
case(kNuDmsq12andAbs23): fparm->SetInitValue(kPhypDm23sq, conv::kGlobFitDm23sq); 
fparm->SetInitValue(kPhypDm12sq, conv::kGlobFitDm12sq); 
break; 
case(kNuDmsq12andAbs31): fparm->SetInitValue(kPhypDm12sq, conv::kGlobFitDm12sq); 
if(Opt::Instance()->gMassHierarchyAssumed == kNmhNormal) fparm->SetInitValue(kPhypDm23sq, conv::kGlobFitDm23sq + conv::kGlobFitDm12sq); 
else if(Opt::Instance()->gMassHierarchyAssumed == kNmhInverted) fparm->SetInitValue(kPhypDm23sq, conv::kGlobFitDm23sq + conv::kGlobFitDm12sq); 
else{ 
 std::cerr << "Mass hierarchy not defined" << std::endl; 
 util::Die(-1); 
} 
break; 
default: std::cerr<<"Unknown mass scheme: "<<odmsq<<std::endl; 
util::Die(-1); 
} 
return fparm; 
} 
FitParamList * FitParamList::NuOsc3FlavourBarDissapFit(int nuisance) { 
FitParamList * fparm = new FitParamList(8+nuisance); 
FitParamList::Append3FlavourOscillation(fparm, 0); 
FitParamList::Append3Flavour23BarOscillation(fparm, 6); 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta): fparm->SetInitValue(kPhypMixing12 , conv::kGlobFitSinsq2Theta12); 
fparm->SetInitValue(kPhypMixing13 , conv::kGlobFitSinsq2Theta13); 
fparm->SetInitValue(kPhypMixing23 , conv::kGlobFitSinsq2Theta23); 
fparm->SetInitValue(kPhypMixing23Bar, conv::kGlobFitSinsq2Theta23); 
break; 
case(kNuMixSinsqTheta): fparm->SetInitValue(kPhypMixing12 , conv::kGlobFitSinsqTheta12); 
fparm->SetInitValue(kPhypMixing13 , conv::kGlobFitSinsqTheta13); 
fparm->SetInitValue(kPhypMixing23 , conv::kGlobFitSinsqTheta23); 
fparm->SetInitValue(kPhypMixing23Bar, conv::kGlobFitSinsqTheta23); 
break; 
default: std::cerr<<"Unknown oscillation mixing parameter choice: "<<omp<<std::endl; 
util::Die(-1);return 0; 
} 
fparm->SetInitValue(kPhypCPV , conv::kGlobFitDeltaCP); 
NuOscDmsqScheme_t odmsq = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch (odmsq) { 
case(kNuDmsqFogliLisi): fparm->SetInitValue(kPhypDm23sq, conv::kGlobFitDmsqFL); 
fparm->SetInitValue(kPhypDm23sqBar, conv::kGlobFitDmsqFL); 
fparm->SetInitValue(kPhypDm12sq, conv::kGlobFitDm12sq); 
break; 
case(kNuDmsq12andAbs23): fparm->SetInitValue(kPhypDm23sq, conv::kGlobFitDm23sq); 
fparm->SetInitValue(kPhypDm23sqBar, conv::kGlobFitDm23sq); 
fparm->SetInitValue(kPhypDm12sq, conv::kGlobFitDm12sq); 
break; 
case(kNuDmsq12andAbs31): fparm->SetInitValue(kPhypDm12sq, conv::kGlobFitDm12sq); 
if(Opt::Instance()->gMassHierarchyAssumed == kNmhNormal){ 
fparm->SetInitValue(kPhypDm23sq, conv::kGlobFitDm23sq + conv::kGlobFitDm12sq); 
fparm->SetInitValue(kPhypDm23sqBar, conv::kGlobFitDm23sq + conv::kGlobFitDm12sq); 
} 
else if(Opt::Instance()->gMassHierarchyAssumed == kNmhInverted){ 
fparm->SetInitValue(kPhypDm23sq, conv::kGlobFitDm23sq + conv::kGlobFitDm12sq); 
fparm->SetInitValue(kPhypDm23sqBar, conv::kGlobFitDm23sq + conv::kGlobFitDm12sq); 
} 
else{ 
 std::cerr << "Mass hierarchy not defined" << std::endl; 
 util::Die(-1); 
} 
break; 
default: std::cerr<<"Unknown mass scheme: "<<odmsq<<std::endl; 
util::Die(-1); 
} 
return fparm; 
} 
FitParamList * FitParamList::NuOsc3FlavourBarNormBarFit(int nuisance) { 
FitParamList * fparm = new FitParamList(13+nuisance); 
FitParamList::Append3FlavourOscillation(fparm, 0); 
FitParamList::Append3FlavourOscillationBar(fparm, 6); 
FitParamList::AppendNormBar(fparm, 12); 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta): fparm->SetInitValue(kPhypMixing12 , conv::kGlobFitSinsq2Theta12); 
fparm->SetInitValue(kPhypMixing13 , conv::kGlobFitSinsq2Theta13); 
fparm->SetInitValue(kPhypMixing23 , conv::kGlobFitSinsq2Theta23); 
break; 
case(kNuMixSinsqTheta): fparm->SetInitValue(kPhypMixing12 , conv::kGlobFitSinsqTheta12); 
fparm->SetInitValue(kPhypMixing13 , conv::kGlobFitSinsqTheta13); 
fparm->SetInitValue(kPhypMixing23 , conv::kGlobFitSinsqTheta23); 
break; 
default: std::cerr<<"Unknown oscillation mixing parameter choice: "<<omp<<std::endl; 
util::Die(-1);return 0; 
} 
fparm->SetInitValue(kPhypCPV , conv::kGlobFitDeltaCP); 
NuOscDmsqScheme_t odmsq = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch (odmsq) { 
case(kNuDmsqFogliLisi): fparm->SetInitValue(kPhypDm23sq, conv::kGlobFitDmsqFL); 
fparm->SetInitValue(kPhypDm12sq, conv::kGlobFitDm12sq); 
break; 
case(kNuDmsq12andAbs23): fparm->SetInitValue(kPhypDm23sq, conv::kGlobFitDm23sq); 
fparm->SetInitValue(kPhypDm12sq, conv::kGlobFitDm12sq); 
break; 
case(kNuDmsq12andAbs31): fparm->SetInitValue(kPhypDm12sq, conv::kGlobFitDm12sq); 
if(Opt::Instance()->gMassHierarchyAssumed == kNmhNormal) fparm->SetInitValue(kPhypDm23sq, conv::kGlobFitDm23sq + conv::kGlobFitDm12sq); 
else if(Opt::Instance()->gMassHierarchyAssumed == kNmhInverted) fparm->SetInitValue(kPhypDm23sq, conv::kGlobFitDm23sq + conv::kGlobFitDm12sq); 
else{ 
 std::cerr << "Mass hierarchy not defined" << std::endl; 
 util::Die(-1); 
} 
break; 
default: std::cerr<<"Usnknown mass scheme: "<<odmsq<<std::endl; 
util::Die(-1); 
} 
fparm->SetInitValue(kPhypBetaBar, conv::kGlobFitBetaBar); 
return fparm; 
} 
FitParamList * FitParamList::NuOsc3FlavourNormBarFit(int nuisance) { 
FitParamList * fparm = new FitParamList(7+nuisance); 
FitParamList::Append3FlavourOscillation(fparm, 0); 
FitParamList::AppendNormBar(fparm, 6); 
return fparm; 
} 
FitParamList * FitParamList::NuOscSterile4FlavourFit(int nuisance) { 
FitParamList * fparm = new FitParamList(12+nuisance); 
FitParamList::Append4FlavourSterileOscillation(fparm, 0); 
return fparm; 
} 
FitParamList * FitParamList::NuOscSterile5FlavourFit(int nuisance) { 
FitParamList * fparm = new FitParamList(18+nuisance); 
FitParamList::Append4FlavourSterileOscillation(fparm, 0); 
return fparm; 
} 
FitParamList * FitParamList::NuOscSterileEffectiveFit(int nuisance) { 
FitParamList * fparm = new FitParamList(3+nuisance); 
FitParamList::AppendEffectiveSterileOscillation(fparm, 0); 
return fparm; 
} 
FitParamList * FitParamList::NumuDisapFit(int nuisance) { 
FitParamList * fparm = new FitParamList(2+nuisance); 
FitParamList::Append2FlavourOscillation(fparm, 0); 
return fparm; 
} 
FitParamList * FitParamList::NumuDecayFit(int nuisance) { 
FitParamList * fparm = new FitParamList(2+nuisance); 
fparm->AddParam(0, kPhypSinsq2ThetaDecay, 1.0, 0.0, 1.0, 0.02, false, false); 
fparm->AddParam(1, kPhypAlphaDecay, 0.01, 1E-4, 1E-3, 1E-5, false, false); 
return fparm; 
} 
FitParamList * FitParamList::NumuDecohFit(int nuisance) { 
FitParamList * fparm = new FitParamList(2+nuisance); 
fparm->AddParam(0, kPhypSinsq2ThetaDecoh, 1.0, 0.0, 1.0, 0.02, false, false); 
fparm->AddParam(1, kPhypMusqDecoh, 0.01, 0.001, 0.04, 0.001, false, false); 
return fparm; 
} 
void FitParamList::Append3FlavourOscillation(FitParamList * fparm, int start) { 
int ip = start; 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta): fparm->AddParam( ip++, kPhypMixing23, kInitFitSinsq2Theta23, kMinFitSinsq2Theta23, kMaxFitSinsq2Theta23, kStepSinsq2Theta23, false, false); 
fparm->AddParam( ip++, kPhypMixing13, kInitFitSinsq2Theta13, kMinFitSinsq2Theta13, kMaxFitSinsq2Theta13, kStepSinsq2Theta13, false, false); 
fparm->AddParam( ip++, kPhypMixing12, kInitFitSinsq2Theta12, kMinFitSinsq2Theta12, kMaxFitSinsq2Theta12, kStepSinsq2Theta12, false, false); 
break; 
case(kNuMixSinsqTheta): fparm->AddParam( ip++, kPhypMixing23, kInitFitSinsqTheta23, kMinFitSinsqTheta23, kMaxFitSinsqTheta23, kStepSinsqTheta23, false, false); 
fparm->AddParam( ip++, kPhypMixing13, kInitFitSinsqTheta13, kMinFitSinsqTheta13, kMaxFitSinsqTheta13, kStepSinsqTheta13, false, false); 
fparm->AddParam( ip++, kPhypMixing12, kInitFitSinsqTheta12, kMinFitSinsqTheta12, kMaxFitSinsqTheta12, kStepSinsqTheta12, false, false); 
break; 
default: delete fparm; 
return; 
} 
NuOscDeltaCP_t dcp = Opt::Instance()->gOscDeltaCP; 
switch(dcp){ 
case(kNuDeltaCPPhase): fparm->AddParam( ip++, kPhypCPV, 0, -kpi, kpi, 1.0E-2, false, false); 
break; 
case(kNuDeltaCPSin): fparm->AddParam( ip++, kPhypCPV, 0, -1, 1, 1.0E-2, false, false); 
break; 
default: delete fparm; 
return; 
} 
NuOscDmsqScheme_t odmsq = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch (odmsq) { 
case(kNuDmsqFogliLisi): fparm->AddParam( ip++, kPhypDm23sq, kGlobFitDmsqFL, kMinFitDm23sq, kMaxFitDm23sq, kStepDm23sq, false, false); 
break; 
case(kNuDmsq12andAbs23): fparm->AddParam( ip++, kPhypDm23sq, kInitFitDm23sq, kMinFitDm23sq, kMaxFitDm23sq, kStepDm23sq, false, false); 
break; 
case(kNuDmsq12andAbs31): if(Opt::Instance()->gMassHierarchyAssumed == kNmhNormal) fparm->AddParam( ip++, kPhypDm23sq, kInitFitDm23sq + kInitFitDm12sq, kMinFitDm23sq, kMaxFitDm23sq, kStepDm23sq, false, false); 
else if(Opt::Instance()->gMassHierarchyAssumed == kNmhInverted) fparm->AddParam( ip++, kPhypDm23sq, kInitFitDm23sq - kInitFitDm12sq, kMinFitDm23sq, kMaxFitDm23sq, kStepDm23sq, false, false); 
else{ 
 std::cerr << "Mass hierarchy not defined" << std::endl; 
 util::Die(-1); 
 return; 
} 
break; 
default: std::cerr<<"Unknown mass scheme: "<<odmsq<<std::endl; 
util::Die(-1); 
return; 
} 
fparm->AddParam( ip++, kPhypDm12sq, kInitFitDm12sq, kMinFitDm12sq, kMaxFitDm12sq, kStepDm12sq, false, false); 
} 
void FitParamList::Append3FlavourOscillationBar(FitParamList * fparm, int start) { 
int ip = start; 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta): fparm->AddParam( ip++, kPhypMixing23Bar, kInitFitSinsq2Theta23Bar, kMinFitSinsq2Theta23Bar, kMaxFitSinsq2Theta23Bar, kStepSinsq2Theta23Bar, false, false); 
fparm->AddParam( ip++, kPhypMixing13Bar, kInitFitSinsq2Theta13Bar, kMinFitSinsq2Theta13Bar, kMaxFitSinsq2Theta13Bar, kStepSinsq2Theta13Bar, false, false); 
fparm->AddParam( ip++, kPhypMixing12Bar, kInitFitSinsq2Theta12Bar, kMinFitSinsq2Theta12Bar, kMaxFitSinsq2Theta12Bar, kStepSinsq2Theta12Bar, false, false); 
break; 
case(kNuMixSinsqTheta): fparm->AddParam( ip++, kPhypMixing23Bar, kInitFitSinsqTheta23Bar, kMinFitSinsqTheta23Bar, kMaxFitSinsqTheta23Bar, kStepSinsqTheta23Bar, false, false); 
fparm->AddParam( ip++, kPhypMixing13Bar, kInitFitSinsqTheta13Bar, kMinFitSinsqTheta13Bar, kMaxFitSinsqTheta13Bar, kStepSinsqTheta13Bar, false, false); 
fparm->AddParam( ip++, kPhypMixing12Bar, kInitFitSinsqTheta12Bar, kMinFitSinsqTheta12Bar, kMaxFitSinsqTheta12Bar, kStepSinsqTheta12Bar, false, false); 
break; 
default: delete fparm; 
return; 
} 
NuOscDeltaCP_t dcp = Opt::Instance()->gOscDeltaCP; 
switch(dcp){ 
case(kNuDeltaCPPhase): fparm->AddParam( ip++, kPhypCPVBar, 0, -kpi, kpi, 1.0E-2, false, false); 
break; 
case(kNuDeltaCPSin): fparm->AddParam( ip++, kPhypCPVBar, 0, -1, 1, 1.0E-2, false, false); 
break; 
default: delete fparm; 
return; 
} 
NuOscDmsqScheme_t odmsq = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch (odmsq) { 
case(kNuDmsqFogliLisi): fparm->AddParam( ip++, kPhypDm23sqBar, kGlobFitDmsqFL, kMinFitDm23sqBar, kMaxFitDm23sqBar, kStepDm23sqBar, false, false); 
break; 
case(kNuDmsq12andAbs23): fparm->AddParam( ip++, kPhypDm23sqBar, kInitFitDm23sqBar, kMinFitDm23sqBar, kMaxFitDm23sqBar, kStepDm23sqBar, false, false); 
break; 
case(kNuDmsq12andAbs31): if(Opt::Instance()->gMassHierarchyAssumed == kNmhNormal) fparm->AddParam( ip++, kPhypDm23sqBar, kInitFitDm23sqBar + kInitFitDm12sqBar, kMinFitDm23sqBar, kMaxFitDm23sqBar, kStepDm23sqBar, false, false); 
else if(Opt::Instance()->gMassHierarchyAssumed == kNmhInverted) fparm->AddParam( ip++, kPhypDm23sqBar, kInitFitDm23sqBar - kInitFitDm12sqBar, kMinFitDm23sqBar, kMaxFitDm23sqBar, kStepDm23sqBar, false, false); 
else{ 
 std::cerr << "Mass hierarchy not defined" << std::endl; 
 util::Die(-1); 
 return; 
} 
break; 
default: std::cerr<<"Unknown mass scheme: "<<odmsq<<std::endl; 
util::Die(-1); 
return; 
} 
fparm->AddParam( ip++, kPhypDm12sqBar, kInitFitDm12sqBar, kMinFitDm12sqBar, kMaxFitDm12sqBar, kStepDm12sqBar, false, false); 
} 
void FitParamList::Append3Flavour23BarOscillation(FitParamList * fparm, int start) { 
int ip = start; 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta): fparm->AddParam( ip++, kPhypMixing23Bar, kInitFitSinsq2Theta23Bar, kMinFitSinsq2Theta23Bar, kMaxFitSinsq2Theta23Bar, kStepSinsq2Theta23Bar, false, false); 
break; 
case(kNuMixSinsqTheta): fparm->AddParam( ip++, kPhypMixing23Bar, kInitFitSinsqTheta23Bar, kMinFitSinsqTheta23Bar, kMaxFitSinsqTheta23Bar, kStepSinsqTheta23Bar, false, false); 
break; 
default: delete fparm; 
return; 
} 
NuOscDmsqScheme_t odmsq = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch (odmsq) { 
case(kNuDmsqFogliLisi): fparm->AddParam( ip++, kPhypDm23sqBar, kGlobFitDmsqFL, kMinFitDm23sqBar, kMaxFitDm23sqBar, kStepDm23sqBar, false, false); 
break; 
case(kNuDmsq12andAbs23): fparm->AddParam( ip++, kPhypDm23sqBar, kInitFitDm23sqBar, kMinFitDm23sqBar, kMaxFitDm23sqBar, kStepDm23sqBar, false, false); 
break; 
case(kNuDmsq12andAbs31): if(Opt::Instance()->gMassHierarchyAssumed == kNmhNormal) fparm->AddParam( ip++, kPhypDm23sqBar, kInitFitDm23sqBar + kInitFitDm12sqBar, kMinFitDm23sqBar, kMaxFitDm23sqBar, kStepDm23sqBar, false, false); 
else if(Opt::Instance()->gMassHierarchyAssumed == kNmhInverted) fparm->AddParam( ip++, kPhypDm23sqBar, kInitFitDm23sqBar - kInitFitDm12sqBar, kMinFitDm23sqBar, kMaxFitDm23sqBar, kStepDm23sqBar, false, false); 
else{ 
assert(1); 
util::Die(-1); 
return; 
} 
break; 
default: std::cerr<<"Unknown mass scheme: "<<odmsq<<std::endl; 
util::Die(-1); 
return; 
} 
} 
void FitParamList::AppendNormBar(FitParamList * fparm, int start) { 
int ip = start; 
fparm->AddParam( ip++, kPhypBetaBar, kInitFitBetaBar, kMinFitBetaBar, kMaxFitBetaBar, kStepBetaBar, false, false); 
} 
void FitParamList::Append4FlavourSterileOscillation(FitParamList * fparm, int start) { 
int ip = start; 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta): fparm->AddParam( ip++, kPhypMixing12, kInitFitSinsq2Theta12, kMinFitSinsq2Theta12, kMaxFitSinsq2Theta12, kStepSinsq2Theta12, false, false); 
fparm->AddParam( ip++, kPhypMixing13, kInitFitSinsq2Theta13, kMinFitSinsq2Theta13, kMaxFitSinsq2Theta13, kStepSinsq2Theta13, false, false); 
fparm->AddParam( ip++, kPhypMixing14, kInitFitSinsq2Theta14, kMinFitSinsq2Theta14, kMaxFitSinsq2Theta14, kStepSinsq2Theta14, false, false); 
fparm->AddParam( ip++, kPhypMixing23, kInitFitSinsq2Theta23, kMinFitSinsq2Theta23, kMaxFitSinsq2Theta23, kStepSinsq2Theta23, false, false); 
fparm->AddParam( ip++, kPhypMixing24, kInitFitSinsq2Theta24, kMinFitSinsq2Theta24, kMaxFitSinsq2Theta24, kStepSinsq2Theta24, false, false); 
fparm->AddParam( ip++, kPhypMixing34, kInitFitSinsq2Theta34, kMinFitSinsq2Theta34, kMaxFitSinsq2Theta34, kStepSinsq2Theta34, false, false); 
break; 
case(kNuMixSinsqTheta): fparm->AddParam( ip++, kPhypMixing12, kInitFitSinsqTheta12, kMinFitSinsqTheta12, kMaxFitSinsqTheta12, kStepSinsqTheta12, false, false); 
fparm->AddParam( ip++, kPhypMixing13, kInitFitSinsqTheta13, kMinFitSinsqTheta13, kMaxFitSinsqTheta13, kStepSinsqTheta13, false, false); 
fparm->AddParam( ip++, kPhypMixing14, kInitFitSinsq2Theta14, kMinFitSinsq2Theta14, kMaxFitSinsq2Theta14, kStepSinsq2Theta14, false, false); 
fparm->AddParam( ip++, kPhypMixing23, kInitFitSinsqTheta23, kMinFitSinsqTheta23, kMaxFitSinsqTheta23, kStepSinsqTheta23, false, false); 
fparm->AddParam( ip++, kPhypMixing24, kInitFitSinsqTheta24, kMinFitSinsqTheta24, kMaxFitSinsqTheta24, kStepSinsqTheta24, false, false); 
fparm->AddParam( ip++, kPhypMixing34, kInitFitSinsqTheta34, kMinFitSinsqTheta34, kMaxFitSinsqTheta34, kStepSinsqTheta34, false, false); 
break; 
default: delete fparm; 
return; 
} 
NuOscDeltaCP_t dcp = Opt::Instance()->gOscDeltaCP; 
switch(dcp){ 
case(kNuDeltaCPPhase): fparm->AddParam( ip++, kPhypDelta12, 0, -kpi, kpi, 1.0E-2, false, false); 
fparm->AddParam( ip++, kPhypDelta13, 0, -kpi, kpi, 1.0E-2, false, false); 
fparm->AddParam( ip++, kPhypDelta34, 0, -kpi, kpi, 1.0E-2, false, false); 
break; 
case(kNuDeltaCPSin): fparm->AddParam( ip++, kPhypDelta12, 0, -1, 1, 1.0E-2, false, false); 
fparm->AddParam( ip++, kPhypDelta13, 0, -1, 1, 1.0E-2, false, false); 
fparm->AddParam( ip++, kPhypDelta34, 0, -1, 1, 1.0E-2, false, false); 
break; 
default: delete fparm; 
return; 
} 
fparm->AddParam( ip++, kPhypDm12sq, kInitFitDm12sq, kMinFitDm12sq, kMaxFitDm12sq, kStepDm12sq, false, false); 
NuOscDmsqScheme_t odmsq = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch (odmsq) { 
case(kNuDmsqFogliLisi): fparm->AddParam( ip++, kPhypDm23sq, kGlobFitDmsqFL, kMinFitDm23sq, kMaxFitDm23sq, kStepDm23sq, false, false); 
break; 
case(kNuDmsq12andAbs23): fparm->AddParam( ip++, kPhypDm23sq, kInitFitDm23sq, kMinFitDm23sq, kMaxFitDm23sq, kStepDm23sq, false, false); 
break; 
case(kNuDmsq12andAbs31): if(Opt::Instance()->gMassHierarchyAssumed == kNmhNormal) fparm->AddParam( ip++, kPhypDm23sq, kInitFitDm23sq + kInitFitDm12sq, kMinFitDm23sq, kMaxFitDm23sq, kStepDm23sq, false, false); 
else if(Opt::Instance()->gMassHierarchyAssumed == kNmhInverted) fparm->AddParam( ip++, kPhypDm23sq, kInitFitDm23sq - kInitFitDm12sq, kMinFitDm23sq, kMaxFitDm23sq, kStepDm23sq, false, false); 
else{ 
 std::cerr << "Mass hierarchy not defined" << std::endl; 
 util::Die(-1); 
 return; 
} 
break; 
default: std::cerr<<"Unknown mass scheme: "<<odmsq<<std::endl; 
util::Die(-1); 
return; 
} 
fparm->AddParam( ip++, kPhypDm41sq, kInitFitDm41sq, kMinFitDm41sq, kMaxFitDm41sq, kStepDm41sq, false, false); 
} 
void FitParamList::Append5FlavourSterileOscillation(FitParamList * fparm, int start) { 
int ip = start; 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta): fparm->AddParam( ip++, kPhypMixing12, kInitFitSinsq2Theta12, kMinFitSinsq2Theta12, kMaxFitSinsq2Theta12, kStepSinsq2Theta12, false, false); 
fparm->AddParam( ip++, kPhypMixing13, kInitFitSinsq2Theta13, kMinFitSinsq2Theta13, kMaxFitSinsq2Theta13, kStepSinsq2Theta13, false, false); 
fparm->AddParam( ip++, kPhypMixing14, kInitFitSinsq2Theta14, kMinFitSinsq2Theta14, kMaxFitSinsq2Theta14, kStepSinsq2Theta14, false, false); 
fparm->AddParam( ip++, kPhypMixing15, kInitFitSinsq2Theta15, kMinFitSinsq2Theta15, kMaxFitSinsq2Theta15, kStepSinsq2Theta15, false, false); 
fparm->AddParam( ip++, kPhypMixing23, kInitFitSinsq2Theta23, kMinFitSinsq2Theta23, kMaxFitSinsq2Theta23, kStepSinsq2Theta23, false, false); 
fparm->AddParam( ip++, kPhypMixing24, kInitFitSinsq2Theta24, kMinFitSinsq2Theta24, kMaxFitSinsq2Theta24, kStepSinsq2Theta24, false, false); 
fparm->AddParam( ip++, kPhypMixing25, kInitFitSinsq2Theta25, kMinFitSinsq2Theta25, kMaxFitSinsq2Theta25, kStepSinsq2Theta25, false, false); 
fparm->AddParam( ip++, kPhypMixing34, kInitFitSinsq2Theta34, kMinFitSinsq2Theta34, kMaxFitSinsq2Theta34, kStepSinsq2Theta34, false, false); 
fparm->AddParam( ip++, kPhypMixing35, kInitFitSinsq2Theta35, kMinFitSinsq2Theta35, kMaxFitSinsq2Theta35, kStepSinsq2Theta35, false, false); 
break; 
case(kNuMixSinsqTheta): fparm->AddParam( ip++, kPhypMixing12, kInitFitSinsqTheta12, kMinFitSinsqTheta12, kMaxFitSinsqTheta12, kStepSinsqTheta12, false, false); 
fparm->AddParam( ip++, kPhypMixing13, kInitFitSinsqTheta13, kMinFitSinsqTheta13, kMaxFitSinsqTheta13, kStepSinsqTheta13, false, false); 
fparm->AddParam( ip++, kPhypMixing14, kInitFitSinsqTheta14, kMinFitSinsqTheta14, kMaxFitSinsqTheta14, kStepSinsqTheta14, false, false); 
fparm->AddParam( ip++, kPhypMixing15, kInitFitSinsqTheta15, kMinFitSinsqTheta15, kMaxFitSinsqTheta15, kStepSinsqTheta15, false, false); 
fparm->AddParam( ip++, kPhypMixing23, kInitFitSinsqTheta23, kMinFitSinsqTheta23, kMaxFitSinsqTheta23, kStepSinsqTheta23, false, false); 
fparm->AddParam( ip++, kPhypMixing24, kInitFitSinsqTheta24, kMinFitSinsqTheta24, kMaxFitSinsqTheta24, kStepSinsqTheta24, false, false); 
fparm->AddParam( ip++, kPhypMixing25, kInitFitSinsqTheta25, kMinFitSinsqTheta25, kMaxFitSinsqTheta25, kStepSinsqTheta25, false, false); 
fparm->AddParam( ip++, kPhypMixing34, kInitFitSinsqTheta34, kMinFitSinsqTheta34, kMaxFitSinsqTheta34, kStepSinsqTheta34, false, false); 
fparm->AddParam( ip++, kPhypMixing35, kInitFitSinsqTheta35, kMinFitSinsqTheta35, kMaxFitSinsqTheta35, kStepSinsqTheta35, false, false); 
break; 
default: delete fparm; 
return; 
} 
NuOscDeltaCP_t dcp = Opt::Instance()->gOscDeltaCP; 
switch(dcp){ 
case(kNuDeltaCPPhase): fparm->AddParam( ip++, kPhypDelta12, 0, -kpi, kpi, 1.0E-2, false, false); 
fparm->AddParam( ip++, kPhypDelta13, 0, -kpi, kpi, 1.0E-2, false, false); 
fparm->AddParam( ip++, kPhypDelta15, 0, -kpi, kpi, 1.0E-2, false, false); 
fparm->AddParam( ip++, kPhypDelta34, 0, -kpi, kpi, 1.0E-2, false, false); 
fparm->AddParam( ip++, kPhypDelta35, 0, -kpi, kpi, 1.0E-2, false, false); 
break; 
case(kNuDeltaCPSin): fparm->AddParam( ip++, kPhypDelta12, 0, -1, 1, 1.0E-2, false, false); 
fparm->AddParam( ip++, kPhypDelta13, 0, -1, 1, 1.0E-2, false, false); 
fparm->AddParam( ip++, kPhypDelta15, 0, -1, 1, 1.0E-2, false, false); 
fparm->AddParam( ip++, kPhypDelta34, 0, -1, 1, 1.0E-2, false, false); 
fparm->AddParam( ip++, kPhypDelta35, 0, -1, 1, 1.0E-2, false, false); 
break; 
default: delete fparm; 
return; 
} 
fparm->AddParam( ip++, kPhypDm12sq, kInitFitDm12sq, kMinFitDm12sq, kMaxFitDm12sq, kStepDm12sq, false, false); 
NuOscDmsqScheme_t odmsq = Opt::Instance()->GetEffectiveDmsqScheme(); 
switch (odmsq) { 
case(kNuDmsqFogliLisi): fparm->AddParam( ip++, kPhypDm23sq, kGlobFitDmsqFL, kMinFitDm23sq, kMaxFitDm23sq, kStepDm23sq, false, false); 
break; 
case(kNuDmsq12andAbs23): fparm->AddParam( ip++, kPhypDm23sq, kInitFitDm23sq, kMinFitDm23sq, kMaxFitDm23sq, kStepDm23sq, false, false); 
break; 
case(kNuDmsq12andAbs31): if(Opt::Instance()->gMassHierarchyAssumed == kNmhNormal) fparm->AddParam( ip++, kPhypDm23sq, kInitFitDm23sq + kInitFitDm12sq, kMinFitDm23sq, kMaxFitDm23sq, kStepDm23sq, false, false); 
else if(Opt::Instance()->gMassHierarchyAssumed == kNmhInverted) fparm->AddParam( ip++, kPhypDm23sq, kInitFitDm23sq - kInitFitDm12sq, kMinFitDm23sq, kMaxFitDm23sq, kStepDm23sq, false, false); 
else{ 
 std::cerr << "Mass hierarchy not defined" << std::endl; 
 util::Die(-1); 
 return; 
} 
break; 
default: std::cerr<<"Unknown mass scheme: "<<odmsq<<std::endl; 
util::Die(-1); 
return; 
} 
fparm->AddParam( ip++, kPhypDm41sq, kInitFitDm41sq, kMinFitDm41sq, kMaxFitDm41sq, kStepDm41sq, false, false); 
fparm->AddParam( ip++, kPhypDm51sq, kInitFitDm51sq, kMinFitDm51sq, kMaxFitDm51sq, kStepDm51sq, false, false); 
} 
void FitParamList::AppendEffectiveSterileOscillation(FitParamList * fparm, int start) { 
int ip = start; 
fparm->AddParam( ip++, kPhypDm41sq , 1., 0.0, 100, 0.10, false, false); 
fparm->AddParam( ip++, kPhypMixingEE , 0.1, 0.0, 1.0, 0.01, false, false); 
fparm->AddParam( ip++, kPhypMixingMuMu, 0.1, 0.0, 1.0, 0.01, false, false); 
return; 
} 
void FitParamList::Append2FlavourOscillation(FitParamList * fparm, int start) { 
int ip = start; 
NuOscMixParam_t omp = Opt::Instance()->gOscMixingParamChoice; 
switch(omp) { 
case(kNuMixSinsq2Theta): fparm->AddParam( ip++, kPhypMixing23, kInitFitSinsq2Theta23, kMinFitSinsq2Theta23, kMaxFitSinsq2Theta23, kStepSinsq2Theta23, false, false); 
break; 
case(kNuMixSinsqTheta): fparm->AddParam( ip++, kPhypMixing23, kInitFitSinsqTheta23, kMinFitSinsqTheta23, kMaxFitSinsqTheta23, kStepSinsq2Theta23, false, false); 
break; 
default: delete fparm; 
return; 
} 
fparm->AddParam( ip++, kPhypDm23sq, kInitFitDm23sq, kMinFitDm23sq, kMaxFitDm23sq, kStepDm23sq, false, false); 
} 
void FitParamList::AppendAllSystematics(FitParamList * , int ) { 
} 
PhysHypothesis_t FitParamList::PhysicsHypothesis(void) const { 
if( this->Exists(kPhypDm51sq) ) { 
return kHypOscSterile5F; 
} 
if(this->Exists(kPhypDm41sq) ) { 
return kHypOscSterile4F; 
} 
if( this->Exists(kPhypDm12sqBar) && this->Exists(kPhypDm23sqBar) && this->Exists(kPhypMixing13Bar) && this->Exists(kPhypMixing12Bar) && this->Exists(kPhypMixing23Bar) && this->Exists(kPhypCPVBar) && this->Exists(kPhypDm12sq) && this->Exists(kPhypDm23sq) && this->Exists(kPhypMixing13) && this->Exists(kPhypMixing12) && this->Exists(kPhypMixing23) && this->Exists(kPhypCPV) && this->Exists(kPhypBetaBar) ) { 
return kHypOsc3FBarNormBar; 
} 
if( this->Exists(kPhypDm12sq) && this->Exists(kPhypDm23sq) && this->Exists(kPhypMixing13) && this->Exists(kPhypMixing12) && this->Exists(kPhypMixing23) && this->Exists(kPhypCPV) && this->Exists(kPhypBetaBar) ) { 
return kHypOsc3FNormBar; 
} 
if( this->Exists(kPhypDm12sqBar) && this->Exists(kPhypDm23sqBar) && this->Exists(kPhypMixing13Bar) && this->Exists(kPhypMixing12Bar) && this->Exists(kPhypMixing23Bar) && this->Exists(kPhypCPVBar) && this->Exists(kPhypDm12sq) && this->Exists(kPhypDm23sq) && this->Exists(kPhypMixing13) && this->Exists(kPhypMixing12) && this->Exists(kPhypMixing23) && this->Exists(kPhypCPV) ) { 
return kHypOsc3FBar; 
} 
if( this->Exists(kPhypDm23sqBar) && this->Exists(kPhypMixing23Bar) && this->Exists(kPhypDm12sq) && this->Exists(kPhypDm23sq) && this->Exists(kPhypMixing13) && this->Exists(kPhypMixing12) && this->Exists(kPhypMixing23) && this->Exists(kPhypCPV) ) { 
return kHypOsc3FBarDissap; 
} 
if( this->Exists(kPhypDm12sq) && this->Exists(kPhypDm23sq) && this->Exists(kPhypMixing13) && this->Exists(kPhypMixing12) && this->Exists(kPhypMixing23) && this->Exists(kPhypCPV) ) { 
return kHypOsc3F; 
} 
else if( this->Exists(kPhypDm23sq) && this->Exists(kPhypMixing23) ) { 
return kHypNuMuDisapp2F; 
} 
else if( this->Exists(kPhypAlphaDecay) && this->Exists(kPhypSinsq2ThetaDecay) ) { 
return kHypDecay; 
} 
else if( this->Exists(kPhypMusqDecoh) && this->Exists(kPhypSinsq2ThetaDecoh) ) { 
return kHypDecoh; 
} 
else { 
if(this->Size() > 0) { 
bool all_systematics = true; 
map<PhysParamId_t, int>::const_iterator it = fIdMap.begin(); 
for( ; it != fIdMap.begin(); ++it) { 
PhysParamId_t p = it->first; 
if(p < kNuis000) { 
all_systematics = false; 
break; 
} 
} 
if(all_systematics) return kHypVoid; 
} 
} 
return kHypUndefined; 
} 
void FitParamList::Copy(const FitParamList & plst) { 
if(this->fNParams != plst.fNParams) { 
this->CleanUp(); 
this->Init(plst.fNParams); 
} 
this->fParListName = plst.fParListName; 
this->fSystMode = plst.fSystMode; 
this->fIdMap.insert(plst.fIdMap.begin(), plst.fIdMap.end()); 
for(int i = 0; i < plst.fNParams; i++) { 
this->fName[i].SetString(plst.fName[i].GetString().Data()); 
this->fBestFitValue[i] = plst.fBestFitValue[i]; 
this->fCurrValue[i] = plst.fCurrValue[i]; 
this->fInitValue[i] = plst.fInitValue[i]; 
this->fMinValue[i] = plst.fMinValue[i]; 
this->fMaxValue[i] = plst.fMaxValue[i]; 
this->fStepSize[i] = plst.fStepSize[i]; 
this->fIsFixed[i] = plst.fIsFixed[i]; 
this->fIsNuisance[i] = plst.fIsNuisance[i]; 
this->fMigradError[i] = plst.fMigradError[i]; 
this->fHesseError[i] = plst.fHesseError[i]; 
this->fPlusError[i] = plst.fPlusError[i]; 
this->fMinusError[i] = plst.fMinusError[i]; 
this->fDoMarg[i] = plst.fDoMarg[i]; 
this->fPriorMode[i] = plst.fPriorMode[i]; 
this->fPriorModeName[i] = TObjString(plst.fPriorModeName[i]); 
this->fMeanGaus[i] = plst.fMeanGaus[i]; 
this->fSigmaGaus[i] = plst.fSigmaGaus[i]; 
this->fMinValueFlat[i] = plst.fMinValueFlat[i]; 
this->fMaxValueFlat[i] = plst.fMaxValueFlat[i]; 
this->fIsPrior2D[i] = plst.fIsPrior2D[i]; 
if(plst.fPriorHisto[i]!=0) this->fPriorHisto[i] = (TH1D*) plst.fPriorHisto[i]->Clone(""); 
else this->fPriorHisto[i] = 0; 
if(plst.fToyHisto[i]!=0) this->fToyHisto[i] = (TH1D*) plst.fToyHisto[i]->Clone(""); 
else this->fToyHisto[i] = 0; 
if(plst.fPriorHisto2D[i]!=0) this->fPriorHisto2D[i] = (TH2D*) plst.fPriorHisto2D[i]->Clone(""); 
else this->fPriorHisto2D[i] = 0; 
if(plst.fToyHisto2D[i]!=0) this->fToyHisto2D[i] = (TH2D*) plst.fToyHisto2D[i]->Clone(""); 
else this->fToyHisto2D[i] = 0; 
} 
for(int i = 0; i < plst.fNParams; i++) { 
for(int j = 0; j < plst.fNParams; j++) { 
(*this->fCovMatrix)[i][j] = (*plst.fCovMatrix)[i][j]; 
} 
} 
this->fBestFitStatisticContributions = plst.fBestFitStatisticContributions; 
this->fBestFitStatistic = plst.fBestFitStatistic; 
this->fCurrStatistic = plst.fCurrStatistic; 
this->fFitTime = plst.fFitTime; 
this->fFitTries = plst.fFitTries; 
this->fStatusCodes.insert(plst.fStatusCodes.begin(), plst.fStatusCodes.end()); 
this->fMigradErrorsSet = plst.fMigradErrorsSet; 
this->fHesseErrorsSet = plst.fHesseErrorsSet; 
this->fMinosErrorsSet = plst.fMinosErrorsSet; 
this->fShowCurrValuesOnly = plst.fShowCurrValuesOnly; 
this->fShowBestFitValuesOnly = plst.fShowBestFitValuesOnly; 
} 
void FitParamList::Init(int nparams) { 
fIdMap.clear(); 
fParListName = ""; 
fSystMode = -1; 
fNParams = nparams; 
if(nparams>0) { 
fName = new TObjString[fNParams]; 
fBestFitValue = new double[fNParams]; 
fCurrValue = new double[fNParams]; 
fInitValue = new double[fNParams]; 
fMinValue = new double[fNParams]; 
fMaxValue = new double[fNParams]; 
fStepSize = new double[fNParams]; 
fIsFixed = new bool [fNParams]; 
fIsNuisance = new bool [fNParams]; 
fMigradError = new double[fNParams]; 
fHesseError = new double[fNParams]; 
fPlusError = new double[fNParams]; 
fMinusError = new double[fNParams]; 
fParameterScaling = new double[fNParams]; 
fCovMatrix = new TMatrixDSym(fNParams); 
fDoMarg = new bool [fNParams]; 
fPriorMode = new int [fNParams]; 
fPriorModeName = new TObjString[fNParams]; 
fMeanGaus = new double [fNParams]; 
fSigmaGaus = new double [fNParams]; 
fMinValueFlat = new double [fNParams]; 
fMaxValueFlat = new double [fNParams]; 
fPriorHisto = new TH1D * [fNParams]; 
fToyHisto = new TH1D * [fNParams]; 
fIsPrior2D = new bool [fNParams]; 
fPriorHisto2D = new TH2D * [fNParams]; 
fToyHisto2D = new TH2D * [fNParams]; 
} else { 
fName = 0; 
fBestFitValue = 0; 
fCurrValue = 0; 
fInitValue = 0; 
fMinValue = 0; 
fMaxValue = 0; 
fStepSize = 0; 
fIsFixed = 0; 
fIsNuisance = 0; 
fMigradError = 0; 
fHesseError = 0; 
fPlusError = 0; 
fMinusError = 0; 
fParameterScaling = 0; 
fCovMatrix = 0; 
fDoMarg = 0; 
fPriorMode = 0; 
fPriorModeName = 0; 
fMeanGaus = 0; 
fSigmaGaus = 0; 
fMinValueFlat = 0; 
fMaxValueFlat = 0; 
fIsPrior2D = 0; 
fPriorHisto = 0; 
fToyHisto = 0; 
fPriorHisto2D = 0; 
fToyHisto2D = 0; 
} 
for (int i = 0 ; i < fNParams ; i++) { 
fName [i].SetString("Uninitialised"); 
fBestFitValue [i] = 0; 
fCurrValue [i] = 0; 
fInitValue [i] = 0; 
fMinValue [i] = 0; 
fMaxValue [i] = 0; 
fStepSize [i] = 0; 
fIsFixed [i] = 0; 
fIsNuisance [i] = 0; 
fMigradError [i] = 0; 
fHesseError [i] = 0; 
fPlusError [i] = 0; 
fMinusError [i] = 0; 
fParameterScaling[i] = 1; 
fDoMarg [i] = 0; 
fPriorMode [i] = 0; 
fPriorModeName[i].SetString("Uninitialised"); 
fMeanGaus [i] = 0; 
fSigmaGaus [i] = 0; 
fMinValueFlat [i] = 0; 
fMaxValueFlat [i] = 0; 
fIsPrior2D [i] = 0; 
fPriorHisto [i] = 0; 
fToyHisto [i] = 0; 
fPriorHisto2D [i] = 0; 
fToyHisto2D [i] = 0; 
} 
fShowCurrValuesOnly = false; 
fShowBestFitValuesOnly = false; 
fBestFitStatistic = 0.; 
fCurrStatistic = 0.; 
fFitTime = -1; 
fFitTries = 0; 
fStatusCodes.clear(); 
fMigradErrorsSet = false; 
fHesseErrorsSet = false; 
fMinosErrorsSet = false; 
} 
void FitParamList::CleanUp(void) { 
fIdMap.clear(); 
fStatusCodes.clear(); 
if( fName ) { delete [] fName ; fName = 0; } 
if( fBestFitValue ) { delete [] fBestFitValue ; fBestFitValue = 0; } 
if( fCurrValue ) { delete [] fCurrValue ; fCurrValue = 0; } 
if( fInitValue ) { delete [] fInitValue ; fInitValue = 0; } 
if( fMinValue ) { delete [] fMinValue ; fMinValue = 0; } 
if( fMaxValue ) { delete [] fMaxValue ; fMaxValue = 0; } 
if( fStepSize ) { delete [] fStepSize ; fStepSize = 0; } 
if( fIsFixed ) { delete [] fIsFixed ; fIsFixed = 0; } 
if( fIsNuisance ) { delete [] fIsNuisance ; fIsNuisance = 0; } 
if( fMigradError ) { delete [] fMigradError ; fMigradError = 0; } 
if( fHesseError ) { delete [] fHesseError ; fHesseError = 0; } 
if( fPlusError ) { delete [] fPlusError ; fPlusError = 0; } 
if( fMinusError ) { delete [] fMinusError ; fMinusError = 0; } 
if( fParameterScaling ) { delete [] fParameterScaling ; fParameterScaling = 0; } 
if( fCovMatrix ) { delete fCovMatrix ; fCovMatrix = 0; } 
if (fDoMarg ) { delete [] fDoMarg ; fDoMarg = 0 ; } 
if (fPriorMode ) { delete [] fPriorMode ; fPriorMode = 0 ; } 
if (fPriorModeName ) { delete [] fPriorModeName; fPriorModeName = 0 ; } 
if (fMeanGaus ) { delete [] fMeanGaus ; fMeanGaus = 0 ; } 
if (fSigmaGaus ) { delete [] fSigmaGaus ; fSigmaGaus = 0 ; } 
if (fMinValueFlat ) { delete [] fMinValueFlat ; fMinValueFlat = 0 ; } 
if (fMaxValueFlat ) { delete [] fMaxValueFlat ; fMaxValueFlat = 0 ; } 
if (fPriorHisto ) { delete [] fPriorHisto ; fPriorHisto = 0 ; } 
if (fToyHisto ) { delete [] fToyHisto ; fToyHisto = 0 ; } 
if (fIsPrior2D ) { delete [] fIsPrior2D ; fIsPrior2D = 0 ; } 
if (fPriorHisto2D ) { delete [] fPriorHisto2D ; fPriorHisto2D = 0 ; } 
if (fToyHisto2D ) { delete [] fToyHisto2D ; fToyHisto2D = 0 ; } 
fBestFitStatisticContributions.clear(); 
fBestFitStatistic = 0.; 
fCurrStatistic = 0.; 
fFitTime = 0.; 
fFitTries = -1; 
fParListName = ""; 
fSystMode = -1; 
} 
int FitParamList::Id(PhysParamId_t p) const { 
map<PhysParamId_t, int>::const_iterator it = fIdMap.find(p); 
if(it == fIdMap.end()) { 
assert(1); 
util::Die(-1); return 0; 
} 
int id = it->second; 
return id; 
} 
valor::conv::PhysParamId_t FitParamList::WhichParam(int id) const { 
map<PhysParamId_t, int>::const_iterator it = fIdMap.begin(); 
for( ; it != fIdMap.end(); ++it) { 
int curr_id = it->second; 
if(curr_id == id) return it->first; 
} 
return kPhypUndefined; 
} 
double FitParamList::HypothesisFitStatisticPenalty(Option_t * ) const { 
double chisq = 0; 
double center, error, current, tweak; 
for (int ip = kPhypMixing23 ; ip < kNuis000 ; ip++) { 
PhysParamId_t p = (PhysParamId_t) ip; 
if (not (this->Exists(p) && this->IsNuisance(p))) continue; 
current = this->CurrValue(p); 
center = Opt::Instance()->GetGlobalBestFit(p); 
error = Opt::Instance()->GetGlobalFitError(p)*center; 
#ifdef USE_NEAREST_23_OCTANT_PENALTY 
if (p==conv::kPhypMixing23 && Opt::Instance()->gOscMixingParamChoice == conv::kNuMixSinsqTheta) { 
double flipped_current = util::FlipOctantAroundMaxDisap(current,this->CurrValue(conv::kPhypMixing13)); 
if (std::fabs(flipped_current-center) < std::fabs(current-center)) { 
current = flipped_current; 
} 
} 
#endif 
#ifdef DOUBLE_ANGLE_REACTOR_PENALTY 
if(p==conv::kPhypMixing13 && omp==conv::kNuMixSinsqTheta){ 
double current_sinsq2th = 1 - (1-2*current)*(1-2*current); 
current = current_sinsq2th; 
center = conv::kGlobFitSinsq2Theta13; 
error = conv::kGlobFitErrSinsq2Theta13 * center; 
} 
#endif 
if (center == -999) { 
assert(1); 
continue; 
} 
tweak = (current-center)/error; 
chisq += tweak*tweak; 
} 
return chisq; 
} 
bool FitParamList::IsComplete() { 
for (int ip = 0 ; ip < fNParams; ip++) { 
PhysParamId_t p = this->WhichParam(ip); 
if (p==conv::kPhypUndefined) {return false;} 
} 
return true; 
} 
int FitParamList::FirstEmptyEntry() { 
for (int ip = 0 ; ip < fNParams; ip++) { 
PhysParamId_t p = this->WhichParam(ip); 
if (p==conv::kPhypUndefined) {return ip;} 
} 
return conv::kBadResult; 
} 
void FitParamList::SetDoMarg(valor::conv::PhysParamId_t p,bool domarg) { 
fDoMarg [this->Id(p)] = domarg; 
} 
void FitParamList::SetPriorMode(valor::conv::PhysParamId_t p,int priormode) { 
fPriorMode [this->Id(p)] = priormode; 
if (priormode==0) fPriorModeName [this->Id(p)].SetString("flat"); 
else if (priormode==1) fPriorModeName [this->Id(p)].SetString("gaus"); 
else if (priormode==2) fPriorModeName [this->Id(p)].SetString("user"); 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
util::Die(-1);return; 
} 
} 
void FitParamList::SetPriorMode(valor::conv::PhysParamId_t p,string priormodename) { 
if(priormodename=="flat"){ 
fPriorModeName [this->Id(p)].SetString("flat"); 
fPriorMode [this->Id(p)] = 0; 
} 
else if (priormodename=="gaus"){ 
fPriorModeName [this->Id(p)].SetString("gaus"); 
fPriorMode [this->Id(p)] = 1; 
} 
else if (priormodename=="user"){ 
fPriorModeName [this->Id(p)].SetString("user"); 
fPriorMode [this->Id(p)] = 2; 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
util::Die(-1);return; 
} 
} 
void FitParamList::SetMeanGaus(valor::conv::PhysParamId_t p,double mean) { 
fMeanGaus [this->Id(p)] = mean; 
} 
void FitParamList::SetSigmaGaus(valor::conv::PhysParamId_t p,double sigma) { 
fSigmaGaus [this->Id(p)] = sigma; 
} 
void FitParamList::SetMinValueFlat(valor::conv::PhysParamId_t p,double minvalmarg) { 
fMinValueFlat [this->Id(p)] = minvalmarg; 
} 
void FitParamList::SetMaxValueFlat(valor::conv::PhysParamId_t p,double maxvalmarg) { 
fMaxValueFlat [this->Id(p)] = maxvalmarg; 
} 
void FitParamList::SetPriorHisto(valor::conv::PhysParamId_t p,TH1D *hprior) { 
char name[200]; 
sprintf(name,"%s_%s","hPrior",util::RawParamAsStringRaw(p).c_str()); 
fPriorHisto [this->Id(p)] = (TH1D*) hprior->Clone(name); 
this->SetPriorDimension2D(p,false); 
} 
void FitParamList::SetPriorHisto2D(valor::conv::PhysParamId_t p,TH2D *hprior) { 
char name[200]; 
sprintf(name,"%s_%s","hPrior",util::RawParamAsStringRaw(p).c_str()); 
fPriorHisto2D [this->Id(p)] = (TH2D*) hprior->Clone(name); 
this->SetPriorDimension2D(p,true); 
} 
void FitParamList::SetToyHisto(valor::conv::PhysParamId_t p,TH1D *hprior) { 
char name[200]; 
sprintf(name,"%s_%s","hToy",util::RawParamAsStringRaw(p).c_str()); 
fToyHisto [this->Id(p)] = (TH1D*) hprior->Clone(name); 
fToyHisto [this->Id(p)]->Reset(); 
} 
void FitParamList::SetToyHisto2D(valor::conv::PhysParamId_t p,TH2D *hprior) { 
char name[200]; 
sprintf(name,"%s_%s","hToy2D",util::RawParamAsStringRaw(p).c_str()); 
fToyHisto2D [this->Id(p)] = (TH2D*) hprior->Clone(name); 
fToyHisto2D [this->Id(p)]->Reset(); 
} 
string FitParamList::GetPriorModeName (valor::conv::PhysParamId_t p) const { 
const char * data = fPriorModeName[this->Id(p)].GetString().Data(); 
return string(data); 
} 
void FitParamList::SetPriorDimension2D(valor::conv::PhysParamId_t p, bool isprior2d){ 
fIsPrior2D [this->Id(p)] = isprior2d; 
} 
namespace valor { 
ostream & operator << (ostream & stream, const PhysHypothesis & ph) { 
ph.Print(stream); 
return stream; 
} 
} 
PhysHypothesis::PhysHypothesis(PhysHypothesis_t h) { 
this->Init(h); 
} 
PhysHypothesis::PhysHypothesis(string sh) { 
PhysHypothesis_t h = util::PhysHypFromString(sh); 
this->Init(h); 
} 
PhysHypothesis::PhysHypothesis(const PhysHypothesis & ph) { 
this->Copy(ph); 
} 
PhysHypothesis::PhysHypothesis(const FitParamList & fp) { 
PhysHypothesis_t hyp = fp.PhysicsHypothesis(); 
this->Init(hyp); 
for (int i = 0 ; i < fp.Size() ; i++) { 
PhysParamId_t p = fp.WhichParam(i); 
this->SetCurrValue(p, fp.CurrValue(p)); 
this->SetNuisance(p, fp.IsNuisance(p)); 
} 
#ifdef __show_init_mesg_info__ 
assert(1); 
#endif 
} 
PhysHypothesis::~PhysHypothesis() { 
fHypothesis = kHypUndefined; 
fParams.clear(); 
} 
double PhysHypothesis::CurrValue(PhysParamId_t p) const { 
map<int,double>::const_iterator it = fParams.find(p); 
if(it == fParams.end()) { 
assert(1); 
util::Die(-1); return conv::kBadResult; 
} 
return it->second; 
} 
void PhysHypothesis::SetCurrValue(PhysParamId_t p, double v) { 
fParams[p] = v; 
} 
void PhysHypothesis::Copy(const PhysHypothesis & ph) { 
fHypothesis = ph.fHypothesis; 
fParams = ph.fParams; 
fIsNuisance = ph.fIsNuisance; 
} 
void PhysHypothesis::Init(PhysHypothesis_t h) { 
fHypothesis = h; 
fParams.clear(); 
if(fHypothesis == kHypNuMuDisapp2F) { 
fParams[kPhypMixing23] = 0; 
fParams[kPhypDm23sq] = 0; 
} 
if(fHypothesis == kHypOsc3F) { 
fParams[kPhypMixing12] = 0; 
fParams[kPhypMixing13] = 0; 
fParams[kPhypMixing23] = 0; 
fParams[kPhypCPV ] = 0; 
fParams[kPhypDm23sq ] = 0; 
fParams[kPhypDm12sq ] = 0; 
} 
if(fHypothesis == kHypOsc3FBar) { 
fParams[kPhypMixing12 ] = 0; 
fParams[kPhypMixing13 ] = 0; 
fParams[kPhypMixing23 ] = 0; 
fParams[kPhypCPV ] = 0; 
fParams[kPhypDm23sq ] = 0; 
fParams[kPhypDm12sq ] = 0; 
fParams[kPhypMixing12Bar] = 0; 
fParams[kPhypMixing13Bar] = 0; 
fParams[kPhypMixing23Bar] = 0; 
fParams[kPhypCPVBar ] = 0; 
fParams[kPhypDm23sqBar ] = 0; 
fParams[kPhypDm12sqBar ] = 0; 
} 
if(fHypothesis == kHypOsc3FBar) { 
fParams[kPhypMixing12 ] = 0; 
fParams[kPhypMixing13 ] = 0; 
fParams[kPhypMixing23 ] = 0; 
fParams[kPhypCPV ] = 0; 
fParams[kPhypDm23sq ] = 0; 
fParams[kPhypDm12sq ] = 0; 
fParams[kPhypMixing23Bar] = 0; 
fParams[kPhypDm23sqBar ] = 0; 
} 
if(fHypothesis == kHypOsc3FBarNormBar) { 
fParams[kPhypMixing12 ] = 0; 
fParams[kPhypMixing13 ] = 0; 
fParams[kPhypMixing23 ] = 0; 
fParams[kPhypCPV ] = 0; 
fParams[kPhypDm23sq ] = 0; 
fParams[kPhypDm12sq ] = 0; 
fParams[kPhypMixing12Bar] = 0; 
fParams[kPhypMixing13Bar] = 0; 
fParams[kPhypMixing23Bar] = 0; 
fParams[kPhypCPVBar ] = 0; 
fParams[kPhypDm23sqBar ] = 0; 
fParams[kPhypDm12sqBar ] = 0; 
fParams[kPhypBetaBar ] = 0; 
} 
if(fHypothesis == kHypOsc3FNormBar) { 
fParams[kPhypMixing12 ] = 0; 
fParams[kPhypMixing13 ] = 0; 
fParams[kPhypMixing23 ] = 0; 
fParams[kPhypCPV ] = 0; 
fParams[kPhypDm23sq ] = 0; 
fParams[kPhypDm12sq ] = 0; 
fParams[kPhypBetaBar ] = 0; 
} 
if(fHypothesis == kHypDecay) { 
fParams[kPhypSinsq2ThetaDecay] = 0; 
fParams[kPhypAlphaDecay] = 0; 
} 
if(fHypothesis == kHypDecoh) { 
fParams[kPhypSinsq2ThetaDecoh] = 0; 
fParams[kPhypMusqDecoh] = 0; 
} 
} 
void PhysHypothesis::Print(ostream & stream) const { 
stream << endl; 
stream << "................................................................." << endl; 
stream << "Hypothesis: \n" << util::AsString(fHypothesis) << endl; 
stream << "Parameters: " << endl; 
map<int,double>::const_iterator it = fParams.begin(); 
for( ; it != fParams.end(); ++it) { 
PhysParamId_t p = (PhysParamId_t) it->first; 
double v = it->second; 
stream << " - " << setw(15) << util::NameRegistry::Instance()->AsString(p) << " = " << setprecision(8) << setw(12) << v << endl; 
} 
stream << "................................................................." << endl; 
} 
PhysParamList PhysHypothesis::AsPhysParamList(void) const { 
PhysParamList pl; 
map<int, double>::const_iterator iter = fParams.begin(); 
for( ; iter != fParams.end(); ++iter) { 
PhysParamId_t p = (PhysParamId_t)iter->first; 
double v = iter->second; 
pl.SetValue(p,v); 
} 
return pl; 
} 
void PhysHypothesis::CopyToPhysParamList(PhysParamList & pl) const { 
map<int, double>::const_iterator iter = fParams.begin(); 
for( ; iter != fParams.end(); ++iter) { 
PhysParamId_t p = (PhysParamId_t)iter->first; 
double v = iter->second; 
pl.SetValue(p,v); 
} 
return; 
} 
void PhysHypothesis::SetNuisance (conv::PhysParamId_t p, bool isNuisance) { 
fIsNuisance[p] = isNuisance; 
return; 
} 
bool PhysHypothesis::IsNuisance(conv::PhysParamId_t p) const { 
map<int,bool>::const_iterator it = fIsNuisance.find(p); 
if(it == fIsNuisance.end()) { 
return false; 
} 
return it->second; 
} 
bool PhysHypothesis::Contains(conv::PhysParamId_t p) const { 
map<int,double>::const_iterator it = fParams.find(p); 
return (it != fParams.end()); 
} 
FitDataABC::FitDataABC() { 
} 
FitDataABC::~FitDataABC() { 
} 
ClassImp(FitInputs) FitInputs::FitInputs( FitDataABC * o, FitModelABC * e, FitParamList * fpar, string opt, double errdef, bool goodnessoffit) : fObs(o), fExp(e), fFitParams(fpar), fOpt(opt), fErrDef(errdef), fGoodnessOfFit(goodnessoffit), fIncludePenaltySyst(true), fIncludePenaltyHyp (true) { 
} 
FitInputs::~FitInputs() { 
} 
void FitInputs::UpdateParamList(FitParamList * fpar) { 
fFitParams = fpar; 
} 
FitDataABC & FitInputs::Observation(void) { 
return *fObs; 
} 
FitModelABC & FitInputs::Expectation(void) { 
return *fExp; 
} 
FitParamList & FitInputs::FitParams(void) { 
return *fFitParams; 
} 
double FitInputs::Statistic(Option_t * option, std::map<std::string,double> * likelihood_components) const { 
double total_statistic = 0; 
double data_statistic = 0; 
double syst_penalty = 0; 
double phys_penalty = 0; 
if (option || fGoodnessOfFit) { 
const char * s = fGoodnessOfFit ? "%s gof" : "%s"; 
TString newopt = TString::Format(s,option); 
data_statistic = fObs->GetFitStatistic(fExp,*fFitParams, newopt.Data(), likelihood_components); 
} 
else { 
data_statistic = fObs->GetFitStatistic(fExp,*fFitParams, NULL, likelihood_components); 
} 
TString option_ts(option); 
if (!option_ts.Contains("nopenalty")){ 
if (fIncludePenaltySyst) {syst_penalty = fExp->GetFitStatisticPenalty(option);} 
if (fIncludePenaltyHyp ) {phys_penalty = fFitParams->HypothesisFitStatisticPenalty(option);} 
} 
if (likelihood_components) { 
(*likelihood_components)["penalty_syst"] = syst_penalty; 
(*likelihood_components)["penalty_hyp" ] = phys_penalty; 
} 
total_statistic = syst_penalty + phys_penalty; 
#ifndef __VALOR_FMWK_PENALTY_ONLY__ 
total_statistic += data_statistic; 
#endif 
assert(1); 
assert(TMath::Finite(total_statistic)); 
return total_statistic; 
} 
void FitInputs::IncludePenaltySyst(bool use_penalty) { 
fIncludePenaltySyst = use_penalty; 
} 
void FitInputs::IncludePenaltyHyp(bool use_penalty) { 
fIncludePenaltyHyp = use_penalty; 
} 
double FitInputs::operator() (const std::vector<double>& x) const { 
fFitParams->Sync(x); 
return this->Statistic("poisson"); 
} 
void valor::FitFunc ( Int_t &, Double_t *, Double_t &f, Double_t *par, Int_t ) { 
FitInputs * inputs = (FitInputs *) gMinuit->GetObjectFit(); 
FitParamList & fpar = inputs->FitParams(); 
fpar.Sync(par,true); 
f = inputs->Statistic(); 
fpar.SetCurrStatistic(f); 
} 
FitFunctor::FitFunctor(FitInputs * inputs) { 
fFitInputs = inputs; 
} 
FitFunctor::~FitFunctor() { 
} 
double FitFunctor::operator() (const double * x) const { 
return this->DoEval(x); 
} 
double FitFunctor::DoEval(const double * x) const { 
fFitInputs->FitParams().Sync(x); 
return fFitInputs->Statistic(); 
} 
ROOT::Math::IBaseFunctionMultiDim * FitFunctor::Clone(void) const { 
return new FitFunctor(fFitInputs); 
} 
unsigned int FitFunctor::NDim(void) const { 
return fFitInputs->FitParams().GetNumberParameters(); 
} 
FitMethodFunc::~FitMethodFunc() { 
} 
double FitMethodFunc::operator() (const double * x) const { 
return this->DoEval(x); 
} 
double FitMethodFunc::DoEval(const double * x) const { 
fFitInputs->FitParams().Sync(x); 
return fFitInputs->Statistic("poisson"); 
} 
ROOT::Math::BasicFitMethodFunction<ROOT::Math::IBaseFunctionMultiDim>::Type_t FitMethodFunc::Type(void) const { 
return ROOT::Math::FitMethodFunction::kLeastSquare; 
} 
double FitMethodFunc::DataElement(const double *par, unsigned int , double * ) const { 
fFitInputs->FitParams().Sync(par); 
double chisqbin = 0; 
assert(!"FitMethodFunc::DataElement not implemented yet"); 
return chisqbin; 
} 
FitModelABC::FitModelABC() { 
} 
FitModelABC::~FitModelABC() { 
} 
FitterABC::FitterABC() { 
} 
FitterABC::~FitterABC() { 
} 

#define __show_init_mesg_info__ 

#ifndef NSIGMA_LIMIT 

#define NSIGMA_LIMIT 5 

#endif 
ClassImp(CorrelatedSystematics) CorrelatedSystematics::CorrelatedSystematics(unsigned int n_syst, const PhysParamId_t * syst_params, const string & xml_node_name) : TNamed(), fDefaultValues (NULL), fUntunedValues (NULL), fInitialValues (NULL), fCurrentValues (NULL), fCovMtrx (NULL), fCovMtrxInv (NULL), fCovMtrxChoL (NULL), fCovMtrxChoLInv (NULL), fSystParameters (NULL), fIsConfigured (false) { 
this->Init(n_syst,syst_params,xml_node_name); 
} 
CorrelatedSystematics::CorrelatedSystematics() : TNamed(), fDefaultValues (NULL), fUntunedValues (NULL), fInitialValues (NULL), fCurrentValues (NULL), fCovMtrx (NULL), fCovMtrxInv (NULL), fCovMtrxChoL (NULL), fCovMtrxChoLInv (NULL), fSystParameters (NULL), fIsConfigured (false) { 
this->Init(0,nullptr); 
} 
CorrelatedSystematics::CorrelatedSystematics(const CorrelatedSystematics & c) : TNamed(c), fDefaultValues (new TVectorD(*(c.fDefaultValues ))), fUntunedValues (new TVectorD(*(c.fUntunedValues ))), fInitialValues (new TVectorD(*(c.fInitialValues ))), fCurrentValues (new TVectorD(*(c.fCurrentValues ))), fCovMtrx (new TMatrixD(*(c.fCovMtrx ))), fCovMtrxInv (new TMatrixD(*(c.fCovMtrxInv ))), fCovMtrxChoL (new TMatrixD(*(c.fCovMtrxChoL ))), fCovMtrxChoLInv (new TMatrixD(*(c.fCovMtrxChoLInv))), fUntunedArray (fUntunedValues->GetMatrixArray()), fInitialArray (fInitialValues->GetMatrixArray()), fCurrentArray (fCurrentValues->GetMatrixArray()), fNSystParameters (c.fNSystParameters), fSystParameters (new conv::PhysParamId_t[fNSystParameters]), fXMLNodeName (c.fXMLNodeName), fIsConfigured (true) { 
for (unsigned int ip = 0 ; ip < fNSystParameters ; ip++) { 
fSystParameters[ip] = c.fSystParameters[ip]; 
} 
for (int ip = 0 ; ip < conv::knppmax ; ip++) { 
fParam2Idx[ip] = c.fParam2Idx[ip]; 
} 
} 
CorrelatedSystematics::~CorrelatedSystematics() { 
this->CleanUp(); 
} 
void CorrelatedSystematics::Init(unsigned int n_syst, const PhysParamId_t * syst_params, const string & xml_node_name) { 
this->CleanUp(); 
fNSystParameters = n_syst; 
fSystParameters = new PhysParamId_t[fNSystParameters]; 
for (unsigned int i = 0 ; i < n_syst ; i++) { 
fSystParameters[i] = syst_params[i]; 
} 
fDefaultValues = new TVectorD(fNSystParameters); 
fUntunedValues = new TVectorD(fNSystParameters); 
fInitialValues = new TVectorD(fNSystParameters); 
fCurrentValues = new TVectorD(fNSystParameters); 
fCovMtrx = NULL; 
fCovMtrxInv = NULL; 
fCovMtrxChoL = NULL; 
fCovMtrxChoLInv = NULL; 
fIsTweaked = false; 
fUntunedArray = fUntunedValues->GetMatrixArray(); 
fInitialArray = fInitialValues->GetMatrixArray(); 
fCurrentArray = fCurrentValues->GetMatrixArray(); 
for (int ip = 0 ; ip < conv::knppmax; ip++) { 
fParam2Idx[ip] = -1; 
} 
for(int i = 0 ; i < fCurrentValues->GetNrows(); i++ ) { 
(*fDefaultValues)[i] = 1.; 
(*fUntunedValues)[i] = 1.; 
(*fInitialValues)[i] = 1.; 
(*fCurrentValues)[i] = 1.; 
} 
this->FillParam2Idx(); 
this->SetName("Systematics"); 
fXMLNodeName = xml_node_name; 
bool failure = false; 
for (unsigned int ii = 0 ; ii < n_syst ; ii++) { 
if (fSystParameters[ii] == conv::kPhypUndefined) { 
failure = true; 
assert(1); 
continue; 
} 
for (unsigned int jj = 0 ; jj < ii ; jj++) { 
if (fSystParameters[ii] == fSystParameters[jj]) { 
assert(1); 
failure = true; 
break; 
} 
} 
} 
if (failure) { 
util::Die(-1); 
} 
return; 
} 
void CorrelatedSystematics::FillParam2Idx(void) { 
for (int ip = 0 ; ip < conv::knppmax; ip++) { 
fParam2Idx[ip] = -1; 
PhysParamId_t p = (PhysParamId_t)ip; 
for (unsigned int i = 0 ; i < fNSystParameters; i++) { 
if (p == fSystParameters[i]) { 
fParam2Idx[p] = i; 
break; 
} 
} 
} 
} 
void CorrelatedSystematics::CleanUp(void) { 
if ( fDefaultValues ) { delete fDefaultValues ; fDefaultValues = NULL;} 
if ( fUntunedValues ) { delete fUntunedValues ; fUntunedValues = NULL;} 
if ( fInitialValues ) { delete fInitialValues ; fInitialValues = NULL;} 
if ( fCurrentValues ) { delete fCurrentValues ; fCurrentValues = NULL;} 
if ( fCovMtrx ) { delete fCovMtrx ; fCovMtrx = NULL;} 
if ( fCovMtrxInv ) { delete fCovMtrxInv ; fCovMtrxInv = NULL;} 
if ( fCovMtrxChoL ) { delete fCovMtrxChoL ; fCovMtrxChoL = NULL;} 
if ( fCovMtrxChoLInv ) { delete fCovMtrxChoLInv ; fCovMtrxChoLInv = NULL;} 
if ( fSystParameters) { delete[] fSystParameters; fSystParameters = NULL;} 
fIsConfigured = false; 
} 
bool CorrelatedSystematics::Read(TXMLEngine* xml, XMLNodePointer_t root_node) { 
if (fIsConfigured) { 
PhysParamId_t tmp_par[fNSystParameters]; 
for (unsigned int i = 0 ; i < fNSystParameters ; i++) { 
tmp_par[i] = fSystParameters[i]; 
} 
this->CleanUp(); 
this->Init(fNSystParameters,tmp_par); 
} 
assert(1); 
TString nodepath = ""; 
if (fXMLNodeName.size()) { 
nodepath = TString::Format("%s/",fXMLNodeName.c_str()); 
} 
TString untuned_values_path = nodepath+"untuned_values"; 
if (util::NodeExists(xml,root_node,untuned_values_path.Data())) { 
TVectorD * tmp_vec = util::XML2TVectorD(xml,root_node,untuned_values_path.Data()); 
if(!tmp_vec) { 
assert(1); 
util::Die(1); return false; 
} 
if (tmp_vec->GetNrows()!=fUntunedValues->GetNrows()) { 
assert(1); 
util::Die(1); return false; 
} 
(*fUntunedValues) = (*tmp_vec); 
delete tmp_vec; 
} 
else { 
assert(1); 
(*fUntunedValues) = *fDefaultValues; 
} 
TString initial_values_path = nodepath+"initial_values"; 
if (util::NodeExists(xml,root_node,initial_values_path.Data())) { 
TVectorD * tmp_vec = util::XML2TVectorD(xml,root_node,initial_values_path.Data()); 
if(!tmp_vec) { 
assert(1); 
util::Die(1); return false; 
} 
if (tmp_vec->GetNrows()!=fInitialValues->GetNrows()) { 
assert(1); 
util::Die(1); return false; 
} 
(*fInitialValues) = (*tmp_vec); 
delete tmp_vec; 
} 
else { 
assert(1); 
(*fInitialValues) = *fUntunedValues; 
} 
(*fCurrentValues) = *fInitialValues; 
TString cov_mtrx_path = nodepath+"covariance_matrix"; 
fCovMtrx = util::XML2TMatrixD(xml,root_node,cov_mtrx_path.Data()); 
if(!fCovMtrx) { 
assert(1); 
util::Die(1); return false; 
} 
TMatrixD & cov = *fCovMtrx; 
const int np = fNSystParameters; 
if(cov.GetNrows() != np || cov.GetNcols() != np) { 
assert(1); 
util::Die(1); return false; 
} 
TString force_uncorrelated_path = nodepath+"force_uncorrelated"; 
bool force_uncorrelated = false; 
if (util::NodeExists(xml,root_node,force_uncorrelated_path.Data())) { 
force_uncorrelated = util::XML2Bool(xml,root_node,force_uncorrelated_path.Data()); 
} 
if (force_uncorrelated) { 
assert(1); 
for (int i = 0 ; i < np; i++) { 
for (int j = 0 ; j < np; j++) { 
if (i!=j) {cov(i,j) = 0;}; 
} 
} 
} 
this->CholeskyDecomposeMatrix(); 
this->InvertMatrices(); 
fIsConfigured = true; 
#ifdef __init_check_inverse__ 
TMatrixD covTimesInverse = (cov * (*fCovMtrxInv)); 
for (int ii = 0 ; ii < np ; ii++) { 
for (int jj = 0 ; jj < np ; jj++) { 
int target = (ii==jj); 
if (fabs(covTimesInverse[ii][jj]-target) > 1E-9) { 
assert(1); 
fIsConfigured = false; 
} 
} 
} 
if (!fIsConfigured) {util::Die(1); return fIsConfigured;} 
#endif 
#ifdef __show_init_mesg_debug__ 
assert(1); 
util::PrintMatrix(cov,7,5); 
assert(1); 
util::PrintMatrix(*fCovMtrxInv,7,5); 
#endif 
return fIsConfigured; 
} 
double CorrelatedSystematics::CurrentValue(PhysParamId_t p) const { 
int idx = this->Param2Idx(p); 
return fCurrentArray[idx]; 
} 
double CorrelatedSystematics::CurrentValueByIndex(int idx) const { 
return fCurrentArray[idx]; 
} 
double CorrelatedSystematics::InitialValue(PhysParamId_t p) const { 
int idx = this->Param2Idx(p); 
return fInitialArray[idx]; 
} 
double CorrelatedSystematics::InitialValueByIndex(int idx) const { 
return fInitialArray[idx]; 
} 
double CorrelatedSystematics::UntunedValue(PhysParamId_t p) const { 
int idx = this->Param2Idx(p); 
return fUntunedArray[idx]; 
} 
double CorrelatedSystematics::UntunedValueByIndex(int idx) const { 
return fUntunedArray[idx]; 
} 
void CorrelatedSystematics::SetCurrentValue(PhysParamId_t p, double value) { 
int idx = this->Param2Idx(p); 
fCurrentArray[idx] = value; 
} 
void CorrelatedSystematics::SetCurrentValueByIndex(int idx, double value) { 
fCurrentArray[idx] = value; 
} 
double CorrelatedSystematics::OneSigmaError(PhysParamId_t p) const { 
const TMatrixD & cov = *fCovMtrx; 
int idx = this->Param2Idx(p); 
return TMath::Sqrt(cov[idx][idx]); 
} 
double CorrelatedSystematics::OneSigmaErrorByIndex(int idx) const { 
const TMatrixD & cov = *fCovMtrx; 
return TMath::Sqrt(cov[idx][idx]); 
} 
double CorrelatedSystematics::CovMatrixElement(PhysParamId_t p1, PhysParamId_t p2) const { 
const TMatrixD & cov = *fCovMtrx; 
int idx1 = this->Param2Idx(p1); 
int idx2 = this->Param2Idx(p2); 
return cov[idx1][idx2]; 
} 
double CorrelatedSystematics::CovMatrixElementByIndex(int idx1, int idx2) const { 
const TMatrixD & cov = *fCovMtrx; 
return cov[idx1][idx2]; 
} 
void CorrelatedSystematics::Tweak( bool force_inputs, const TVectorD * input_vec , Option_t * opt ) { 

#ifdef __show_tweak_mesg_debug__ 
assert(1); 
#endif 
fIsTweaked = true; 
bool reset_to_untuned = (opt && TString(opt).Contains("untuned")); 
if (reset_to_untuned) { 
(*fCurrentValues) = (*fUntunedValues); 
return; 
} 
TVectorD & initial_values = *fInitialValues; 
TVectorD & current_values = *fCurrentValues; 
if(force_inputs) { 
if(input_vec==0) { 

#ifdef __show_tweak_mesg_debug__ 
assert(1); 
#endif 
fIsTweaked = false; 
current_values = initial_values; 
return; 
} 
else { 

#ifdef __show_tweak_mesg_debug__ 
assert(1); 
#endif 
const TVectorD & vec = *input_vec; 
assert(1); 
assert(vec.GetNoElements() == (int)fNSystParameters); 
current_values = vec; 
} 
} 
else { 

#ifdef __show_tweak_mesg_debug__ 
assert(1); 
#endif 
const TMatrixD & L = *fCovMtrxChoL; 
TVectorD vec = util::CholeskyGenerateCorrelatedParams(L,initial_values); 
current_values = vec; 
} 
return; 
} 
void CorrelatedSystematics::Tweak( bool force_inputs, const TVectorD * input_vec , const map<conv::PhysParamId_t, bool> & should_tweak, Option_t * ) { 

#ifdef __show_tweak_mesg_debug__ 
assert(1); 
#endif 
fIsTweaked = true; 
TVectorD & initial_values = *fInitialValues; 
TVectorD & current_values = *fCurrentValues; 
if(force_inputs) { 
if(input_vec==0) { 

#ifdef __show_tweak_mesg_debug__ 
assert(1); 
#endif 
fIsTweaked = false; 
current_values = initial_values; 
return; 
} 
else { 

#ifdef __show_tweak_mesg_debug__ 
assert(1); 
#endif 
TVectorD vec(*input_vec); 
assert(vec.GetNoElements() == (int)fNSystParameters); 
for (int ip = 0; ip < vec.GetNoElements() ; ip++) { 
PhysParamId_t p = this->Idx2Param(ip); 
if (!should_tweak.count(p) || !should_tweak.at(p)) { 
vec[ip]=current_values[ip]; 
} 
} 
current_values = vec; 
} 
} 
else { 

#ifdef __show_tweak_mesg_debug__ 
assert(1); 
#endif 
const TMatrixD & L = *fCovMtrxChoL; 
TVectorD vec = util::CholeskyGenerateCorrelatedParams(L,initial_values); 
for (int ip = 0; ip < vec.GetNoElements() ; ip++) { 
PhysParamId_t p = this->Idx2Param(ip); 
if (!should_tweak.count(p) || !should_tweak.at(p)) { 
vec[ip]=current_values[ip]; 
} 
} 
current_values = vec; 
} 
return; 
} 
void CorrelatedSystematics::Tweak( bool force_inputs, const TVectorD * input_vec , bool (* use_twk_param)(PhysParamId_t), Option_t * ) { 

#ifdef __show_tweak_mesg_debug__ 
assert(1); 
#endif 
fIsTweaked = true; 
TVectorD & initial_values = *fInitialValues; 
TVectorD & current_values = *fCurrentValues; 
if(force_inputs) { 
if(input_vec==0) { 

#ifdef __show_tweak_mesg_debug__ 
assert(1); 
#endif 
fIsTweaked = false; 
current_values = initial_values; 
return; 
} 
else { 

#ifdef __show_tweak_mesg_debug__ 
assert(1); 
#endif 
TVectorD vec(*input_vec); 
assert(vec.GetNoElements() == (int)fNSystParameters); 
for (int ip = 0; ip < vec.GetNoElements() ; ip++) { 
PhysParamId_t p = this->Idx2Param(ip); 
if (!use_twk_param(p)) { 
vec[ip]=current_values[ip]; 
} 
} 
current_values = vec; 
} 
} 
else { 

#ifdef __show_tweak_mesg_debug__ 
assert(1); 
#endif 
const TMatrixD & L = *fCovMtrxChoL; 
TVectorD vec = util::CholeskyGenerateCorrelatedParams(L,initial_values); 
for (int ip = 0; ip < vec.GetNoElements() ; ip++) { 
PhysParamId_t p = this->Idx2Param(ip); 
if (!use_twk_param(p)) { 
vec[ip]=current_values[ip]; 
} 
} 
current_values = vec; 
} 
return; 
} 
void CorrelatedSystematics::CholeskyDecomposeMatrix(void) { 
assert(1); 
if (fCovMtrxChoL) {delete fCovMtrxChoL; fCovMtrxChoL = NULL;} 
#ifdef __show_cholesky_mesg_info__ 
assert(1); 
#endif 
#ifdef __show_cholesky_mesg_debug__ 
assert(1); 
util::PrintMatrix(this->CovMatrix(),7,5); 
#endif 
TMatrixD L = util::CholeskyDecomposition(this->CovMatrix()); 
fCovMtrxChoL = new TMatrixD(L); 
#ifdef __show_cholesky_mesg_debug__ 
assert(1); 
util::PrintMatrix(*fCovMtrxChoL,7,5); 
#endif 
} 
double CorrelatedSystematics::ChisqPenalty(bool ) const { 
return this->FitStatisticPenalty(); 
} 
double CorrelatedSystematics::FitStatisticPenalty(Option_t * ) const { 
const TMatrixD & cov (this->CovMatrix() ); 
const TMatrixD & covInv (this->CovMatrixInv()); 
const int np = cov.GetNrows(); 
TMatrixD dev (1,np); 
TMatrixD devT (np,1); 
for(int i = 0; i < np; i++){ 
dev [0][i] = fCurrentArray[i]-fInitialArray[i]; 
devT[i][0] = fCurrentArray[i]-fInitialArray[i]; 
} 
#ifdef __show_chisqpenalty_mesg_debug__ 
assert(1); 
util::PrintVectorPair(*fCurrentValues,*fInitialValues,fSystParameters,7,5); 
#endif 
#ifdef __show_chisqpenalty_mesg_debug2__ 
assert(1); 
util::PrintMatrix(cov,7,5); 
assert(1); 
util::PrintMatrix(covInv,7,5); 
#endif 
TMatrixD chisqpenalty = dev * covInv * devT; 
double chisq_penalty = chisqpenalty[0][0]; 
#ifdef __show_chisqpenalty_mesg_debug__ 
assert(1); 
#endif 
return chisq_penalty; 
} 
void CorrelatedSystematics::PrintSystematicVariations(std::ostream & stream) const { 
for (int i = 0 ; i < fCurrentValues->GetNoElements(); i++) { 
PhysParamId_t p = fSystParameters[i]; 
stream << (*fCurrentValues)[i] << "\t" << NameRegistry::Instance()->AsString(p) << endl; 
} 
} 
int CorrelatedSystematics::Param2Idx(PhysParamId_t p) const { 
assert(p!=kPhypUndefined); 
int idx = fParam2Idx[p]; 
#ifdef __VALOR_FMWK_DEBUG_ENABLED__ 
if (idx < 0 || idx > (int)fNSystParameters) { 
assert(1); 
util::Die(-1); 
} 
#endif 
return idx; 
} 
bool CorrelatedSystematics::Contains(PhysParamId_t p) const { 
if (p==kPhypUndefined) { 
return false; 
} 
int idx = fParam2Idx[p]; 
if (idx < 0 || idx > (int)fNSystParameters) { 
return false; 
} 
return true; 
} 
conv::PhysParamId_t CorrelatedSystematics::Idx2Param (int index) const { 
assert(index >= 0 && index <= (int)fNSystParameters); 
return fSystParameters[index]; 
} 
void CorrelatedSystematics::UpdateFrom(const valor::FitParamList & fpl) { 
for (int i = 0 ; i < fInitialValues->GetNoElements() ; i++) { 
PhysParamId_t p = fSystParameters[i]; 
if (fpl.Exists(p)) { 
fCurrentArray[i] = fpl.CurrValue(p); 
} 
else { 
assert(1); 
} 
} 
fIsTweaked = true; 
return; 
} 
void CorrelatedSystematics::UpdateFrom(const valor::PhysParamList & ppl) { 
for (int i = 0 ; i < fInitialValues->GetNoElements() ; i++) { 
PhysParamId_t p = fSystParameters[i]; 
if (ppl.Contains(p)) { 
fCurrentArray[i] = ppl.Value(p); 
} 
else { 
assert(1); 
} 
} 
fIsTweaked = true; 
return; 
} 
void CorrelatedSystematics::UpdateCentralValuesAndCovarianceFromFPL(const valor::FitParamList & fpl) { 
const TMatrixDSym & fpl_cov = *(fpl.GetCovMatrix()); 
for (unsigned int i = 0 ; i < fNSystParameters ; i++) { 
PhysParamId_t p = fSystParameters[i]; 
if (fpl.Exists(p)) { 
fInitialArray [i] = fpl.CurrValue(p); 
fCurrentArray [i] = fpl.CurrValue(p); 
int ifpl = fpl.Id(p); 
for (unsigned int j = 0 ; j <= i ; j++) { 
PhysParamId_t p2 = fSystParameters[j]; 
if (fpl.Exists(p2)) { 
int jfpl = fpl.Id(p2); 
double matrix_entry = fpl_cov(ifpl,jfpl); 
(*fCovMtrx)(i,j) = matrix_entry; 
(*fCovMtrx)(j,i) = matrix_entry; 
} 
} 
} 
else { 
assert(1); 
} 
} 
assert(1); 
this->CholeskyDecomposeMatrix(); 
this->InvertMatrices(); 
} 
void CorrelatedSystematics::CopyTweaksTo(valor::PhysParamList & ppl) const { 
for (int i = 0 ; i < fCurrentValues->GetNoElements() ; i++) { 
PhysParamId_t p = fSystParameters[i]; 
ppl.SetValue(p,fCurrentArray[i]); 
} 
return; 
} 
void CorrelatedSystematics::CopyTweaksTo(valor::FitParamList & fpl) const { 
for (int i = 0 ; i < fInitialValues->GetNoElements() ; i++) { 
PhysParamId_t p = fSystParameters[i]; 
if (fpl.Exists(p)) { 
fpl.SetCurrentValue(p,fCurrentArray[i]); 
} 
else { 
assert(1); 
} 
} 
return; 
} 
void CorrelatedSystematics::CopyOneSigmaErrorsTo(valor::PhysParamList & ppl) const { 
for (int i = 0 ; i < fCurrentValues->GetNoElements() ; i++) { 
PhysParamId_t p = fSystParameters[i]; 
ppl.SetValue(p,this->OneSigmaError(p)); 
} 
return; 
} 
void CorrelatedSystematics::SetXMLNodeName(std::string xml_node_name) { 
fXMLNodeName = xml_node_name; 
} 
std::string CorrelatedSystematics::GetXMLNodeName(void) const { 
return fXMLNodeName; 
} 
unsigned int CorrelatedSystematics::Size(void) const { 
return fNSystParameters; 
} 
conv::PhysParamId_t CorrelatedSystematics::WhichParam(int idx) const { 
return fSystParameters[idx]; 
} 
bool CorrelatedSystematics::AppendParamsTo(valor::FitParamList & fpl) const { 
for (unsigned int i = 0 ; i < fNSystParameters ; i++) { 
PhysParamId_t p = fSystParameters[i]; 
double one_sig = this->OneSigmaError(p); 
double central = fInitialArray[i]; 
double pmin = central - NSIGMA_LIMIT*one_sig; 
double pmax = central + NSIGMA_LIMIT*one_sig; 
double step = 0.1 * one_sig; 
fpl.AddParam(-999,p,central,pmin,pmax,step,false,true); 
} 
return true; 
} 
void CorrelatedSystematics::SetCovMatrix(const TMatrixD & matr) { 
*fCovMtrx = matr; 
assert(1); 
this->CholeskyDecomposeMatrix(); 
this->InvertMatrices(); 
} 
void CorrelatedSystematics::InvertMatrices() { 
if (fCovMtrxInv ) {delete fCovMtrxInv ; fCovMtrxInv = NULL;} 
if (fCovMtrxChoLInv) {delete fCovMtrxChoLInv; fCovMtrxChoLInv = NULL;} 
double det; 
fCovMtrxChoLInv = new TMatrixD(*fCovMtrxChoL); 
fCovMtrxChoLInv->Invert(&det); 
assert(1); 
TMatrixD cholInvT(TMatrixD::kTransposed,*fCovMtrxChoLInv); 
fCovMtrxInv = new TMatrixD(cholInvT * (*fCovMtrxChoLInv)); 
#ifdef __matrix_invert_direct__ 
TMatrixD & cov = *fCovMtrx; 
fCovMtrxInv = new TMatrixD(cov); 
fCovMtrxInv->Invert(&det); 
assert(1); 
#elif defined(__matrix_invert_svd__) 
TMatrixD & cov = *fCovMtrx; 
fCovMtrxInv = new TMatrixD(util::MatrixPseudoInverted(cov)); 
assert(1); 
#endif 
#ifdef __check_inverse__ 
bool inv_ok = true; 
TMatrixD covTimesInverse = ( (*fCovMtrx) * (*fCovMtrxInv)); 
int np = fCovMtrx->GetNrows(); 
for (int ii = 0 ; ii < np ; ii++) { 
for (int jj = 0 ; jj < np ; jj++) { 
int target = (ii==jj); 
if (fabs(covTimesInverse[ii][jj]-target) > 1E-9) { 
assert(1); 
inv_ok = false; 
} 
} 
} 
if (!inv_ok) {util::Die(1); return;} 
fIsConfigured = fIsConfigured && inv_ok; 
#endif 
return; 
} 
ClassImp(CompoundCorrelatedSystematics) CompoundCorrelatedSystematics::CompoundCorrelatedSystematics(const vector<const CorrelatedSystematics*> & vec, string xml_node_name, std::string name) : CorrelatedSystematics() { 
this->SetNameTitle(name.c_str(),name.c_str()); 
this->CompoundInit(vec.size(),vec.data(),xml_node_name); 
return; 
} 
CompoundCorrelatedSystematics::CompoundCorrelatedSystematics(unsigned int n_cov_matrices, const CorrelatedSystematics * const * syst_objs, string xml_node_name, std::string name) : CorrelatedSystematics() { 
this->SetNameTitle(name.c_str(),name.c_str()); 
this->CompoundInit(n_cov_matrices,syst_objs,xml_node_name); 
return; 
} 
void CompoundCorrelatedSystematics::CompoundInit(unsigned int n_cov_matrices, const CorrelatedSystematics * const * syst_objs, string xml_node_name) { 
assert(1); 
unsigned int total_elements = 0; 
for (unsigned int icov = 0 ; icov < n_cov_matrices ; icov++) { 
const CorrelatedSystematics * corr = syst_objs[icov]; 
if (!corr) { 
assert(1); 
util::Die(-1);return; 
} 
if (!(corr->IsConfigured())) { 
assert(1); 
util::Die(-1);return; 
} 
total_elements += corr->Size(); 
} 
assert(1); 
std::vector<const TMatrixD *> all_cov_matrices; 
std::vector<const TVectorD *> all_untuned_vectors; 
std::vector<const TVectorD *> all_initial_vectors; 
std::vector<const TVectorD *> all_current_vectors; 
PhysParamId_t * params = new PhysParamId_t[total_elements]; 
int iparam = 0; 
for (unsigned int icov = 0 ; icov < n_cov_matrices ; icov++) { 
const CorrelatedSystematics * corr = syst_objs[icov]; 
for (unsigned int ip = 0 ; ip < corr->Size(); ip++) { 
params[iparam++] = corr->WhichParam(ip); 
} 
all_cov_matrices .push_back(&(corr->CovMatrix ())); 
all_untuned_vectors.push_back(&(corr->UntunedValues())); 
all_initial_vectors.push_back(&(corr->InitialValues())); 
all_current_vectors.push_back(&(corr->CurrentValues())); 
} 
this->Init(total_elements, params, xml_node_name); 
delete[] params; 
fCovMtrx = new TMatrixD(util::ConcatenateTMatrices(all_cov_matrices)); 
(*fUntunedValues) = util::ConcatenateTVectors(all_untuned_vectors); 
(*fInitialValues) = util::ConcatenateTVectors(all_initial_vectors); 
(*fCurrentValues) = util::ConcatenateTVectors(all_current_vectors); 
this->CholeskyDecomposeMatrix(); 
this->InvertMatrices(); 
fXMLNodeName = xml_node_name; 
fIsConfigured = true; 
return; 
} 
CompoundCorrelatedSystematics::~CompoundCorrelatedSystematics() { 
} 
CompoundFitData::CompoundFitData() { 
fName = "UninitialisedCompoundFitData"; 
} 
CompoundFitData::~CompoundFitData() { 
for (FitDataABC *& d : fSubData) { 
delete d; d = 0; 
} 
} 
std::string CompoundFitData::Name() const { 
return fName; 
} 
bool CompoundFitData::Read(string file, Option_t * ) { 
bool status = true; 
TXMLEngine* xml = new TXMLEngine; 
XMLDocPointer_t xmldoc = xml->ParseFile(file.c_str()); 
if (xmldoc==0) { 
assert(1); 
delete xml; 
util::Die(1); return false; 
} 
XMLNodePointer_t root_node = xml->DocGetRootElement(xmldoc); 
for ( XMLNodePointer_t curr_node = util::FindNode(xml,root_node,"data"); 
(!(xml->IsEmptyNode(curr_node))); 
curr_node = xml->GetNext(curr_node) ) { 
string data_name = util::XML2String(xml,curr_node,"name"); 
string class_name = util::XML2String(xml,curr_node,"class"); 
TString config_path = util::XML2String(xml,curr_node,"config"); 
gSystem->ExpandPathName(config_path); 
TClass * curr_class = TClass::GetClass(class_name.c_str()); 
if (!curr_class) { 
assert(1); 
status = false; 
continue; 
} 
void * curr_obj = curr_class->New(); 
FitDataABC * curr_data = static_cast<FitDataABC*>(curr_obj); 
if (!curr_data) { 
assert(1); 
status = false; 
continue; 
} 
status = status && curr_data->Read(config_path.Data()); 
fSubData.push_back(curr_data); 
} 
if (not status) { 
assert(1); 
util::Die(-1); 
} 
return status; 
} 
bool CompoundFitData::Generate (FitModelABC * model, const PhysHypothesis & ph, bool stat_fluct) { 
CompoundFitModel * cfm = dynamic_cast<CompoundFitModel*>(model); 
#ifdef __VALOR_FMWK_PARALLEL__ 
std::atomic_bool status(true); 
#else 
bool status = true; 
#endif 
int ientry = 0; 
for (std::vector<FitDataABC*>::iterator it = fSubData.begin(); it != fSubData.end(); ++it,++ientry) { 
FitDataABC & d = **it; 
FitModelABC & m = *(cfm ? cfm->GetSubModel(ientry) : model); 
#ifdef __VALOR_FMWK_PARALLEL__ 
std::function<void(void)> f = [&]{status = status && d.Generate(&m, ph, stat_fluct);}; 
util::VThreadPool::Instance()->AddTask(f); 
#else 
status = status && d.Generate(&m, ph, stat_fluct); 
#endif 
} 
#ifdef __VALOR_FMWK_PARALLEL__ 
util::VThreadPool::Instance()->Wait(); 
#endif 
return status; 
} 
bool CompoundFitData::Generate (FitModelABC * model, const FitParamList & fp, bool stat_fluct) { 
CompoundFitModel * cfm = dynamic_cast<CompoundFitModel*>(model); 
#ifdef __VALOR_FMWK_PARALLEL__ 
std::atomic_bool status(true); 
#else 
bool status = true; 
#endif 
int ientry = 0; 
for (std::vector<FitDataABC*>::iterator it = fSubData.begin(); it != fSubData.end(); ++it,++ientry) { 
FitDataABC & d = **it; 
FitModelABC & m = *(cfm ? cfm->GetSubModel(ientry) : model); 
#ifdef __VALOR_FMWK_PARALLEL__ 
std::function<void(void)> f = [&]{status = status && d.Generate(&m, fp, stat_fluct);}; 
util::VThreadPool::Instance()->AddTask(f); 
#else 
status = status && d.Generate(&m, fp, stat_fluct); 
#endif 
} 
#ifdef __VALOR_FMWK_PARALLEL__ 
util::VThreadPool::Instance()->Wait(); 
#endif 
return status; 
} 
bool CompoundFitData::Generate (FitModelABC * model, bool stat_fluct) { 
CompoundFitModel * cfm = dynamic_cast<CompoundFitModel*>(model); 
#ifdef __VALOR_FMWK_PARALLEL__ 
std::atomic_bool status(true); 
#else 
bool status = true; 
#endif 
int ientry = 0; 
for (std::vector<FitDataABC*>::iterator it = fSubData.begin(); it != fSubData.end(); ++it,++ientry) { 
FitDataABC & d = **it; 
FitModelABC & m = *(cfm ? cfm->GetSubModel(ientry) : model); 
#ifdef __VALOR_FMWK_PARALLEL__ 
std::function<void(void)> f = [&]{status = status && d.Generate(&m, stat_fluct);}; 
util::VThreadPool::Instance()->AddTask(f); 
#else 
status = status && d.Generate(&m, stat_fluct); 
#endif 
} 
#ifdef __VALOR_FMWK_PARALLEL__ 
util::VThreadPool::Instance()->Wait(); 
#endif 
return status; 
} 
bool CompoundFitData::Write (TObjArray* collection, const char * tag, Option_t * write_opt) { 
bool status = true; 
for (std::vector<FitDataABC*>::iterator it = fSubData.begin(); it != fSubData.end(); ++it) { 
status = status && (*it)->Write(collection,tag,write_opt); 
} 
return status; 
} 
double CompoundFitData::GetFitStatistic (FitModelABC * model, const PhysHypothesis & ph, Option_t * opt, std::map<std::string,double> * likelihood_components) { 
double statistic = 0; 
CompoundFitModel * cfm = dynamic_cast<CompoundFitModel*>(model); 
if (!cfm) {util::Die(-1);return conv::kBadResult;} 
model->Generate(ph,opt); 
for (unsigned int imodel = 0; imodel < fSubData.size() ; imodel++) { 
statistic += fSubData[imodel]->GetFitStatistic(cfm->GetSubModel(imodel), opt, likelihood_components); 
} 
assert(1); 
return statistic; 
} 
double CompoundFitData::GetFitStatistic (FitModelABC * model, const FitParamList & fp, Option_t * opt, std::map<std::string,double> * likelihood_components ) { 
double statistic = 0; 
CompoundFitModel * cfm = dynamic_cast<CompoundFitModel*>(model); 
if (!cfm) {util::Die(-1);return conv::kBadResult;} 
model->Generate(fp,opt); 
for (unsigned int imodel = 0; imodel < fSubData.size() ; imodel++) { 
statistic += fSubData[imodel]->GetFitStatistic(cfm->GetSubModel(imodel), opt, likelihood_components); 
} 
assert(1); 
return statistic; 
} 
double CompoundFitData::GetFitStatistic (FitModelABC * model, Option_t * opt, std::map<std::string,double> * likelihood_components ) { 
double statistic = 0; 
CompoundFitModel * cfm = dynamic_cast<CompoundFitModel*>(model); 
if (!cfm) {util::Die(-1);return conv::kBadResult;} 
for (unsigned int imodel = 0; imodel < fSubData.size() ; imodel++) { 
statistic += fSubData[imodel]->GetFitStatistic(cfm->GetSubModel(imodel), opt, likelihood_components); 
} 
assert(1); 
return statistic; 
} 
int CompoundFitData::NumOfBins(Option_t * ) const { 
int nbins = 0; 
for (std::vector<FitDataABC*>::const_iterator it = fSubData.begin(); it != fSubData.end(); ++it) { 
nbins += (*it)->NumOfBins(); 
} 
assert(1); 
return nbins; 
} 
bool CompoundFitData::Write (const char * filename, const char * tag, Option_t * write_opt, Option_t * file_opt) { 
assert(1); 
TObjArray * array = new TObjArray(); 
bool status = this->Write(array,tag,write_opt); 
Option_t * used_file_opt = (file_opt == 0) ? "recreate" : file_opt; 
TFile f(filename, used_file_opt); 
array->Write(); 
f.Close(); 
return status; 
} 
void CompoundFitData::AddSubData(FitDataABC * data, Option_t * ) { 
fSubData.push_back(data); 
return; 
} 
const FitDataABC * CompoundFitData::GetSubData(int data_idx, Option_t * ) const { 
return fSubData.at(data_idx); 
} 
FitDataABC * CompoundFitData::GetSubData(int data_idx, Option_t * ) { 
return fSubData.at(data_idx); 
} 
unsigned int CompoundFitData::GetNSubData(Option_t * ) const { 
return fSubData.size(); 
} 
void CompoundFitData::SetName(std::string name) { 
fName = name; 
} 
CompoundFitModel::CompoundFitModel() : fSystematics(0), fOwnerOfSystematics(false) { 
fName = "UninitialisedCompoundFitModel"; 
} 
CompoundFitModel::~CompoundFitModel() { 
if (fSystematics && fOwnerOfSystematics) { delete fSystematics; } 
for (FitModelABC *& m : fSubModels) { 
delete m; m=0; 
} 
} 
std::string CompoundFitModel::Name() const { 
return fName; 
} 
bool CompoundFitModel::Read(string file, Option_t * opt) { 
bool status = true; 
TXMLEngine* xml = new TXMLEngine; 
XMLDocPointer_t xmldoc = xml->ParseFile(file.c_str()); 
if (xmldoc==0) { 
assert(1); 
delete xml; 
util::Die(1); return false; 
} 
XMLNodePointer_t root_node = xml->DocGetRootElement(xmldoc); 
for ( XMLNodePointer_t curr_node = util::FindNode(xml,root_node,"model"); 
(!(xml->IsEmptyNode(curr_node))); 
curr_node = xml->GetNext(curr_node) ) { 
string model_name = util::XML2String(xml,curr_node,"name"); 
string class_name = util::XML2String(xml,curr_node,"class"); 
TString config_path = util::XML2String(xml,curr_node,"config"); 
gSystem->ExpandPathName(config_path); 
TClass * curr_class = TClass::GetClass(class_name.c_str()); 
if (!curr_class) { 
assert(1); 
status = false; 
continue; 
} 
void * curr_obj = curr_class->New(); 
FitModelABC * curr_model = static_cast<FitModelABC*>(curr_obj); 
if (!curr_model) { 
assert(1); 
status = false; 
continue; 
} 
status = curr_model->Read(config_path.Data(), opt); 
fSubModels.push_back(curr_model); 
} 
if (not status) { util::Die(-1); } 
assert(1); 
return status; 
} 
bool CompoundFitModel::Generate (const PhysHypothesis & ph, Option_t * opt) { 
bool status = true; 
#ifdef __VALOR_FMWK_PARALLEL__ 
std::atomic_bool astat(status); 
for (std::vector<FitModelABC*>::iterator it = fSubModels.begin(); it != fSubModels.end(); ++it) { 
FitModelABC & m = **it; 
std::function<void(void)> f = [&]{astat = astat && m.Generate(ph,opt);}; 
util::VThreadPool::Instance()->AddTask(f); 
} 
util::VThreadPool::Instance()->Wait(); 
status = astat; 
#else 
for (std::vector<FitModelABC*>::iterator it = fSubModels.begin(); it != fSubModels.end(); ++it) { 
status = status && (*it)->Generate(ph,opt); 
} 
#endif 
return status; 
} 
bool CompoundFitModel::Generate (const FitParamList & fp, Option_t * opt) { 
bool status = true; 
if (fSystematics) { 
fSystematics->UpdateFrom(fp); 
status = this->Generate(PhysHypothesis(fp),opt); 
} 
else { 
#ifdef __VALOR_FMWK_PARALLEL__ 
std::atomic_bool astat(status); 
for (std::vector<FitModelABC*>::iterator it = fSubModels.begin(); it != fSubModels.end(); ++it) { 
FitModelABC & m = **it; 
std::function<void(void)> f = [&]{astat = astat && m.Generate(fp,opt);}; 
util::VThreadPool::Instance()->AddTask(f); 
} 
util::VThreadPool::Instance()->Wait(); 
status = astat; 
#else 
for (std::vector<FitModelABC*>::iterator it = fSubModels.begin(); it != fSubModels.end(); ++it) { 
status = status && (*it)->Generate(fp,opt); 
} 
#endif 
} 
return status; 
} 
void CompoundFitModel::RandomizeSystematics (Option_t * opt) { 
if (fSystematics) { 
fSystematics->Tweak(false, NULL,opt); 
} 
else { 
for (std::vector<FitModelABC*>::iterator it = fSubModels.begin(); it != fSubModels.end(); ++it) { 
(*it)->RandomizeSystematics(opt); 
} 
} 
} 
void CompoundFitModel::RandomizeSystematics (bool (*should_randomize)(conv::PhysParamId_t), Option_t * opt) { 
if (fSystematics) { 
fSystematics->Tweak(false, NULL, should_randomize, opt); 
} 
else { 
for (std::vector<FitModelABC*>::iterator it = fSubModels.begin(); it != fSubModels.end(); ++it) { 
(*it)->RandomizeSystematics(should_randomize, opt); 
} 
} 
} 
void CompoundFitModel::RandomizeSystematics (std::map<valor::conv::PhysParamId_t, bool> should_randomize, Option_t * opt) { 
if (fSystematics) { 
fSystematics->Tweak(false, NULL, should_randomize, opt); 
} 
else { 
for (std::vector<FitModelABC*>::iterator it = fSubModels.begin(); it != fSubModels.end(); ++it) { 
(*it)->RandomizeSystematics(should_randomize, opt); 
} 
} 
} 
void CompoundFitModel::TweakSystematic (string syst_name, double twkdial, Option_t * opt) { 
assert(!"Not implemented"); 
(void)syst_name; 
PhysParamId_t syst = conv::kPhypUndefined; 
this->TweakSystematic(syst,twkdial,opt); 
} 
void CompoundFitModel::TweakSystematic (conv::PhysParamId_t syst, double twkdial, Option_t * opt) { 
if (fSystematics) { 
fSystematics->SetCurrentValue(syst, twkdial); 
} 
else { 
for (std::vector<FitModelABC*>::iterator it = fSubModels.begin(); it != fSubModels.end(); ++it) { 
(*it)->TweakSystematic(syst, twkdial, opt); 
} 
} 
} 
void CompoundFitModel::ResetSystematics (Option_t * opt) { 
if (fSystematics) { 
fSystematics->Tweak(true,NULL); 
} 
else { 
for (std::vector<FitModelABC*>::iterator it = fSubModels.begin(); it != fSubModels.end(); ++it) { 
(*it)->ResetSystematics(opt); 
} 
} 
return; 
} 
void CompoundFitModel::PrintSystematics (std::ostream & stream, Option_t * opt) const { 
if (fSystematics) { 
fSystematics->Print(opt); 
} 
else { 
for (std::vector<FitModelABC*>::const_iterator it = fSubModels.begin(); it != fSubModels.end(); ++it) { 
(*it)->PrintSystematics(stream,opt); 
} 
} 
return; 
} 
PhysParamList CompoundFitModel::Tweaks(Option_t * opt) const { 
PhysParamList ppl; 
if (fSystematics) { 
fSystematics->CopyTweaksTo(ppl); 
} 
else { 
for (std::vector<FitModelABC*>::const_iterator it = fSubModels.begin(); it != fSubModels.end(); ++it) { 
PhysParamList ppl2 = (*it)->Tweaks(); 
ppl.MergeFrom(ppl2,opt); 
} 
} 
return ppl; 
} 
bool CompoundFitModel::Write (TObjArray* collection, const char * tag, Option_t * write_opt) { 
bool status = true; 
for (std::vector<FitModelABC*>::iterator it = fSubModels.begin(); it != fSubModels.end(); ++it) { 
status = status && (*it)->Write(collection,tag,write_opt); 
} 
return status; 
} 
bool CompoundFitModel::Write (const char * filename, const char * tag, Option_t * write_opt, Option_t * file_opt) { 
assert(1); 
TObjArray * array = new TObjArray(); 
bool status = this->Write(array,tag,write_opt); 
Option_t * used_file_opt = (file_opt == 0) ? "recreate" : file_opt; 
TFile f(filename, used_file_opt); 
array->Write(); 
f.Close(); 
return status; 
} 
double CompoundFitModel::GetFitStatisticPenalty(Option_t * opt) const { 
if (fSystematics) { 
return fSystematics->FitStatisticPenalty(opt); 
} 
assert(1); 
double fitstat = 0; 
for (std::vector<FitModelABC*>::const_iterator it = fSubModels.begin(); it != fSubModels.end(); ++it) { 
fitstat+= (*it)->GetFitStatisticPenalty(opt); 
} 
return fitstat; 
} 
void CompoundFitModel::AddSubModel(FitModelABC * model, Option_t * ) { 
fSubModels.push_back(model); 
return; 
} 
const FitModelABC * CompoundFitModel::GetSubModel(int model_idx, Option_t * ) const { 
return fSubModels.at(model_idx); 
} 
FitModelABC * CompoundFitModel::GetSubModel(int model_idx, Option_t * ) { 
return fSubModels.at(model_idx); 
} 
unsigned int CompoundFitModel::GetNSubModels(Option_t * ) const { 
return fSubModels.size(); 
} 
CorrelatedSystematics * CompoundFitModel::GetSystematics(Option_t * ) { 
return fSystematics; 
} 
const CorrelatedSystematics * CompoundFitModel::GetSystematics(Option_t * ) const { 
return fSystematics; 
} 
void CompoundFitModel::SetSystConf(CorrelatedSystematics * syst, Option_t * opt) { 
TString ts(opt); 
if (ts.Contains("copy") ) { 
fSystematics = dynamic_cast<CorrelatedSystematics *>(syst->Clone()); 
fOwnerOfSystematics = true; 
} 
else { 
fSystematics = syst; 
fOwnerOfSystematics = ts.Contains("adopt"); 
} 
for (std::vector<FitModelABC*>::iterator it = fSubModels.begin(); it != fSubModels.end(); ++it) { 
(*it)->SetSystConf(syst,""); 
} 
return; 
} 
void CompoundFitModel::SetName(std::string name) { 
fName = name; 
} 
#define __show_fit_result__ 
#define __show_fit_steps__ 
FitterMinuit::FitterMinuit() : FitterABC() { 
this->Init(); 
} 
FitterMinuit::FitterMinuit(FitInputs * fit_inputs, Option_t * option) : FitterABC() { 
this->Init(fit_inputs, option); 
} 
FitterMinuit::~FitterMinuit() { 
} 
void FitterMinuit::Init(void) { 
fFitInputs = 0; 
fOption = ""; 
fNFreeFitParams = 0; 
fNFitBins = 0; 
fCalcHesseErrors = false; 
fCalcMinosErrors = false; 
fTol = 0.1; 
fStr = 1; 
fPrintLevel = -1; 
fMaxNumCalls = 100000; 
fMigradMinStatusCode = -999; 
fMigradErrStatusCode = -999; 
fHesseErrStatusCode = -999; 
fMinosErrStatusCode = -999; 
fFitTime = 0; 
fFitTries = 0; 
} 
void FitterMinuit::Init(FitInputs * fit_inputs, Option_t * option) { 
assert(1); 
this->Init(); 
fFitInputs = fit_inputs; 
if(!fFitInputs) { 
assert(1); 
exit(1); 
} 
FitParamList & fit_params = fFitInputs->FitParams(); 
int param_list_size = fit_params.Size(); 
assert(1); 
fOption = option; 
fCalcHesseErrors = fOption.Contains("hesse"); 
fCalcMinosErrors = fOption.Contains("minos"); 
if(fOption.Contains("minuit")) { 
TVirtualFitter::SetDefaultFitter("Minuit"); 
TVirtualFitter * fitter = TVirtualFitter::Fitter(0,param_list_size); 
Double_t arglist[5]; 
arglist[0] = fPrintLevel; 
fitter->ExecuteCommand("SET PRINT",arglist,1); 
fit_params.SetTo(fitter); 
fitter->SetFCN(FitFunc); 
} 
if(fOption.Contains("tolerance",TString::kIgnoreCase)) { 
TPRegexp tol_re("(?<=tolerance\\=)-?[\\d.]+(?:e-?\\d+)?"); 
TObjArray * matches = tol_re.MatchS(fOption,"i"); 
double tolerance = 0; 
if(matches->GetEntries()==1) { 
TObjString * tolerance_string = dynamic_cast<TObjString*>(matches->At(0)); 
if (tolerance_string) { 
tolerance = strtod(tolerance_string->GetString().Data(),NULL); 
} 
} 
delete matches; 
if (tolerance > conv::kAVerySmallNum) { 
assert(1); 
this->SetTol(tolerance); 
} 
else { 
assert(1); 
} 
} 
if(fOption.Contains("maxcalls",TString::kIgnoreCase)) { 
TPRegexp call_re("(?<=maxcalls\\=)-?[\\d.]+(?:e-?\\d+)?"); 
TObjArray * matches = call_re.MatchS(fOption,"i"); 
double maxcalls = 0; 
if(matches->GetEntries()==1) { 
TObjString * maxcalls_string = dynamic_cast<TObjString*>(matches->At(0)); 
if (maxcalls_string) { 
maxcalls = strtod(maxcalls_string->GetString().Data(),NULL); 
} 
} 
delete matches; 
if (maxcalls > conv::kAVerySmallNum) { 
int ncalls = TMath::Nint(maxcalls); 
assert(1); 
this->SetMaxCalls(ncalls); 
} 
else { 
assert(1); 
} 
} 
fNFitBins = fit_inputs->Observation().NumOfBins(); 
fNFreeFitParams = fit_params.GetNumberFreeParameters(); 
if(fNFitBins <= 0) { 
assert(1); 
util::Die(-1); 
return; 
} 
assert(fNFitBins > 0); 
assert(fNFreeFitParams >= 0); 
assert(1); 
} 
bool FitterMinuit::Configure(const Registry & conf) { 
assert(1); 
return true; 
} 
bool FitterMinuit::DoTheFit(void) { 
TStopwatch w; 
w.Start(); 
fFitTime = 0; 
fFitTries = -1; 
FitParamList & fit_params = fFitInputs->FitParams(); 
int param_list_size = fit_params.Size(); 
TVirtualFitter * fitter = TVirtualFitter::Fitter(0,param_list_size); 
Double_t arglist[5]; 
arglist[0] = fPrintLevel; 
fitter->ExecuteCommand("SET PRINT",arglist,1); 
fit_params.SetTo(fitter); 
fitter->SetFCN(FitFunc); 
fit_params.SetFitTime(-999); 
fit_params.SetBestFitStatistic(-999); 
fit_params.ClearStatusCodes(); 
bool ok = this->RunOnce(false); 
fFitTries = 1; 
if(fMigradMinStatusCode == 4) { 
assert(1); 
if( fOption.Contains("with_simplex_fallback") ) { 
assert(1); 
this->RunOnce(true); 
fFitTries++; 
} 
} 
w.Stop(); 
fFitTime = w.CpuTime(); 
std::map<std::string, double> likelihood_contributions; 
assert(1); 
assert(1); 
fit_params.SetFitTime (fFitTime); 
fit_params.SetFitTries(fFitTries); 
fit_params.SetStatusCode("migrad_min", fMigradMinStatusCode); 
fit_params.SetStatusCode("migrad_err", fMigradErrStatusCode); 
if(fCalcHesseErrors) { 
fit_params.SetStatusCode("hesse_err", fHesseErrStatusCode); 
} 
if(fCalcMinosErrors) { 
fit_params.SetStatusCode("minos_err", fMinosErrStatusCode); 
} 
return ok; 
} 
bool FitterMinuit::RunOnce(bool use_simplex) { 
fHesseErrStatusCode = -1; 
double fcntemp; 
FitParamList & fp = fFitInputs->FitParams(); 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
TVirtualFitter * fitter = TVirtualFitter::GetFitter(); 
Double_t arg[5]; 
arg[0] = fStr; 
fitter->ExecuteCommand("SET STRategy",arg,1); 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
gMinuit->SetObjectFit(fFitInputs); 
fitter->ExecuteCommand("SHO EPS", arg, 1); 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
Double_t arglist[100]; 
arglist[0] = fMaxNumCalls; 
arglist[1] = fTol; 
if(!use_simplex) { 
fMigradMinStatusCode = fitter->ExecuteCommand("MIGRAD",arglist, 2); 
} 
else { 
arglist[1] = 0.1; 
fMigradMinStatusCode = fitter->ExecuteCommand("SIMPLEX",arglist, 2); 
} 
if(fMigradMinStatusCode == 4 && !use_simplex) return false; 
else if(fMigradMinStatusCode == 4 && use_simplex) { 
fp.CopyCurrToBestFitValues(); 
return false; 
} 
int num_of_params = fp.GetNumberParameters(); 
for(int ip = 0; ip < num_of_params; ip++) { 
double value, error; 
gMinuit->GetParameter(ip, value, error); 
PhysParamId_t p = fp.WhichParam(ip); 
fp.Update(p, value, true); 
} 
fp.CopyCurrToBestFitValues(); 
std::map<std::string,double> stat_contrib; 
(void)fFitInputs->Statistic("likelihood_ratio",&stat_contrib); 
fp.SetBestFitStatisticContributions(stat_contrib); 
#ifdef __show_fit_result__ 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
fitter->ExecuteCommand("SHOW FCNVALUE",&fcntemp,0); 
Double_t aminn = 0; 
fitter->PrintResults(3,aminn); 
#endif 
TMatrixDSym cov(num_of_params); 
int ifree = 0; 
int jfree = 0; 
for(int i = 0; i<num_of_params; i++) { 
if (!fp.IsFixedByIndex(i)) { 
for(int j = 0; j<num_of_params; j++) { 
if (!fp.IsFixedByIndex(j)) { 
double scaling = fp.ParameterScalingByIndex(i)*fp.ParameterScalingByIndex(j); 
cov[i][j] = fitter->GetCovarianceMatrixElement(ifree,jfree)/scaling; 
jfree++; 
} 
} 
jfree = 0; 
ifree++; 
} 
} 
const CompoundFitModel * cm = dynamic_cast<CompoundFitModel*>(&fFitInputs->Expectation()); 
if (cm) { 
for (int i = 0; i < num_of_params; i++) { 
if (!fp.IsFixedByIndex(i)) {continue;} 
PhysParamId_t p = fp.WhichParam(i); 
if (cm->GetSystematics()->Contains(p)) { 
cov[i][i] = cm->GetSystematics()->CovMatrixElement(p,p); 
} 
} 
} 
fp.SetCovMatrix(cov); 
double unfilled = -999; 
vector<double> migrad_err (num_of_params, unfilled); 
vector<double> hesse_err (num_of_params, unfilled); 
vector<double> minos_err_minus(num_of_params, unfilled); 
vector<double> minos_err_plus (num_of_params, unfilled); 
for (int ip = 0 ; ip < num_of_params ; ip++) { 
migrad_err[ip] = fitter->GetParError(ip)/fp.ParameterScalingByIndex(ip); 
} 
fp.SetMigradErrors(migrad_err); 
double ha(0.0); 
double edm, errdef; 
int nvpar, nparx; 
int errMatrixStatus = fitter->GetStats(ha, edm, errdef, nvpar, nparx); 
fMigradErrStatusCode = errMatrixStatus; 
if(fCalcHesseErrors) { 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
fitter->ExecuteCommand("HESSE",arglist, 1); 
errMatrixStatus = fitter->GetStats(ha, edm, errdef, nvpar, nparx); 
fHesseErrStatusCode = errMatrixStatus; 
for (int ip = 0 ; ip < num_of_params ; ip++) { 
hesse_err[ip] = fitter->GetParError(ip)/fp.ParameterScalingByIndex(ip); 
} 
fp.SetHesseErrors (hesse_err); 
} 
if(fCalcMinosErrors) { 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
fMinosErrStatusCode = fitter->ExecuteCommand("MINOS",arglist, 1); 
} 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
errMatrixStatus = fitter->GetStats(ha, edm, errdef, nvpar, nparx); 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
if(fCalcMinosErrors) { 
for(int ip = 0; ip < num_of_params; ip++) { 
double glob_corr, parerr; 
fitter->GetErrors(ip, minos_err_plus[ip], minos_err_minus[ip],parerr,glob_corr); 
} 
fp.SetMinosErrors (minos_err_plus, minos_err_minus); 
} 
if(fCalcHesseErrors) { 
#ifdef __show_fit_result__ 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
Double_t amin = 0; 
fitter->PrintResults(3,amin); 
} 
assert(1); 
#endif 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
return true; 
} 
int FitterMinuit::FitStatusCode (Option_t * option) const { 
if(!option) return 9999; 
TString opt(option); 
if ( opt.Contains("migrad_min") ) return fMigradMinStatusCode; 
if ( opt.Contains("migrad_err") ) return fMigradErrStatusCode; 
if ( opt.Contains("hesse_err") ) return fHesseErrStatusCode; 
if ( opt.Contains("minos_err") ) return fMinosErrStatusCode; 
return -999; 
} 
#define __show_fit_init_info__ 
#define __show_fit_result__ 
#define __show_fit_steps__ 
#define __show_fit_cpu_time__ 
#define __give_fitter_covariance_matrix__ 
FitterMinuit2::FitterMinuit2() : FitterABC() { 
this->Init(); 
} 
FitterMinuit2::FitterMinuit2(FitInputs * fit_inputs, Option_t * option) : FitterABC() { 
this->Init(fit_inputs, option); 
} 
FitterMinuit2::~FitterMinuit2() { 
} 
void FitterMinuit2::Init(void) { 
fFitInputs = 0; 
fOption = ""; 
fNFitBins = 0; 
fCalcHesseErrors = false; 
fCalcMinosErrors = false; 
fTol = 0.1; 
fStr = 1; 
fMaxNumCalls = 100000; 
fMigradMinStatusCode = -999; 
fMigradErrStatusCode = -999; 
fHesseErrStatusCode = -999; 
fMinosErrStatusCode = -999; 
fFitTime = 0; 
fFitTries = 0; 
fUseFumili = false; 
} 
void FitterMinuit2::Init(FitInputs * fit_inputs, Option_t * option) { 
assert(1); 
this->Init(); 
fFitInputs = fit_inputs; 
if(!fFitInputs) { 
assert(1); 
exit(1); 
} 
FitParamList & fit_params = fFitInputs->FitParams(); 
int param_list_size = fit_params.Size(); 
assert(1); 
fOption = option; 
fCalcHesseErrors = fOption.Contains("hesse"); 
fCalcMinosErrors = fOption.Contains("minos"); 
fUseFumili = fOption.Contains("fumili"); 
#ifdef __show_fit_init_info__ 
assert(1); 
#endif 
fit_params.SetTo(fUserParams); 
assert(1); 
if(fOption.Contains("tolerance",TString::kIgnoreCase)) { 
TPRegexp tol_re("(?<=tolerance\\=)-?[\\d.]+(?:e-?\\d+)?"); 
TObjArray * matches = tol_re.MatchS(fOption,"i"); 
double tolerance = 0; 
if(matches->GetEntries()==1) { 
TObjString * tolerance_string = dynamic_cast<TObjString*>(matches->At(0)); 
if (tolerance_string) { 
tolerance = strtod(tolerance_string->GetString().Data(),NULL); 
} 
} 
delete matches; 
if (tolerance > conv::kAVerySmallNum) { 
assert(1); 
this->SetTol(tolerance); 
} 
else { 
assert(1); 
} 
} 
if(fOption.Contains("maxcalls",TString::kIgnoreCase)) { 
TPRegexp call_re("(?<=maxcalls\\=)-?[\\d.]+(?:e-?\\d+)?"); 
TObjArray * matches = call_re.MatchS(fOption,"i"); 
double maxcalls = 0; 
if(matches->GetEntries()==1) { 
TObjString * maxcalls_string = dynamic_cast<TObjString*>(matches->At(0)); 
if (maxcalls_string) { 
maxcalls = strtod(maxcalls_string->GetString().Data(),NULL); 
} 
} 
delete matches; 
if (maxcalls > conv::kAVerySmallNum) { 
int ncalls = TMath::Nint(maxcalls); 
assert(1); 
this->SetMaxCalls(ncalls); 
} 
else { 
assert(1); 
} 
} 
fNFitBins = fit_inputs->Observation().NumOfBins(); 
int n_free_params = fit_params.GetNumberFreeParameters(); 
assert(fNFitBins > 0); 
assert(n_free_params >= 0); 
assert(1); 
} 
bool FitterMinuit2::Configure(const Registry & conf) { 
assert(1); 
return true; 
} 
void FitterMinuit2::FillPriorCovMatrix(Option_t * ) { 
assert(1); 
const FitParamList & fp = fFitInputs->FitParams(); 
int num_of_params = fp.GetNumberParameters(); 
int num_of_free_params = fp.GetNumberFreeParameters(); 
fCovMtrx.ResizeTo(num_of_free_params,num_of_free_params); 
const CompoundFitModel * cm = dynamic_cast<CompoundFitModel*>(&fFitInputs->Expectation()); 
if (cm) { 
const TMatrixD & full_cov = cm->GetSystematics()->CovMatrix(); 
int ifree = 0; 
for (int i = 0 ; i < num_of_params ; i++) { 
if (fp.IsFixedByIndex(i)) {continue;} 
int jfree = 0; 
for (int j = 0 ; j < num_of_params ; j++) { 
if (fp.IsFixedByIndex(j)) {continue;} 
fCovMtrx[ifree][jfree] = full_cov[i][j]; 
jfree++; 
} 
ifree++; 
} 
} 
else { 
assert(!"Not supporting creating prior cov matrix without CFM model yet"); 
} 
} 
bool FitterMinuit2::DoTheFit(void) { 

#ifdef __show_fit_cpu_time__ 
TStopwatch w; 
w.Start(); 
#endif 
fFitTime = 0; 
bool ok = this->RunOnce(); 
#ifdef __show_fit_cpu_time__ 
w.Stop(); 
assert(1); 
fFitTime = w.CpuTime(); 
#endif 
return ok; 
} 
bool FitterMinuit2::RunOnce(void) { 
FitParamList & fp = fFitInputs->FitParams(); 
unsigned int nfreeparams = (unsigned int)fp.GetNumberFreeParameters(); 
unsigned int nparams = (unsigned int)fp.GetNumberParameters(); 
vector<double> bestfit_free; 
vector<double> err_migrad_cov; 
vector<double> err_migrad_err; 
vector<double> err_hesse_cov; 
vector<double> err_hesse_err; 
vector<double> err_minosplus; 
vector<double> err_minosminus; 
ROOT::Minuit2::MnStrategy strategy(fStr); 
#ifdef __give_fitter_covariance_matrix__ 
this->FillPriorCovMatrix(); 
ROOT::Minuit2::MnUserCovariance input_cov(nfreeparams); 
for(unsigned int i = 0; i < nfreeparams; i++) { 
for(unsigned int j = 0; j < nfreeparams; j++) { 
input_cov(i,j) = fCovMtrx(i,j); 
} 
} 
#ifdef __show_fit_cov_matrix_debug__ 
assert(1); 
assert(1); 
#endif 
#endif 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
ROOT::Minuit2::MnApplication * mnapp = NULL; 
if (!fUseFumili) { 
#ifdef __give_fitter_covariance_matrix__ 
mnapp = new ROOT::Minuit2::MnMigrad(*fFitInputs, fUserParams, input_cov); 
#else 
mnapp = new ROOT::Minuit2::MnMigrad(*fFitInputs, fUserParams); 
#endif 
} 
else { 
assert(!"Fumili still has issues"); 
#ifdef __give_fitter_covariance_matrix__ 
#else 
#endif 
} 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
ROOT::Minuit2::FunctionMinimum bestfit = (*mnapp)(fMaxNumCalls, fTol); 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
fMigradMinStatusCode = bestfit.UserState().CovarianceStatus(); 
fMigradErrStatusCode = bestfit.UserState().CovarianceStatus(); 
if (fMigradMinStatusCode <2) { 
assert(1); 
} 
fFitInputs->FitParams().CopyCurrToBestFitValues(); 
std::vector<ROOT::Minuit2::MinuitParameter> bestfit_params = bestfit.UserParameters().Parameters(); 
for(unsigned int ip = 0; ip < bestfit_params.size(); ip++) { 
if(!bestfit_params[ip].IsFixed()) { 
bestfit_free.push_back(bestfit_params[ip].Value()); 
} 
#ifdef __show_fit_steps_debug__ 
assert(1); 
#endif 
} 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
if(bestfit.HasCovariance()) { 
ROOT::Minuit2::MnUserCovariance cov_migrad(bestfit.UserState().Covariance()); 
this->CopyCovarianceToFPL(cov_migrad); 
} 
err_migrad_err = bestfit.UserParameters().Errors(); 
for(unsigned int ip = 0; ip < nparams; ip++) { 
#ifdef __show_fit_steps_debug__ 
assert(1); 
#endif 
} 
fFitInputs->FitParams().SetMigradErrors(err_migrad_err); 
if (fCalcHesseErrors) { 
assert(1); 
ROOT::Minuit2::MnHesse hesse(2); 
ROOT::Minuit2::MnUserParameterState hesse_state = hesse(*fFitInputs, bestfit.UserState(),fMaxNumCalls); 
fHesseErrStatusCode = hesse_state.CovarianceStatus(); 
if(hesse_state.HasCovariance()) { 
ROOT::Minuit2::MnUserCovariance cov_hesse(hesse_state.Covariance()); 
this->CopyCovarianceToFPL(cov_hesse); 
} 
err_hesse_err = bestfit.UserParameters().Errors(); 
fFitInputs->FitParams().SetHesseErrors(err_hesse_err); 
for(unsigned int ip = 0; ip < nparams; ip++) { 
#ifdef __show_fit_steps_debug__ 
assert(1); 
#endif 
} 
} 
if (fCalcMinosErrors) { 
assert(1); 
ROOT::Minuit2::MnMinos minos(*fFitInputs,bestfit); 
fMinosErrStatusCode = 0; 
for(unsigned int ip = 0; ip < nparams; ip++) { 
if(bestfit_params[ip].IsFixed()) { continue; } 
double up = minos.Upper(ip); 
double lo = minos.Lower(ip); 
err_minosminus.push_back(lo); 
err_minosplus. push_back(up); 
#ifdef __show_fit_steps_debug__ 
assert(1); 
#endif 
} 
fFitInputs->FitParams().SetMinosErrors(err_minosplus, err_minosminus); 
} 
fFitInputs->FitParams().SetFitTime ( fFitTime ); 
fFitInputs->FitParams().SetFitTries(fFitTries); 
fFitInputs->FitParams().SetBestFitStatistic(fFitInputs->FitParams().GetBestFitStatistic()); 
#ifdef __show_fit_result__ 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
assert(1); 
assert(1); 
assert(1); 
if (fCalcHesseErrors) { 
assert(1); 
} 
if (fCalcMinosErrors) { 
assert(1); 
} 
#endif 
#ifdef __show_fit_steps__ 
assert(1); 
#endif 
if (mnapp) {delete mnapp;} 
return true; 
} 
int FitterMinuit2::FitStatusCode(Option_t * option) const { 
if(!option) return 9999; 
TString opt(option); 
if ( opt.Contains("migrad_min") ) return fMigradMinStatusCode; 
if ( opt.Contains("migrad_err") ) return fMigradErrStatusCode; 
if ( opt.Contains("hesse_err") ) return fHesseErrStatusCode; 
if ( opt.Contains("minos_err") ) return fMinosErrStatusCode; 
return -999; 
} 
int FitterMinuit2::NDOF() const { 
return fNFitBins - fFitInputs->FitParams().GetNumberFreeParameters(); 
} 
int FitterMinuit2::NFitParams() const { 
return fFitInputs->FitParams().GetNumberFreeParameters(); 
} 
void FitterMinuit2::CopyCovarianceToFPL(const ROOT::Minuit2::MnUserCovariance & mncov) { 
FitParamList & fp = fFitInputs->FitParams(); 
int num_of_params = fp.GetNumberParameters(); 
TMatrixDSym cov(num_of_params); 
int ifree = 0; 
int jfree = 0; 
for(int i = 0; i<num_of_params; i++) { 
if (!fp.IsFixedByIndex(i)) { 
for(int j = 0; j<num_of_params; j++) { 
if (!fp.IsFixedByIndex(j)) { 
double scaling = fp.ParameterScalingByIndex(i)*fp.ParameterScalingByIndex(j); 
cov[i][j] = mncov(ifree,jfree)/scaling; 
jfree++; 
} 
} 
jfree = 0; 
ifree++; 
} 
} 
const CompoundFitModel * cm = dynamic_cast<CompoundFitModel*>(&fFitInputs->Expectation()); 
if (cm) { 
for (int i = 0; i < num_of_params; i++) { 
if (!fp.IsFixedByIndex(i)) {continue;} 
PhysParamId_t p = fp.WhichParam(i); 
cov[i][i] = cm->GetSystematics()->CovMatrixElement(p,p); 
} 
} 
fp.SetCovMatrix(cov); 
return; 
} 
FitterABC * valor::util::GetFitter (FitInputs * inputs, Option_t * option) { 
if(!inputs) return 0; 
if(!option) return 0; 
TString opt(option); 
if ( opt.Contains("minuit2") || opt.Contains ("fumili") ) { 
assert(1); 
return new FitterMinuit2(inputs,option); 
} 
if ( opt.Contains("minuit") ) { 
assert(1); 
return new FitterMinuit(inputs,option); 
} 
assert(1); 
return 0; 
} 
double valor::util::RandomiseParametersByAcceptance(FitInputs & fitinputs, const TMatrixD * cholesky_for_throws, int max_attempts, double scaling_factor) { 
TRandom3 & rnd = Rnd::Instance()->RndOther(); 
FitParamList & fp = fitinputs.FitParams(); 
double chisqmin = fp.GetBestFitStatistic(); 
int np = fp.Size(); 
for (int i_attempt = 0; i_attempt < max_attempts; i_attempt++) { 
double acceptance_chisq = -2. * std::log(rnd.Uniform(0,1)); 
double throw_chisq = 0; 
if (cholesky_for_throws) { 
TVectorD throwvec(np); 
for (int ip = 0 ; ip <np; ip++) { 
double x = rnd.Gaus(); 
throw_chisq += x*x; 
throwvec[ip] = x; 
} 
throwvec *= (*cholesky_for_throws); 
for (int ip = 0 ; ip <np; ip++) { 
double mean = fp.BestFitValueByIndex(ip); 
double val = throwvec[ip] + mean;; 
val = std::min(val,fp.MaxValueByIndex(ip)); 
val = std::max(val,fp.MinValueByIndex(ip)); 
fp.SetCurrentValueByIndex(ip,val); 
} 
} 
else { 
for (int ip = 0 ; ip <np; ip++) { 
double mean = fp.BestFitValueByIndex(ip); 
double sigma = fp.MigradErrorByIndex(ip); 
double x = rnd.Gaus(mean,sigma); 
double var = (x-mean)/sigma; 
throw_chisq += var*var; 
fp.SetCurrentValueByIndex(ip,x); 
} 
} 
double chisq = fitinputs.Statistic(); 
double dchisq = chisq - chisqmin; 
double final_chisq = dchisq-throw_chisq; 
if (final_chisq < acceptance_chisq - std::log(scaling_factor)) { 
return final_chisq; 
} 
} 
assert(1); 
return conv::kBadResult; 
} 
TMatrixDSym valor::util::CalculateCovariance(std::vector<PhysParamList> param_sets, const CorrelatedSystematics & example_format) { 
int nvar = param_sets[0].NParams(); 
std::vector<TVectorD> all_vec; 
TPrincipal pca(nvar); 
for (unsigned int i = 0; i < param_sets.size(); i++) { 
all_vec.push_back(param_sets[i].AsTVector(&example_format)); 
pca.AddRow(all_vec.back().GetMatrixArray()); 
} 
TMatrixD lower_triangle_cov(*(pca.GetCovarianceMatrix())); 
return util::LowerTriangularMatrixToSymMatrix(lower_triangle_cov); 
} 
bool valor::util::AttemptMCMCStep(FitInputs & fitinputs, double & current_chisq, int & n_attempts_output, double step_size_factor, const TMatrixD * cholesky_for_throws, int max_attempts) { 
const bool respect_fixed = true; 
const bool respect_limits = false; 
TRandom3 & rnd = Rnd::Instance()->RndOther(); 
FitParamList & fp = fitinputs.FitParams(); 
int npar = fp.Size(); 
TVectorD start_values(fp.AsTVector("current")); 
for (int i_attempt = 0; i_attempt < max_attempts; i_attempt++) { 
bool bad_throw = false; 
if (cholesky_for_throws) { 
TVectorD throwvec(npar); 
for (int ip = 0 ; ip <npar; ip++) { 
throwvec[ip] = rnd.Gaus(); 
} 
TVectorD correlated_throws(throwvec); 
correlated_throws *= (*cholesky_for_throws); 
for (int ip = 0 ; ip <npar; ip++) { 
if (fp.IsFixedByIndex(ip) && respect_fixed) { 
continue; 
} 
double current = start_values[ip]; 
double corr_step = step_size_factor * correlated_throws[ip]; 
double val = corr_step + current; 
if (respect_limits && (val > fp.MaxValueByIndex(ip) || val < fp.MinValueByIndex(ip))) { 
bad_throw = true; 
break; 
} 
fp.SetCurrentValueByIndex(ip,val); 
} 
} 
else { 
for (int ip = 0 ; ip < npar; ip++) { 
if (fp.IsFixedByIndex(ip) && respect_fixed) { 
continue; 
} 
double current = start_values[ip]; 
double sigma = step_size_factor * fp.MigradErrorByIndex(ip); 
double val = rnd.Gaus(current,sigma); 
if (respect_limits && (val > fp.MaxValueByIndex(ip) || val < fp.MinValueByIndex(ip))) { 
bad_throw = true; 
break; 
} 
fp.SetCurrentValueByIndex(ip,val); 
} 
} 
if (bad_throw) { 
i_attempt--; 
continue; 
} 
double step_chisq = fitinputs.Statistic(); 
double delta_chisq = step_chisq-current_chisq; 
double rand_prob = rnd.Uniform(); 
double rand_chisq = -2 * std::log(rand_prob); 
if (delta_chisq < rand_chisq) { 
n_attempts_output = i_attempt+1; 
assert(1); 
assert(1); 
current_chisq = step_chisq; 
assert(1); 
return true; 
} 
assert(1); 
} 
assert(1); 
for (int ip = 0 ; ip < npar; ip++) { 
fp.SetCurrentValueByIndex(ip,start_values[ip]); 
} 
n_attempts_output = max_attempts; 
return false; 
} 
ClassImp(KBCubHcmbEdge2Edge) KBCubHcmbEdge2Edge::KBCubHcmbEdge2Edge() : TNamed() { 
this->Init(); 
} 
KBCubHcmbEdge2Edge::KBCubHcmbEdge2Edge(string name, string title) : TNamed(name.c_str(), title.c_str()) { 
this->Init(); 
} 
KBCubHcmbEdge2Edge::~KBCubHcmbEdge2Edge() { 
this->CleanUp(); 
} 
bool KBCubHcmbEdge2Edge::Read(string file) { 
this->CleanUp(); 
file = util::CompleteConfigPath(file); 
TString ts_file = file.c_str(); 
gSystem->ExpandPathName(ts_file); 
FileStat_t dummy; 
if (gSystem->GetPathInfo(ts_file.Data(), dummy)) { 
assert(1); 
util::Die(1); return false; 
} 
TXMLEngine* xml = new TXMLEngine; 
XMLDocPointer_t xmldoc = xml->ParseFile(ts_file.Data()); 
if (xmldoc==0) { 
assert(1); 
delete xml; 
util::Die(1); return false; 
} 
XMLNodePointer_t root_node = xml->DocGetRootElement(xmldoc); 
string space = util::XML2String(xml,root_node,"space"); 
fKineSpace = util::KineSpaceFromString(space); 
if(fKineSpace == conv::kspUndefined) { 
assert(1); 
return false; 
} 
assert(1); 
fNDimensions = util::NDim(fKineSpace); 
fKineVars = util::KineVar(fKineSpace); 
for(unsigned int i = 0; i < fNDimensions; i++) { 
conv::KineVar_t kv = fKineVars[i]; 
fKineVar2Dim[kv] = i; 
} 
fFixedWidth . reserve(fNDimensions); 
fMinimum . reserve(fNDimensions); 
fMaximum . reserve(fNDimensions); 
fBinEdges . reserve(fNDimensions); 
string type = util::XML2String(xml,root_node,"type"); 
if(type != "edge-to-edge") { 
assert(1); 
return false; 
} 
for(unsigned int idim = 0; idim < fNDimensions; idim++) { 
conv::KineVar_t kine_var = fKineVars[idim]; 
string kine_var_str = util::AsString(kine_var); 
const char * kine_var_ccs = kine_var_str.c_str(); 
string bin_size = util::XML2String( xml,root_node,Form("%s_binning/bin_size",kine_var_ccs)); 
unsigned int nbins = (unsigned int) util::XML2Int(xml,root_node,Form("%s_binning/nbins",kine_var_ccs)); 
assert(1); 
if(bin_size == "fixed") { 
vector<double> range = util::XML2DblArray( xml,root_node,Form("%s_binning/range",kine_var_ccs)); 
if(range.size() != 2) { 
assert(1); 
return false; 
} 
VALORArray * arr = new VALORArray(nbins+1); 
double dx = (range[1] - range[0]) / nbins; 
double x = range[0]; 
for(unsigned int i = 0; i < nbins+1; i++) { 
arr->SetEntry(x,i); 
x += dx; 
} 
fBinEdges [idim] = arr; 
fFixedWidth[idim] = true; 
fMinimum [idim] = range[0]; 
fMaximum [idim] = range[1]; 
} 
else if(bin_size == "variable") { 
vector<double> bin_edges = util::XML2DblArray( xml,root_node,Form("%s_binning/bin_edges",kine_var_ccs)); 
if(bin_edges.size() != nbins+1) { 
assert(1); 
return false; 
} 
VALORArray * arr = new VALORArray(nbins+1); 
for(unsigned int i = 0; i < nbins+1; i++) { 
arr->SetEntry(bin_edges[i],i); 
} 
fBinEdges [idim] = arr; 
fFixedWidth[idim] = false; 
fMinimum [idim] = bin_edges[0]; 
fMaximum [idim] = bin_edges[nbins]; 
} 
else { 
assert(1); 
return false; 
} 
} 
assert(1); 
return true; 
} 
KBCubHcmbEdge2Edge* KBCubHcmbEdge2Edge::Contract(conv::KineSpace_t ks) const { 
KBCubHcmbEdge2Edge* binning = new KBCubHcmbEdge2Edge(); 
binning->fKineSpace = ks; 
binning->fKineVars = util::KineVarSubset(fKineSpace, ks); 
binning->fNDimensions = binning->fKineVars.size(); 
for(unsigned int i = 0; i < binning->fNDimensions; ++i) { 
binning->fKineVar2Dim[fKineVars[i]] = i; 
} 
binning->fMinimum.reserve(binning->fNDimensions); 
binning->fMaximum.reserve(binning->fNDimensions); 
binning->fBinEdges.reserve(binning->fNDimensions); 
for(unsigned int d = 0; d < fNDimensions; ++d) { 
if(std::find(binning->fKineVars.begin(), binning->fKineVars.end(), fKineVars[d]) != binning->fKineVars.end()) { 
binning->fBinEdges.push_back(fBinEdges[d]); 
binning->fFixedWidth.push_back(fFixedWidth[d]); 
binning->fMinimum.push_back(fMinimum[d]); 
binning->fMaximum.push_back(fMaximum[d]); 
} 
} 
return binning; 
} 
unsigned int KBCubHcmbEdge2Edge::NBins(unsigned int dimension) const { 
return (fBinEdges[dimension]->GetSize() - 1); 
} 
unsigned int KBCubHcmbEdge2Edge::NBins(conv::KineVar_t kv) const { 
unsigned int dimension = this->Dimension(kv); 
return this->NBins(dimension); 
} 
unsigned int KBCubHcmbEdge2Edge::NBins(void) const { 
unsigned int nbins = this->NBins(0); 
for(unsigned int idim = 1; idim < fNDimensions; idim++) { 
nbins *= this->NBins(idim); 
} 
return nbins; 
} 
bool KBCubHcmbEdge2Edge::FixedWidth(unsigned int dimension) const { 
if (dimension >= fNDimensions) { 
assert(1); 
util::Die(-1) ; return false; 
} 
return fFixedWidth[dimension]; 
} 
bool KBCubHcmbEdge2Edge::FixedWidth(conv::KineVar_t kv) const { 
unsigned int dimension = this->Dimension(kv); 
return this->FixedWidth(dimension); 
} 
bool KBCubHcmbEdge2Edge::VariableWidth(unsigned int dimension) const { 
return (! this->FixedWidth(dimension)); 
} 
bool KBCubHcmbEdge2Edge::VariableWidth(conv::KineVar_t kv) const { 
return (! this->FixedWidth(kv)); 
} 
double KBCubHcmbEdge2Edge::Minimum(unsigned int dimension) const { 
return fMinimum[dimension]; 
} 
double KBCubHcmbEdge2Edge::Minimum(conv::KineVar_t kv) const { 
unsigned int dimension = this->Dimension(kv); 
return this->Minimum(dimension); 
} 
double KBCubHcmbEdge2Edge::Maximum(unsigned int dimension) const { 
if (dimension >= fNDimensions) { 
assert(1); 
util::Die(-1) ; return false; 
} 
return fMaximum[dimension]; 
} 
double KBCubHcmbEdge2Edge::Maximum(conv::KineVar_t kv) const { 
unsigned int dimension = this->Dimension(kv); 
return this->Maximum(dimension); 
} 
double KBCubHcmbEdge2Edge::BinMinimum( unsigned int linearized_bin, unsigned int dimension) const { 
if (dimension >= fNDimensions) { 
assert(1); 
util::Die(-1) ; return false; 
} 
vector<unsigned int> binarr = this->BinArr(linearized_bin); 
unsigned int bin = binarr[dimension]; 
const double * bin_edges = this->BinEdgeArr(dimension); 
return bin_edges[bin]; 
} 
double KBCubHcmbEdge2Edge::BinMinimum( unsigned int linearized_bin, conv::KineVar_t kv) const { 
unsigned int dimension = this->Dimension(kv); 
if (dimension >= fNDimensions) { 
assert(1); 
util::Die(-1) ; return false; 
} 
vector<unsigned int> binarr = this->BinArr(linearized_bin); 
unsigned int bin = binarr[dimension]; 
const double * bin_edges = this->BinEdgeArr(dimension); 
return bin_edges[bin]; 
} 
double KBCubHcmbEdge2Edge::BinMaximum( unsigned int linearized_bin, unsigned int dimension) const { 
if (dimension >= fNDimensions) { 
assert(1); 
util::Die(-1) ; return false; 
} 
vector<unsigned int> binarr = this->BinArr(linearized_bin); 
unsigned int bin = binarr[dimension]; 
const double * bin_edges = this->BinEdgeArr(dimension); 
return bin_edges[bin+1]; 
} 
double KBCubHcmbEdge2Edge::BinMaximum( unsigned int linearized_bin, conv::KineVar_t kv) const { 
unsigned int dimension = this->Dimension(kv); 
if (dimension >= fNDimensions) { 
assert(1); 
util::Die(-1) ; return false; 
} 
vector<unsigned int> binarr = this->BinArr(linearized_bin); 
unsigned int bin = binarr[dimension]; 
const double * bin_edges = this->BinEdgeArr(dimension); 
return bin_edges[bin+1]; 
} 
vector<double> KBCubHcmbEdge2Edge::BinRange( unsigned int linearized_bin, unsigned int dimension) const { 
vector<double> range(2); 
if (dimension >= fNDimensions) { 
assert(1); 
util::Die(-1) ; return range; 
} 
vector<unsigned int> binarr = this->BinArr(linearized_bin); 
unsigned int bin = binarr[dimension]; 
const double * bin_edges = this->BinEdgeArr(dimension); 
range[0] = bin_edges[bin]; 
range[1] = bin_edges[bin+1]; 
return range; 
} 
vector<double> KBCubHcmbEdge2Edge::BinRange( unsigned int linearized_bin, conv::KineVar_t kv) const { 
vector<double> range(2); 
unsigned int dimension = this->Dimension(kv); 
if (dimension >= fNDimensions) { 
assert(1); 
util::Die(-1) ; return range; 
} 
vector<unsigned int> binarr = this->BinArr(linearized_bin); 
unsigned int bin = binarr[dimension]; 
const double * bin_edges = this->BinEdgeArr(dimension); 
range[0] = bin_edges[bin]; 
range[1] = bin_edges[bin+1]; 
return range; 
} 
double KBCubHcmbEdge2Edge::BinWidth( unsigned int linearized_bin, unsigned int dimension) const { 
vector<double> range = this->BinRange(linearized_bin, dimension); 
double width = range[1] - range[0]; 
return width; 
} 
double KBCubHcmbEdge2Edge::BinWidth( unsigned int linearized_bin, conv::KineVar_t kv) const { 
vector<double> range = this->BinRange(linearized_bin, kv); 
double width = range[1] - range[0]; 
return width; 
} 
vector<double> KBCubHcmbEdge2Edge::BinWidth(unsigned int linearized_bin) const { 
vector<double> bwidth(fNDimensions); 
for(unsigned int idim = 0; idim < fNDimensions; idim++) { 
bwidth[idim] = this->BinWidth(linearized_bin, idim); 
} 
return bwidth; 
} 
double KBCubHcmbEdge2Edge::BinCentre( unsigned int linearized_bin, unsigned int dimension) const { 
vector<double> range = this->BinRange(linearized_bin, dimension); 
double centre = 0.5 * (range[1] + range[0]); 
return centre; 
} 
double KBCubHcmbEdge2Edge::BinCentre( unsigned int linearized_bin, conv::KineVar_t kv) const { 
vector<double> range = this->BinRange(linearized_bin, kv); 
double centre = 0.5 * (range[1] + range[0]); 
return centre; 
} 
vector<double> KBCubHcmbEdge2Edge::BinCentre(unsigned int linearized_bin) const { 
vector<double> centre(fNDimensions); 
for(unsigned int idim = 0; idim < fNDimensions; idim++) { 
centre[idim] = this->BinCentre(linearized_bin, idim); 
} 
return centre; 
} 
const double * KBCubHcmbEdge2Edge::BinEdgeArr(unsigned int dimension) const { 
if (dimension >= fNDimensions) { 
assert(1); 
util::Die(-1) ; return NULL; 
} 
return fBinEdges[dimension]->GetArray(); 
} 
const double * KBCubHcmbEdge2Edge::BinEdgeArr(conv::KineVar_t kv) const { 
unsigned int dimension = this->Dimension(kv); 
return this->BinEdgeArr(dimension); 
} 
const VALORArray * KBCubHcmbEdge2Edge::BinEdgeVArr(unsigned int dimension) const { 
if (dimension >= fNDimensions) { 
assert(1); 
util::Die(-1) ; return NULL; 
} 
return fBinEdges[dimension]; 
} 
const VALORArray * KBCubHcmbEdge2Edge::BinEdgeVArr(conv::KineVar_t kv) const { 
unsigned int dimension = this->Dimension(kv); 
return this->BinEdgeVArr(dimension); 
} 
unsigned int KBCubHcmbEdge2Edge::FindBin(double x, unsigned int dimension) const { 
unsigned int n = 1 + this->NBins(dimension); 
const double * arr = this->BinEdgeArr(dimension); 
return TMath::BinarySearch(n,arr,x); 
} 
unsigned int KBCubHcmbEdge2Edge::FindBin(double x, conv::KineVar_t kv) const { 
unsigned int dimension = this->Dimension(kv); 
return this->FindBin(x,dimension); 
} 
unsigned int KBCubHcmbEdge2Edge::FindBin(vector<double> & xarr) const { 
return this->FindLinearizedBin(xarr); 
} 
vector<unsigned int> KBCubHcmbEdge2Edge::FindBinArr(vector<double> & xarr) const { 
vector<unsigned int> binarr; 
if (xarr.size() != fNDimensions) { 
assert(1); 
util::Die(-1) ; return binarr; 
} 
binarr.reserve(fNDimensions); 
for(unsigned int idim = 0; idim < fNDimensions; idim++) { 
double x = xarr[idim]; 
binarr[idim] = this->FindBin(x,idim); 
assert(1); 
} 
return binarr; 
} 
unsigned int KBCubHcmbEdge2Edge::FindLinearizedBin(vector<double> & xarr) const { 
vector<unsigned int> binarr = this->FindBinArr(xarr); 
return this->LinearizedBin(binarr); 
} 
unsigned int KBCubHcmbEdge2Edge::LinearizedBin(vector<unsigned int> & binarr) const { 
unsigned int linearized_bin = binarr[0]; 
for(unsigned int idim = 1; idim < fNDimensions; idim++) { 
unsigned int nbins_subspace = 1; 
for(unsigned int idim2 = 0; idim2 < idim; idim2++) { 
nbins_subspace *= this->NBins(idim2); 
} 
linearized_bin += (nbins_subspace * binarr[idim]); 
} 
return linearized_bin; 
} 
vector<unsigned int> KBCubHcmbEdge2Edge::BinArr(unsigned int linearized_bin) const { 
vector<unsigned int> binarr(fNDimensions); 
unsigned int nbins_subspace = this->NBins(); 
for(unsigned int idim = fNDimensions-1; idim > 0; idim--) { 
nbins_subspace /= this->NBins(idim); 
unsigned int bin = linearized_bin / nbins_subspace; 
binarr[idim] = bin; 
linearized_bin -= (bin * nbins_subspace); 
} 
binarr[0] = linearized_bin; 
return binarr; 
} 
unsigned int KBCubHcmbEdge2Edge::Bin( unsigned int linearized_bin, unsigned int dimension) const { 
return this->BinArr(linearized_bin)[dimension]; 
} 
unsigned int KBCubHcmbEdge2Edge::Dimension(conv::KineVar_t kv) const { 
std::map<conv::KineVar_t,unsigned int>::const_iterator it = fKineVar2Dim.find(kv); 
if (it == fKineVar2Dim.end()) { 
assert(1); 
util::Die(-1) ; return -1; 
} 
int dimension = it->second; 
return dimension; 
} 
bool KBCubHcmbEdge2Edge::Contains(conv::KineVar_t kv) const { 
std::map<conv::KineVar_t,unsigned int>::const_iterator it = fKineVar2Dim.find(kv); 
return (it != fKineVar2Dim.end()); 
} 
conv::KineVar_t KBCubHcmbEdge2Edge::KineVar(unsigned int dimension) { 
if(dimension < fNDimensions) return fKineVars[dimension]; 
return conv::kvUndefined; 
} 
void KBCubHcmbEdge2Edge::Init(void) { 
fKineSpace = conv::kspUndefined; 
fNDimensions = 0; 
fKineVars.clear(); 
fKineVar2Dim.clear(); 
fFixedWidth.clear(); 
fMinimum.clear(); 
fMaximum.clear(); 
fBinEdges.clear(); 
} 
void KBCubHcmbEdge2Edge::CleanUp(void) { 
vector<VALORArray*>::iterator it = fBinEdges.begin(); 
for( ; it != fBinEdges.end(); ++it) { 
VALORArray * arr = *it; 
if(arr) delete arr; 
arr = 0; 
} 
this->Init(); 
} 
ClassImp(KBCubHcmbMondrian) KBCubHcmbMondrian::KBCubHcmbMondrian() : TNamed() { 
this->Init(); 
} 
KBCubHcmbMondrian::KBCubHcmbMondrian(string name, string title) : TNamed(name.c_str(), title.c_str()) { 
this->Init(); 
} 
KBCubHcmbMondrian::~KBCubHcmbMondrian() { 
this->CleanUp(); 
} 
bool KBCubHcmbMondrian::Read(string file) { 
this->CleanUp(); 
file = util::CompleteConfigPath(file); 
TString ts_file = file.c_str(); 
gSystem->ExpandPathName(ts_file); 
FileStat_t dummy; 
if (gSystem->GetPathInfo(ts_file.Data(), dummy)) { 
assert(1); 
util::Die(1); return false; 
} 
TXMLEngine* xml = new TXMLEngine; 
XMLDocPointer_t xmldoc = xml->ParseFile(ts_file.Data()); 
if (xmldoc==0) { 
assert(1); 
delete xml; 
util::Die(1); return false; 
} 
XMLNodePointer_t root_node = xml->DocGetRootElement(xmldoc); 
string space = util::XML2String(xml,root_node,"space"); 
fKineSpace = util::KineSpaceFromString(space); 
if(fKineSpace == conv::kspUndefined) { 
assert(1); 
return false; 
} 
assert(1); 
fNDimensions = util::NDim(fKineSpace); 
assert(1); 
fKineVars = util::KineVar(fKineSpace); 
for(unsigned int i = 0; i < fNDimensions; i++) { 
conv::KineVar_t kv = fKineVars[i]; 
fKineVar2Dim[kv] = i; 
} 
fMinimum.reserve(fNDimensions); 
fMaximum.reserve(fNDimensions); 
string type = util::XML2String(xml,root_node,"type"); 
if(type != "mondrian") { 
assert(1); 
return false; 
} 
int nbins = util::XML2Int(xml,root_node,"nbins"); 
if(nbins <= 0) { 
assert(1); 
return false; 
} 
fNBins = (unsigned int) nbins; 
assert(1); 
fBinEdges.reserve(fNBins * fNDimensions * 2); 
unsigned int l = 0; 
for(unsigned int ibin = 0; ibin < fNBins; ibin++) { 
assert(1); 
vector<double> edges = util::XML2DblArray( xml,root_node,Form("bin_%d",ibin)); 
if(edges.size() != 2*fNDimensions) { 
assert(1); 
return false; 
} 
unsigned int k = 0; 
for(unsigned int idim = 0; idim < fNDimensions; idim++) { 
double min = edges[k++]; 
double max = edges[k++]; 
fBinEdges[l++] = min; 
fBinEdges[l++] = max; 
assert(1); 
if(ibin == 0) { 
fMinimum[idim] = min; 
fMaximum[idim] = max; 
} else { 
fMinimum[idim] = TMath::Min(fMinimum[idim], min); 
fMaximum[idim] = TMath::Max(fMaximum[idim], max); 
} 
} 
} 
return true; 
} 
KBCubHcmbMondrian* KBCubHcmbMondrian::Contract(conv::KineSpace_t ks) const { 
KBCubHcmbMondrian* mond = new KBCubHcmbMondrian(); 
mond->fKineSpace = ks; 
mond->fKineVars = util::KineVarSubset(fKineSpace, ks); 
mond->fNDimensions = mond->fKineVars.size(); 
for(unsigned int i = 0; i < mond->fNDimensions; ++i) { 
mond->fKineVar2Dim[fKineVars[i]] = i; 
} 
mond->fMinimum.reserve(mond->fNDimensions); 
mond->fMaximum.reserve(mond->fNDimensions); 
for(unsigned int d = 0; d < fNDimensions; ++d) { 
mond->fMinimum[d] = std::numeric_limits<double>::max(); 
mond->fMaximum[d] = -std::numeric_limits<double>::max(); 
} 
mond->fBinEdges.reserve(mond->fNDimensions); 
int EDGES_PER_BIN = 2 * fNDimensions; 
int EDGES_PER_DIM = 2; 
for(unsigned int i = 0; i < fNBins; ++i) { 
for(unsigned int d = 0; d < fNDimensions; ++d) { 
int index = i * EDGES_PER_BIN + d * EDGES_PER_DIM; 
if(std::find(mond->fKineVars.begin(), mond->fKineVars.end(), fKineVars[d]) != mond->fKineVars.end()) { 
mond->fBinEdges.push_back(fBinEdges[index]); 
mond->fBinEdges.push_back(fBinEdges[index + 1]); 
} 
} 
} 
EDGES_PER_BIN = 2 * mond->fNDimensions; 
mond->fNBins = mond->fBinEdges.size() / EDGES_PER_BIN; 
std::vector<int> duplicateBins; 
for(unsigned int i = 0; i < mond->fNBins; ++i) { 
if(std::find(duplicateBins.begin(), duplicateBins.end(), i) != duplicateBins.end()) { 
continue; 
} 
int index1 = i * EDGES_PER_BIN; 
for(unsigned int j = i + 1; j < mond->fNBins; ++j) { 
int index2 = j * EDGES_PER_BIN; 
bool duplicate = true; 
for(unsigned int d = 0; d < 2 * mond->fNDimensions; ++d) { 
if(mond->fBinEdges[index1 + d] != mond->fBinEdges[index2 + d]) { 
duplicate = false; 
break; 
} 
} 
if(duplicate) { 
duplicateBins.push_back(j); 
} 
} 
for(unsigned int d = 0; d < mond->fNDimensions; ++d) { 
int lowIndex = index1 + d * EDGES_PER_DIM; 
int highIndex = index1 + d * EDGES_PER_DIM + 1; 
if(mond->fMinimum[d] > mond->fBinEdges[lowIndex]) { 
mond->fMinimum[d] = mond->fBinEdges[lowIndex]; 
} 
if(mond->fMaximum[d] < mond->fBinEdges[highIndex]) { 
mond->fMaximum[d] = mond->fBinEdges[highIndex]; 
} 
} 
} 
for(unsigned int i = mond->fNBins - 1; i > 0; --i) { 
if(std::find(duplicateBins.begin(), duplicateBins.end(), i) != duplicateBins.end()) { 
auto begin = mond->fBinEdges.begin() + i * EDGES_PER_BIN; 
auto end = mond->fBinEdges.begin() + (i + 1) * EDGES_PER_BIN; 
mond->fBinEdges.erase(begin, end); 
} 
} 
mond->fNBins -= duplicateBins.size(); 
return mond; 
} 
double KBCubHcmbMondrian::Minimum(unsigned int dimension) const { 
return fMinimum[dimension]; 
} 
double KBCubHcmbMondrian::Minimum(conv::KineVar_t kv) const { 
unsigned int dimension = this->Dimension(kv); 
return this->Minimum(dimension); 
} 
double KBCubHcmbMondrian::Maximum(unsigned int dimension) const { 
if (dimension >= fNDimensions) { 
assert(1); 
util::Die(-1) ; return conv::kBadResult; 
} 
return fMaximum[dimension]; 
} 
double KBCubHcmbMondrian::Maximum(conv::KineVar_t kv) const { 
unsigned int dimension = this->Dimension(kv); 
return this->Maximum(dimension); 
} 
double KBCubHcmbMondrian::BinMinimum(unsigned int bin, unsigned int dimension) const { 
if (bin >= fNBins) { 
assert(1); 
util::Die(-1) ; return conv::kBadResult; 
} 
if (dimension >= fNDimensions) { 
assert(1); 
util::Die(-1) ; return conv::kBadResult; 
} 
unsigned int idx = (2 * fNDimensions * bin) + (2 * dimension); 
return fBinEdges[idx]; 
} 
double KBCubHcmbMondrian::BinMinimum(unsigned int bin, conv::KineVar_t kv) const { 
unsigned int dimension = this->Dimension(kv); 
return this->BinMinimum(bin,dimension); 
} 
double KBCubHcmbMondrian::BinMaximum(unsigned int bin, unsigned int dimension) const { 
if (bin >= fNBins) { 
assert(1); 
util::Die(-1) ; return conv::kBadResult; 
} 
if (dimension >= fNDimensions) { 
assert(1); 
util::Die(-1) ; return conv::kBadResult; 
} 
unsigned int idx = (2 * fNDimensions * bin) + (2 * dimension) + 1; 
return fBinEdges[idx]; 
} 
double KBCubHcmbMondrian::BinMaximum(unsigned int bin, conv::KineVar_t kv) const { 
unsigned int dimension = this->Dimension(kv); 
return this->BinMaximum(bin,dimension); 
} 
vector<double> KBCubHcmbMondrian::BinRange( unsigned int bin, unsigned int dimension) const { 
vector<double> range(2); 
if (bin >= fNBins) { 
assert(1); 
util::Die(-1) ; return range; 
} 
if (dimension >= fNDimensions) { 
assert(1); 
util::Die(-1) ; return range; 
} 
unsigned int idx_base = (2 * fNDimensions * bin) + (2 * dimension); 
range[0] = fBinEdges[idx_base]; 
range[1] = fBinEdges[idx_base+1]; 
return range; 
} 
vector<double> KBCubHcmbMondrian::BinRange( unsigned int bin, conv::KineVar_t kv) const { 
unsigned int dimension = this->Dimension(kv); 
return this->BinRange(bin,dimension); 
} 
double KBCubHcmbMondrian::BinWidth(unsigned int bin, unsigned int dimension) const { 
vector<double> range = this->BinRange(bin,dimension); 
double width = range[1] - range[0]; 
return width; 
} 
double KBCubHcmbMondrian::BinWidth(unsigned int bin, conv::KineVar_t kv) const { 
unsigned int dimension = this->Dimension(kv); 
return this->BinWidth(bin,dimension); 
} 
vector<double> KBCubHcmbMondrian::BinWidth(unsigned int bin) const { 
vector<double> bwidth(fNDimensions); 
for(unsigned int idim = 0; idim < fNDimensions; idim++) { 
bwidth[idim] = this->BinWidth(bin, idim); 
} 
return bwidth; 
} 
double KBCubHcmbMondrian::BinCentre(unsigned int bin, unsigned int dimension) const { 
vector<double> range = this->BinRange(bin,dimension); 
double centre = 0.5 * (range[1] + range[0]); 
return centre; 
} 
double KBCubHcmbMondrian::BinCentre(unsigned int bin, conv::KineVar_t kv) const { 
unsigned int dimension = this->Dimension(kv); 
return this->BinCentre(bin,dimension); 
} 
vector<double> KBCubHcmbMondrian::BinCentre(unsigned int bin) const { 
vector<double> centre(fNDimensions); 
for(unsigned int idim = 0; idim < fNDimensions; idim++) { 
centre[idim] = this->BinCentre(bin, idim); 
} 
return centre; 
} 
unsigned int KBCubHcmbMondrian::FindBin(vector<double> & xarr) const { 
if (xarr.size() == fNDimensions) { 
for(unsigned int ibin = 0; ibin < fNBins; ibin++) { 
bool inside = true; 
for(unsigned int idim = 0; idim < fNDimensions; idim++) { 
double x = xarr[idim]; 
unsigned int idx = (2 * fNDimensions * ibin) + (2 * idim); 
double min = fBinEdges[idx]; 
double max = fBinEdges[idx+1]; 
inside = inside && (x >= min && x < max); 
if(!inside) break; 
} 
if(inside) { 
return ibin; 
} 
} 
} 
assert(1); 
util::Die(-1); 
return 0; 
} 
void KBCubHcmbMondrian::UseEdge2EdgeBinning( const KBCubHcmbEdge2Edge * kbe2e) { 
fKBE2E = kbe2e; 
unsigned int ne2ebins = fKBE2E->NBins(); 
for(unsigned int e2e_lin_bin = 0; e2e_lin_bin < ne2ebins; e2e_lin_bin++) { 
vector<double> xarr = fKBE2E->BinCentre(e2e_lin_bin); 
unsigned int mondrian_bin = this->FindBin(xarr); 
fBinMondrianFromE2E.insert( pair<unsigned int,unsigned int>(e2e_lin_bin, mondrian_bin) ); 
fBinMondrianToE2E.insert( pair<unsigned int,unsigned int>(mondrian_bin, e2e_lin_bin) ); 
} 
} 
unsigned int KBCubHcmbMondrian::MapFromLinearizedE2E(unsigned int e2e_lin_bin) const { 
std::map<unsigned int, unsigned int>::const_iterator it = fBinMondrianFromE2E.find(e2e_lin_bin); 
if (it == fBinMondrianFromE2E.end()) { 
assert(1); 
util::Die(-1) ; return 0; 
} 
return it->second; 
} 
unsigned int KBCubHcmbMondrian::Dimension(conv::KineVar_t kv) const { 
std::map<conv::KineVar_t,unsigned int>::const_iterator it = fKineVar2Dim.find(kv); 
if (it == fKineVar2Dim.end()) { 
assert(1); 
util::Die(-1) ; return 0; 
} 
int dimension = it->second; 
return dimension; 
} 
bool KBCubHcmbMondrian::Contains(conv::KineVar_t kv) const { 
std::map<conv::KineVar_t,unsigned int>::const_iterator it = fKineVar2Dim.find(kv); 
return (it != fKineVar2Dim.end()); 
} 
std::vector<TLine> KBCubHcmbMondrian::GetBinningTLines(void) const { 
std::vector<TLine> bin_edge_lines; 
if (fNDimensions == 2) { 
bin_edge_lines.reserve(fNBins * fNDimensions * 4); 
for (unsigned int ibin = 0; ibin < fNBins ; ibin++ ) { 
double x0 = this->BinMinimum(ibin,0); 
double x1 = this->BinMaximum(ibin,0); 
double y0 = this->BinMinimum(ibin,1); 
double y1 = this->BinMaximum(ibin,1); 
TLine lxl = TLine(x0,y0,x1,y0); 
TLine lxh = TLine(x0,y1,x1,y1); 
TLine lyl = TLine(x0,y0,x0,y1); 
TLine lyh = TLine(x1,y0,x1,y1); 
bin_edge_lines.push_back(lxl); 
bin_edge_lines.push_back(lxh); 
bin_edge_lines.push_back(lyl); 
bin_edge_lines.push_back(lyh); 
} 
} 
return bin_edge_lines; 
} 
conv::KineVar_t KBCubHcmbMondrian::KineVar(unsigned int dimension) { 
if(dimension < fNDimensions) return fKineVars[dimension]; 
return conv::kvUndefined; 
} 
TH2D* KBCubHcmbMondrian::ToTH2D(conv::KineVar_t kv1, conv::KineVar_t kv2) const { 
int dim1 = 0; 
int dim2 = 1; 
if(fNDimensions > 2) { 
if(kv1 == conv::kvUndefined || kv2 == conv::kvUndefined) { 
assert(1); 
util::Die(-1); 
} 
dim1 = Dimension(kv1); 
dim2 = Dimension(kv2); 
} 
std::set<double> dim1Edges; 
std::set<double> dim2Edges; 
const int EDGES_PER_BIN = 2 * fNDimensions; 
const int EDGES_PER_DIM = 2; 
for(unsigned int i = 0; i < fNBins; ++i) { 
dim1Edges.insert(fBinEdges[i * EDGES_PER_BIN + EDGES_PER_DIM * dim1]); 
dim1Edges.insert(fBinEdges[i * EDGES_PER_BIN + EDGES_PER_DIM * dim1 + 1]); 
dim2Edges.insert(fBinEdges[i * EDGES_PER_BIN + EDGES_PER_DIM * dim2]); 
dim2Edges.insert(fBinEdges[i * EDGES_PER_BIN + EDGES_PER_DIM * dim2 + 1]); 
} 
int nDim1Bins = dim1Edges.size() - 1; 
double dim1BinEdges[nDim1Bins + 1]; 
std::copy(dim1Edges.begin(), dim2Edges.end(), dim1BinEdges); 
int nDim2Bins = dim2Edges.size() - 1; 
double dim2BinEdges[nDim1Bins + 1]; 
std::copy(dim2Edges.begin(), dim2Edges.end(), dim2BinEdges); 
TH2D* histo = new TH2D("histo", "histo", nDim1Bins, dim1BinEdges, nDim2Bins, dim2BinEdges); 
return histo; 
} 
void KBCubHcmbMondrian::Init(void) { 
fKineSpace = conv::kspUndefined; 
fNDimensions = 0; 
fKineVars.clear(); 
fKineVar2Dim.clear(); 
fNBins = 0; 
fBinEdges.clear(); 
fMinimum.clear(); 
fMaximum.clear(); 
fBinMondrianFromE2E.clear(); 
fBinMondrianToE2E.clear(); 
} 
void KBCubHcmbMondrian::CleanUp(void) { 
this->Init(); 
} 
StdFitNtp::StdFitNtp() { 
this->Init(); 
} 
StdFitNtp::~StdFitNtp() { 
this->Clean(); 
} 
void StdFitNtp::Create(const char* file_name, const char* ntp_name, const char* ntp_label) { 
assert(1); 
if(file_name) { 
fOutFile = new TFile(file_name, "recreate"); 
} 
fTrueParamArr = new PhysParamList; 
fBestFitParamArr = new FitParamList; 
fBestFitModelArr = new TObjArray; 
fDataArr = new TObjArray; 
fBestFitModelArr -> SetOwner(false); 
fDataArr -> SetOwner(false); 
fVTree = new TTree(ntp_name, ntp_label); 
fVTree->Branch("true_params", "valor::PhysParamList", &fTrueParamArr, 1280000,0); 
fVTree->Branch("best_fit_params", "valor::FitParamList", &fBestFitParamArr, 1280000,0); 
fVTree->Branch("best_fit_model", "TObjArray", &fBestFitModelArr, 1280000,0); 
fVTree->Branch("data", "TObjArray", &fDataArr, 1280000,0); 
} 
void StdFitNtp::Reset(void) { 
fTrueParamArr -> Clear(); 
fBestFitParamArr -> Clear(); 
fBestFitModelArr -> Clear(); 
fDataArr -> Clear(); 
} 
void StdFitNtp::Fill(void) { 
fVTree -> Fill(); 
} 
void StdFitNtp::Save(void) { 
if(fOutFile) { 
fOutFile -> cd(); 
fVTree -> Write(); 
} 
} 
void StdFitNtp::Init(void) { 
assert(1); 
fOutFile = 0; 
fVTree = 0; 
fTrueParamArr = 0; 
fBestFitParamArr = 0; 
fBestFitModelArr = 0; 
fDataArr = 0; 
} 
void StdFitNtp::Clean(void) { 
assert(1); 
if (fOutFile) { 
fOutFile->Close(); 
delete fOutFile; 
} 
} 
NuOsc3Flavour::NuOsc3Flavour() { 
this->Init(); 
} 
NuOsc3Flavour::~NuOsc3Flavour( ) { 
} 
void NuOsc3Flavour::Init() { 
this->SetBaseline(kBaselineT2K); 
NuMassHierarchy_t nmh = Opt::Instance()->gMassHierarchyAssumed; 
this->SetMassHierarchy(nmh); 
this->SetDensity(kCrustDensityT2K); 
} 
void NuOsc3Flavour::SetBaseline(double length) { 
fBaseline = length; 
} 
void NuOsc3Flavour::SetDensity(double density) { 
fNe = density * kNA * 0.5; 
} 
void NuOsc3Flavour::SetMassHierarchy(NuMassHierarchy_t h) { 
if(h==kNmhUndefined){ 
assert(1); 
assert(1); 
util::Die(-1); 
return; 
} 
fMassHierarchy = h; 
} 
void NuOsc3Flavour::SetOscParameters( double sinsq2theta12, double sinsq2theta13, double sinsq2theta23, double dmsq12_in, double dmsq23_in, double deltaCP) { 
dmsq12 = dmsq12_in; 
dmsq23 = dmsq23_in; 
if(dmsq12 < 5.0e-6) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4, changing it to 5.0E-6 eV^2/c^4"<<endl; 
if(dmsq12 > 5.0e-3) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4, changing it to 5.0E-3 eV^2/c^4"<<endl; 
if(dmsq23 < 2.0e-4) cerr<<"The input value of |dm32sq| is restricted to the range 2.0E-4 - 2.0E-2 eV^2/c^4, changing it to 2.0E-4 eV^2/c^4"<<endl; 
if(dmsq23 > 4.0e-2) cerr<<"The input value of |dm32sq| is restricted to the range 2.0E-4 - 4.0E-2 eV^2/c^4, changing it to 4.0E-2 eV^2/c^4"<<endl; 
dmsq12 = TMath::Min(dmsq12, 5.0e-3); 
dmsq12 = TMath::Max(dmsq12, 5.0e-6); 
dmsq23 = TMath::Min(dmsq23, 4.0e-2); 
dmsq23 = TMath::Max(dmsq23, 2.0e-4); 
if(fMassHierarchy == kNmhInverted) { 
dmsq23 = -dmsq23; 
} 
dmsq13 = dmsq12 + dmsq23; 
sinsq2theta12 = TMath::Min(1.,sinsq2theta12); 
sinsq2theta12 = TMath::Max(0.,sinsq2theta12); 
sinsq2theta13 = TMath::Min(1.,sinsq2theta13); 
sinsq2theta13 = TMath::Max(0.,sinsq2theta13); 
sinsq2theta23 = TMath::Min(1.,sinsq2theta23); 
sinsq2theta23 = TMath::Max(0.,sinsq2theta23); 
double s12 = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta12))); 
double s13 = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta13))); 
double s23 = 0; 
if(Opt::Instance()->gOscOctantChoice == conv::kNuOctantOne) s23 = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta23))); 
else if(Opt::Instance()->gOscOctantChoice == conv::kNuOctantTwo) s23 = sqrt(1 - (0.5 * (1 - sqrt(1 - sinsq2theta23)))); 
double c12 = sqrt(1 - s12 * s12); 
double c13 = sqrt(1 - s13 * s13); 
double c23 = sqrt(1 - s23 * s23); 
CalcPMNSElements(s12, c12, s13, c13, s23, c23, dmsq12, dmsq13, deltaCP); 
useEquations12 = true; 
if(((fabs(deltaCP) > 3.10 && fabs(deltaCP) < 3.18) || fabs(deltaCP) < 0.01 || fabs(fabs(deltaCP) - 6.2832) < 0.01) && sinsq2theta13 > 1.0e-8) useEquations12 = false; 
if(sinsq2theta13 < 1.0e-5 && sinsq2theta23 < 1.0e-5 && sinsq2theta12 >= 1.0e-6) nFlavourIndex = 12; 
else if(sinsq2theta12 < 1.0e-4 && sinsq2theta23 < 1.0e-6 && sinsq2theta13 >= 1.0e-6) nFlavourIndex = 13; 
else if(sinsq2theta12 < 1.0e-4 && sinsq2theta13 < 1.0e-4 && sinsq2theta23 >= 1.0e-6) nFlavourIndex = 23; 
else nFlavourIndex = -1; 
if(sinsq2theta12 < 1.0e-6 && sinsq2theta13 < 1.0e-6 && sinsq2theta23 < 1.0e-6) nFlavourIndex = 0; 
} 
void NuOsc3Flavour::SetOscParametersSinSqTAll(  double sinsqtheta12, double sinsqtheta13, double sinsqtheta23,  double dmsq12_in, double dmsq23_in,  double deltaCP) { 
dmsq12 = dmsq12_in; 
dmsq23 = dmsq23_in; 
if(dmsq12 < 5.0e-6) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4, changing it to 5.0E-6 eV^2/c^4"<<endl; 
if(dmsq12 > 5.0e-3) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4, changing it to 5.0E-3 eV^2/c^4"<<endl; 
if(dmsq23 < 2.0e-4) cerr<<"The input value of |dm32sq| is restricted to the range 2.0E-4 - 4.0E-2 eV^2/c^4, changing it to 2.0E-4 eV^2/c^4"<<endl; 
if(dmsq23 > 4.0e-2) cerr<<"The input value of |dm32sq| is restricted to the range 2.0E-4 - 4.0E-2 eV^2/c^4, changing it to 4.0E-2 eV^2/c^4"<<endl; 
dmsq12 = TMath::Min(dmsq12, 5.0e-3); 
dmsq12 = TMath::Max(dmsq12, 5.0e-6); 
dmsq23 = TMath::Min(dmsq23, 4.0e-2); 
dmsq23 = TMath::Max(dmsq23, 2.0e-4); 
if(fMassHierarchy == kNmhInverted) { 
dmsq23 = -dmsq23; 
} 
dmsq13 = dmsq12 + dmsq23; 
sinsqtheta12 = TMath::Min(0.99999,sinsqtheta12); 
sinsqtheta12 = TMath::Max(0.,sinsqtheta12); 
sinsqtheta13 = TMath::Min(0.99999,sinsqtheta13); 
sinsqtheta13 = TMath::Max(0.,sinsqtheta13); 
sinsqtheta23 = TMath::Min(0.99999,sinsqtheta23); 
sinsqtheta23 = TMath::Max(0.,sinsqtheta23); 
double s12 = sqrt(sinsqtheta12); 
double s13 = sqrt(sinsqtheta13); 
double s23 = sqrt(sinsqtheta23); 
double c12 = sqrt(1 - s12 * s12); 
double c13 = sqrt(1 - s13 * s13); 
double c23 = sqrt(1 - s23 * s23); 
CalcPMNSElements(s12, c12, s13, c13, s23, c23, dmsq12, dmsq13, deltaCP); 
useEquations12 = true; 
if(((fabs(deltaCP) > 3.10 && fabs(deltaCP) < 3.18) || fabs(deltaCP) < 0.01 || fabs(fabs(deltaCP) - 6.2832) < 0.01) && sinsqtheta13 > 3.0e-9) useEquations12 = false; 
if(sinsqtheta13 < 3.0e-6 && sinsqtheta23 < 3.0e-6 && sinsqtheta12 >= 3.0e-7) nFlavourIndex = 12; 
else if(sinsqtheta12 < 3.0e-5 && sinsqtheta23 < 3.0e-7 && sinsqtheta13 >= 3.0e-7) nFlavourIndex = 13; 
else if(sinsqtheta12 < 3.0e-5 && sinsqtheta13 < 3.0e-5 && sinsqtheta23 >= 3.0e-7) nFlavourIndex = 23; 
else nFlavourIndex = -1; 
if(sinsqtheta12 < 3.0e-7 && sinsqtheta13 < 3.0e-7 && sinsqtheta23 < 3.0e-7) nFlavourIndex = 0; 
} 
void NuOsc3Flavour::SetOscParametersSinSqTAllSinDeltaCP(  double sinsqtheta12, double sinsqtheta13, double sinsqtheta23,  double dmsq12_in, double dmsq23_in,  double sindeltaCP) { 
dmsq12 = dmsq12_in; 
dmsq23 = dmsq23_in; 
if(dmsq12 < 5.0e-6) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4, changing it to 5.0E-6 eV^2/c^4"<<endl; 
if(dmsq12 > 5.0e-3) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4, changing it to 5.0E-3 eV^2/c^4"<<endl; 
if(dmsq23 < 2.0e-4) cerr<<"The input value of |dm32sq| is restricted to the range 2.0E-4 - 4.0E-2 eV^2/c^4, changing it to 2.0E-4 eV^2/c^4"<<endl; 
if(dmsq23 > 4.0e-2) cerr<<"The input value of |dm32sq| is restricted to the range 2.0E-4 - 4.0E-2 eV^2/c^4, changing it to 4.0E-2 eV^2/c^4"<<endl; 
dmsq12 = TMath::Min(dmsq12, 5.0e-3); 
dmsq12 = TMath::Max(dmsq12, 5.0e-6); 
dmsq23 = TMath::Min(dmsq23, 4.0e-2); 
dmsq23 = TMath::Max(dmsq23, 2.0e-4); 
if(fMassHierarchy == kNmhInverted) { 
dmsq23 = -dmsq23; 
} 
dmsq13 = dmsq12 + dmsq23; 
sinsqtheta12 = TMath::Min(0.99999,sinsqtheta12); 
sinsqtheta12 = TMath::Max(0.,sinsqtheta12); 
sinsqtheta13 = TMath::Min(0.99999,sinsqtheta13); 
sinsqtheta13 = TMath::Max(0.,sinsqtheta13); 
sinsqtheta23 = TMath::Min(0.99999,sinsqtheta23); 
sinsqtheta23 = TMath::Max(0.,sinsqtheta23); 
double s12 = sqrt(sinsqtheta12); 
double s13 = sqrt(sinsqtheta13); 
double s23 = sqrt(sinsqtheta23); 
double c12 = sqrt(1 - s12 * s12); 
double c13 = sqrt(1 - s13 * s13); 
double c23 = sqrt(1 - s23 * s23); 
double cosdeltaCP = sqrt(1-sindeltaCP*sindeltaCP); 
PMNSVacuum[0][0][re] = c12*c13; 
PMNSVacuum[0][0][im] = 0.0; 
PMNSVacuum[0][1][re] = c13*s12; 
PMNSVacuum[0][1][im] = 0.0; 
PMNSVacuum[0][2][re] = s13*cosdeltaCP; 
PMNSVacuum[0][2][im] = s13*sindeltaCP; 
PMNSVacuum[1][0][re] = -s12*c23 - c12*s23*s13*cosdeltaCP; 
PMNSVacuum[1][0][im] = -s12*c23 - c12*s23*s13*sindeltaCP; 
PMNSVacuum[1][1][re] = c12*c23 - s12*s23*s13*cosdeltaCP; 
PMNSVacuum[1][1][im] = c12*c23 - s12*s23*s13*sindeltaCP; 
PMNSVacuum[1][2][re] = s23*c13; 
PMNSVacuum[1][2][im] = 0.0; 
PMNSVacuum[2][0][re] = s12*s23 - s13*c12*c23*cosdeltaCP; 
PMNSVacuum[2][0][im] = s12*s23 - s13*c12*c23*sindeltaCP; 
PMNSVacuum[2][1][re] = -s23*c12 - s12*c23*s13*cosdeltaCP; 
PMNSVacuum[2][1][im] = -s23*c12 - s12*c23*s13*sindeltaCP; 
PMNSVacuum[2][2][re] = c13*c23; 
PMNSVacuum[2][2][im] = 0.0; 
modUe1sq = c12*c12*c13*c13; 
modUe2sq = c13*c13*s12*s12; 
modUe3sq = s13*s13; 
modUmu1sq = s12*s12*c23*c23 + 2*s12*c23*c12*s23*s13*cosdeltaCP + c12*c12*s23*s23*s13*s13; 
modUmu2sq = c12*c12*c23*c23 - 2*c12*c23*s12*s23*s13*cosdeltaCP + s12*s12*s23*s23*s13*s13; 
modUmu3sq = s23*s23*c13*c13; 
modUtau1sq = s12*s12*s23*s23 - 2*s12*s23*s13*c12*c23*cosdeltaCP + s13*s13*c12*c12*c23*c23; 
modUtau2sq = s23*s23*c12*c12 + 2*s23*c12*s12*c23*s13*cosdeltaCP + s12*s12*c23*c23*s13*s13; 
modUtau3sq = c13*c13*c23*c23; 
Re12 = c13*c13*s12*c12*(-c12*c23*c23*s12 + s12*s13*s13*s23*s23*c12 + (s12*s12*s13*s23*c23 - c12*c23*s13*s23*c12) * cosdeltaCP); 
Im12 = -c13*c13*s12*c12*c23*s13*s23*sindeltaCP; 
arg12 = atan2(Im12, Re12); 
Re13 = -s13*c13*c13*s23*s23*c12*s13*c12 - s13*c13*c13*s23*c23*s12*c12*cosdeltaCP; 
Im13 = s13*c13*c13*s23*c23*s12*c12*sindeltaCP; 
arg13 = atan2(Im13, Re13); 
Re23 = -s13*s13*c13*c13*s23*s23*s12*s12 + s13*c13*c13*s23*s12*c12*c23*cosdeltaCP; 
Im23 = -s13*c13*c13*s23*s12*c12*c23*sindeltaCP; 
arg23 = atan2(Im23, Re23); 
UMassUdaggerVacuum[0][0][re] = c13*c13*s12*s12*dmsq12 + s13*s13*dmsq13; 
UMassUdaggerVacuum[0][0][im] = 0.0; 
UMassUdaggerVacuum[0][1][re] = c13*s12*(c12*c23 - s12*s13*s23*cosdeltaCP)*dmsq12 + s13*c13*s23*cosdeltaCP*dmsq13; 
UMassUdaggerVacuum[0][1][im] = c13*s12*s12*s13*s23*sindeltaCP*dmsq12 - s13*c13*s23*sindeltaCP*dmsq13; 
UMassUdaggerVacuum[0][2][re] = c13*s12*(-s23*c12 - s12*c23*s13*cosdeltaCP)*dmsq12 + s13*c13*c23*cosdeltaCP*dmsq13; 
UMassUdaggerVacuum[0][2][im] = c13*s12*s12*c23*s13*sindeltaCP*dmsq12 - s13*c13*c23*sindeltaCP*dmsq13; 
UMassUdaggerVacuum[1][0][re] = c13*s12*(c12*c23 - s12*s13*s23*cosdeltaCP)*dmsq12 + s13*c13*s23*cosdeltaCP*dmsq13; 
UMassUdaggerVacuum[1][0][im] = -c13*s12*s12*s13*s23*sindeltaCP*dmsq12 + s13*c13*s23*sindeltaCP*dmsq13; 
UMassUdaggerVacuum[1][1][re] = (c12*c12*c23*c23 + s12*s12*s13*s13*s23*s23 - 2.0*c12*c23*s12*s13*s23*cosdeltaCP)*dmsq12 + c13*c13*s23*s23*dmsq13; 
UMassUdaggerVacuum[1][1][im] = 0.0; 
UMassUdaggerVacuum[1][2][re] = (-c12*c23*s23*c12 + s12*s12*c23*s13*s13*s23 + s23*c12*s12*s13*s23*cosdeltaCP  -c12*c23*s12*c23*s13*cosdeltaCP) * dmsq12 + c13*c13*s23*c23*dmsq13; 
UMassUdaggerVacuum[1][2][im] = (s23*c12*s12*s13*s23*sindeltaCP + c12*c23*s12*c23*s13*sindeltaCP) * dmsq12; 
UMassUdaggerVacuum[2][0][re] = c13*s12*(-s23*c12 - s12*c23*s13*cosdeltaCP)*dmsq12 + s13*c13*c23*cosdeltaCP*dmsq13; 
UMassUdaggerVacuum[2][0][im] = -c13*s12*s12*c23*s13*sindeltaCP*dmsq12 + s13*c13*c23*sindeltaCP*dmsq13; 
UMassUdaggerVacuum[2][1][re] = (-c12*c23*s23*c12 + s12*s12*s13*s13*s23*c23 - c12*c23*s12*c23*s13*cosdeltaCP  +s23*s23*c12*s12*s13*cosdeltaCP) * dmsq12 + c13*c13*s23*c23*dmsq13; 
UMassUdaggerVacuum[2][1][im] = (-c12*c23*s12*c23*s13*sindeltaCP - s23*s23*c12*s12*s13*sindeltaCP) * dmsq12; 
UMassUdaggerVacuum[2][2][re] = (s23*s23*c12*c12 + s12*s12*c23*c23*s13*s13 + 2.0*s23*c12*s12*c23*s13*cosdeltaCP) * dmsq12 + c13*c13*c23*c23*dmsq13; 
UMassUdaggerVacuum[2][2][im] = 0.0; 
useEquations12 = true; 
if(sinsqtheta13 < 3.0e-6 && sinsqtheta23 < 3.0e-6 && sinsqtheta12 >= 3.0e-7) nFlavourIndex = 12; 
else if(sinsqtheta12 < 3.0e-5 && sinsqtheta23 < 3.0e-7 && sinsqtheta13 >= 3.0e-7) nFlavourIndex = 13; 
else if(sinsqtheta12 < 3.0e-5 && sinsqtheta13 < 3.0e-5 && sinsqtheta23 >= 3.0e-7) nFlavourIndex = 23; 
else nFlavourIndex = -1; 
if(sinsqtheta12 < 3.0e-7 && sinsqtheta13 < 3.0e-7 && sinsqtheta23 < 3.0e-7) nFlavourIndex = 0; 
} 
void NuOsc3Flavour::SetOscParametersSSq2TDmAtmSol(  double sinsq2theta12, double sinsq2theta13, double sinsq2theta23,  double dmsq12_in, double dmsqAtm_in,  double deltaCP) { 
dmsq12 = dmsq12_in; 
dmsqAtm = dmsqAtm_in; 
if(dmsq12 < 5.0e-6) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4, changing it to 5.0E-6 eV^2/c^4"<<endl; 
if(dmsq12 > 5.0e-3) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4, changing it to 5.0E-3 eV^2/c^4"<<endl; 
if(dmsqAtm < 2.0e-4) cerr<<"The input value of the Fogli-Lisi |dmsq| is restricted to the range 2.0E-4 - 2.0E-2 eV^2/c^4, changing it to 2.0E-4 eV^2/c^4"<<endl; 
if(dmsqAtm > 4.0e-2) cerr<<"The input value of the Fogli-Lisi |dmsq| is restricted to the range 2.0E-4 - 4.0E-2 eV^2/c^4, changing it to 4.0E-2 eV^2/c^4"<<endl; 
dmsq12 = TMath::Min(dmsq12, 5.0e-3); 
dmsq12 = TMath::Max(dmsq12, 5.0e-6); 
dmsqAtm = TMath::Min(dmsqAtm, 4.0e-2); 
dmsqAtm = TMath::Max(dmsqAtm, 2.0e-4); 
if(fMassHierarchy == kNmhInverted) { 
dmsqAtm = -dmsqAtm; 
} 
dmsq23 = dmsqAtm - 0.5*dmsq12; 
dmsq13 = dmsqAtm + 0.5*dmsq12; 
sinsq2theta12 = TMath::Min(1.,sinsq2theta12); 
sinsq2theta12 = TMath::Max(0.,sinsq2theta12); 
sinsq2theta13 = TMath::Min(1.,sinsq2theta13); 
sinsq2theta13 = TMath::Max(0.,sinsq2theta13); 
sinsq2theta23 = TMath::Min(1.,sinsq2theta23); 
sinsq2theta23 = TMath::Max(0.,sinsq2theta23); 
double s12 = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta12))); 
double s13 = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta13))); 
double s23 = 0; 
if(Opt::Instance()->gOscOctantChoice == conv::kNuOctantOne) s23 = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta23))); 
else if(Opt::Instance()->gOscOctantChoice == conv::kNuOctantTwo) s23 = sqrt(1 - (0.5 * (1 - sqrt(1 - sinsq2theta23)))); 
double c12 = sqrt(1 - s12 * s12); 
double c13 = sqrt(1 - s13 * s13); 
double c23 = sqrt(1 - s23 * s23); 
CalcPMNSElements(s12, c12, s13, c13, s23, c23, dmsq12, dmsq13, deltaCP); 
useEquations12 = true; 
if(((fabs(deltaCP) > 3.10 && fabs(deltaCP) < 3.18) || fabs(deltaCP) < 0.01 || fabs(fabs(deltaCP) - 6.2832) < 0.01) && sinsq2theta13 > 1.0e-8) useEquations12 = false; 
if(sinsq2theta13 < 1.0e-5 && sinsq2theta23 < 1.0e-5 && sinsq2theta12 >= 1.0e-6) nFlavourIndex = 12; 
else if(sinsq2theta12 < 1.0e-4 && sinsq2theta23 < 1.0e-6 && sinsq2theta13 >= 1.0e-6) nFlavourIndex = 13; 
else if(sinsq2theta12 < 1.0e-4 && sinsq2theta13 < 1.0e-4 && sinsq2theta23 >= 1.0e-6) nFlavourIndex = 23; 
else nFlavourIndex = -1; 
if(sinsq2theta12 < 1.0e-6 && sinsq2theta13 < 1.0e-6 && sinsq2theta23 < 1.0e-6) nFlavourIndex = 0; 
} 
void NuOsc3Flavour::SetOscParametersDmsqAtmSol(  double sinsqtheta12, double sinsqtheta13, double sinsqtheta23,  double dmsq12_in, double dmsqAtm_in,  double deltaCP) { 
dmsq12 = dmsq12_in; 
dmsqAtm = dmsqAtm_in; 
if(dmsq12 < 5.0e-6) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4, changing it to 5.0E-6 eV^2/c^4"<<endl; 
if(dmsq12 > 5.0e-3) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4, changing it to 5.0E-3 eV^2/c^4"<<endl; 
if(dmsqAtm < 2.0e-4) cerr<<"The input value of the Fogli-Lisi |dmsq| is restricted to the range 2.0E-4 - 2.0E-2 eV^2/c^4, changing it to 2.0E-4 eV^2/c^4"<<endl; 
if(dmsqAtm > 4.0e-2) cerr<<"The input value of the Fogli-Lisi |dmsq| is restricted to the range 2.0E-4 - 4.0E-2 eV^2/c^4, changing it to 4.0E-2 eV^2/c^4"<<endl; 
dmsq12 = TMath::Min(dmsq12, 5.0e-3); 
dmsq12 = TMath::Max(dmsq12, 5.0e-6); 
dmsqAtm = TMath::Min(dmsqAtm, 4.0e-2); 
dmsqAtm = TMath::Max(dmsqAtm, 2.0e-4); 
if(fMassHierarchy == kNmhInverted) { 
dmsqAtm = -dmsqAtm; 
} 
dmsq23 = dmsqAtm - 0.5*dmsq12; 
dmsq13 = dmsqAtm + 0.5*dmsq12; 
sinsqtheta12 = TMath::Min(0.99999,sinsqtheta12); 
sinsqtheta12 = TMath::Max(0.,sinsqtheta12); 
sinsqtheta13 = TMath::Min(0.99999,sinsqtheta13); 
sinsqtheta13 = TMath::Max(0.,sinsqtheta13); 
sinsqtheta23 = TMath::Min(0.99999,sinsqtheta23); 
sinsqtheta23 = TMath::Max(0.,sinsqtheta23); 
double s12 = sqrt(sinsqtheta12); 
double s13 = sqrt(sinsqtheta13); 
double s23 = sqrt(sinsqtheta23); 
double c12 = sqrt(1 - s12 * s12); 
double c13 = sqrt(1 - s13 * s13); 
double c23 = sqrt(1 - s23 * s23); 
CalcPMNSElements(s12, c12, s13, c13, s23, c23, dmsq12, dmsq13, deltaCP); 
useEquations12 = true; 
if(((fabs(deltaCP) > 3.10 && fabs(deltaCP) < 3.18) || fabs(deltaCP) < 0.01 || fabs(fabs(deltaCP) - 6.2832) < 0.01) && sinsqtheta13 > 3.0e-9) useEquations12 = false; 
if(sinsqtheta13 < 3.0e-6 && sinsqtheta23 < 3.0e-6 && sinsqtheta12 >= 3.0e-7) nFlavourIndex = 12; 
else if(sinsqtheta12 < 3.0e-5 && sinsqtheta23 < 3.0e-7 && sinsqtheta13 >= 3.0e-7) nFlavourIndex = 13; 
else if(sinsqtheta12 < 3.0e-5 && sinsqtheta13 < 3.0e-5 && sinsqtheta23 >= 3.0e-7) nFlavourIndex = 23; 
else nFlavourIndex = -1; 
if(sinsqtheta12 < 3.0e-7 && sinsqtheta13 < 3.0e-7 && sinsqtheta23 < 3.0e-7) nFlavourIndex = 0; 
} 
void NuOsc3Flavour::SetOscParametersDmsqAtmSolSinDeltaCP(  double sinsqtheta12, double sinsqtheta13, double sinsqtheta23,  double dmsq12_in, double dmsqAtm_in,  double sindeltaCP) { 
dmsq12 = dmsq12_in; 
dmsqAtm = dmsqAtm_in; 
if(dmsq12 > 5.0e-3 || dmsq12 < 5.0e-6) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4"<<endl; 
if(dmsqAtm > 4.0e-2 || dmsqAtm < 2.0e-4) cerr<<"The input value of the Fogli-Lisi |dmsq| is restricted to the range 2.0E-4 - 4.0E-2 eV^2/c^4"<<endl; 
dmsq12 = TMath::Min(dmsq12, 5.0e-3); 
dmsq12 = TMath::Max(dmsq12, 5.0e-6); 
dmsqAtm = TMath::Min(dmsqAtm, 4.0e-2); 
dmsqAtm = TMath::Max(dmsqAtm, 2.0e-4); 
if(fMassHierarchy == kNmhInverted) { 
dmsqAtm = -dmsqAtm; 
} 
dmsq23 = dmsqAtm - 0.5*dmsq12; 
dmsq13 = dmsqAtm + 0.5*dmsq12; 
sinsqtheta12 = TMath::Min(0.99999,sinsqtheta12); 
sinsqtheta12 = TMath::Max(0.,sinsqtheta12); 
sinsqtheta13 = TMath::Min(0.99999,sinsqtheta13); 
sinsqtheta13 = TMath::Max(0.,sinsqtheta13); 
sinsqtheta23 = TMath::Min(0.99999,sinsqtheta23); 
sinsqtheta23 = TMath::Max(0.,sinsqtheta23); 
double s12 = sqrt(sinsqtheta12); 
double s13 = sqrt(sinsqtheta13); 
double s23 = sqrt(sinsqtheta23); 
double c12 = sqrt(1 - s12 * s12); 
double c13 = sqrt(1 - s13 * s13); 
double c23 = sqrt(1 - s23 * s23); 
double cosdeltaCP = sqrt(1-sindeltaCP*sindeltaCP); 
PMNSVacuum[0][0][re] = c12*c13; 
PMNSVacuum[0][0][im] = 0.0; 
PMNSVacuum[0][1][re] = c13*s12; 
PMNSVacuum[0][1][im] = 0.0; 
PMNSVacuum[0][2][re] = s13*cosdeltaCP; 
PMNSVacuum[0][2][im] = s13*sindeltaCP; 
PMNSVacuum[1][0][re] = -s12*c23 - c12*s23*s13*cosdeltaCP; 
PMNSVacuum[1][0][im] = -s12*c23 - c12*s23*s13*sindeltaCP; 
PMNSVacuum[1][1][re] = c12*c23 - s12*s23*s13*cosdeltaCP; 
PMNSVacuum[1][1][im] = c12*c23 - s12*s23*s13*sindeltaCP; 
PMNSVacuum[1][2][re] = s23*c13; 
PMNSVacuum[1][2][im] = 0.0; 
PMNSVacuum[2][0][re] = s12*s23 - s13*c12*c23*cosdeltaCP; 
PMNSVacuum[2][0][im] = s12*s23 - s13*c12*c23*sindeltaCP; 
PMNSVacuum[2][1][re] = -s23*c12 - s12*c23*s13*cosdeltaCP; 
PMNSVacuum[2][1][im] = -s23*c12 - s12*c23*s13*sindeltaCP; 
PMNSVacuum[2][2][re] = c13*c23; 
PMNSVacuum[2][2][im] = 0.0; 
modUe1sq = c12*c12*c13*c13; 
modUe2sq = c13*c13*s12*s12; 
modUe3sq = s13*s13; 
modUmu1sq = s12*s12*c23*c23 + 2*s12*c23*c12*s23*s13*cosdeltaCP + c12*c12*s23*s23*s13*s13; 
modUmu2sq = c12*c12*c23*c23 - 2*c12*c23*s12*s23*s13*cosdeltaCP + s12*s12*s23*s23*s13*s13; 
modUmu3sq = s23*s23*c13*c13; 
modUtau1sq = s12*s12*s23*s23 - 2*s12*s23*s13*c12*c23*cosdeltaCP + s13*s13*c12*c12*c23*c23; 
modUtau2sq = s23*s23*c12*c12 + 2*s23*c12*s12*c23*s13*cosdeltaCP + s12*s12*c23*c23*s13*s13; 
modUtau3sq = c13*c13*c23*c23; 
Re12 = c13*c13*s12*c12*(-c12*c23*c23*s12 + s12*s13*s13*s23*s23*c12 + (s12*s12*s13*s23*c23 - c12*c23*s13*s23*c12) * cosdeltaCP); 
Im12 = -c13*c13*s12*c12*c23*s13*s23*sindeltaCP; 
arg12 = atan2(Im12, Re12); 
Re13 = -s13*c13*c13*s23*s23*c12*s13*c12 - s13*c13*c13*s23*c23*s12*c12*cosdeltaCP; 
Im13 = s13*c13*c13*s23*c23*s12*c12*sindeltaCP; 
arg13 = atan2(Im13, Re13); 
Re23 = -s13*s13*c13*c13*s23*s23*s12*s12 + s13*c13*c13*s23*s12*c12*c23*cosdeltaCP; 
Im23 = -s13*c13*c13*s23*s12*c12*c23*sindeltaCP; 
arg23 = atan2(Im23, Re23); 
UMassUdaggerVacuum[0][0][re] = c13*c13*s12*s12*dmsq12 + s13*s13*dmsq13; 
UMassUdaggerVacuum[0][0][im] = 0.0; 
UMassUdaggerVacuum[0][1][re] = c13*s12*(c12*c23 - s12*s13*s23*cosdeltaCP)*dmsq12 + s13*c13*s23*cosdeltaCP*dmsq13; 
UMassUdaggerVacuum[0][1][im] = c13*s12*s12*s13*s23*sindeltaCP*dmsq12 - s13*c13*s23*sindeltaCP*dmsq13; 
UMassUdaggerVacuum[0][2][re] = c13*s12*(-s23*c12 - s12*c23*s13*cosdeltaCP)*dmsq12 + s13*c13*c23*cosdeltaCP*dmsq13; 
UMassUdaggerVacuum[0][2][im] = c13*s12*s12*c23*s13*sindeltaCP*dmsq12 - s13*c13*c23*sindeltaCP*dmsq13; 
UMassUdaggerVacuum[1][0][re] = c13*s12*(c12*c23 - s12*s13*s23*cosdeltaCP)*dmsq12 + s13*c13*s23*cosdeltaCP*dmsq13; 
UMassUdaggerVacuum[1][0][im] = -c13*s12*s12*s13*s23*sindeltaCP*dmsq12 + s13*c13*s23*sindeltaCP*dmsq13; 
UMassUdaggerVacuum[1][1][re] = (c12*c12*c23*c23 + s12*s12*s13*s13*s23*s23 - 2.0*c12*c23*s12*s13*s23*cosdeltaCP)*dmsq12 + c13*c13*s23*s23*dmsq13; 
UMassUdaggerVacuum[1][1][im] = 0.0; 
UMassUdaggerVacuum[1][2][re] = (-c12*c23*s23*c12 + s12*s12*c23*s13*s13*s23 + s23*c12*s12*s13*s23*cosdeltaCP -c12*c23*s12*c23*s13*cosdeltaCP) * dmsq12 + c13*c13*s23*c23*dmsq13; 
UMassUdaggerVacuum[1][2][im] = (s23*c12*s12*s13*s23*sindeltaCP + c12*c23*s12*c23*s13*sindeltaCP) * dmsq12; 
UMassUdaggerVacuum[2][0][re] = c13*s12*(-s23*c12 - s12*c23*s13*cosdeltaCP)*dmsq12 + s13*c13*c23*cosdeltaCP*dmsq13; 
UMassUdaggerVacuum[2][0][im] = -c13*s12*s12*c23*s13*sindeltaCP*dmsq12 + s13*c13*c23*sindeltaCP*dmsq13; 
UMassUdaggerVacuum[2][1][re] = (-c12*c23*s23*c12 + s12*s12*s13*s13*s23*c23 - c12*c23*s12*c23*s13*cosdeltaCP +s23*s23*c12*s12*s13*cosdeltaCP) * dmsq12 + c13*c13*s23*c23*dmsq13; 
UMassUdaggerVacuum[2][1][im] = (-c12*c23*s12*c23*s13*sindeltaCP - s23*s23*c12*s12*s13*sindeltaCP) * dmsq12; 
UMassUdaggerVacuum[2][2][re] = (s23*s23*c12*c12 + s12*s12*c23*c23*s13*s13 + 2.0*s23*c12*s12*c23*s13*cosdeltaCP) * dmsq12 + c13*c13*c23*c23*dmsq13; 
UMassUdaggerVacuum[2][2][im] = 0.0; 
useEquations12 = true; 
if(sinsqtheta13 < 3.0e-6 && sinsqtheta23 < 3.0e-6 && sinsqtheta12 >= 3.0e-7) nFlavourIndex = 12; 
else if(sinsqtheta12 < 3.0e-5 && sinsqtheta23 < 3.0e-7 && sinsqtheta13 >= 3.0e-7) nFlavourIndex = 13; 
else if(sinsqtheta12 < 3.0e-5 && sinsqtheta13 < 3.0e-5 && sinsqtheta23 >= 3.0e-7) nFlavourIndex = 23; 
else nFlavourIndex = -1; 
if(sinsqtheta12 < 3.0e-7 && sinsqtheta13 < 3.0e-7 && sinsqtheta23 < 3.0e-7) nFlavourIndex = 0; 
} 
void NuOsc3Flavour::SetOscParametersSSq2TDmsq13( double sinsq2theta12, double sinsq2theta13, double sinsq2theta23, double dmsq12_in, double dmsq13_in, double deltaCP) { 
dmsq12 = dmsq12_in; 
dmsq13 = dmsq13_in; 
if(dmsq12 < 5.0e-6) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4, changing it to 5.0E-6 eV^2/c^4"<<endl; 
if(dmsq12 > 5.0e-3) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4, changing it to 5.0E-3 eV^2/c^4"<<endl; 
if(dmsq13 < 2.0e-4) cerr<<"The input value of |dm31sq| is restricted to the range 2.0E-4 - 2.0E-2 eV^2/c^4, changing it to 2.0E-4 eV^2/c^4"<<endl; 
if(dmsq13 > 4.0e-2) cerr<<"The input value of |dm31sq| is restricted to the range 2.0E-4 - 4.0E-2 eV^2/c^4, changing it to 4.0E-2 eV^2/c^4"<<endl; 
dmsq12 = TMath::Min(dmsq12, 5.0e-3); 
dmsq12 = TMath::Max(dmsq12, 5.0e-6); 
dmsq13 = TMath::Min(dmsq13, 4.0e-2); 
dmsq13 = TMath::Max(dmsq13, 2.0e-4); 
if(dmsq12 > 5.0e-3 || dmsq12 < 5.0e-6) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4"<<endl; 
if(dmsq13 > 2.0e-2 || dmsq13 < 2.0e-4) cerr<<"The input value of |dm31sq| is restricted to the range 2.0E-4 - 2.0E-2 eV^2/c^4"<<endl; 
if(fMassHierarchy == kNmhInverted) { 
dmsq13 = -dmsq13; 
} 
dmsq23 = dmsq13 - dmsq12; 
sinsq2theta12 = TMath::Min(1.,sinsq2theta12); 
sinsq2theta12 = TMath::Max(0.,sinsq2theta12); 
sinsq2theta13 = TMath::Min(1.,sinsq2theta13); 
sinsq2theta13 = TMath::Max(0.,sinsq2theta13); 
sinsq2theta23 = TMath::Min(1.,sinsq2theta23); 
sinsq2theta23 = TMath::Max(0.,sinsq2theta23); 
double s12 = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta12))); 
double s13 = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta13))); 
double s23 = 0; 
if(Opt::Instance()->gOscOctantChoice == conv::kNuOctantOne) s23 = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta23))); 
else if(Opt::Instance()->gOscOctantChoice == conv::kNuOctantTwo) s23 = sqrt(1 - (0.5 * (1 - sqrt(1 - sinsq2theta23)))); 
double c12 = sqrt(1 - s12 * s12); 
double c13 = sqrt(1 - s13 * s13); 
double c23 = sqrt(1 - s23 * s23); 
CalcPMNSElements(s12, c12, s13, c13, s23, c23, dmsq12, dmsq13, deltaCP); 
useEquations12 = true; 
if(((fabs(deltaCP) > 3.10 && fabs(deltaCP) < 3.18) || fabs(deltaCP) < 0.01 || fabs(fabs(deltaCP) - 6.2832) < 0.01) && sinsq2theta13 > 1.0e-8) useEquations12 = false; 
if(sinsq2theta13 < 1.0e-5 && sinsq2theta23 < 1.0e-5 && sinsq2theta12 >= 1.0e-6) nFlavourIndex = 12; 
else if(sinsq2theta12 < 1.0e-4 && sinsq2theta23 < 1.0e-6 && sinsq2theta13 >= 1.0e-6) nFlavourIndex = 13; 
else if(sinsq2theta12 < 1.0e-4 && sinsq2theta13 < 1.0e-4 && sinsq2theta23 >= 1.0e-6) nFlavourIndex = 23; 
else nFlavourIndex = -1; 
if(sinsq2theta12 < 1.0e-6 && sinsq2theta13 < 1.0e-6 && sinsq2theta23 < 1.0e-6) nFlavourIndex = 0; 
} 
void NuOsc3Flavour::SetOscParametersDmsq13(  double sinsqtheta12, double sinsqtheta13, double sinsqtheta23,  double dmsq12_in, double dmsq13_in,  double deltaCP) { 
dmsq12 = dmsq12_in; 
dmsq13 = dmsq13_in; 
if(dmsq12 < 5.0e-6) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4, changing it to 5.0E-6 eV^2/c^4"<<endl; 
if(dmsq12 > 5.0e-3) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4, changing it to 5.0E-3 eV^2/c^4"<<endl; 
if(dmsq13 < 2.0e-4) cerr<<"The input value of |dm31sq| is restricted to the range 2.0E-4 - 2.0E-2 eV^2/c^4, changing it to 2.0E-4 eV^2/c^4"<<endl; 
if(dmsq13 > 4.0e-2) cerr<<"The input value of |dm31sq| is restricted to the range 2.0E-4 - 4.0E-2 eV^2/c^4, changing it to 4.0E-2 eV^2/c^4"<<endl; 
dmsq12 = TMath::Min(dmsq12, 5.0e-3); 
dmsq12 = TMath::Max(dmsq12, 5.0e-6); 
dmsq13 = TMath::Min(dmsq13, 4.0e-2); 
dmsq13 = TMath::Max(dmsq13, 2.0e-4); 
if(fMassHierarchy == kNmhInverted) { 
dmsq13 = -dmsq13; 
} 
dmsq23 = dmsq13 - dmsq12; 
sinsqtheta12 = TMath::Min(0.99999,sinsqtheta12); 
sinsqtheta12 = TMath::Max(0.,sinsqtheta12); 
sinsqtheta13 = TMath::Min(0.99999,sinsqtheta13); 
sinsqtheta13 = TMath::Max(0.,sinsqtheta13); 
sinsqtheta23 = TMath::Min(0.99999,sinsqtheta23); 
sinsqtheta23 = TMath::Max(0.,sinsqtheta23); 
double s12 = sqrt(sinsqtheta12); 
double s13 = sqrt(sinsqtheta13); 
double s23 = sqrt(sinsqtheta23); 
double c12 = sqrt(1 - s12 * s12); 
double c13 = sqrt(1 - s13 * s13); 
double c23 = sqrt(1 - s23 * s23); 
CalcPMNSElements(s12, c12, s13, c13, s23, c23, dmsq12, dmsq13, deltaCP); 
useEquations12 = true; 
if(((fabs(deltaCP) > 3.10 && fabs(deltaCP) < 3.18) || fabs(deltaCP) < 0.01 || fabs(fabs(deltaCP) - 6.2832) < 0.01) && sinsqtheta13 > 3.0e-9) useEquations12 = false; 
if(sinsqtheta13 < 3.0e-6 && sinsqtheta23 < 3.0e-6 && sinsqtheta12 >= 3.0e-7) nFlavourIndex = 12; 
else if(sinsqtheta12 < 3.0e-5 && sinsqtheta23 < 3.0e-7 && sinsqtheta13 >= 3.0e-7) nFlavourIndex = 13; 
else if(sinsqtheta12 < 3.0e-5 && sinsqtheta13 < 3.0e-5 && sinsqtheta23 >= 3.0e-7) nFlavourIndex = 23; 
else nFlavourIndex = -1; 
if(sinsqtheta12 < 3.0e-7 && sinsqtheta13 < 3.0e-7 && sinsqtheta23 < 3.0e-7) nFlavourIndex = 0; 
} 
void NuOsc3Flavour::SetOscParametersDmsq13SinDeltaCP(  double sinsqtheta12, double sinsqtheta13, double sinsqtheta23,  double dmsq12_in, double dmsq13_in,  double sindeltaCP) { 
dmsq12 = dmsq12_in; 
dmsq13 = dmsq13_in; 
if(dmsq12 > 5.0e-3 || dmsq12 < 5.0e-6) cerr<<"The input value of dm21sq is restricted to the range 5.0E-6 - 5.0E-3 eV^2/c^4"<<endl; 
if(dmsq13 > 4.0e-2 || dmsq13 < 2.0e-4) cerr<<"The input value of |dm31sq| is restricted to the range 2.0E-4 - 4.0E-2 eV^2/c^4"<<endl; 
dmsq12 = TMath::Min(dmsq12, 5.0e-3); 
dmsq12 = TMath::Max(dmsq12, 5.0e-6); 
dmsq13 = TMath::Min(dmsq13, 4.0e-2); 
dmsq13 = TMath::Max(dmsq13, 2.0e-4); 
if(fMassHierarchy == kNmhInverted) { 
dmsq13 = -dmsq13; 
} 
dmsq23 = dmsq13 - dmsq12; 
sinsqtheta12 = TMath::Min(0.99999,sinsqtheta12); 
sinsqtheta12 = TMath::Max(0.,sinsqtheta12); 
sinsqtheta13 = TMath::Min(0.99999,sinsqtheta13); 
sinsqtheta13 = TMath::Max(0.,sinsqtheta13); 
sinsqtheta23 = TMath::Min(0.99999,sinsqtheta23); 
sinsqtheta23 = TMath::Max(0.,sinsqtheta23); 
double s12 = sqrt(sinsqtheta12); 
double s13 = sqrt(sinsqtheta13); 
double s23 = sqrt(sinsqtheta23); 
double c12 = sqrt(1 - s12 * s12); 
double c13 = sqrt(1 - s13 * s13); 
double c23 = sqrt(1 - s23 * s23); 
double cosdeltaCP = sqrt(1-sindeltaCP*sindeltaCP); 
PMNSVacuum[0][0][re] = c12*c13; 
PMNSVacuum[0][0][im] = 0.0; 
PMNSVacuum[0][1][re] = c13*s12; 
PMNSVacuum[0][1][im] = 0.0; 
PMNSVacuum[0][2][re] = s13*cosdeltaCP; 
PMNSVacuum[0][2][im] = s13*sindeltaCP; 
PMNSVacuum[1][0][re] = -s12*c23 - c12*s23*s13*cosdeltaCP; 
PMNSVacuum[1][0][im] = -s12*c23 - c12*s23*s13*sindeltaCP; 
PMNSVacuum[1][1][re] = c12*c23 - s12*s23*s13*cosdeltaCP; 
PMNSVacuum[1][1][im] = c12*c23 - s12*s23*s13*sindeltaCP; 
PMNSVacuum[1][2][re] = s23*c13; 
PMNSVacuum[1][2][im] = 0.0; 
PMNSVacuum[2][0][re] = s12*s23 - s13*c12*c23*cosdeltaCP; 
PMNSVacuum[2][0][im] = s12*s23 - s13*c12*c23*sindeltaCP; 
PMNSVacuum[2][1][re] = -s23*c12 - s12*c23*s13*cosdeltaCP; 
PMNSVacuum[2][1][im] = -s23*c12 - s12*c23*s13*sindeltaCP; 
PMNSVacuum[2][2][re] = c13*c23; 
PMNSVacuum[2][2][im] = 0.0; 
modUe1sq = c12*c12*c13*c13; 
modUe2sq = c13*c13*s12*s12; 
modUe3sq = s13*s13; 
modUmu1sq = s12*s12*c23*c23 + 2*s12*c23*c12*s23*s13*cosdeltaCP + c12*c12*s23*s23*s13*s13; 
modUmu2sq = c12*c12*c23*c23 - 2*c12*c23*s12*s23*s13*cosdeltaCP + s12*s12*s23*s23*s13*s13; 
modUmu3sq = s23*s23*c13*c13; 
modUtau1sq = s12*s12*s23*s23 - 2*s12*s23*s13*c12*c23*cosdeltaCP + s13*s13*c12*c12*c23*c23; 
modUtau2sq = s23*s23*c12*c12 + 2*s23*c12*s12*c23*s13*cosdeltaCP + s12*s12*c23*c23*s13*s13; 
modUtau3sq = c13*c13*c23*c23; 
Re12 = c13*c13*s12*c12*(-c12*c23*c23*s12 + s12*s13*s13*s23*s23*c12 + (s12*s12*s13*s23*c23 - c12*c23*s13*s23*c12) * cosdeltaCP); 
Im12 = -c13*c13*s12*c12*c23*s13*s23*sindeltaCP; 
arg12 = atan2(Im12, Re12); 
Re13 = -s13*c13*c13*s23*s23*c12*s13*c12 - s13*c13*c13*s23*c23*s12*c12*cosdeltaCP; 
Im13 = s13*c13*c13*s23*c23*s12*c12*sindeltaCP; 
arg13 = atan2(Im13, Re13); 
Re23 = -s13*s13*c13*c13*s23*s23*s12*s12 + s13*c13*c13*s23*s12*c12*c23*cosdeltaCP; 
Im23 = -s13*c13*c13*s23*s12*c12*c23*sindeltaCP; 
arg23 = atan2(Im23, Re23); 
UMassUdaggerVacuum[0][0][re] = c13*c13*s12*s12*dmsq12 + s13*s13*dmsq13; 
UMassUdaggerVacuum[0][0][im] = 0.0; 
UMassUdaggerVacuum[0][1][re] = c13*s12*(c12*c23 - s12*s13*s23*cosdeltaCP)*dmsq12 + s13*c13*s23*cosdeltaCP*dmsq13; 
UMassUdaggerVacuum[0][1][im] = c13*s12*s12*s13*s23*sindeltaCP*dmsq12 - s13*c13*s23*sindeltaCP*dmsq13; 
UMassUdaggerVacuum[0][2][re] = c13*s12*(-s23*c12 - s12*c23*s13*cosdeltaCP)*dmsq12 + s13*c13*c23*cosdeltaCP*dmsq13; 
UMassUdaggerVacuum[0][2][im] = c13*s12*s12*c23*s13*sindeltaCP*dmsq12 - s13*c13*c23*sindeltaCP*dmsq13; 
UMassUdaggerVacuum[1][0][re] = c13*s12*(c12*c23 - s12*s13*s23*cosdeltaCP)*dmsq12 + s13*c13*s23*cosdeltaCP*dmsq13; 
UMassUdaggerVacuum[1][0][im] = -c13*s12*s12*s13*s23*sindeltaCP*dmsq12 + s13*c13*s23*sindeltaCP*dmsq13; 
UMassUdaggerVacuum[1][1][re] = (c12*c12*c23*c23 + s12*s12*s13*s13*s23*s23 - 2.0*c12*c23*s12*s13*s23*cosdeltaCP)*dmsq12 + c13*c13*s23*s23*dmsq13; 
UMassUdaggerVacuum[1][1][im] = 0.0; 
UMassUdaggerVacuum[1][2][re] = (-c12*c23*s23*c12 + s12*s12*c23*s13*s13*s23 + s23*c12*s12*s13*s23*cosdeltaCP -c12*c23*s12*c23*s13*cosdeltaCP) * dmsq12 + c13*c13*s23*c23*dmsq13; 
UMassUdaggerVacuum[1][2][im] = (s23*c12*s12*s13*s23*sindeltaCP + c12*c23*s12*c23*s13*sindeltaCP) * dmsq12; 
UMassUdaggerVacuum[2][0][re] = c13*s12*(-s23*c12 - s12*c23*s13*cosdeltaCP)*dmsq12 + s13*c13*c23*cosdeltaCP*dmsq13; 
UMassUdaggerVacuum[2][0][im] = -c13*s12*s12*c23*s13*sindeltaCP*dmsq12 + s13*c13*c23*sindeltaCP*dmsq13; 
UMassUdaggerVacuum[2][1][re] = (-c12*c23*s23*c12 + s12*s12*s13*s13*s23*c23 - c12*c23*s12*c23*s13*cosdeltaCP +s23*s23*c12*s12*s13*cosdeltaCP) * dmsq12 + c13*c13*s23*c23*dmsq13; 
UMassUdaggerVacuum[2][1][im] = (-c12*c23*s12*c23*s13*sindeltaCP - s23*s23*c12*s12*s13*sindeltaCP) * dmsq12; 
UMassUdaggerVacuum[2][2][re] = (s23*s23*c12*c12 + s12*s12*c23*c23*s13*s13 + 2.0*s23*c12*s12*c23*s13*cosdeltaCP) * dmsq12 + c13*c13*c23*c23*dmsq13; 
UMassUdaggerVacuum[2][2][im] = 0.0; 
useEquations12 = true; 
if(sinsqtheta13 < 3.0e-6 && sinsqtheta23 < 3.0e-6 && sinsqtheta12 >= 3.0e-7) nFlavourIndex = 12; 
else if(sinsqtheta12 < 3.0e-5 && sinsqtheta23 < 3.0e-7 && sinsqtheta13 >= 3.0e-7) nFlavourIndex = 13; 
else if(sinsqtheta12 < 3.0e-5 && sinsqtheta13 < 3.0e-5 && sinsqtheta23 >= 3.0e-7) nFlavourIndex = 23; 
else nFlavourIndex = -1; 
if(sinsqtheta12 < 3.0e-7 && sinsqtheta13 < 3.0e-7 && sinsqtheta23 < 3.0e-7) nFlavourIndex = 0; 
} 
void NuOsc3Flavour::CalcPMNSElements(double s12, double c12, double s13, double c13, double s23, double c23, double dmsq21, double dmsq31, double deltaCP) { 
PMNSVacuum[0][0][re] = c12*c13; 
PMNSVacuum[0][0][im] = 0.0; 
PMNSVacuum[0][1][re] = c13*s12; 
PMNSVacuum[0][1][im] = 0.0; 
PMNSVacuum[0][2][re] = s13*cos(deltaCP); 
PMNSVacuum[0][2][im] = s13*sin(deltaCP); 
PMNSVacuum[1][0][re] = -s12*c23 - c12*s23*s13*cos(deltaCP); 
PMNSVacuum[1][0][im] = -s12*c23 - c12*s23*s13*sin(deltaCP); 
PMNSVacuum[1][1][re] = c12*c23 - s12*s23*s13*cos(deltaCP); 
PMNSVacuum[1][1][im] = c12*c23 - s12*s23*s13*sin(deltaCP); 
PMNSVacuum[1][2][re] = s23*c13; 
PMNSVacuum[1][2][im] = 0.0; 
PMNSVacuum[2][0][re] = s12*s23 - s13*c12*c23*cos(deltaCP); 
PMNSVacuum[2][0][im] = s12*s23 - s13*c12*c23*sin(deltaCP); 
PMNSVacuum[2][1][re] = -s23*c12 - s12*c23*s13*cos(deltaCP); 
PMNSVacuum[2][1][im] = -s23*c12 - s12*c23*s13*sin(deltaCP); 
PMNSVacuum[2][2][re] = c13*c23; 
PMNSVacuum[2][2][im] = 0.0; 
modUe1sq = c12*c12*c13*c13; 
modUe2sq = c13*c13*s12*s12; 
modUe3sq = s13*s13; 
modUmu1sq = s12*s12*c23*c23 + 2*s12*c23*c12*s23*s13*cos(deltaCP) + c12*c12*s23*s23*s13*s13; 
modUmu2sq = c12*c12*c23*c23 - 2*c12*c23*s12*s23*s13*cos(deltaCP) + s12*s12*s23*s23*s13*s13; 
modUmu3sq = s23*s23*c13*c13; 
modUtau1sq = s12*s12*s23*s23 - 2*s12*s23*s13*c12*c23*cos(deltaCP) + s13*s13*c12*c12*c23*c23; 
modUtau2sq = s23*s23*c12*c12 + 2*s23*c12*s12*c23*s13*cos(deltaCP) + s12*s12*c23*c23*s13*s13; 
modUtau3sq = c13*c13*c23*c23; 
Re12 = c13*c13*s12*c12*(-c12*c23*c23*s12 + s12*s13*s13*s23*s23*c12 + (s12*s12*s13*s23*c23 - c12*c23*s13*s23*c12) * cos(deltaCP)); 
Im12 = -c13*c13*s12*c12*c23*s13*s23*sin(deltaCP); 
arg12 = atan2(Im12, Re12); 
Re13 = -s13*c13*c13*s23*s23*c12*s13*c12 - s13*c13*c13*s23*c23*s12*c12*cos(deltaCP); 
Im13 = s13*c13*c13*s23*c23*s12*c12*sin(deltaCP); 
arg13 = atan2(Im13, Re13); 
Re23 = -s13*s13*c13*c13*s23*s23*s12*s12 + s13*c13*c13*s23*s12*c12*c23*cos(deltaCP); 
Im23 = -s13*c13*c13*s23*s12*c12*c23*sin(deltaCP); 
arg23 = atan2(Im23, Re23); 
UMassUdaggerVacuum[0][0][re] = c13*c13*s12*s12*dmsq21 + s13*s13*dmsq31; 
UMassUdaggerVacuum[0][0][im] = 0.0; 
UMassUdaggerVacuum[0][1][re] = c13*s12*(c12*c23 - s12*s13*s23*cos(deltaCP))*dmsq21 + s13*c13*s23*cos(deltaCP)*dmsq31; 
UMassUdaggerVacuum[0][1][im] = c13*s12*s12*s13*s23*sin(deltaCP)*dmsq21 - s13*c13*s23*sin(deltaCP)*dmsq31; 
UMassUdaggerVacuum[0][2][re] = c13*s12*(-s23*c12 - s12*c23*s13*cos(deltaCP))*dmsq21 + s13*c13*c23*cos(deltaCP)*dmsq31; 
UMassUdaggerVacuum[0][2][im] = c13*s12*s12*c23*s13*sin(deltaCP)*dmsq21 - s13*c13*c23*sin(deltaCP)*dmsq31; 
UMassUdaggerVacuum[1][0][re] = c13*s12*(c12*c23 - s12*s13*s23*cos(deltaCP))*dmsq21 + s13*c13*s23*cos(deltaCP)*dmsq31; 
UMassUdaggerVacuum[1][0][im] = -c13*s12*s12*s13*s23*sin(deltaCP)*dmsq21 + s13*c13*s23*sin(deltaCP)*dmsq31; 
UMassUdaggerVacuum[1][1][re] = (c12*c12*c23*c23 + s12*s12*s13*s13*s23*s23 - 2.0*c12*c23*s12*s13*s23*cos(deltaCP))*dmsq21 + c13*c13*s23*s23*dmsq31; 
UMassUdaggerVacuum[1][1][im] = 0.0; 
UMassUdaggerVacuum[1][2][re] = (-c12*c23*s23*c12 + s12*s12*c23*s13*s13*s23 + s23*c12*s12*s13*s23*cos(deltaCP) -c12*c23*s12*c23*s13*cos(deltaCP)) * dmsq21 + c13*c13*s23*c23*dmsq31; 
UMassUdaggerVacuum[1][2][im] = (s23*c12*s12*s13*s23*sin(deltaCP) + c12*c23*s12*c23*s13*sin(deltaCP)) * dmsq21; 
UMassUdaggerVacuum[2][0][re] = c13*s12*(-s23*c12 - s12*c23*s13*cos(deltaCP))*dmsq21 + s13*c13*c23*cos(deltaCP)*dmsq31; 
UMassUdaggerVacuum[2][0][im] = -c13*s12*s12*c23*s13*sin(deltaCP)*dmsq21 + s13*c13*c23*sin(deltaCP)*dmsq31; 
UMassUdaggerVacuum[2][1][re] = (-c12*c23*s23*c12 + s12*s12*s13*s13*s23*c23 - c12*c23*s12*c23*s13*cos(deltaCP) +s23*s23*c12*s12*s13*cos(deltaCP)) * dmsq21 + c13*c13*s23*c23*dmsq31; 
UMassUdaggerVacuum[2][1][im] = (-c12*c23*s12*c23*s13*sin(deltaCP) - s23*s23*c12*s12*s13*sin(deltaCP)) * dmsq21; 
UMassUdaggerVacuum[2][2][re] = (s23*s23*c12*c12 + s12*s12*c23*c23*s13*s13 + 2.0*s23*c12*s12*c23*s13*cos(deltaCP)) * dmsq21 + c13*c13*c23*c23*dmsq31; 
UMassUdaggerVacuum[2][2][im] = 0.0; 
} 
std::complex<double> NuOsc3Flavour::GetPMNSElement(int row, int column) { 
std::complex<double> element(PMNSVacuum[row][column][re], PMNSVacuum[row][column][im]); 
return element; 
} 
double NuOsc3Flavour::CalcVacuumOscProb(int nu_start, int nu_end, double energy) { 
OscChannelId_t osch = util::GetOscChannel(nu_start, nu_end); 
if(osch == kOscUndefined) { 
assert(1); 
return 0.; 
} 
double oscProb = 0.0; 
double sinsqDelta23 = sin((kOscDimensFactor * dmsq23 * fBaseline) / energy) * sin((kOscDimensFactor * dmsq23 * fBaseline) / energy); 
double sinsqDelta12 = sin((kOscDimensFactor * dmsq12 * fBaseline) / energy) * sin((kOscDimensFactor * dmsq12 * fBaseline) / energy); 
double sinsqDelta13 = sin((kOscDimensFactor * dmsq13 * fBaseline) / energy) * sin((kOscDimensFactor * dmsq13 * fBaseline) / energy); 
double sinDelta23 = sin((2.0 * kOscDimensFactor * dmsq23 * fBaseline) / energy); 
double sinDelta12 = sin((2.0 * kOscDimensFactor * dmsq12 * fBaseline) / energy); 
double sinDelta13 = sin((2.0 * kOscDimensFactor * dmsq13 * fBaseline) / energy); 
if(osch == kOscNuE2NuE || osch == kOscNuEBar2NuEBar) { 
oscProb = 1 - (4 * (modUe2sq*modUe1sq*sinsqDelta12 + modUe3sq*modUe1sq*sinsqDelta13 + modUe3sq*modUe2sq*sinsqDelta23)); 
} 
else if(osch == kOscNuMu2NuE || osch == kOscNuEBar2NuMuBar) { 
oscProb = 2 * (Im12*sinDelta12 + Im13*sinDelta13 + Im23*sinDelta23) - 4 * (Re12*sinsqDelta12 + Re13*sinsqDelta13 + Re23*sinsqDelta23); 
} 
else if(osch == kOscNuMuBar2NuEBar || osch == kOscNuE2NuMu) { 
oscProb = -2 * (Im12*sinDelta12 + Im13*sinDelta13 + Im23*sinDelta23) - 4 * (Re12*sinsqDelta12 + Re13*sinsqDelta13 + Re23*sinsqDelta23); 
} 
else if(osch == kOscNuMu2NuMu || osch == kOscNuMuBar2NuMuBar) { 
oscProb = 1 - (4 * (modUmu2sq*modUmu1sq*sinsqDelta12 + modUmu3sq*modUmu1sq*sinsqDelta13 + modUmu3sq*modUmu2sq*sinsqDelta23)); 
} 
else if(osch == kOscNuE2NuTau || osch == kOscNuTauBar2NuEBar) { 
oscProb += 1 - (4 * (modUe2sq*modUe1sq*sinsqDelta12  + modUe3sq*modUe1sq*sinsqDelta13 + modUe3sq*modUe2sq*sinsqDelta23)); 
oscProb += -2 * (Im12*sinDelta12 + Im13*sinDelta13 + Im23*sinDelta23)  - 4 * (Re12*sinsqDelta12 + Re13*sinsqDelta13 + Re23*sinsqDelta23); 
oscProb = 1.0 - oscProb; 
} 
else if(osch == kOscNuEBar2NuTauBar || osch == kOscNuTau2NuE) { 
oscProb += 1 - (4 * (modUe2sq*modUe1sq*sinsqDelta12  + modUe3sq*modUe1sq*sinsqDelta13 + modUe3sq*modUe2sq*sinsqDelta23)); 
oscProb += 2 * (Im12*sinDelta12 + Im13*sinDelta13 + Im23*sinDelta23)  - 4 * (Re12*sinsqDelta12 + Re13*sinsqDelta13 + Re23*sinsqDelta23); 
oscProb = 1.0 - oscProb; 
} 
else if(osch == kOscNuMu2NuTau || osch == kOscNuTauBar2NuMuBar) { 
oscProb += 2 * (Im12*sinDelta12 + Im13*sinDelta13 + Im23*sinDelta23)  - 4 * (Re12*sinsqDelta12 + Re13*sinsqDelta13 + Re23*sinsqDelta23); 
oscProb += 1 - (4 * (modUmu2sq*modUmu1sq*sinsqDelta12  + modUmu3sq*modUmu1sq*sinsqDelta13 + modUmu3sq*modUmu2sq*sinsqDelta23)); 
oscProb = 1.0 - oscProb; 
} 
else if(osch == kOscNuMuBar2NuTauBar || osch == kOscNuTau2NuMu) { 
oscProb += -2 * (Im12*sinDelta12 + Im13*sinDelta13 + Im23*sinDelta23)  - 4 * (Re12*sinsqDelta12 + Re13*sinsqDelta13 + Re23*sinsqDelta23); 
oscProb += 1 - (4 * (modUmu2sq*modUmu1sq*sinsqDelta12  + modUmu3sq*modUmu1sq*sinsqDelta13 + modUmu3sq*modUmu2sq*sinsqDelta23)); 
oscProb = 1.0 - oscProb; 
} 
else if(osch == kOscNuTau2NuTau || osch == kOscNuTauBar2NuTauBar) { 
oscProb = 1 - (4 * (modUtau2sq*modUtau1sq*sinsqDelta12 + modUtau3sq*modUtau1sq*sinsqDelta13 + modUtau3sq*modUtau2sq*sinsqDelta23)); 
} 
return oscProb; 
} 
double NuOsc3Flavour::CalcVacuumOscProbPDG(int nu_start, int nu_end, double energy) { 
OscChannelId_t osch = util::GetOscChannel(nu_start, nu_end); 
if(osch == kOscUndefined) { 
assert(1); 
return 0.; 
} 
double oscProb = 0.0; 
double cosDelta12; 
double cosDelta13; 
double cosDelta23; 
if( osch == kOscNuE2NuE || osch == kOscNuEBar2NuEBar || osch == kOscNuMu2NuMu || osch == kOscNuMuBar2NuMuBar || osch == kOscNuTau2NuTau || osch == kOscNuTauBar2NuTauBar ) { 
cosDelta12 = cos((2 * kOscDimensFactor * dmsq12 * fBaseline) / energy); 
cosDelta13 = cos((2 * kOscDimensFactor * dmsq13 * fBaseline) / energy); 
cosDelta23 = cos((2 * kOscDimensFactor * dmsq23 * fBaseline) / energy); 
} 
else if( osch == kOscNuMu2NuE || osch == kOscNuEBar2NuMuBar ) { 
cosDelta12 = cos(((2 * kOscDimensFactor * dmsq12 * fBaseline) / energy) - arg12); 
cosDelta13 = cos(((2 * kOscDimensFactor * dmsq13 * fBaseline) / energy) - arg13); 
cosDelta23 = cos(((2 * kOscDimensFactor * dmsq23 * fBaseline) / energy) - arg23); 
} 
else if( osch == kOscNuMuBar2NuEBar || osch == kOscNuE2NuMu ) { 
cosDelta12 = cos(((2 * kOscDimensFactor * dmsq12 * fBaseline) / energy) + arg12); 
cosDelta13 = cos(((2 * kOscDimensFactor * dmsq13 * fBaseline) / energy) + arg13); 
cosDelta23 = cos(((2 * kOscDimensFactor * dmsq23 * fBaseline) / energy) + arg23); 
} 
else { 
assert(!"Failed to calculate cosDelta"); 
} 
if( osch == kOscNuE2NuE || osch == kOscNuEBar2NuEBar ) { 
oscProb = modUe1sq*modUe1sq + modUe2sq*modUe2sq + modUe3sq*modUe3sq + 2*modUe2sq*modUe1sq*cosDelta12 + 2*modUe3sq*modUe1sq*cosDelta13 + 2*modUe2sq*modUe3sq*cosDelta23; 
} 
else if( osch == kOscNuMuBar2NuEBar || osch == kOscNuE2NuMu || osch == kOscNuMu2NuE || osch == kOscNuEBar2NuMuBar ) { 
oscProb = modUe1sq*modUmu1sq + modUe2sq*modUmu2sq + modUe3sq*modUmu3sq + 2*sqrt(Re12*Re12 + Im12*Im12)*cosDelta12 + 2*sqrt(Re13*Re13 + Im13*Im13)*cosDelta13 + 2*sqrt(Re23*Re23 + Im23*Im23)*cosDelta23; 
} 
else if( osch == kOscNuMu2NuMu || osch == kOscNuMuBar2NuMuBar ) { 
oscProb = modUmu1sq*modUmu1sq + modUmu2sq*modUmu2sq + modUmu3sq*modUmu3sq + 2*modUmu2sq*modUmu1sq*cosDelta12 + 2*modUmu3sq*modUmu1sq*cosDelta13 + 2*modUmu2sq*modUmu3sq*cosDelta23; 
} 
else if( osch == kOscNuTau2NuTau || osch == kOscNuTauBar2NuTauBar ) { 
oscProb = modUtau1sq*modUtau1sq + modUtau2sq*modUtau2sq + modUtau3sq*modUtau3sq + 2*modUtau2sq*modUtau1sq*cosDelta12 + 2*modUtau3sq*modUtau1sq*cosDelta13 + 2*modUtau2sq*modUtau3sq*cosDelta23; 
} 
else if( osch == kOscNuE2NuTau || osch == kOscNuTauBar2NuEBar ) { 
cosDelta12 = cos((2 * kOscDimensFactor * dmsq12 * fBaseline) / energy); 
cosDelta13 = cos((2 * kOscDimensFactor * dmsq13 * fBaseline) / energy); 
cosDelta23 = cos((2 * kOscDimensFactor * dmsq23 * fBaseline) / energy); 
oscProb += modUe1sq*modUe1sq + modUe2sq*modUe2sq + modUe3sq*modUe3sq + 2*modUe2sq*modUe1sq*cosDelta12 + 2*modUe3sq*modUe1sq*cosDelta13 + 2*modUe2sq*modUe3sq*cosDelta23; 
cosDelta12 = cos(((2 * kOscDimensFactor * dmsq12 * fBaseline) / energy) + arg12); 
cosDelta13 = cos(((2 * kOscDimensFactor * dmsq13 * fBaseline) / energy) + arg13); 
cosDelta23 = cos(((2 * kOscDimensFactor * dmsq23 * fBaseline) / energy) + arg23); 
oscProb += modUe1sq*modUmu1sq + modUe2sq*modUmu2sq + modUe3sq*modUmu3sq + 2*sqrt(Re12*Re12 + Im12*Im12)*cosDelta12 + 2*sqrt(Re13*Re13 + Im13*Im13)*cosDelta13 + 2*sqrt(Re23*Re23 + Im23*Im23)*cosDelta23; 
oscProb = 1.0 - oscProb; 
} 
else if( osch == kOscNuEBar2NuTauBar || osch == kOscNuTau2NuE ) { 
cosDelta12 = cos((2 * kOscDimensFactor * dmsq12 * fBaseline) / energy); 
cosDelta13 = cos((2 * kOscDimensFactor * dmsq13 * fBaseline) / energy); 
cosDelta23 = cos((2 * kOscDimensFactor * dmsq23 * fBaseline) / energy); 
oscProb += modUe1sq*modUe1sq + modUe2sq*modUe2sq + modUe3sq*modUe3sq + 2*modUe2sq*modUe1sq*cosDelta12 + 2*modUe3sq*modUe1sq*cosDelta13 + 2*modUe2sq*modUe3sq*cosDelta23; 
cosDelta12 = cos(((2 * kOscDimensFactor * dmsq12 * fBaseline) / energy) - arg12); 
cosDelta13 = cos(((2 * kOscDimensFactor * dmsq13 * fBaseline) / energy) - arg13); 
cosDelta23 = cos(((2 * kOscDimensFactor * dmsq23 * fBaseline) / energy) - arg23); 
oscProb += modUe1sq*modUmu1sq + modUe2sq*modUmu2sq + modUe3sq*modUmu3sq + 2*sqrt(Re12*Re12 + Im12*Im12)*cosDelta12 + 2*sqrt(Re13*Re13 + Im13*Im13)*cosDelta13 + 2*sqrt(Re23*Re23 + Im23*Im23)*cosDelta23; 
oscProb = 1.0 - oscProb; 
} 
else if( osch == kOscNuMu2NuTau || osch == kOscNuTauBar2NuMuBar ) { 
cosDelta12 = cos(((2 * kOscDimensFactor * dmsq12 * fBaseline) / energy) - arg12); 
cosDelta13 = cos(((2 * kOscDimensFactor * dmsq13 * fBaseline) / energy) - arg13); 
cosDelta23 = cos(((2 * kOscDimensFactor * dmsq23 * fBaseline) / energy) - arg23); 
oscProb += modUe1sq*modUmu1sq + modUe2sq*modUmu2sq + modUe3sq*modUmu3sq + 2*sqrt(Re12*Re12 + Im12*Im12)*cosDelta12 + 2*sqrt(Re13*Re13 + Im13*Im13)*cosDelta13 + 2*sqrt(Re23*Re23 + Im23*Im23)*cosDelta23; 
cosDelta12 = cos((2 * kOscDimensFactor * dmsq12 * fBaseline) / energy); 
cosDelta13 = cos((2 * kOscDimensFactor * dmsq13 * fBaseline) / energy); 
cosDelta23 = cos((2 * kOscDimensFactor * dmsq23 * fBaseline) / energy); 
oscProb += modUmu1sq*modUmu1sq + modUmu2sq*modUmu2sq + modUmu3sq*modUmu3sq + 2*modUmu2sq*modUmu1sq*cosDelta12 + 2*modUmu3sq*modUmu1sq*cosDelta13 + 2*modUmu2sq*modUmu3sq*cosDelta23; 
oscProb = 1.0 - oscProb; 
} 
else if( osch == kOscNuMuBar2NuTauBar || osch == kOscNuTau2NuMu ) { 
cosDelta12 = cos(((2 * kOscDimensFactor * dmsq12 * fBaseline) / energy) + arg12); 
cosDelta13 = cos(((2 * kOscDimensFactor * dmsq13 * fBaseline) / energy) + arg13); 
cosDelta23 = cos(((2 * kOscDimensFactor * dmsq23 * fBaseline) / energy) + arg23); 
oscProb += modUe1sq*modUmu1sq + modUe2sq*modUmu2sq + modUe3sq*modUmu3sq + 2*sqrt(Re12*Re12 + Im12*Im12)*cosDelta12 + 2*sqrt(Re13*Re13 + Im13*Im13)*cosDelta13 + 2*sqrt(Re23*Re23 + Im23*Im23)*cosDelta23; 
cosDelta12 = cos((2 * kOscDimensFactor * dmsq12 * fBaseline) / energy); 
cosDelta13 = cos((2 * kOscDimensFactor * dmsq13 * fBaseline) / energy); 
cosDelta23 = cos((2 * kOscDimensFactor * dmsq23 * fBaseline) / energy); 
oscProb += modUmu1sq*modUmu1sq + modUmu2sq*modUmu2sq + modUmu3sq*modUmu3sq + 2*modUmu2sq*modUmu1sq*cosDelta12 + 2*modUmu3sq*modUmu1sq*cosDelta13 + 2*modUmu2sq*modUmu3sq*cosDelta23; 
oscProb = 1.0 - oscProb; 
} 
return oscProb; 
} 
double NuOsc3Flavour::CalcMatterOscProb(int nu_start, int nu_end, double energy) { 
OscChannelId_t osch = util::GetOscChannel(nu_start, nu_end); 
if(osch == kOscUndefined) { 
assert(1); 
return 0.; 
} 
double oscProb = 0.; 
if(nFlavourIndex == 0) { 
if(osch == kOscNuE2NuE || osch == kOscNuMu2NuMu || osch == kOscNuTau2NuTau || osch == kOscNuEBar2NuEBar || osch == kOscNuMuBar2NuMuBar || osch == kOscNuTauBar2NuTauBar) return 1.0; 
else return 0.0; 
} 
else if(nFlavourIndex > 0) { 
oscProb = this->Calc2FlavMatterOscProb(nu_start, nu_end, energy, nFlavourIndex); 
return oscProb; 
} 
double UMassUdagger[3][3][2]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
UMassUdagger[i][j][re] = UMassUdaggerVacuum[i][j][re]; 
if( util::IsNeutrino(nu_start) ) { 
UMassUdagger[i][j][im] = UMassUdaggerVacuum[i][j][im]; 
} 
else if( util::IsAntiNeutrino(nu_start) ) { 
 UMassUdagger[i][j][im] = -UMassUdaggerVacuum[i][j][im]; 
} 
} 
} 
if( util::IsNeutrino(nu_start) ) { 
UMassUdagger[0][0][re] = UMassUdaggerVacuum[0][0][re] + 2.0*1.0e9*energy*sqrt(2.0)*kGF_SI*fNe; 
} 
else if( util::IsAntiNeutrino(nu_start) ) { 
UMassUdagger[0][0][re] = UMassUdaggerVacuum[0][0][re] - 2.0*1.0e9*energy*sqrt(2.0)*kGF_SI*fNe; 
} 
double modUMassUdaggersq[3][3]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
modUMassUdaggersq[i][j] = UMassUdagger[i][j][re] * UMassUdagger[i][j][re]  + UMassUdagger[i][j][im] * UMassUdagger[i][j][im]; 
} 
} 
double c0[2]; 
c0[re] = UMassUdagger[0][0][re] * modUMassUdaggersq[1][2] + UMassUdagger[1][1][re] * modUMassUdaggersq[0][2] + UMassUdagger[2][2][re] * modUMassUdaggersq[0][1] - (UMassUdagger[0][0][re] * UMassUdagger[1][1][re] * UMassUdagger[2][2][re] - UMassUdagger[0][0][im] * UMassUdagger[1][1][im] * UMassUdagger[2][2][re] - UMassUdagger[0][0][re] * UMassUdagger[1][1][im] * UMassUdagger[2][2][im] - UMassUdagger[0][0][im] * UMassUdagger[1][1][re] * UMassUdagger[2][2][im]) - 2.0 * (UMassUdagger[0][2][re] * UMassUdagger[0][1][re] * UMassUdagger[1][2][re] + UMassUdagger[0][2][im] * UMassUdagger[0][1][im] * UMassUdagger[1][2][re] - UMassUdagger[0][2][re] * UMassUdagger[0][1][im] * UMassUdagger[1][2][im] + UMassUdagger[0][2][im] * UMassUdagger[0][1][re] * UMassUdagger[1][2][im]); 
c0[im] = UMassUdagger[0][0][im] * modUMassUdaggersq[1][2] + UMassUdagger[1][1][im] * modUMassUdaggersq[0][2] + UMassUdagger[2][2][im] * modUMassUdaggersq[0][1] - (UMassUdagger[0][0][re] * UMassUdagger[1][1][re] * UMassUdagger[2][2][im] - UMassUdagger[0][0][im] * UMassUdagger[1][1][im] * UMassUdagger[2][2][im] + UMassUdagger[0][0][re] * UMassUdagger[1][1][im] * UMassUdagger[2][2][re] + UMassUdagger[0][0][im] * UMassUdagger[1][1][re] * UMassUdagger[2][2][re]); 
double c1[2]; 
c1[re] = UMassUdagger[0][0][re] * UMassUdagger[1][1][re] - UMassUdagger[0][0][im] * UMassUdagger[1][1][im] + UMassUdagger[0][0][re] * UMassUdagger[2][2][re] - UMassUdagger[0][0][im] * UMassUdagger[2][2][im] + UMassUdagger[1][1][re] * UMassUdagger[2][2][re] - UMassUdagger[1][1][im] * UMassUdagger[2][2][im] - modUMassUdaggersq[0][1] - modUMassUdaggersq[0][2] - modUMassUdaggersq[1][2]; 
c1[im] = UMassUdagger[0][0][re] * UMassUdagger[1][1][im] + UMassUdagger[0][0][im] * UMassUdagger[1][1][re] + UMassUdagger[0][0][re] * UMassUdagger[2][2][im] + UMassUdagger[0][0][im] * UMassUdagger[2][2][re] + UMassUdagger[1][1][re] * UMassUdagger[2][2][im] + UMassUdagger[1][1][im] * UMassUdagger[2][2][re]; 
double c2[2]; 
c2[re] = -UMassUdagger[0][0][re] - UMassUdagger[1][1][re] - UMassUdagger[2][2][re]; 
c2[im] = -UMassUdagger[0][0][im] - UMassUdagger[1][1][im] - UMassUdagger[2][2][im]; 
double p = c2[re]*c2[re] - 3.0*c1[re]; 
double q = -0.5*27.0*c0[re] - c2[re]*c2[re]*c2[re] + 0.5*9.0*c2[re]*c1[re]; 
double phi = atan2(sqrt(27.0 * (0.25*c1[re]*c1[re]*(p - c1[re]) + c0[re]*(q + (27.0/4.0)*c0[re]))), q) / 3.0; 
double eigenvalues[3]; 
if(dmsq23 > 0) { 
eigenvalues[0] = (sqrt(p) * 2.0 * cos(phi + 2.0*3.1415927/3.0)) / 3.0 - c2[re] / 3.0; 
eigenvalues[1] = (sqrt(p) * 2.0 * cos(phi - 2.0*3.1415927/3.0)) / 3.0 - c2[re] / 3.0; 
eigenvalues[2] = (sqrt(p) * 2.0 * cos(phi)) / 3.0 - c2[re] / 3.0; 
} 
else { 
eigenvalues[0] = (sqrt(p) * 2.0 * cos(phi - 2.0*3.1415927/3.0)) / 3.0 - c2[re] / 3.0; 
eigenvalues[1] = (sqrt(p) * 2.0 * cos(phi)) / 3.0 - c2[re] / 3.0; 
eigenvalues[2] = (sqrt(p) * 2.0 * cos(phi + 2.0*3.1415927/3.0)) / 3.0 - c2[re] / 3.0; 
} 
#ifdef __show_warning__ 
double eigenvalueSum = eigenvalues[0] + eigenvalues[1] + eigenvalues[2]; 
double trace = UMassUdagger[0][0][re] + UMassUdagger[1][1][re] + UMassUdagger[2][2][re]; 
if(fabs((eigenvalueSum - trace) / trace) > 1.0e-4) { 
assert(1); 
} 
#endif 
double UMassUdaggerMinusEv[3][3][2]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
for(int k=0; k<2; k++) { 
 UMassUdaggerMinusEv[i][j][k] = UMassUdagger[i][j][k]; 
} 
} 
} 
double UMatter[3][3][2]; 
double normalisation; 
#ifdef __show_warning__ 
double eigenvectorCheck[3][2]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<2; j++) { 
eigenvectorCheck[i][j] = 0.0; 
} 
} 
#endif 
double numerator1[2]; 
double numerator3[2]; 
double denominator[2]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
UMassUdaggerMinusEv[j][j][re] = UMassUdagger[j][j][re] - eigenvalues[i]; 
} 
if(useEquations12) { 
numerator1[re] = UMassUdaggerMinusEv[1][1][re] * UMassUdaggerMinusEv[0][2][re] - UMassUdaggerMinusEv[1][1][im] * UMassUdaggerMinusEv[0][2][im] - (UMassUdaggerMinusEv[1][2][re] * UMassUdaggerMinusEv[0][1][re]  - UMassUdaggerMinusEv[1][2][im] * UMassUdaggerMinusEv[0][1][im]); 
numerator1[im] = UMassUdaggerMinusEv[1][1][re] * UMassUdaggerMinusEv[0][2][im] + UMassUdaggerMinusEv[1][1][im] * UMassUdaggerMinusEv[0][2][re] - (UMassUdaggerMinusEv[1][2][re] * UMassUdaggerMinusEv[0][1][im]  + UMassUdaggerMinusEv[1][2][im] * UMassUdaggerMinusEv[0][1][re]); 
numerator3[re] = UMassUdaggerMinusEv[0][1][re] * UMassUdaggerMinusEv[0][1][re] + UMassUdaggerMinusEv[0][1][im] * UMassUdaggerMinusEv[0][1][im] - (UMassUdaggerMinusEv[0][0][re] * UMassUdaggerMinusEv[1][1][re]  - UMassUdaggerMinusEv[0][0][im] * UMassUdaggerMinusEv[1][1][im]); 
numerator3[im] = -(UMassUdaggerMinusEv[0][0][re] * UMassUdaggerMinusEv[1][1][im]  + UMassUdaggerMinusEv[0][0][im] * UMassUdaggerMinusEv[1][1][re]); 
denominator[re] = UMassUdaggerMinusEv[0][0][re] * UMassUdaggerMinusEv[1][2][re] - UMassUdaggerMinusEv[0][0][im] * UMassUdaggerMinusEv[1][2][im] - (UMassUdaggerMinusEv[0][2][re] * UMassUdaggerMinusEv[0][1][re]  + UMassUdaggerMinusEv[0][2][im] * UMassUdaggerMinusEv[0][1][im]); 
denominator[im] = UMassUdaggerMinusEv[0][0][re] * UMassUdaggerMinusEv[1][2][im] + UMassUdaggerMinusEv[0][0][im] * UMassUdaggerMinusEv[1][2][re] - (-UMassUdaggerMinusEv[0][2][re] * UMassUdaggerMinusEv[0][1][im]  + UMassUdaggerMinusEv[0][2][im] * UMassUdaggerMinusEv[0][1][re]); 
} 
else { 
numerator1[re] = UMassUdaggerMinusEv[1][1][re] * UMassUdaggerMinusEv[2][2][re] - UMassUdaggerMinusEv[1][1][im] * UMassUdaggerMinusEv[2][2][im] - (UMassUdaggerMinusEv[1][2][re] * UMassUdaggerMinusEv[1][2][re]  + UMassUdaggerMinusEv[1][2][im] * UMassUdaggerMinusEv[1][2][im]); 
numerator1[im] = UMassUdaggerMinusEv[1][1][re] * UMassUdaggerMinusEv[2][2][im]  + UMassUdaggerMinusEv[1][1][im] * UMassUdaggerMinusEv[2][2][re]; 
numerator3[re] = UMassUdaggerMinusEv[0][1][re] * UMassUdaggerMinusEv[1][2][re] - UMassUdaggerMinusEv[0][1][im] * UMassUdaggerMinusEv[1][2][im]  - (UMassUdaggerMinusEv[1][1][re] * UMassUdaggerMinusEv[0][2][re]  + UMassUdaggerMinusEv[1][1][im] * UMassUdaggerMinusEv[0][2][im]); 
numerator3[im] = -UMassUdaggerMinusEv[0][1][re] * UMassUdaggerMinusEv[1][2][im] - UMassUdaggerMinusEv[0][1][im] * UMassUdaggerMinusEv[1][2][re]  - (-UMassUdaggerMinusEv[1][1][re] * UMassUdaggerMinusEv[0][2][im]  + UMassUdaggerMinusEv[1][1][im] * UMassUdaggerMinusEv[0][2][re]); 
denominator[re] = UMassUdaggerMinusEv[1][2][re] * UMassUdaggerMinusEv[0][2][re] + UMassUdaggerMinusEv[1][2][im] * UMassUdaggerMinusEv[0][2][im]  - (UMassUdaggerMinusEv[2][2][re] * UMassUdaggerMinusEv[0][1][re]  + UMassUdaggerMinusEv[2][2][im] * UMassUdaggerMinusEv[0][1][im]); 
denominator[im] = -UMassUdaggerMinusEv[1][2][re] * UMassUdaggerMinusEv[0][2][im] + UMassUdaggerMinusEv[1][2][im] * UMassUdaggerMinusEv[0][2][re]  - (-UMassUdaggerMinusEv[2][2][re] * UMassUdaggerMinusEv[0][1][im]  + UMassUdaggerMinusEv[2][2][im] * UMassUdaggerMinusEv[0][1][re]); 
} 
UMatter[0][i][re] = (numerator1[re] * denominator[re] + numerator1[im] * denominator[im]) / (denominator[re] * denominator[re] + denominator[im] * denominator[im]); 
UMatter[0][i][im] = (-numerator1[re] * denominator[im] + numerator1[im] * denominator[re]) / (denominator[re] * denominator[re] + denominator[im] * denominator[im]); 
UMatter[1][i][re] = 1.0; 
UMatter[1][i][im] = 0.0; 
UMatter[2][i][re] = (numerator3[re] * denominator[re] + numerator3[im] * denominator[im]) / (denominator[re] * denominator[re] + denominator[im] * denominator[im]); 
UMatter[2][i][im] = (-numerator3[re] * denominator[im] + numerator3[im] * denominator[re]) / (denominator[re] * denominator[re] + denominator[im] * denominator[im]); 
normalisation = sqrt(UMatter[0][i][re] * UMatter[0][i][re] + UMatter[0][i][im] * UMatter[0][i][im] + UMatter[1][i][re] * UMatter[1][i][re] + UMatter[1][i][im] * UMatter[1][i][im] + UMatter[2][i][re] * UMatter[2][i][re] + UMatter[2][i][im] * UMatter[2][i][im]); 
for(int k=0; k<3; k++) { 
UMatter[k][i][re] = UMatter[k][i][re] / normalisation; 
UMatter[k][i][im] = UMatter[k][i][im] / normalisation; 
} 
#ifdef __show_warning__ 
for(int m=0; m<3; m++) { 
eigenvectorCheck[i][re] += UMassUdaggerMinusEv[i][m][re] * UMatter[m][i][re] - UMassUdaggerMinusEv[i][m][im] * UMatter[m][i][im]; 
eigenvectorCheck[i][im] += UMassUdaggerMinusEv[i][m][re] * UMatter[m][i][im] + UMassUdaggerMinusEv[i][m][im] * UMatter[m][i][re]; 
} 
#endif 
} 
#ifdef __show_warning__ 
for(int i=0; i<3; i++) { 
if(fabs(eigenvectorCheck[i][re]) > 1.0e-8) { 
assert(1); 
} 
if(fabs(eigenvectorCheck[i][im]) > 1.0e-8) { 
assert(1); 
} 
} 
#endif 
#ifdef __show_warning__ 
double scalarProduct[3][2]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<2; j++) { 
scalarProduct[i][j] = 0.0; 
} 
} 
for(int i=0; i<2; i++) { 
for(int j=0; j<3; j++) { 
scalarProduct[i][re] += UMatter[j][i][re] * UMatter[j][i+1][re]  + UMatter[j][i][im] * UMatter[j][i+1][im]; 
scalarProduct[i][im] += -UMatter[j][i][re] * UMatter[j][i+1][im]  + UMatter[j][i][im] * UMatter[j][i+1][re]; 
} 
} 
for(int j=0; j<3; j++) { 
scalarProduct[2][re] += UMatter[j][0][re] * UMatter[j][2][re] + UMatter[j][0][im] * UMatter[j][2][im]; 
scalarProduct[2][im] += -UMatter[j][0][re] * UMatter[j][2][im] + UMatter[j][0][im] * UMatter[j][2][re]; 
} 
for(int i=0; i<3; i++) { 
if(fabs(scalarProduct[i][re]) > 1.0e-4) { 
assert(1); 
} 
if(fabs(scalarProduct[i][im]) > 1.0e-4) { 
assert(1); 
} 
} 
#endif 
double UMatterDagger[3][3][2]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
UMatterDagger[i][j][re] = UMatter[j][i][re]; 
UMatterDagger[i][j][im] = -UMatter[j][i][im]; 
} 
} 
#ifdef __show_warning__ 
double inverseCheck[3][3][2]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
inverseCheck[i][j][re] = 0.0; 
inverseCheck[i][j][im] = 0.0; 
} 
} 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
for(int k=0; k<3; k++) { 
inverseCheck[i][j][re] += UMatter[i][k][re] * UMatterDagger[k][j][re] - UMatter[i][k][im] * UMatterDagger[k][j][im]; 
inverseCheck[i][j][im] += UMatter[i][k][re] * UMatterDagger[k][j][im] + UMatter[i][k][im] * UMatterDagger[k][j][re]; 
} 
} 
} 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
if(i == j) { 
if(fabs(inverseCheck[i][j][re] - 1.0) > 1.0e-4) { 
assert(1); 
} 
if(fabs(inverseCheck[i][j][im]) > 1.0e-4) { 
assert(1); 
} 
} 
else { 
if(fabs(inverseCheck[i][j][re]) > 1.0e-4) { 
assert(1); 
} 
if(fabs(inverseCheck[i][j][im]) > 1.0e-4) { 
assert(1); 
} 
} 
} 
} 
#endif 
double initialFlavourState[3][2]; 
for(int i=0; i<3; i++) { 
initialFlavourState[i][re] = 0.0; 
initialFlavourState[i][im] = 0.0; 
} 
if(nu_start == kPdgNuE || nu_start == kPdgNuEBar) { 
initialFlavourState[0][re] = 1.0; 
} 
else if(nu_start == kPdgNuMu || nu_start == kPdgNuMuBar) { 
initialFlavourState[1][re] = 1.0; 
} 
else if(nu_start == kPdgNuTau || nu_start == kPdgNuTauBar) { 
initialFlavourState[2][re] = 1.0; 
} 
double initialMassState[3][2]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<2; j++) { 
initialMassState[i][j] = 0.0; 
} 
} 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
initialMassState[i][re] += UMatterDagger[i][j][re] * initialFlavourState[j][re]  - UMatterDagger[i][j][im] * initialFlavourState[j][im]; 
initialMassState[i][im] += UMatterDagger[i][j][re] * initialFlavourState[j][im] + UMatterDagger[i][j][im] * initialFlavourState[j][re]; 
} 
} 
double finalMassState[3][2]; 
finalMassState[0][re] = initialMassState[0][re]; 
finalMassState[0][im] = initialMassState[0][im]; 
finalMassState[1][re] = initialMassState[1][re] * cos((2.0 * kOscDimensFactor * (eigenvalues[1] - eigenvalues[0]) * fBaseline) / energy) - initialMassState[1][im] * -sin((2.0 * kOscDimensFactor * (eigenvalues[1] - eigenvalues[0]) * fBaseline) / energy); 
finalMassState[1][im] = initialMassState[1][re] * -sin((2.0 * kOscDimensFactor * (eigenvalues[1] - eigenvalues[0]) * fBaseline) / energy) + initialMassState[1][im] * cos((2.0 * kOscDimensFactor * (eigenvalues[1] - eigenvalues[0]) * fBaseline) / energy); 
finalMassState[2][re] = initialMassState[2][re] * cos((2.0 * kOscDimensFactor * (eigenvalues[2] - eigenvalues[0]) * fBaseline) / energy) - initialMassState[2][im] * -sin((2.0 * kOscDimensFactor * (eigenvalues[2] - eigenvalues[0]) * fBaseline) / energy); 
finalMassState[2][im] = initialMassState[2][re] * -sin((2.0 * kOscDimensFactor * (eigenvalues[2] - eigenvalues[0]) * fBaseline) / energy) + initialMassState[2][im] * cos((2.0 * kOscDimensFactor * (eigenvalues[2] - eigenvalues[0]) * fBaseline) / energy); 
double finalFlavourState[3][2]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<2; j++) { 
finalFlavourState[i][j] = 0.0; 
} 
} 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
finalFlavourState[i][re] += UMatter[i][j][re] * finalMassState[j][re]  - UMatter[i][j][im] * finalMassState[j][im]; 
finalFlavourState[i][im] += UMatter[i][j][re] * finalMassState[j][im]  + UMatter[i][j][im] * finalMassState[j][re]; 
} 
} 
if(nu_end == kPdgNuE || nu_end == kPdgNuEBar) { 
oscProb = finalFlavourState[0][re]*finalFlavourState[0][re] + finalFlavourState[0][im]*finalFlavourState[0][im]; 
} 
else if(nu_end == kPdgNuMu || nu_end == kPdgNuMuBar) { 
oscProb = finalFlavourState[1][re]*finalFlavourState[1][re] + finalFlavourState[1][im]*finalFlavourState[1][im]; 
} 
else if(nu_end == kPdgNuTau || nu_end == kPdgNuTauBar) { 
oscProb = finalFlavourState[2][re]*finalFlavourState[2][re] + finalFlavourState[2][im]*finalFlavourState[2][im]; 
} 
return oscProb; 
} 
double NuOsc3Flavour::Calc2FlavMatterOscProb(int nu_start, int nu_end, double energy, int index) { 
OscChannelId_t osch = util::GetOscChannel(nu_start, nu_end); 
if(osch == kOscUndefined) { 
assert(1); 
return 0.; 
} 
if(index == 12) { 
if(osch == kOscNuTau2NuTau || osch == kOscNuTauBar2NuTauBar) return 1.0; 
else if(osch == kOscNuTau2NuE || osch == kOscNuTau2NuMu || osch == kOscNuTauBar2NuEBar || osch == kOscNuTauBar2NuMuBar || osch == kOscNuE2NuTau || osch == kOscNuMu2NuTau || osch == kOscNuEBar2NuTauBar || osch == kOscNuMuBar2NuTauBar) return 0.0; 
} 
else if(index == 13) { 
if(osch == kOscNuMu2NuMu || osch == kOscNuMuBar2NuMuBar) return 1.0; 
else if(osch == kOscNuMu2NuE || osch == kOscNuMu2NuTau || osch == kOscNuMuBar2NuEBar || osch == kOscNuMuBar2NuTauBar || osch == kOscNuE2NuMu || osch == kOscNuTau2NuMu || osch == kOscNuEBar2NuMuBar || osch == kOscNuTauBar2NuMuBar) return 0.0; 
} 
else if(index == 23) { 
if(osch == kOscNuE2NuE || osch == kOscNuEBar2NuEBar) return 1.0; 
else if(osch == kOscNuE2NuMu || osch == kOscNuE2NuTau || osch == kOscNuEBar2NuMuBar || osch == kOscNuEBar2NuTauBar  || osch == kOscNuMu2NuE || osch == kOscNuTau2NuE ||osch == kOscNuMuBar2NuEBar || osch == kOscNuTauBar2NuEBar) return 0.0; 
} 
double oscProb = 0.0; 
double UMassUdagger[2][2][2] = {}; 
if(index == 12) { 
for(int i=0; i<2; i++) { 
for(int j=0; j<2; j++)  { 
 UMassUdagger[i][j][re] = UMassUdaggerVacuum[i][j][re]; 
 if( util::IsNeutrino(nu_start) )  UMassUdagger[i][j][im] = UMassUdaggerVacuum[i][j][im]; 
 else if( util::IsAntiNeutrino(nu_start) )  UMassUdagger[i][j][im] = -UMassUdaggerVacuum[i][j][im]; 
 } 
} 
} 
else if(index == 13) { 
UMassUdagger[0][0][re] = UMassUdaggerVacuum[0][0][re]; 
UMassUdagger[1][0][re] = UMassUdaggerVacuum[2][0][re]; 
UMassUdagger[0][1][re] = UMassUdaggerVacuum[0][2][re]; 
UMassUdagger[1][1][re] = UMassUdaggerVacuum[2][2][re]; 
if( util::IsNeutrino(nu_start) ) { 
UMassUdagger[0][0][im] = UMassUdaggerVacuum[0][0][im]; 
UMassUdagger[1][0][im] = UMassUdaggerVacuum[2][0][im]; 
UMassUdagger[0][1][im] = UMassUdaggerVacuum[0][2][im]; 
UMassUdagger[1][1][im] = UMassUdaggerVacuum[2][2][im]; 
} 
else if( util::IsAntiNeutrino(nu_start) ) { 
UMassUdagger[0][0][im] = -UMassUdaggerVacuum[0][0][im]; 
UMassUdagger[1][0][im] = -UMassUdaggerVacuum[2][0][im]; 
UMassUdagger[0][1][im] = -UMassUdaggerVacuum[0][2][im]; 
UMassUdagger[1][1][im] = -UMassUdaggerVacuum[2][2][im]; 
} 
} 
else if(index == 23) { 
for(int i=0; i<2; i++) { 
for(int j=0; j<2; j++)  {  
 UMassUdagger[i][j][re] = UMassUdaggerVacuum[i+1][j+1][re]; 
 if( util::IsNeutrino(nu_start) )  UMassUdagger[i][j][im] = UMassUdaggerVacuum[i+1][j+1][im]; 
 else if( util::IsAntiNeutrino(nu_start) )  UMassUdagger[i][j][im] = -UMassUdaggerVacuum[i+1][j+1][im]; 
 } 
} 
} 
if(index == 12 || index == 13) { 
if( util::IsNeutrino(nu_start) ) UMassUdagger[0][0][re] = UMassUdaggerVacuum[0][0][re] + 2.0*1.0e9*energy*sqrt(2.0)*kGF_SI*fNe; 
else if( util::IsAntiNeutrino(nu_start) ) UMassUdagger[0][0][re] = UMassUdaggerVacuum[0][0][re] - 2.0*1.0e9*energy*sqrt(2.0)*kGF_SI*fNe; 
} 
double eigenvalues[2]; 
eigenvalues[0] = 0.5 * (UMassUdagger[0][0][re] + UMassUdagger[1][1][re]  + sqrt((UMassUdagger[0][0][re] + UMassUdagger[1][1][re]) * (UMassUdagger[0][0][re] + UMassUdagger[1][1][re])  - 4.0 * (UMassUdagger[0][0][re] * UMassUdagger[1][1][re] - (UMassUdagger[0][1][re] * UMassUdagger[0][1][re]  + UMassUdagger[0][1][im] * UMassUdagger[0][1][im])))); 
eigenvalues[1] = 0.5 * (UMassUdagger[0][0][re] + UMassUdagger[1][1][re]  - sqrt((UMassUdagger[0][0][re] + UMassUdagger[1][1][re]) * (UMassUdagger[0][0][re] + UMassUdagger[1][1][re])  - 4.0 * (UMassUdagger[0][0][re] * UMassUdagger[1][1][re] - (UMassUdagger[0][1][re] * UMassUdagger[0][1][re]  + UMassUdagger[0][1][im] * UMassUdagger[0][1][im])))); 
double UMatter[2][2][2]; 
UMatter[0][0][re] = -(UMassUdagger[1][1][re] - eigenvalues[0]) / sqrt((UMassUdagger[1][1][re] - eigenvalues[0]) * (UMassUdagger[1][1][re] - eigenvalues[0])  + UMassUdagger[1][0][re] * UMassUdagger[1][0][re] + UMassUdagger[1][0][im] * UMassUdagger[1][0][im]); 
UMatter[0][0][im] = 0.0; 
UMatter[0][1][re] = -(UMassUdagger[1][1][re] - eigenvalues[1]) / sqrt((UMassUdagger[1][1][re] - eigenvalues[1]) * (UMassUdagger[1][1][re] - eigenvalues[1])  + UMassUdagger[1][0][re] * UMassUdagger[1][0][re] + UMassUdagger[1][0][im] * UMassUdagger[1][0][im]); 
UMatter[0][1][im] = 0.0; 
UMatter[1][0][re] = UMassUdagger[1][0][re] / sqrt((UMassUdagger[1][1][re] - eigenvalues[0]) * (UMassUdagger[1][1][re] - eigenvalues[0])  + UMassUdagger[1][0][re] * UMassUdagger[1][0][re] + UMassUdagger[1][0][im] * UMassUdagger[1][0][im]); 
UMatter[1][0][im] = UMassUdagger[1][0][im] / sqrt((UMassUdagger[1][1][re] - eigenvalues[0]) * (UMassUdagger[1][1][re] - eigenvalues[0])  + UMassUdagger[1][0][re] * UMassUdagger[1][0][re] + UMassUdagger[1][0][im] * UMassUdagger[1][0][im]); 
UMatter[1][1][re] = UMassUdagger[1][0][re] / sqrt((UMassUdagger[1][1][re] - eigenvalues[1]) * (UMassUdagger[1][1][re] - eigenvalues[1])  + UMassUdagger[1][0][re] * UMassUdagger[1][0][re] + UMassUdagger[1][0][im] * UMassUdagger[1][0][im]); 
UMatter[1][1][im] = UMassUdagger[1][0][im] / sqrt((UMassUdagger[1][1][re] - eigenvalues[1]) * (UMassUdagger[1][1][re] - eigenvalues[1])  + UMassUdagger[1][0][re] * UMassUdagger[1][0][re] + UMassUdagger[1][0][im] * UMassUdagger[1][0][im]); 
double UMatterDagger[2][2][2]; 
for(int i=0; i<2; i++) { 
for(int j=0; j<2; j++) { 
UMatterDagger[i][j][re] = UMatter[j][i][re]; 
UMatterDagger[i][j][im] = -UMatter[j][i][im]; 
} 
} 
double initialFlavourState[2][2]; 
for(int i=0; i<2; i++) { 
initialFlavourState[i][re] = 0.0; 
initialFlavourState[i][im] = 0.0; 
} 
if(index == 12) { 
if(nu_start == kPdgNuE || nu_start == kPdgNuEBar) initialFlavourState[0][re] = 1.0; 
else if(nu_start == kPdgNuMu || nu_start == kPdgNuMuBar) initialFlavourState[1][re] = 1.0; 
} 
else if(index == 13) { 
if(nu_start == kPdgNuE || nu_start == kPdgNuEBar) initialFlavourState[0][re] = 1.0; 
else if(nu_start == kPdgNuTau || nu_start == kPdgNuTauBar) initialFlavourState[1][re] = 1.0; 
} 
else if(index == 23) { 
if(nu_start == kPdgNuMu || nu_start == kPdgNuMuBar) initialFlavourState[0][re] = 1.0; 
else if(nu_start == kPdgNuTau || nu_start == kPdgNuTauBar) initialFlavourState[1][re] = 1.0; 
} 
double initialMassState[2][2]; 
for(int i=0; i<2; i++) { 
for(int j=0; j<2; j++) { 
initialMassState[i][j] = 0.0; 
} 
} 
for(int i=0; i<2; i++) { 
for(int j=0; j<2; j++) { 
initialMassState[i][re] += UMatterDagger[i][j][re] * initialFlavourState[j][re] - UMatterDagger[i][j][im] * initialFlavourState[j][im]; 
initialMassState[i][im] += UMatterDagger[i][j][re] * initialFlavourState[j][im] + UMatterDagger[i][j][im] * initialFlavourState[j][re]; 
} 
} 
double finalMassState[2][2]; 
finalMassState[0][re] = initialMassState[0][re]; 
finalMassState[0][im] = initialMassState[0][im]; 
finalMassState[1][re] = initialMassState[1][re] * cos((2.0 * kOscDimensFactor * (eigenvalues[1] - eigenvalues[0]) * fBaseline) / energy) - initialMassState[1][im] * -sin((2.0 * kOscDimensFactor * (eigenvalues[1] - eigenvalues[0]) * fBaseline) / energy); 
finalMassState[1][im] = initialMassState[1][re] * -sin((2.0 * kOscDimensFactor * (eigenvalues[1] - eigenvalues[0]) * fBaseline) / energy) + initialMassState[1][im] * cos((2.0 * kOscDimensFactor * (eigenvalues[1] - eigenvalues[0]) * fBaseline) / energy); 
double finalFlavourState[2][2]; 
for(int i=0; i<2; i++) { 
for(int j=0; j<2; j++) { 
finalFlavourState[i][j] = 0.0; 
} 
} 
for(int i=0; i<2; i++) { 
for(int j=0; j<2; j++) { 
finalFlavourState[i][re] += UMatter[i][j][re] * finalMassState[j][re] - UMatter[i][j][im] * finalMassState[j][im]; 
finalFlavourState[i][im] += UMatter[i][j][re] * finalMassState[j][im] + UMatter[i][j][im] * finalMassState[j][re]; 
} 
} 
if(index == 12) { 
if(nu_end == kPdgNuE || nu_end == kPdgNuEBar) oscProb = finalFlavourState[0][re]*finalFlavourState[0][re] + finalFlavourState[0][im]*finalFlavourState[0][im]; 
else if(nu_end == kPdgNuMu || nu_end == kPdgNuMuBar) oscProb = finalFlavourState[1][re]*finalFlavourState[1][re] + finalFlavourState[1][im]*finalFlavourState[1][im]; 
} 
else if(index == 13) { 
if(nu_end == kPdgNuE || nu_end == kPdgNuEBar) oscProb = finalFlavourState[0][re]*finalFlavourState[0][re] + finalFlavourState[0][im]*finalFlavourState[0][im]; 
else if(nu_end == kPdgNuTau || nu_end == kPdgNuTauBar) oscProb = finalFlavourState[1][re]*finalFlavourState[1][re] + finalFlavourState[1][im]*finalFlavourState[1][im]; 
} 
else if(index == 23) { 
if(nu_end == kPdgNuMu || nu_end == kPdgNuMuBar) oscProb = finalFlavourState[0][re]*finalFlavourState[0][re] + finalFlavourState[0][im]*finalFlavourState[0][im]; 
else if(nu_end == kPdgNuTau || nu_end == kPdgNuTauBar) oscProb = finalFlavourState[1][re]*finalFlavourState[1][re] + finalFlavourState[1][im]*finalFlavourState[1][im]; 
} 
return oscProb; 
} 
void NuOsc3Flavour::CalcMatterOscProbAll(bool isAntineutrino, double energy, double osc_probs[3][3]) { 
if(nFlavourIndex == 0) { 
for (int i = 0 ; i < nFlav ; i++){ 
for (int j = 0 ; j < nFlav ; j++){ 
osc_probs[i][j] = (i==j); 
} 
} 
return; 
} 
else if(nFlavourIndex > 0) { 
for (int i = 0 ; i < nFlav ; i++){ 
 for (int j = 0 ; j < nFlav ; j++){ 
 if(isAntineutrino)  osc_probs[i][j] = this->Calc2FlavMatterOscProb(-(12+2*i), -(12+2*j), energy, nFlavourIndex); 
 else  osc_probs[i][j] = this->Calc2FlavMatterOscProb(12+2*i, 12+2*j, energy, nFlavourIndex); 
 } 
} 
return; 
} 
double UMassUdagger[3][3][2]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
UMassUdagger[i][j][re] = UMassUdaggerVacuum[i][j][re]; 
if( !isAntineutrino ) { 
UMassUdagger[i][j][im] = UMassUdaggerVacuum[i][j][im]; 
} 
else { 
UMassUdagger[i][j][im] = -UMassUdaggerVacuum[i][j][im]; 
} 
} 
} 
if( !isAntineutrino ) { 
UMassUdagger[0][0][re] = UMassUdaggerVacuum[0][0][re] + 2.0*1.0e9*energy*sqrt(2.0)*kGF_SI*fNe; 
} 
else { 
UMassUdagger[0][0][re] = UMassUdaggerVacuum[0][0][re] - 2.0*1.0e9*energy*sqrt(2.0)*kGF_SI*fNe; 
} 
double modUMassUdaggersq[3][3]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
modUMassUdaggersq[i][j] = UMassUdagger[i][j][re] * UMassUdagger[i][j][re] + UMassUdagger[i][j][im] * UMassUdagger[i][j][im]; 
} 
} 
double c0[2]; 
c0[re] = UMassUdagger[0][0][re] * modUMassUdaggersq[1][2] + UMassUdagger[1][1][re] * modUMassUdaggersq[0][2] + UMassUdagger[2][2][re] * modUMassUdaggersq[0][1] - (UMassUdagger[0][0][re] * UMassUdagger[1][1][re] * UMassUdagger[2][2][re] - UMassUdagger[0][0][im] * UMassUdagger[1][1][im] * UMassUdagger[2][2][re] - UMassUdagger[0][0][re] * UMassUdagger[1][1][im] * UMassUdagger[2][2][im] - UMassUdagger[0][0][im] * UMassUdagger[1][1][re] * UMassUdagger[2][2][im]) - 2.0 * (UMassUdagger[0][2][re] * UMassUdagger[0][1][re] * UMassUdagger[1][2][re] + UMassUdagger[0][2][im] * UMassUdagger[0][1][im] * UMassUdagger[1][2][re] - UMassUdagger[0][2][re] * UMassUdagger[0][1][im] * UMassUdagger[1][2][im] + UMassUdagger[0][2][im] * UMassUdagger[0][1][re] * UMassUdagger[1][2][im]); 
c0[im] = UMassUdagger[0][0][im] * modUMassUdaggersq[1][2] + UMassUdagger[1][1][im] * modUMassUdaggersq[0][2] + UMassUdagger[2][2][im] * modUMassUdaggersq[0][1] - (UMassUdagger[0][0][re] * UMassUdagger[1][1][re] * UMassUdagger[2][2][im] - UMassUdagger[0][0][im] * UMassUdagger[1][1][im] * UMassUdagger[2][2][im] + UMassUdagger[0][0][re] * UMassUdagger[1][1][im] * UMassUdagger[2][2][re] + UMassUdagger[0][0][im] * UMassUdagger[1][1][re] * UMassUdagger[2][2][re]); 
double c1[2]; 
c1[re] = UMassUdagger[0][0][re] * UMassUdagger[1][1][re] - UMassUdagger[0][0][im] * UMassUdagger[1][1][im] + UMassUdagger[0][0][re] * UMassUdagger[2][2][re] - UMassUdagger[0][0][im] * UMassUdagger[2][2][im] + UMassUdagger[1][1][re] * UMassUdagger[2][2][re] - UMassUdagger[1][1][im] * UMassUdagger[2][2][im] - modUMassUdaggersq[0][1] - modUMassUdaggersq[0][2] - modUMassUdaggersq[1][2]; 
c1[im] = UMassUdagger[0][0][re] * UMassUdagger[1][1][im] + UMassUdagger[0][0][im] * UMassUdagger[1][1][re] + UMassUdagger[0][0][re] * UMassUdagger[2][2][im] + UMassUdagger[0][0][im] * UMassUdagger[2][2][re] + UMassUdagger[1][1][re] * UMassUdagger[2][2][im] + UMassUdagger[1][1][im] * UMassUdagger[2][2][re]; 
double c2[2]; 
c2[re] = -UMassUdagger[0][0][re] - UMassUdagger[1][1][re] - UMassUdagger[2][2][re]; 
c2[im] = -UMassUdagger[0][0][im] - UMassUdagger[1][1][im] - UMassUdagger[2][2][im]; 
double p = c2[re]*c2[re] - 3.0*c1[re]; 
double q = -0.5*27.0*c0[re] - c2[re]*c2[re]*c2[re] + 0.5*9.0*c2[re]*c1[re]; 
double phi = atan2(sqrt(27.0 * (0.25*c1[re]*c1[re]*(p - c1[re]) + c0[re]*(q + (27.0/4.0)*c0[re]))), q) / 3.0; 
double eigenvalues[3]; 
if(dmsq23 > 0) { 
eigenvalues[0] = (sqrt(p) * 2.0 * cos(phi + 2.0*3.1415927/3.0)) / 3.0 - c2[re] / 3.0; 
eigenvalues[1] = (sqrt(p) * 2.0 * cos(phi - 2.0*3.1415927/3.0)) / 3.0 - c2[re] / 3.0; 
eigenvalues[2] = (sqrt(p) * 2.0 * cos(phi)) / 3.0 - c2[re] / 3.0; 
} 
else { 
eigenvalues[0] = (sqrt(p) * 2.0 * cos(phi - 2.0*3.1415927/3.0)) / 3.0 - c2[re] / 3.0; 
eigenvalues[1] = (sqrt(p) * 2.0 * cos(phi)) / 3.0 - c2[re] / 3.0; 
eigenvalues[2] = (sqrt(p) * 2.0 * cos(phi + 2.0*3.1415927/3.0)) / 3.0 - c2[re] / 3.0; 
} 
#ifdef __show_warning__ 
double eigenvalueSum = eigenvalues[0] + eigenvalues[1] + eigenvalues[2]; 
double trace = UMassUdagger[0][0][re] + UMassUdagger[1][1][re] + UMassUdagger[2][2][re]; 
if(fabs((eigenvalueSum - trace) / trace) > 1.0e-4) { 
assert(1); 
} 
#endif 
double UMassUdaggerMinusEv[3][3][2]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
for(int k=0; k<2; k++) { 
UMassUdaggerMinusEv[i][j][k] = UMassUdagger[i][j][k]; 
} 
} 
} 
double UMatter[3][3][2]; 
double normalisation; 
#ifdef __show_warning__ 
double eigenvectorCheck[3][2]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<2; j++) { 
eigenvectorCheck[i][j] = 0.0; 
} 
} 
#endif 
double numerator1[2]; 
double numerator3[2]; 
double denominator[2]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
UMassUdaggerMinusEv[j][j][re] = UMassUdagger[j][j][re] - eigenvalues[i]; 
} 
if(useEquations12) { 
numerator1[re] = UMassUdaggerMinusEv[1][1][re] * UMassUdaggerMinusEv[0][2][re] - UMassUdaggerMinusEv[1][1][im] * UMassUdaggerMinusEv[0][2][im] - (UMassUdaggerMinusEv[1][2][re] * UMassUdaggerMinusEv[0][1][re] - UMassUdaggerMinusEv[1][2][im] * UMassUdaggerMinusEv[0][1][im]); 
numerator1[im] = UMassUdaggerMinusEv[1][1][re] * UMassUdaggerMinusEv[0][2][im] + UMassUdaggerMinusEv[1][1][im] * UMassUdaggerMinusEv[0][2][re] - (UMassUdaggerMinusEv[1][2][re] * UMassUdaggerMinusEv[0][1][im] + UMassUdaggerMinusEv[1][2][im] * UMassUdaggerMinusEv[0][1][re]); 
numerator3[re] = UMassUdaggerMinusEv[0][1][re] * UMassUdaggerMinusEv[0][1][re] + UMassUdaggerMinusEv[0][1][im] * UMassUdaggerMinusEv[0][1][im] - (UMassUdaggerMinusEv[0][0][re] * UMassUdaggerMinusEv[1][1][re] - UMassUdaggerMinusEv[0][0][im] * UMassUdaggerMinusEv[1][1][im]); 
numerator3[im] = -(UMassUdaggerMinusEv[0][0][re] * UMassUdaggerMinusEv[1][1][im] + UMassUdaggerMinusEv[0][0][im] * UMassUdaggerMinusEv[1][1][re]); 
denominator[re] = UMassUdaggerMinusEv[0][0][re] * UMassUdaggerMinusEv[1][2][re] - UMassUdaggerMinusEv[0][0][im] * UMassUdaggerMinusEv[1][2][im] - (UMassUdaggerMinusEv[0][2][re] * UMassUdaggerMinusEv[0][1][re] + UMassUdaggerMinusEv[0][2][im] * UMassUdaggerMinusEv[0][1][im]); 
denominator[im] = UMassUdaggerMinusEv[0][0][re] * UMassUdaggerMinusEv[1][2][im] + UMassUdaggerMinusEv[0][0][im] * UMassUdaggerMinusEv[1][2][re] - (-UMassUdaggerMinusEv[0][2][re] * UMassUdaggerMinusEv[0][1][im] + UMassUdaggerMinusEv[0][2][im] * UMassUdaggerMinusEv[0][1][re]); 
} 
else { 
numerator1[re] = UMassUdaggerMinusEv[1][1][re] * UMassUdaggerMinusEv[2][2][re] - UMassUdaggerMinusEv[1][1][im] * UMassUdaggerMinusEv[2][2][im] - (UMassUdaggerMinusEv[1][2][re] * UMassUdaggerMinusEv[1][2][re] + UMassUdaggerMinusEv[1][2][im] * UMassUdaggerMinusEv[1][2][im]); 
numerator1[im] = UMassUdaggerMinusEv[1][1][re] * UMassUdaggerMinusEv[2][2][im] + UMassUdaggerMinusEv[1][1][im] * UMassUdaggerMinusEv[2][2][re]; 
numerator3[re] = UMassUdaggerMinusEv[0][1][re] * UMassUdaggerMinusEv[1][2][re] - UMassUdaggerMinusEv[0][1][im] * UMassUdaggerMinusEv[1][2][im] - (UMassUdaggerMinusEv[1][1][re] * UMassUdaggerMinusEv[0][2][re] + UMassUdaggerMinusEv[1][1][im] * UMassUdaggerMinusEv[0][2][im]); 
numerator3[im] = -UMassUdaggerMinusEv[0][1][re] * UMassUdaggerMinusEv[1][2][im] - UMassUdaggerMinusEv[0][1][im] * UMassUdaggerMinusEv[1][2][re] - (-UMassUdaggerMinusEv[1][1][re] * UMassUdaggerMinusEv[0][2][im] + UMassUdaggerMinusEv[1][1][im] * UMassUdaggerMinusEv[0][2][re]); 
denominator[re] = UMassUdaggerMinusEv[1][2][re] * UMassUdaggerMinusEv[0][2][re] + UMassUdaggerMinusEv[1][2][im] * UMassUdaggerMinusEv[0][2][im] - (UMassUdaggerMinusEv[2][2][re] * UMassUdaggerMinusEv[0][1][re] + UMassUdaggerMinusEv[2][2][im] * UMassUdaggerMinusEv[0][1][im]); 
denominator[im] = -UMassUdaggerMinusEv[1][2][re] * UMassUdaggerMinusEv[0][2][im] + UMassUdaggerMinusEv[1][2][im] * UMassUdaggerMinusEv[0][2][re] - (-UMassUdaggerMinusEv[2][2][re] * UMassUdaggerMinusEv[0][1][im] + UMassUdaggerMinusEv[2][2][im] * UMassUdaggerMinusEv[0][1][re]); 
} 
UMatter[0][i][re] = (numerator1[re] * denominator[re] + numerator1[im] * denominator[im]) / (denominator[re] * denominator[re] + denominator[im] * denominator[im]); 
UMatter[0][i][im] = (-numerator1[re] * denominator[im] + numerator1[im] * denominator[re]) / (denominator[re] * denominator[re] + denominator[im] * denominator[im]); 
UMatter[1][i][re] = 1.0; 
UMatter[1][i][im] = 0.0; 
UMatter[2][i][re] = (numerator3[re] * denominator[re] + numerator3[im] * denominator[im]) / (denominator[re] * denominator[re] + denominator[im] * denominator[im]); 
UMatter[2][i][im] = (-numerator3[re] * denominator[im] + numerator3[im] * denominator[re]) / (denominator[re] * denominator[re] + denominator[im] * denominator[im]); 
normalisation = sqrt(UMatter[0][i][re] * UMatter[0][i][re] + UMatter[0][i][im] * UMatter[0][i][im] + UMatter[1][i][re] * UMatter[1][i][re] + UMatter[1][i][im] * UMatter[1][i][im] + UMatter[2][i][re] * UMatter[2][i][re] + UMatter[2][i][im] * UMatter[2][i][im]); 
for(int k=0; k<3; k++) { 
UMatter[k][i][re] = UMatter[k][i][re] / normalisation; 
UMatter[k][i][im] = UMatter[k][i][im] / normalisation; 
} 
#ifdef __show_warning__ 
for(int m=0; m<3; m++) { 
eigenvectorCheck[i][re] += UMassUdaggerMinusEv[i][m][re] * UMatter[m][i][re] - UMassUdaggerMinusEv[i][m][im] * UMatter[m][i][im]; 
eigenvectorCheck[i][im] += UMassUdaggerMinusEv[i][m][re] * UMatter[m][i][im] + UMassUdaggerMinusEv[i][m][im] * UMatter[m][i][re]; 
} 
#endif 
} 
#ifdef __show_warning__ 
for(int i=0; i<3; i++) { 
if(fabs(eigenvectorCheck[i][re]) > 1.0e-8) { 
assert(1); 
} 
if(fabs(eigenvectorCheck[i][im]) > 1.0e-8) { 
assert(1); 
} 
} 
#endif 
#ifdef __show_warning__ 
double scalarProduct[3][2]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<2; j++) { 
scalarProduct[i][j] = 0.0; 
} 
} 
for(int i=0; i<2; i++) { 
for(int j=0; j<3; j++) { 
scalarProduct[i][re] += UMatter[j][i][re] * UMatter[j][i+1][re] + UMatter[j][i][im] * UMatter[j][i+1][im]; 
scalarProduct[i][im] += -UMatter[j][i][re] * UMatter[j][i+1][im] + UMatter[j][i][im] * UMatter[j][i+1][re]; 
} 
} 
for(int j=0; j<3; j++) { 
scalarProduct[2][re] += UMatter[j][0][re] * UMatter[j][2][re] + UMatter[j][0][im] * UMatter[j][2][im]; 
scalarProduct[2][im] += -UMatter[j][0][re] * UMatter[j][2][im] + UMatter[j][0][im] * UMatter[j][2][re]; 
} 
for(int i=0; i<3; i++) { 
if(fabs(scalarProduct[i][re]) > 1.0e-4) { 
assert(1); 
} 
if(fabs(scalarProduct[i][im]) > 1.0e-4) { 
assert(1); 
} 
} 
#endif 
double UMatterDagger[3][3][2]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
UMatterDagger[i][j][re] = UMatter[j][i][re]; 
UMatterDagger[i][j][im] = -UMatter[j][i][im]; 
} 
} 
#ifdef __show_warning__ 
double inverseCheck[3][3][2]; 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
inverseCheck[i][j][re] = 0.0; 
inverseCheck[i][j][im] = 0.0; 
} 
} 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
for(int k=0; k<3; k++) { 
inverseCheck[i][j][re] += UMatter[i][k][re] * UMatterDagger[k][j][re] - UMatter[i][k][im] * UMatterDagger[k][j][im]; 
inverseCheck[i][j][im] += UMatter[i][k][re] * UMatterDagger[k][j][im] + UMatter[i][k][im] * UMatterDagger[k][j][re]; 
} 
} 
} 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
if(i == j) { 
if(fabs(inverseCheck[i][j][re] - 1.0) > 1.0e-4) { 
assert(1); 
} 
if(fabs(inverseCheck[i][j][im]) > 1.0e-4) { 
assert(1); 
} 
} 
else { 
if(fabs(inverseCheck[i][j][re]) > 1.0e-4) { 
assert(1); 
} 
if(fabs(inverseCheck[i][j][im]) > 1.0e-4) { 
assert(1); 
} 
} 
} 
} 
#endif 
for (int i_initflav = 0 ; i_initflav < nFlav ; i_initflav++) { 
double initialFlavourState[nFlav][2] = {}; 
double initialMassState [nFlav][2] = {}; 
double finalMassState [nFlav][2] = {}; 
double finalFlavourState [nFlav][2] = {}; 
initialFlavourState[i_initflav][re] = 1.0; 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) { 
initialMassState[i][re] += UMatterDagger[i][j][re] * initialFlavourState[j][re] - UMatterDagger[i][j][im] * initialFlavourState[j][im]; 
initialMassState[i][im] += UMatterDagger[i][j][re] * initialFlavourState[j][im] + UMatterDagger[i][j][im] * initialFlavourState[j][re]; 
} 
} 
finalMassState[0][re] = initialMassState[0][re]; 
finalMassState[0][im] = initialMassState[0][im]; 
for(int i=1; i<nFlav; i++) { 
finalMassState[i][re] = initialMassState[i][re] * cos((2.0 * kOscDimensFactor * (eigenvalues[i] - eigenvalues[0]) * fBaseline) / energy) - initialMassState[i][im] * -sin((2.0 * kOscDimensFactor * (eigenvalues[i] - eigenvalues[0]) * fBaseline) / energy); 
finalMassState[i][im] = initialMassState[i][re] * -sin((2.0 * kOscDimensFactor * (eigenvalues[i] - eigenvalues[0]) * fBaseline) / energy) + initialMassState[i][im] * cos((2.0 * kOscDimensFactor * (eigenvalues[i] - eigenvalues[0]) * fBaseline) / energy); 
} 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) { 
finalFlavourState[i][re] += UMatter[i][j][re] * finalMassState[j][re] - UMatter[i][j][im] * finalMassState[j][im]; 
finalFlavourState[i][im] += UMatter[i][j][re] * finalMassState[j][im] + UMatter[i][j][im] * finalMassState[j][re]; 
} 
} 
for (int i_finalflav = 0 ; i_finalflav < nFlav ; i_finalflav++ ) { 
osc_probs[i_initflav][i_finalflav] = finalFlavourState[i_finalflav][re]*finalFlavourState[i_finalflav][re] + finalFlavourState[i_finalflav][im]*finalFlavourState[i_finalflav][im]; 
} 
} 
return; 
} 
conv::NuMassHierarchy_t NuOsc3Flavour::GetMassHierarchy(void) const { 
return fMassHierarchy; 
} 
double NuOsc3Flavour::GetBaseline(void) const { 
return fBaseline; 
} 
double NuOsc3Flavour::GetDensity(void) const { 
return fNe; 
} 
NuOscSterile::NuOscSterile() { 
this->Init(); 
} 
NuOscSterile::~NuOscSterile() { 
} 
void NuOscSterile::Init() { 
this->SetBaseline(kBaselineT2K); 
NuMassHierarchy_t nmh = Opt::Instance()->gMassHierarchyAssumed; 
this->SetMassHierarchy(nmh); 
this->SetSterileMassHierarchy(32); 
this->SetDensity(kCrustDensityT2K); 
for (int i=0; i<nFlav; i++) { 
for (int j=0; j<nFlav; j++) { 
sinMixingAngle[i][j] = 0.0; 
cosMixingAngle[i][j] = 1.0; 
} 
} 
for (int i=0; i<nFlav; i++) { 
for (int j=0; j<nFlav; j++) { 
dmsq[i][j] = 0.0; 
} 
} 
for (int i=0; i<nFlav; i++) { 
for (int j=0; j<nFlav; j++) { 
deltaCP[i][j] = 0.0; 
} 
} 
for (int i=0; i<nFlav; i++) { 
for (int j=0; j<nFlav; j++) { 
for (int k=0; k<nFlav; k++)  { 
 for (int l=0; l<nFlav; l++)  { 
 if(k == l)  { 
 rotationMatrix[i][j][k][l][re] = 1.0; 
 rotationMatrix[i][j][k][l][im] = 0.0; 
 } 
 else  { 
 rotationMatrix[i][j][k][l][re] = 0.0; 
 rotationMatrix[i][j][k][l][im] = 0.0; 
 } 
 } 
 } 
} 
} 
for (int i=0; i<nFlav; i++) { 
for (int j=0; j<nFlav; j++) { 
UVacuum[i][j][re] = 0.0; 
UVacuum[i][j][im] = 0.0; 
} 
} 
} 
void NuOscSterile::SetBaseline(double length) { 
fBaseline = length; 
} 
void NuOscSterile::SetDensity(double density) { 
fNe = density * kNA * 0.5; 
} 
void NuOscSterile::SetMassHierarchy(NuMassHierarchy_t h) { 

#ifdef DEBUG_INFO 
assert(1); 
#endif 
if(h==kNmhUndefined){ 
assert(1); 
assert(1); 
util::Die(-1); 
return; 
} 
fMassHierarchy = h; 
} 
void NuOscSterile::SetSterileMassHierarchy(int h) { 

#ifdef DEBUG_INFO 
assert(1); 
#endif 
if(h != 32 && h!= 131) { 
assert(1); 
exit(1); 
} 
fSterileMassHierarchy = h; 
} 
void NuOscSterile::SetMixingAngles(double sinsqtheta12, double sinsqtheta13, double sinsqtheta14, double sinsqtheta15,  double sinsqtheta23, double sinsqtheta24, double sinsqtheta25, double sinsqtheta34, double sinsqtheta35) { 
sinsqtheta12 = TMath::Min(1.,sinsqtheta12); 
sinsqtheta12 = TMath::Max(0.,sinsqtheta12); 
sinsqtheta13 = TMath::Min(1.,sinsqtheta13); 
sinsqtheta13 = TMath::Max(0.,sinsqtheta13); 
sinsqtheta14 = TMath::Min(1.,sinsqtheta14); 
sinsqtheta14 = TMath::Max(0.,sinsqtheta14); 
sinsqtheta15 = TMath::Min(1.,sinsqtheta15); 
sinsqtheta15 = TMath::Max(0.,sinsqtheta15); 
sinsqtheta23 = TMath::Min(1.,sinsqtheta23); 
sinsqtheta23 = TMath::Max(0.,sinsqtheta23); 
sinsqtheta24 = TMath::Min(1.,sinsqtheta24); 
sinsqtheta24 = TMath::Max(0.,sinsqtheta24); 
sinsqtheta25 = TMath::Min(1.,sinsqtheta25); 
sinsqtheta25 = TMath::Max(0.,sinsqtheta25); 
sinsqtheta34 = TMath::Min(1.,sinsqtheta34); 
sinsqtheta34 = TMath::Max(0.,sinsqtheta34); 
sinsqtheta35 = TMath::Min(1.,sinsqtheta35); 
sinsqtheta35 = TMath::Max(0.,sinsqtheta35); 
sinMixingAngle[0][1] = sqrt(sinsqtheta12); 
sinMixingAngle[0][2] = sqrt(sinsqtheta13); 
sinMixingAngle[0][3] = sqrt(sinsqtheta14); 
sinMixingAngle[0][4] = sqrt(sinsqtheta15); 
sinMixingAngle[1][2] = sqrt(sinsqtheta23); 
sinMixingAngle[1][3] = sqrt(sinsqtheta24); 
sinMixingAngle[1][4] = sqrt(sinsqtheta25); 
sinMixingAngle[2][3] = sqrt(sinsqtheta34); 
sinMixingAngle[2][4] = sqrt(sinsqtheta35); 
cosMixingAngle[0][1] = sqrt(1.0 - sinsqtheta12); 
cosMixingAngle[0][2] = sqrt(1.0 - sinsqtheta13); 
cosMixingAngle[0][3] = sqrt(1.0 - sinsqtheta14); 
cosMixingAngle[0][4] = sqrt(1.0 - sinsqtheta15); 
cosMixingAngle[1][2] = sqrt(1.0 - sinsqtheta23); 
cosMixingAngle[1][3] = sqrt(1.0 - sinsqtheta24); 
cosMixingAngle[1][4] = sqrt(1.0 - sinsqtheta25); 
cosMixingAngle[2][3] = sqrt(1.0 - sinsqtheta34); 
cosMixingAngle[2][4] = sqrt(1.0 - sinsqtheta35); 
usingOscParams = true; 
} 
void NuOscSterile::SetMixingDoubleAnglesOct1(double sinsq2theta12, double sinsq2theta13, double sinsq2theta14, double sinsq2theta15, double sinsq2theta23, double sinsq2theta24, double sinsq2theta25, double sinsq2theta34, double sinsq2theta35) { 
sinsq2theta12 = TMath::Min(1.,sinsq2theta12); 
sinsq2theta12 = TMath::Max(0.,sinsq2theta12); 
sinsq2theta13 = TMath::Min(1.,sinsq2theta13); 
sinsq2theta13 = TMath::Max(0.,sinsq2theta13); 
sinsq2theta14 = TMath::Min(1.,sinsq2theta14); 
sinsq2theta14 = TMath::Max(0.,sinsq2theta14); 
sinsq2theta15 = TMath::Min(1.,sinsq2theta15); 
sinsq2theta15 = TMath::Max(0.,sinsq2theta15); 
sinsq2theta23 = TMath::Min(1.,sinsq2theta23); 
sinsq2theta23 = TMath::Max(0.,sinsq2theta23); 
sinsq2theta24 = TMath::Min(1.,sinsq2theta24); 
sinsq2theta24 = TMath::Max(0.,sinsq2theta24); 
sinsq2theta25 = TMath::Min(1.,sinsq2theta25); 
sinsq2theta25 = TMath::Max(0.,sinsq2theta25); 
sinsq2theta34 = TMath::Min(1.,sinsq2theta34); 
sinsq2theta34 = TMath::Max(0.,sinsq2theta34); 
sinsq2theta35 = TMath::Min(1.,sinsq2theta35); 
sinsq2theta35 = TMath::Max(0.,sinsq2theta35); 
sinMixingAngle[0][1] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta12))); 
sinMixingAngle[0][2] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta13))); 
sinMixingAngle[0][3] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta14))); 
sinMixingAngle[0][4] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta15))); 
sinMixingAngle[1][2] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta23))); 
sinMixingAngle[1][3] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta24))); 
sinMixingAngle[1][4] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta25))); 
sinMixingAngle[2][3] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta34))); 
sinMixingAngle[2][4] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta35))); 
cosMixingAngle[0][1] = sqrt(1.0 - sinMixingAngle[0][1] * sinMixingAngle[0][1]); 
cosMixingAngle[0][2] = sqrt(1.0 - sinMixingAngle[0][2] * sinMixingAngle[0][2]); 
cosMixingAngle[0][3] = sqrt(1.0 - sinMixingAngle[0][3] * sinMixingAngle[0][3]); 
cosMixingAngle[0][4] = sqrt(1.0 - sinMixingAngle[0][4] * sinMixingAngle[0][4]); 
cosMixingAngle[1][2] = sqrt(1.0 - sinMixingAngle[1][2] * sinMixingAngle[1][2]); 
cosMixingAngle[1][3] = sqrt(1.0 - sinMixingAngle[1][3] * sinMixingAngle[1][3]); 
cosMixingAngle[1][4] = sqrt(1.0 - sinMixingAngle[1][4] * sinMixingAngle[1][4]); 
cosMixingAngle[2][3] = sqrt(1.0 - sinMixingAngle[2][3] * sinMixingAngle[2][3]); 
cosMixingAngle[2][4] = sqrt(1.0 - sinMixingAngle[2][4] * sinMixingAngle[2][4]); 
usingOscParams = true; 
} 
void NuOscSterile::SetMixingDoubleAnglesOct2(double sinsq2theta12, double sinsq2theta13, double sinsq2theta14, double sinsq2theta15,  double sinsq2theta23, double sinsq2theta24, double sinsq2theta25, double sinsq2theta34, double sinsq2theta35) { 
sinsq2theta12 = TMath::Min(1.,sinsq2theta12); 
sinsq2theta12 = TMath::Max(0.,sinsq2theta12); 
sinsq2theta13 = TMath::Min(1.,sinsq2theta13); 
sinsq2theta13 = TMath::Max(0.,sinsq2theta13); 
sinsq2theta14 = TMath::Min(1.,sinsq2theta14); 
sinsq2theta14 = TMath::Max(0.,sinsq2theta14); 
sinsq2theta15 = TMath::Min(1.,sinsq2theta15); 
sinsq2theta15 = TMath::Max(0.,sinsq2theta15); 
sinsq2theta23 = TMath::Min(1.,sinsq2theta23); 
sinsq2theta23 = TMath::Max(0.,sinsq2theta23); 
sinsq2theta24 = TMath::Min(1.,sinsq2theta24); 
sinsq2theta24 = TMath::Max(0.,sinsq2theta24); 
sinsq2theta25 = TMath::Min(1.,sinsq2theta25); 
sinsq2theta25 = TMath::Max(0.,sinsq2theta25); 
sinsq2theta34 = TMath::Min(1.,sinsq2theta34); 
sinsq2theta34 = TMath::Max(0.,sinsq2theta34); 
sinsq2theta35 = TMath::Min(1.,sinsq2theta35); 
sinsq2theta35 = TMath::Max(0.,sinsq2theta35); 
sinMixingAngle[0][1] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta12))); 
sinMixingAngle[0][2] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta13))); 
sinMixingAngle[0][3] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta14))); 
sinMixingAngle[0][4] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta15))); 
sinMixingAngle[1][2] = sqrt(1 - (0.5 * (1 - sqrt(1 - sinsq2theta23)))); 
sinMixingAngle[1][3] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta24))); 
sinMixingAngle[1][4] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta25))); 
sinMixingAngle[2][3] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta34))); 
sinMixingAngle[2][4] = sqrt(0.5 * (1 - sqrt(1 - sinsq2theta35))); 
cosMixingAngle[0][1] = sqrt(1.0 - sinMixingAngle[0][1] * sinMixingAngle[0][1]); 
cosMixingAngle[0][2] = sqrt(1.0 - sinMixingAngle[0][2] * sinMixingAngle[0][2]); 
cosMixingAngle[0][3] = sqrt(1.0 - sinMixingAngle[0][3] * sinMixingAngle[0][3]); 
cosMixingAngle[0][4] = sqrt(1.0 - sinMixingAngle[0][4] * sinMixingAngle[0][4]); 
cosMixingAngle[1][2] = sqrt(1.0 - sinMixingAngle[1][2] * sinMixingAngle[1][2]); 
cosMixingAngle[1][3] = sqrt(1.0 - sinMixingAngle[1][3] * sinMixingAngle[1][3]); 
cosMixingAngle[1][4] = sqrt(1.0 - sinMixingAngle[1][4] * sinMixingAngle[1][4]); 
cosMixingAngle[2][3] = sqrt(1.0 - sinMixingAngle[2][3] * sinMixingAngle[2][3]); 
cosMixingAngle[2][4] = sqrt(1.0 - sinMixingAngle[2][4] * sinMixingAngle[2][4]); 
usingOscParams = true; 
} 
void NuOscSterile::SetDmsq(double dm21sq, double dm31sq, double dm41sq, double dm51sq) { 
dmsq[1][0] = dm21sq; 
dmsq[2][0] = dm31sq; 
if(fMassHierarchy == kNmhInverted) { 
dmsq[2][0] = -dmsq[2][0]; 
} 
dmsq[2][1] = dmsq[2][0] - dmsq[1][0]; 
if(fSterileMassHierarchy == 32) { 
dmsq[3][0] = dm41sq; 
dmsq[3][1] = dm41sq - dm21sq; 
dmsq[4][3] = dm51sq - dm41sq; 
} 
else if(fSterileMassHierarchy == 131) { 
dmsq[3][0] = -dm41sq; 
dmsq[3][1] = -dm41sq - dm21sq; 
dmsq[4][3] = dm51sq + dm41sq; 
} 
dmsq[4][0] = dm51sq; 
dmsq[4][1] = dm51sq - dm21sq; 
if(fMassHierarchy == kNmhNormal) { 
if(fSterileMassHierarchy == 32) dmsq[3][2] = dm41sq - dm31sq; 
else if(fSterileMassHierarchy == 131) dmsq[3][2] = -dm41sq - dm31sq; 
dmsq[4][2] = dm51sq - dm31sq; 
} 
else if(fMassHierarchy == kNmhInverted) { 
if(fSterileMassHierarchy == 32) dmsq[3][2] = dm41sq + dm31sq; 
else if(fSterileMassHierarchy == 131) dmsq[3][2] = -dm41sq + dm31sq; 
dmsq[4][2] = dm51sq + dm31sq; 
} 
} 
void NuOscSterile::SetDeltaCP(double dcp12, double dcp13, double dcp24, double dcp25, double dcp35) { 
deltaCP[0][1] = dcp12; 
deltaCP[0][2] = dcp13; 
deltaCP[1][3] = dcp24; 
deltaCP[1][4] = dcp25; 
deltaCP[2][4] = dcp35; 
usingOscParams = true; 
} 
void NuOscSterile::SetVacuumPMNSReal (double Ue1, double Ue2, double Ue3, double Ue4, double Ue5, double Umu1, double Umu2, double Umu3, double Umu4, double Umu5, double Utau1, double Utau2, double Utau3, double Utau4, double Utau5, double U41, double U42, double U43, double U44, double U45, double U51, double U52, double U53, double U54, double U55 ) { 
UVacuum[0][0][re] = Ue1; 
UVacuum[0][1][re] = Ue2; 
UVacuum[0][2][re] = Ue3; 
UVacuum[0][3][re] = Ue4; 
UVacuum[0][4][re] = Ue5; 
UVacuum[1][0][re] = Umu1; 
UVacuum[1][1][re] = Umu2; 
UVacuum[1][2][re] = Umu3; 
UVacuum[1][3][re] = Umu4; 
UVacuum[1][4][re] = Umu5; 
UVacuum[2][0][re] = Utau1; 
UVacuum[2][1][re] = Utau2; 
UVacuum[2][2][re] = Utau3; 
UVacuum[2][3][re] = Utau4; 
UVacuum[2][4][re] = Utau5; 
UVacuum[3][0][re] = U41; 
UVacuum[3][1][re] = U42; 
UVacuum[3][2][re] = U43; 
UVacuum[3][3][re] = U44; 
UVacuum[3][4][re] = U45; 
UVacuum[4][0][re] = U51; 
UVacuum[4][1][re] = U52; 
UVacuum[4][2][re] = U53; 
UVacuum[4][3][re] = U54; 
UVacuum[4][4][re] = U55; 
usingOscParams = false; 
} 
void NuOscSterile::SetVacuumPMNSIm (double Ue1, double Ue2, double Ue3, double Ue4, double Ue5, double Umu1, double Umu2, double Umu3, double Umu4, double Umu5, double Utau1, double Utau2, double Utau3, double Utau4, double Utau5, double U41, double U42, double U43, double U44, double U45, double U51, double U52, double U53, double U54, double U55 ) { 
UVacuum[0][0][im] = Ue1; 
UVacuum[0][1][im] = Ue2; 
UVacuum[0][2][im] = Ue3; 
UVacuum[0][3][im] = Ue4; 
UVacuum[0][4][im] = Ue5; 
UVacuum[1][0][im] = Umu1; 
UVacuum[1][1][im] = Umu2; 
UVacuum[1][2][im] = Umu3; 
UVacuum[1][3][im] = Umu4; 
UVacuum[1][4][im] = Umu5; 
UVacuum[2][0][im] = Utau1; 
UVacuum[2][1][im] = Utau2; 
UVacuum[2][2][im] = Utau3; 
UVacuum[2][3][im] = Utau4; 
UVacuum[2][4][im] = Utau5; 
UVacuum[3][0][im] = U41; 
UVacuum[3][1][im] = U42; 
UVacuum[3][2][im] = U43; 
UVacuum[3][3][im] = U44; 
UVacuum[3][4][im] = U45; 
UVacuum[4][0][im] = U51; 
UVacuum[4][1][im] = U52; 
UVacuum[4][2][im] = U53; 
UVacuum[4][3][im] = U54; 
UVacuum[4][4][im] = U55; 
usingOscParams = false; 
} 
void NuOscSterile::SetVacuumPMNSImToZero() { 
for (int i=0; i<nFlav; i++) { 
for (int j=0; j<nFlav; j++) { 
UVacuum[i][j][im] = 0.0; 
} 
} 
usingOscParams = false; 
} 
void NuOscSterile::SetVacuumPMNSElementByIndex(int iflav, int imass, double real, double imag) { 
UVacuum[iflav][imass][re] = real; 
UVacuum[iflav][imass][im] = imag; 
usingOscParams = false; 
return; 
} 
void NuOscSterile::SetVacuumPMNSElementByType(int nu_pdg, int nmass, double real, double imag) { 
int imass = nmass-1; 
int iflav=-999; 
switch (abs(nu_pdg)) { 
case kPdgNuE : iflav=0; break; 
case kPdgNuMu : iflav=1; break; 
case kPdgNuTau: iflav=2; break; 
case kPdgNuS4 : iflav=3; break; 
case kPdgNuS5 : iflav=4; break; 
default: cerr<<"NuOscSterile/SetVacuumPMNSElementByType >> Unrecognised PDG: "<<nu_pdg<<endl; exit(-1); 
} 
UVacuum[iflav][imass][re] = real; 
UVacuum[iflav][imass][im] = imag; 
usingOscParams = false; 
return; 
} 
void NuOscSterile::CalcVacuumPMNS() { 
for (int i=0; i<nFlav; i++) { 
for (int j=0; j<nFlav; j++) { 
for (int k=0; k<nFlav; k++)  { 
 for (int l=0; l<nFlav; l++)  { 
 if(k == l)  { 
 rotationMatrix[i][j][k][l][re] = 1.0; 
rotationMatrix[i][j][k][l][im] = 0.0; 
 } 
 if(k == i && l == i)  { 
 rotationMatrix[i][j][k][l][re] = cosMixingAngle[i][j]; 
 rotationMatrix[i][j][k][l][im] = 0.0; 
 } 
 else if(k == i && l == j)  { 
 if(nFlav == 5)  { 
 if((i == 0 && (j == 1 || j == 2)) || (i == 1 && (j == 3 || j == 4)) || (i == 2 && j == 4))  { 
 rotationMatrix[i][j][k][l][re] = sinMixingAngle[i][j] * cos(deltaCP[i][j]); 
 rotationMatrix[i][j][k][l][im] = sinMixingAngle[i][j] * -sin(deltaCP[i][j]); 
 } 
 else  { 
 rotationMatrix[i][j][k][l][re] = sinMixingAngle[i][j]; 
 rotationMatrix[i][j][k][l][im] = 0.0; 
 } 
 } 
 } 
 else if(k == j && l == i)  { 
 if(nFlav == 5) { 
 if((i == 0 && (j == 1 || j == 2)) || (i == 1 && (j == 3 || j == 4)) || (i == 2 && j == 4))  { 
 rotationMatrix[i][j][k][l][re] = -sinMixingAngle[i][j] * cos(deltaCP[i][j]); 
 rotationMatrix[i][j][k][l][im] = -sinMixingAngle[i][j] * sin(deltaCP[i][j]); 
 } 
 else  { 
 rotationMatrix[i][j][k][l][re] = -sinMixingAngle[i][j]; 
 rotationMatrix[i][j][k][l][im] = 0.0; 
 } 
 } 
 } 
 else if(k == j && l == j)  { 
 rotationMatrix[i][j][k][l][re] = cosMixingAngle[i][j]; 
 rotationMatrix[i][j][k][l][im] = 0.0; 
 } 
 else  { 
 if(k != l)  { 
 rotationMatrix[i][j][k][l][re] = 0.0; 
 rotationMatrix[i][j][k][l][im] = 0.0; 
 } 
 } 
 } 
 } 
} 
} 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++)  { 
 if(i == j)  UVacuum[i][j][re] = 1.0; 
 else  UVacuum[i][j][re] = 0.0; 
 UVacuum[i][j][im] = 0.0; 
 } 
} 
double UVacuumCopy[nFlav][nFlav][2]; 
for(int r=0; r<3; r++) { 
for(int s=r+1; s<nFlav; s++) { 
  for(int i=0; i<nFlav; i++)  { 
 for(int j=0; j<nFlav; j++)  { 
 UVacuumCopy[i][j][re] = UVacuum[i][j][re]; 
 UVacuumCopy[i][j][im] = UVacuum[i][j][im]; 
UVacuum[i][j][re] = 0.0; 
 UVacuum[i][j][im] = 0.0; 
 } 
 } 
for(int i=0; i<nFlav; i++)  { 
 for(int j=0; j<nFlav; j++)  { 
 for(int k=0; k<nFlav; k++)  { 
UVacuum[i][j][re] += rotationMatrix[r][s][i][k][re] * UVacuumCopy[k][j][re] - rotationMatrix[r][s][i][k][im] * UVacuumCopy[k][j][im]; 
UVacuum[i][j][im] += rotationMatrix[r][s][i][k][re] * UVacuumCopy[k][j][im] + rotationMatrix[r][s][i][k][im] * UVacuumCopy[k][j][re]; 
 } 
 } 
 } 
} 
} 
} 
bool NuOscSterile::Check3FlavPMNS() { 
double PMNSMatrix3Flav[3][3][2]; 
PMNSMatrix3Flav[0][0][re] = cosMixingAngle[0][1]*cosMixingAngle[0][2]; 
PMNSMatrix3Flav[0][0][im] = 0.0; 
PMNSMatrix3Flav[0][1][re] = cosMixingAngle[0][2]*sinMixingAngle[0][1]; 
PMNSMatrix3Flav[0][1][im] = 0.0; 
PMNSMatrix3Flav[0][2][re] = sinMixingAngle[0][2]*cos(deltaCP[0][2]); 
PMNSMatrix3Flav[0][2][im] = sinMixingAngle[0][2]*-sin(deltaCP[0][2]); 
PMNSMatrix3Flav[1][0][re] = -cosMixingAngle[1][2]*sinMixingAngle[0][1]-sinMixingAngle[0][2]*sinMixingAngle[1][2]*cosMixingAngle[0][1]*cos(deltaCP[0][2]); 
PMNSMatrix3Flav[1][0][im] = -sinMixingAngle[0][2]*sinMixingAngle[1][2]*cosMixingAngle[0][1]*sin(deltaCP[0][2]); 
PMNSMatrix3Flav[1][1][re] = cosMixingAngle[0][1]*cosMixingAngle[1][2]-sinMixingAngle[0][1]*sinMixingAngle[0][2]*sinMixingAngle[1][2]*cos(deltaCP[0][2]); 
PMNSMatrix3Flav[1][1][im] = -sinMixingAngle[0][1]*sinMixingAngle[0][2]*sinMixingAngle[1][2]*sin(deltaCP[0][2]); 
PMNSMatrix3Flav[1][2][re] = cosMixingAngle[0][2]*sinMixingAngle[1][2]; 
PMNSMatrix3Flav[1][2][im] = 0.0; 
PMNSMatrix3Flav[2][0][re] = sinMixingAngle[0][1]*sinMixingAngle[1][2]-sinMixingAngle[0][2]*cosMixingAngle[0][1]*cosMixingAngle[1][2]*cos(deltaCP[0][2]); 
PMNSMatrix3Flav[2][0][im] = -sinMixingAngle[0][2]*cosMixingAngle[0][1]*cosMixingAngle[1][2]*sin(deltaCP[0][2]); 
PMNSMatrix3Flav[2][1][re] = -sinMixingAngle[1][2]*cosMixingAngle[0][1]-sinMixingAngle[0][1]*cosMixingAngle[1][2]*sinMixingAngle[0][2]*cos(deltaCP[0][2]); 
PMNSMatrix3Flav[2][1][im] = -sinMixingAngle[0][1]*cosMixingAngle[1][2]*sinMixingAngle[0][2]*sin(deltaCP[0][2]); 
PMNSMatrix3Flav[2][2][re] = cosMixingAngle[0][2]*cosMixingAngle[1][2]; 
PMNSMatrix3Flav[2][2][im] = 0.0; 
this->CalcVacuumPMNS(); 
for(int i=0; i<3; i++) { 
for(int j=0; j<3; j++) { 
if(fabs(UVacuum[i][j][re] - PMNSMatrix3Flav[i][j][re]) > 1E-12)  { 
 cout<<"NuOscSterile::Check3FlavPMNS() check failed for PMNS matrix element "<<i<<" "<<j<<" re; "; 
 cout<<"difference between UVacuum and PMNSMatrix3Flav is "<<fabs(UVacuum[i][j][re] - PMNSMatrix3Flav[i][j][re])<<endl; 
return false; 
 } 
if(fabs(UVacuum[i][j][im] - PMNSMatrix3Flav[i][j][im]) > 1E-12) { 
assert(1); 
assert(1); 
return false; 
} 
} 
} 
return true; 
} 
void NuOscSterile::CalcMEProduct(int nu_start, int nu_end, int mass1, int mass2) { 
double MEProduct12[2]; 
double MEProduct34[2]; 
MEProduct12[re] = UVacuum[nu_start][mass2][re] * UVacuum[nu_end][mass2][re] - (-UVacuum[nu_start][mass2][im]) * UVacuum[nu_end][mass2][im]; 
MEProduct12[im] = UVacuum[nu_start][mass2][re] * UVacuum[nu_end][mass2][im] + (-UVacuum[nu_start][mass2][im]) * UVacuum[nu_end][mass2][re]; 
MEProduct34[re] = UVacuum[nu_start][mass1][re] * UVacuum[nu_end][mass1][re] - (UVacuum[nu_start][mass1][im]) * -UVacuum[nu_end][mass1][im]; 
MEProduct34[im] = UVacuum[nu_start][mass1][re] * -UVacuum[nu_end][mass1][im] + (UVacuum[nu_start][mass1][im]) * UVacuum[nu_end][mass1][re]; 
MEProduct[re] = MEProduct12[re] * MEProduct34[re] - MEProduct12[im] * MEProduct34[im]; 
MEProduct[im] = MEProduct12[re] * MEProduct34[im] + MEProduct12[im] * MEProduct34[re]; 
} 
double NuOscSterile::CalcVacuumOscProb(int nu_start, int nu_end, double energy) { 
OscChannelId_t osch = util::GetOscChannel(nu_start, nu_end); 
if(osch == kOscUndefined) { 
assert(1); 
return 0.; 
} 
double oscProb = 0.0; 
if(usingOscParams) this->CalcVacuumPMNS(); 
if(osch == kOscNuE2NuE || osch == kOscNuEBar2NuEBar) { 
oscProb = 1.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++) { 
 this->CalcMEProduct(0, 0, i, j); 
 oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy)  * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 } 
} 
} 
else if(osch == kOscNuE2NuMu || osch == kOscNuMuBar2NuEBar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++)  { 
 this->CalcMEProduct(0, 1, i, j); 
 oscProb += 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy) * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 } 
} 
} 
else if(osch == kOscNuE2NuTau || osch == kOscNuTauBar2NuEBar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++)  { 
 this->CalcMEProduct(0, 2, i, j); 
 oscProb += 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy) * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 } 
} 
} 
else if(osch == kOscNuMu2NuE || osch == kOscNuEBar2NuMuBar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++)  { 
 this->CalcMEProduct(0, 1, i, j); 
 oscProb -= 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy)  * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy);  } 
} 
} 
else if(osch == kOscNuMu2NuMu || osch == kOscNuMuBar2NuMuBar) { 
oscProb = 1.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++)  { 
 this->CalcMEProduct(1, 1, i, j); 
 oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy)  * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 } 
} 
} 
else if(osch == kOscNuMu2NuTau || osch == kOscNuTauBar2NuMuBar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++)  { 
 this->CalcMEProduct(1, 2, i, j); 
 oscProb += 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy)  * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 } 
} 
} 
else if(osch == kOscNuTau2NuE || osch == kOscNuEBar2NuTauBar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++)  { 
 this->CalcMEProduct(0, 2, i, j); 
 oscProb -= 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy)  * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 } 
} 
} 
else if(osch == kOscNuTau2NuMu || osch == kOscNuMuBar2NuTauBar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++)  { 
 this->CalcMEProduct(1, 2, i, j); 
 oscProb -= 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy)  * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
} 
} 
} 
else if(osch == kOscNuTau2NuTau || osch == kOscNuTauBar2NuTauBar) { 
oscProb = 1.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++) { 
 this->CalcMEProduct(2, 2, i, j); 
 oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy)  * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 } 
} 
} 
else if(osch == kOscNuE2NuS4 || osch == kOscNuS4Bar2NuEBar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++)  { 
 this->CalcMEProduct(0, 3, i, j); 
 oscProb += 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy) * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 } 
} 
} 
else if(osch == kOscNuE2NuS5 || osch == kOscNuS5Bar2NuEBar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++) { 
 this->CalcMEProduct(0, 4, i, j); 
 oscProb += 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy)  * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 } 
} 
} 
else if(osch == kOscNuMu2NuS4 || osch == kOscNuS4Bar2NuMuBar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++)  { 
 this->CalcMEProduct(1, 3, i, j); 
 oscProb += 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy) * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 } 
} 
} 
else if(osch == kOscNuMu2NuS5 || osch == kOscNuS5Bar2NuMuBar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++) { 
 this->CalcMEProduct(1, 4, i, j); 
 oscProb += 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy) * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 } 
} 
} 
else if(osch == kOscNuTau2NuS4 || osch == kOscNuS4Bar2NuTauBar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++) { 
this->CalcMEProduct(2, 3, i, j); 
oscProb += 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy) * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
} 
} 
} 
else if(osch == kOscNuTau2NuS5 || osch == kOscNuS5Bar2NuTauBar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++) { 
 this->CalcMEProduct(2, 4, i, j); 
 oscProb += 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy) * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 } 
} 
} 
else if(osch == kOscNuS42NuE || osch == kOscNuEBar2NuS4Bar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++) { 
this->CalcMEProduct(0, 3, i, j); 
oscProb -= 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy) * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
} 
} 
} 
else if(osch == kOscNuS42NuMu || osch == kOscNuMuBar2NuS4Bar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++) { 
this->CalcMEProduct(1, 3, i, j); 
oscProb -= 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy) * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
} 
} 
} 
else if(osch == kOscNuS42NuTau || osch == kOscNuTauBar2NuS4Bar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++)  { 
 this->CalcMEProduct(2, 3, i, j); 
 oscProb -= 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy) * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 } 
} 
} 
else if(osch == kOscNuS52NuE || osch == kOscNuEBar2NuS5Bar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++) { 
this->CalcMEProduct(0, 4, i, j); 
oscProb -= 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy) * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
} 
} 
} 
else if(osch == kOscNuS52NuMu || osch == kOscNuMuBar2NuS5Bar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++) { 
this->CalcMEProduct(1, 4, i, j); 
oscProb -= 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy) * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
} 
} 
} 
else if(osch == kOscNuS52NuTau || osch == kOscNuTauBar2NuS5Bar) { 
oscProb = 0.0; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=i+1; j<nFlav; j++)  { 
 this->CalcMEProduct(2, 4, i, j); 
 oscProb -= 2 * MEProduct[im] * sin((2.0 * kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 oscProb -= 4.0 * MEProduct[re] * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy) * sin((kOscDimensFactor * dmsq[j][i] * fBaseline) / energy); 
 } 
} 
} 
return oscProb; 
} 
double NuOscSterile::CalcMatterOscProb(int nu_start, int nu_end, double energy) { 
OscChannelId_t osch = util::GetOscChannel(nu_start, nu_end); 
if(osch == kOscUndefined) { 
assert(1); 
return 0.; 
} 
double oscProb = 0.0; 
if(usingOscParams) this->CalcVacuumPMNS(); 
double UMassUdagger[nFlav][nFlav][2] = {}; 
double massSqMatrix[nFlav][nFlav][2] = {}; 
double UMass[nFlav][nFlav][2] = {}; 
massSqMatrix[1][1][re] = dmsq[1][0]; 
massSqMatrix[2][2][re] = dmsq[2][0]; 
massSqMatrix[3][3][re] = dmsq[3][0]; 
massSqMatrix[4][4][re] = dmsq[4][0]; 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) { 
for(int k=0; k<nFlav; k++) { 
UMass[i][j][re] += UVacuum[i][k][re] * massSqMatrix[k][j][re]  - UVacuum[i][k][im] * massSqMatrix[k][j][im]; 
UMass[i][j][im] += UVacuum[i][k][re] * massSqMatrix[k][j][im]  + UVacuum[i][k][im] * massSqMatrix[k][j][re]; 
} 
} 
} 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) { 
for(int k=0; k<nFlav; k++)  { 
UMassUdagger[i][j][re] += UMass[i][k][re] * UVacuum[j][k][re]  - UMass[i][k][im] * -UVacuum[j][k][im]; 
UMassUdagger[i][j][im] += UMass[i][k][re] * -UVacuum[j][k][im]  + UMass[i][k][im] * UVacuum[j][k][re]; 
 } 
} 
} 
if(util::IsAntiNeutrino(nu_start)) { 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) { 
 UMassUdagger[i][j][im] = -UMassUdagger[i][j][im]; 
} 
} 
} 
double Nn = fNe; 
if(util::IsNeutrino(nu_start)) { 
UMassUdagger[0][0][re] = UMassUdagger[0][0][re] + 2.0*1.0e9*energy*sqrt(2.0)*kGF_SI*fNe - 2.0*1.0e9*energy*0.5*sqrt(2.0)*kGF_SI*Nn; 
UMassUdagger[1][1][re] -= 2.0*1.0e9*energy*0.5*sqrt(2.0)*kGF_SI*Nn; 
UMassUdagger[2][2][re] -= 2.0*1.0e9*energy*0.5*sqrt(2.0)*kGF_SI*Nn; 
} 
else if(util::IsAntiNeutrino(nu_start)) { 
UMassUdagger[0][0][re] = UMassUdagger[0][0][re] - 2.0*1.0e9*energy*sqrt(2.0)*kGF_SI*fNe + 2.0*1.0e9*energy*0.5*sqrt(2.0)*kGF_SI*Nn; 
UMassUdagger[1][1][re] += 2.0*1.0e9*energy*0.5*sqrt(2.0)*kGF_SI*Nn; 
UMassUdagger[2][2][re] += 2.0*1.0e9*energy*0.5*sqrt(2.0)*kGF_SI*Nn; 
} 
double eigenvalues[nFlav] = {}; 
double UMatter[nFlav][nFlav][2] = {}; 
double UMatterDagger[nFlav][nFlav][2] = {}; 
#ifdef __VALOR_FMWK_GSL_ENABLED__ 
util::DiagonaliseGSL(nFlav, &UMassUdagger[0][0][0], &UMatter[0][0][0], &eigenvalues[0]); 
#else 
assert(1); 
exit(-1); 
#endif 
#ifdef __check_diagonalisation__ 
double eigenvalueSum = eigenvalues[0] + eigenvalues[1] + eigenvalues[2] + eigenvalues[3] + eigenvalues[4]; 
double trace = UMassUdagger[0][0][re] + UMassUdagger[1][1][re] + UMassUdagger[2][2][re] + UMassUdagger[3][3][re] + UMassUdagger[4][4][re]; 
assert(1); 
assert(1); 
if(fabs((eigenvalueSum - trace) / trace) > 1.0e-10) { 
assert(1); 
} 
double UMassUdaggerMinusEv[nFlav][nFlav][2]; 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) { 
for(int k=0; k<2; k++)  { 
 UMassUdaggerMinusEv[i][j][k] = UMassUdagger[i][j][k]; 
 } 
} 
} 
double eigenvectorCheck[nFlav][2] = {}; 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) UMassUdaggerMinusEv[j][j][re] = UMassUdagger[j][j][re] - eigenvalues[i]; 
for(int m=0; m<nFlav; m++) { 
eigenvectorCheck[i][re] += UMassUdaggerMinusEv[i][m][re] * UMatter[m][i][re]  - UMassUdaggerMinusEv[i][m][im] * UMatter[m][i][im]; 
eigenvectorCheck[i][im] += UMassUdaggerMinusEv[i][m][re] * UMatter[m][i][im]  + UMassUdaggerMinusEv[i][m][im] * UMatter[m][i][re]; 
} 
} 
for(int i=0; i<nFlav; i++) { 
assert(1); 
if(fabs(eigenvectorCheck[i][re]) > 1.0e-10)  { 
 cerr << "Warning in NuOscSterile::CalcMatterOscProb() : real part of eigenvector check = "  << eigenvectorCheck[i][re] <<"." << endl; 
 } 
if(fabs(eigenvectorCheck[i][im]) > 1.0e-10)  { 
 cerr << "Warning in NuOscSterile::CalcMatterOscProb() : imaginary part of eigenvector check = "  << eigenvectorCheck[i][im] << "." << endl; 
 } 
} 
double scalarProduct[nFlav][2] = {}; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=0; j<nFlav; j++) { 
scalarProduct[i][re] += UMatter[j][i][re] * UMatter[j][i+1][re]  + UMatter[j][i][im] * UMatter[j][i+1][im]; 
scalarProduct[i][im] += -UMatter[j][i][re] * UMatter[j][i+1][im]  + UMatter[j][i][im] * UMatter[j][i+1][re]; 
} 
} 
for(int j=0; j<nFlav; j++) { 
scalarProduct[nFlav-1][re] += UMatter[j][0][re] * UMatter[j][nFlav-1][re] + UMatter[j][0][im] * UMatter[j][nFlav-1][im]; 
scalarProduct[nFlav-1][im] +=- UMatter[j][0][re] * UMatter[j][nFlav-1][im] + UMatter[j][0][im] * UMatter[j][nFlav-1][re]; 
} 
assert(1); 
for(int i=0; i<nFlav; i++) { 
assert(1); 
if(fabs(scalarProduct[i][re]) > 1.0e-8) { 
assert(1); 
} 
if(fabs(scalarProduct[i][im]) > 1.0e-8) { 
assert(1); 
} 
} 
assert(1); 
#endif 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) { 
UMatterDagger[i][j][re] = UMatter[j][i][re]; 
UMatterDagger[i][j][im] = -UMatter[j][i][im]; 
} 
} 
double initialFlavourState[nFlav][2]; 
for(int i=0; i<nFlav; i++) { 
initialFlavourState[i][re] = 0.0; 
initialFlavourState[i][im] = 0.0; 
} 
if(nu_start == kPdgNuE || nu_start == kPdgNuEBar) initialFlavourState[0][re] = 1.0; 
else if(nu_start == kPdgNuMu || nu_start == kPdgNuMuBar) initialFlavourState[1][re] = 1.0; 
else if(nu_start == kPdgNuTau || nu_start == kPdgNuTauBar) initialFlavourState[2][re] = 1.0; 
else if(nu_start == kPdgNuS4 || nu_start == kPdgNuS4Bar) initialFlavourState[3][re] = 1.0; 
else if(nu_start == kPdgNuS5 || nu_start == kPdgNuS5Bar) initialFlavourState[4][re] = 1.0; 
double initialMassState[nFlav][2]; 
for(int i=0; i<nFlav; i++) { 
initialMassState[i][re] = 0.0; 
initialMassState[i][im] = 0.0; 
} 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) { 
initialMassState[i][re] += UMatterDagger[i][j][re] * initialFlavourState[j][re] - UMatterDagger[i][j][im] * initialFlavourState[j][im]; 
initialMassState[i][im] += UMatterDagger[i][j][re] * initialFlavourState[j][im] + UMatterDagger[i][j][im] * initialFlavourState[j][re]; 
} 
} 
double finalMassState[nFlav][2]; 
for(int i=0; i<nFlav; i++) { 
finalMassState[i][re] = 0.0; 
finalMassState[i][im] = 0.0; 
} 
finalMassState[0][re] = initialMassState[0][re]; 
finalMassState[0][im] = initialMassState[0][im]; 
for(int i=1; i<nFlav; i++) { 
finalMassState[i][re] = initialMassState[i][re] * cos((2.0 * kOscDimensFactor * (eigenvalues[i] - eigenvalues[0]) * fBaseline) / energy) - initialMassState[i][im] * -sin((2.0 * kOscDimensFactor * (eigenvalues[i] - eigenvalues[0]) * fBaseline) / energy); 
finalMassState[i][im] = initialMassState[i][re] * -sin((2.0 * kOscDimensFactor * (eigenvalues[i] - eigenvalues[0]) * fBaseline) / energy) + initialMassState[i][im] * cos((2.0 * kOscDimensFactor * (eigenvalues[i] - eigenvalues[0]) * fBaseline) / energy); 
} 
double finalFlavourState[nFlav][2]; 
for(int i=0; i<nFlav; i++) { 
finalFlavourState[i][re] = 0.0; 
finalFlavourState[i][im] = 0.0; 
} 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) { 
finalFlavourState[i][re] += UMatter[i][j][re] * finalMassState[j][re]  - UMatter[i][j][im] * finalMassState[j][im]; 
finalFlavourState[i][im] += UMatter[i][j][re] * finalMassState[j][im]  + UMatter[i][j][im] * finalMassState[j][re]; 
} 
} 
if(nu_end == kPdgNuE || nu_end == kPdgNuEBar) { 
oscProb = finalFlavourState[0][re]*finalFlavourState[0][re] + finalFlavourState[0][im]*finalFlavourState[0][im]; 
} 
else if(nu_end == kPdgNuMu || nu_end == kPdgNuMuBar) { 
oscProb = finalFlavourState[1][re]*finalFlavourState[1][re] + finalFlavourState[1][im]*finalFlavourState[1][im]; 
} 
else if(nu_end == kPdgNuTau || nu_end == kPdgNuTauBar) { 
oscProb = finalFlavourState[2][re]*finalFlavourState[2][re] + finalFlavourState[2][im]*finalFlavourState[2][im]; 
} 
else if(nu_end == kPdgNuS4 || nu_end == kPdgNuS4Bar) { 
oscProb = finalFlavourState[3][re]*finalFlavourState[3][re]  + finalFlavourState[3][im]*finalFlavourState[3][im]; 
} 
else if(nu_end == kPdgNuS5|| nu_end == kPdgNuS5Bar) { 
oscProb = finalFlavourState[4][re]*finalFlavourState[4][re]  + finalFlavourState[4][im]*finalFlavourState[4][im]; 
} 
return oscProb; 
} 
void NuOscSterile::CalcMatterOscProbAll(bool isAntineutrino, double energy, double * osc_probs_out) { 
if(usingOscParams) this->CalcVacuumPMNS(); 
double UMassUdagger[nFlav][nFlav][2] = {}; 
double massSqMatrix[nFlav][nFlav][2] = {}; 
double UMass[nFlav][nFlav][2] = {}; 
massSqMatrix[1][1][re] = dmsq[1][0]; 
massSqMatrix[2][2][re] = dmsq[2][0]; 
massSqMatrix[3][3][re] = dmsq[3][0]; 
massSqMatrix[4][4][re] = dmsq[4][0]; 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) { 
for(int k=0; k<nFlav; k++) { 
UMass[i][j][re] += UVacuum[i][k][re] * massSqMatrix[k][j][re]  - UVacuum[i][k][im] * massSqMatrix[k][j][im]; 
UMass[i][j][im] += UVacuum[i][k][re] * massSqMatrix[k][j][im]  + UVacuum[i][k][im] * massSqMatrix[k][j][re]; 
} 
} 
} 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) { 
for(int k=0; k<nFlav; k++) { 
UMassUdagger[i][j][re] += UMass[i][k][re] * UVacuum[j][k][re]  - UMass[i][k][im] * -UVacuum[j][k][im]; 
UMassUdagger[i][j][im] += UMass[i][k][re] * -UVacuum[j][k][im]  + UMass[i][k][im] * UVacuum[j][k][re]; 
} 
} 
} 
if(isAntineutrino) { 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) { 
 UMassUdagger[i][j][im] = -UMassUdagger[i][j][im]; 
} 
} 
} 
double Nn = fNe; 
if(!isAntineutrino) { 
UMassUdagger[0][0][re] = UMassUdagger[0][0][re] + 2.0*1.0e9*energy*sqrt(2.0)*kGF_SI*fNe - 2.0*1.0e9*energy*0.5*sqrt(2.0)*kGF_SI*Nn; 
UMassUdagger[1][1][re] -= 2.0*1.0e9*energy*0.5*sqrt(2.0)*kGF_SI*Nn; 
UMassUdagger[2][2][re] -= 2.0*1.0e9*energy*0.5*sqrt(2.0)*kGF_SI*Nn; 
} 
else { 
UMassUdagger[0][0][re] = UMassUdagger[0][0][re] - 2.0*1.0e9*energy*sqrt(2.0)*kGF_SI*fNe + 2.0*1.0e9*energy*0.5*sqrt(2.0)*kGF_SI*Nn; 
UMassUdagger[1][1][re] += 2.0*1.0e9*energy*0.5*sqrt(2.0)*kGF_SI*Nn; 
UMassUdagger[2][2][re] += 2.0*1.0e9*energy*0.5*sqrt(2.0)*kGF_SI*Nn; 
} 
double eigenvalues[nFlav] = {}; 
double UMatter[nFlav][nFlav][2] = {}; 
double UMatterDagger[nFlav][nFlav][2] = {}; 
#ifdef __VALOR_FMWK_GSL_ENABLED__ 
util::DiagonaliseGSL(nFlav, &UMassUdagger[0][0][0], &UMatter[0][0][0], &eigenvalues[0]); 
#else 
assert(1); 
exit(-1); 
#endif 
#ifdef __check_diagonalisation__ 
double eigenvalueSum = eigenvalues[0] + eigenvalues[1] + eigenvalues[2] + eigenvalues[3] + eigenvalues[4]; 
double trace = UMassUdagger[0][0][re] + UMassUdagger[1][1][re] + UMassUdagger[2][2][re] + UMassUdagger[3][3][re] + UMassUdagger[4][4][re]; 
assert(1); 
assert(1); 
if(fabs((eigenvalueSum - trace) / trace) > 1.0e-10) { 
assert(1); 
} 
double UMassUdaggerMinusEv[nFlav][nFlav][2]; 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) { 
for(int k=0; k<2; k++) { 
 UMassUdaggerMinusEv[i][j][k] = UMassUdagger[i][j][k]; 
} 
} 
} 
double eigenvectorCheck[nFlav][2] = {}; 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) UMassUdaggerMinusEv[j][j][re] = UMassUdagger[j][j][re] - eigenvalues[i]; 
for(int m=0; m<nFlav; m++) { 
eigenvectorCheck[i][re] += UMassUdaggerMinusEv[i][m][re] * UMatter[m][i][re]  - UMassUdaggerMinusEv[i][m][im] * UMatter[m][i][im]; 
eigenvectorCheck[i][im] += UMassUdaggerMinusEv[i][m][re] * UMatter[m][i][im]  + UMassUdaggerMinusEv[i][m][im] * UMatter[m][i][re]; 
} 
} 
for(int i=0; i<nFlav; i++) { 
assert(1); 
if(fabs(eigenvectorCheck[i][re]) > 1.0e-10) { 
assert(1); 
} 
if(fabs(eigenvectorCheck[i][im]) > 1.0e-10) { 
assert(1); 
} 
} 
double scalarProduct[nFlav][2] = {}; 
for(int i=0; i<nFlav-1; i++) { 
for(int j=0; j<nFlav; j++) { 
scalarProduct[i][re] += UMatter[j][i][re] * UMatter[j][i+1][re]  + UMatter[j][i][im] * UMatter[j][i+1][im]; 
scalarProduct[i][im] += -UMatter[j][i][re] * UMatter[j][i+1][im]  + UMatter[j][i][im] * UMatter[j][i+1][re]; 
} 
} 
for(int j=0; j<nFlav; j++) { 
scalarProduct[nFlav-1][re] += UMatter[j][0][re] * UMatter[j][nFlav-1][re] + UMatter[j][0][im] * UMatter[j][nFlav-1][im]; 
scalarProduct[nFlav-1][im] +=- UMatter[j][0][re] * UMatter[j][nFlav-1][im] + UMatter[j][0][im] * UMatter[j][nFlav-1][re]; 
} 
assert(1); 
for(int i=0; i<nFlav; i++) { 
assert(1); 
if(fabs(scalarProduct[i][re]) > 1.0e-8) { 
assert(1); 
} 
if(fabs(scalarProduct[i][im]) > 1.0e-8) { 
assert(1); 
} 
} 
assert(1); 
#endif 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) { 
UMatterDagger[i][j][re] = UMatter[j][i][re]; 
UMatterDagger[i][j][im] = -UMatter[j][i][im]; 
} 
} 
double(&osc_probs)[nFlav][nFlav] = *reinterpret_cast< double (*) [nFlav][nFlav]> (osc_probs_out); 
for (int i_initflav = 0 ; i_initflav < nFlav ; i_initflav++) { 
double initialFlavourState[nFlav][2] = {}; 
double initialMassState [nFlav][2] = {}; 
double finalMassState [nFlav][2] = {}; 
double finalFlavourState [nFlav][2] = {}; 
initialFlavourState[i_initflav][re] = 1.0; 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) { 
 initialMassState[i][re] += UMatterDagger[i][j][re] * initialFlavourState[j][re]  - UMatterDagger[i][j][im] * initialFlavourState[j][im]; 
 initialMassState[i][im] += UMatterDagger[i][j][re] * initialFlavourState[j][im]  + UMatterDagger[i][j][im] * initialFlavourState[j][re]; 
} 
} 
finalMassState[0][re] = initialMassState[0][re]; 
finalMassState[0][im] = initialMassState[0][im]; 
for(int i=1; i<nFlav; i++) { 
finalMassState[i][re] = initialMassState[i][re] * cos((2.0 * kOscDimensFactor * (eigenvalues[i] - eigenvalues[0]) * fBaseline) / energy)  - initialMassState[i][im] * -sin((2.0 * kOscDimensFactor * (eigenvalues[i] - eigenvalues[0]) * fBaseline) / energy); 
finalMassState[i][im] = initialMassState[i][re] * -sin((2.0 * kOscDimensFactor * (eigenvalues[i] - eigenvalues[0]) * fBaseline) / energy)  + initialMassState[i][im] * cos((2.0 * kOscDimensFactor * (eigenvalues[i] - eigenvalues[0]) * fBaseline) / energy); 
} 
for(int i=0; i<nFlav; i++) { 
for(int j=0; j<nFlav; j++) { 
 finalFlavourState[i][re] += UMatter[i][j][re] * finalMassState[j][re]  - UMatter[i][j][im] * finalMassState[j][im]; 
 finalFlavourState[i][im] += UMatter[i][j][re] * finalMassState[j][im]  + UMatter[i][j][im] * finalMassState[j][re]; 
} 
} 
for (int i_finalflav = 0 ; i_finalflav < nFlav ; i_finalflav++ ) { 
osc_probs[i_initflav][i_finalflav] = finalFlavourState[i_finalflav][re]*finalFlavourState[i_finalflav][re]  + finalFlavourState[i_finalflav][im]*finalFlavourState[i_finalflav][im]; 
} 
} 
return; 
} 
conv::NuMassHierarchy_t NuOscSterile::GetMassHierarchy(void) const { 
return fMassHierarchy; 
} 
namespace valor { 
namespace util { 
ostream & operator << (ostream & stream, const OscParams & oscparams) { 
oscparams.Print(stream); 
oscparams.Print_Toys(stream); 
return stream; 
} 
} 
} 
valor::util::OscParams * valor::util::OscParams::fInstance = 0; 
valor::util::OscParams::OscParams() { 
fInstance = 0; 
this->Init(); 
} 
valor::util::OscParams::~OscParams() { 
fInstance = 0; 
this->Cleanup(); 
} 
valor::util::OscParams * valor::util::OscParams::Instance() { 
if(fInstance == 0) { 
static valor::util::OscParams::Cleaner cleaner; 
cleaner.DummyMethodAndSilentCompiler(); 
fInstance = new OscParams; 
} 
return fInstance; 
} 
void valor::util::OscParams::Init() { 
mixmode_mixing12 = ""; 
mixmode_mixing13 = ""; 
mixmode_mixing23 = ""; 
priormode_mixing12 = ""; 
priormode_mixing13 = ""; 
priormode_mixing23 = ""; 
priormode_dcp = ""; 
priormode_dm12sq = ""; 
priormode_dm23sq = ""; 
for(int i=0;i<2;i++){ 
params_mixing12[i] = conv::kBadResult; 
params_mixing13[i] = conv::kBadResult; 
params_mixing23[i] = conv::kBadResult; 
params_dcp[i] = conv::kBadResult; 
params_dm12sq[i] = conv::kBadResult; 
params_dm23sq[i] = conv::kBadResult; 
} 
hPrior_th13_dcp_nh = 0; 
hPrior_th13_dcp_ih = 0; 
hPrior_23_nh = 0; 
hPrior_23_ih = 0; 
hToyHisto_dcp_nh = new TH1D("hToyHisto_dcp_nh","hToyHisto_dcp_nh",100,-3.5,+3.5); 
hToyHisto_Mix13_nh = new TH1D("hToyHisto_Mix13_nh","hToyHisto_Mix13_nh",100,0.,0.20); 
hToyHisto_Mix23_nh = new TH1D("hToyHisto_Mix23_nh","hToyHisto_Mix23_nh",100,0.2,0.8); 
hToyHisto_Dm23_nh = new TH1D("hToyHisto_Dm23_nh","hToyHisto_Dm23_nh",100,1.5E-3,3.5E-3); 
hToyHisto_Mix12_nh = new TH1D("hToyHisto_Mix12_nh","hToyHisto_Mix12_nh",100,0.2,0.4); 
hToyHisto_Dm12_nh = new TH1D("hToyHisto_Dm12_nh","hToyHisto_Dm12_nh",100,6.E-5,9.E-5); 
hToyHisto_dcp_ih = new TH1D("hToyHisto_dcp_ih","hToyHisto_dcp_ih",100,-3.5,+3.5); 
hToyHisto_Mix13_ih = new TH1D("hToyHisto_Mix13_ih","hToyHisto_Mix13_ih",100,0.,0.20); 
hToyHisto_Mix23_ih = new TH1D("hToyHisto_Mix23_ih","hToyHisto_Mix23_ih",100,0.2,0.8); 
hToyHisto_Dm23_ih = new TH1D("hToyHisto_Dm23_ih","hToyHisto_Dm23_ih",100,1.5E-3,3.5E-3); 
hToyHisto_Mix12_ih = new TH1D("hToyHisto_Mix12_ih","hToyHisto_Mix12_ih",100,0.2,0.4); 
hToyHisto_Dm12_ih = new TH1D("hToyHisto_Dm12_ih","hToyHisto_Dm12_ih",100,6.E-5,9.E-5); 
hToyHisto_dcpBar_nh = new TH1D("hToyHisto_dcpBar_nh","hToyHisto_dcpBar_nh",100,-3.5,+3.5); 
hToyHisto_Mix13Bar_nh = new TH1D("hToyHisto_Mix13Bar_nh","hToyHisto_Mix13Bar_nh",100,0.,0.20); 
hToyHisto_Mix23Bar_nh = new TH1D("hToyHisto_Mix23Bar_nh","hToyHisto_Mix23Bar_nh",100,0.2,0.8); 
hToyHisto_Dm23Bar_nh = new TH1D("hToyHisto_Dm23Bar_nh","hToyHisto_Dm23Bar_nh",100,1.5E-3,3.5E-3); 
hToyHisto_Mix12Bar_nh = new TH1D("hToyHisto_Mix12Bar_nh","hToyHisto_Mix12Bar_nh",100,0.2,0.4); 
hToyHisto_Dm12Bar_nh = new TH1D("hToyHisto_Dm12Bar_nh","hToyHisto_Dm12Bar_nh",100,6.E-5,9.E-5); 
hToyHisto_dcpBar_ih = new TH1D("hToyHisto_dcpBar_ih","hToyHisto_dcpBar_ih",100,-3.5,+3.5); 
hToyHisto_Mix13Bar_ih = new TH1D("hToyHisto_Mix13Bar_ih","hToyHisto_Mix13Bar_ih",100,0.,0.20); 
hToyHisto_Mix23Bar_ih = new TH1D("hToyHisto_Mix23Bar_ih","hToyHisto_Mix23Bar_ih",100,0.2,0.8); 
hToyHisto_Dm23Bar_ih = new TH1D("hToyHisto_Dm23Bar_ih","hToyHisto_Dm23Bar_ih",100,1.5E-3,3.5E-3); 
hToyHisto_Mix12Bar_ih = new TH1D("hToyHisto_Mix12Bar_ih","hToyHisto_Mix12Bar_ih",100,0.2,0.4); 
hToyHisto_Dm12Bar_ih = new TH1D("hToyHisto_Dm12Bar_ih","hToyHisto_Dm12Bar_ih",100,6.E-5,9.E-5); 
hToyHisto_MH = new TH1D("hToyHisto_MH","hToyHisto_MH",2,0,2); 
mixing12_nh = conv::kBadResult; 
mixing13_nh = conv::kBadResult; 
mixing23_nh = conv::kBadResult; 
dcp_nh = conv::kBadResult; 
dm12sq_nh = conv::kBadResult; 
dm23sq_nh = conv::kBadResult; 
mixing12_ih = conv::kBadResult; 
mixing13_ih = conv::kBadResult; 
mixing23_ih = conv::kBadResult; 
dcp_ih = conv::kBadResult; 
dm12sq_ih = conv::kBadResult; 
dm23sq_ih = conv::kBadResult; 
mixing12bar_nh = conv::kBadResult; 
mixing13bar_nh = conv::kBadResult; 
mixing23bar_nh = conv::kBadResult; 
dcpbar_nh = conv::kBadResult; 
dm12sqbar_nh = conv::kBadResult; 
dm23sqbar_nh = conv::kBadResult; 
mixing12bar_ih = conv::kBadResult; 
mixing13bar_ih = conv::kBadResult; 
mixing23bar_ih = conv::kBadResult; 
dcpbar_ih = conv::kBadResult; 
dm12sqbar_ih = conv::kBadResult; 
dm23sqbar_ih = conv::kBadResult; 
beta_bar = conv::kBadResult; 
} 
void valor::util::OscParams::Cleanup() { 
mixmode_mixing12 = ""; 
mixmode_mixing13 = ""; 
mixmode_mixing23 = ""; 
priormode_mixing12 = ""; 
priormode_mixing13 = ""; 
priormode_mixing23 = ""; 
priormode_dcp = ""; 
priormode_dm12sq = ""; 
priormode_dm23sq = ""; 
for(int i=0;i<2;i++){ 
params_mixing12[i] = conv::kBadResult; 
params_mixing13[i] = conv::kBadResult; 
params_mixing23[i] = conv::kBadResult; 
params_dcp[i] = conv::kBadResult; 
params_dm12sq[i] = conv::kBadResult; 
params_dm23sq[i] = conv::kBadResult; 
} 
if(hPrior_th13_dcp_nh) delete hPrior_th13_dcp_nh; 
if(hPrior_th13_dcp_ih) delete hPrior_th13_dcp_ih; 
if(hPrior_23_nh) delete hPrior_23_nh; 
if(hPrior_23_ih) delete hPrior_23_ih; 
if(hToyHisto_dcp_nh) delete hToyHisto_dcp_nh; 
if(hToyHisto_Mix13_nh) delete hToyHisto_Mix13_nh; 
if(hToyHisto_Mix23_nh) delete hToyHisto_Mix23_nh; 
if(hToyHisto_Dm23_nh) delete hToyHisto_Dm23_nh; 
if(hToyHisto_Mix12_nh) delete hToyHisto_Mix12_nh; 
if(hToyHisto_Dm12_nh) delete hToyHisto_Dm12_nh; 
if(hToyHisto_dcp_ih) delete hToyHisto_dcp_ih; 
if(hToyHisto_Mix13_ih) delete hToyHisto_Mix13_ih; 
if(hToyHisto_Mix23_ih) delete hToyHisto_Mix23_ih; 
if(hToyHisto_Dm23_ih) delete hToyHisto_Dm23_ih; 
if(hToyHisto_Mix12_ih) delete hToyHisto_Mix12_ih; 
if(hToyHisto_Dm12_ih) delete hToyHisto_Dm12_ih; 
if(hToyHisto_MH) delete hToyHisto_MH; 
if(hToyHisto_dcpBar_nh) delete hToyHisto_dcpBar_nh; 
if(hToyHisto_Mix13Bar_nh) delete hToyHisto_Mix13Bar_nh; 
if(hToyHisto_Mix23Bar_nh) delete hToyHisto_Mix23Bar_nh; 
if(hToyHisto_Dm23Bar_nh) delete hToyHisto_Dm23Bar_nh; 
if(hToyHisto_Mix12Bar_nh) delete hToyHisto_Mix12Bar_nh; 
if(hToyHisto_Dm12Bar_nh) delete hToyHisto_Dm12Bar_nh; 
if(hToyHisto_dcpBar_ih) delete hToyHisto_dcpBar_ih; 
if(hToyHisto_Mix13Bar_ih) delete hToyHisto_Mix13Bar_ih; 
if(hToyHisto_Mix23Bar_ih) delete hToyHisto_Mix23Bar_ih; 
if(hToyHisto_Dm23Bar_ih) delete hToyHisto_Dm23Bar_ih; 
if(hToyHisto_Mix12Bar_ih) delete hToyHisto_Mix12Bar_ih; 
if(hToyHisto_Dm12Bar_ih) delete hToyHisto_Dm12Bar_ih; 
mixing12_nh = conv::kBadResult; 
mixing13_nh = conv::kBadResult; 
mixing23_nh = conv::kBadResult; 
dcp_nh = conv::kBadResult; 
dm12sq_nh = conv::kBadResult; 
dm23sq_nh = conv::kBadResult; 
mixing12_ih = conv::kBadResult; 
mixing13_ih = conv::kBadResult; 
mixing23_ih = conv::kBadResult; 
dcp_ih = conv::kBadResult; 
dm12sq_ih = conv::kBadResult; 
dm23sq_ih = conv::kBadResult; 
mixing12bar_nh = conv::kBadResult; 
mixing13bar_nh = conv::kBadResult; 
mixing23bar_nh = conv::kBadResult; 
dcpbar_nh = conv::kBadResult; 
dm12sqbar_nh = conv::kBadResult; 
dm23sqbar_nh = conv::kBadResult; 
mixing12bar_ih = conv::kBadResult; 
mixing13bar_ih = conv::kBadResult; 
mixing23bar_ih = conv::kBadResult; 
dcpbar_ih = conv::kBadResult; 
dm12sqbar_ih = conv::kBadResult; 
dm23sqbar_ih = conv::kBadResult; 
beta_bar = conv::kBadResult; 
} 
void valor::util::OscParams::SetPrior(conv::PhysParamId_t physpar,string mode,double par1,double par2,string mixmode) { 
if(physpar==conv::kPhypMixing13){ 
priormode_mixing13 = mode; 
mixmode_mixing13 = mixmode; 
params_mixing13[0] = par1; 
params_mixing13[1] = par2; 
} 
else if(physpar==conv::kPhypMixing23){ 
priormode_mixing23 = mode; 
mixmode_mixing23 = mixmode; 
params_mixing23[0] = par1; 
params_mixing23[1] = par2; 
} 
else if(physpar==conv::kPhypMixing12){ 
priormode_mixing12 = mode; 
mixmode_mixing12 = mixmode; 
params_mixing12[0] = par1; 
params_mixing12[1] = par2; 
} 
else if(physpar==conv::kPhypCPV){ 
priormode_dcp = mode; 
params_dcp[0] = par1; 
params_dcp[1] = par2; 
} 
else if(physpar==conv::kPhypDm23sq){ 
priormode_dm23sq = mode; 
params_dm23sq[0] = par1; 
params_dm23sq[1] = par2; 
} 
else if(physpar==conv::kPhypDm12sq){ 
priormode_dm12sq = mode; 
params_dm12sq[0] = par1; 
params_dm12sq[1] = par2; 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
assert(1); 
assert(1); 
if(mode == "gaus"){ 
assert(1); 
} 
else if(mode == "flat"){ 
assert(1); 
} 
else if(mode == "user"){ 
assert(1); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(IsMixingAngle(physpar)){ 
if( Opt::Instance()->gOscMixingParamChoice == kNuMixSinsqTheta){ 
if(mixmode == "sinsq2th"){ 
assert(1); 
} 
} 
else if( Opt::Instance()->gOscMixingParamChoice == kNuMixSinsq2Theta){ 
if(mixmode == "sinsqth"){ 
assert(1); 
} 
} 
if(mixmode != "sinsq2th" && mixmode != "sinsqth"){ 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
} 
} 
void valor::util::OscParams::SetValues(double input_mixing12_nh, double input_mixing13_nh, double input_mixing23_nh, double input_dcp_nh, double input_dm12sq_nh, double input_dm23sq_nh, double input_beta_bar, double input_mixing12_ih, double input_mixing13_ih, double input_mixing23_ih, double input_dcp_ih, double input_dm12sq_ih, double input_dm23sq_ih, double input_mh_nh_prior, bool marginalize_MH, double input_mixing12bar_nh, double input_mixing13bar_nh, double input_mixing23bar_nh, double input_dcpbar_nh, double input_dm12sqbar_nh, double input_dm23sqbar_nh, double input_mixing12bar_ih, double input_mixing13bar_ih, double input_mixing23bar_ih, double input_dcpbar_ih, double input_dm12sqbar_ih, double input_dm23sqbar_ih ) { 
randomize_mixing12_nh = (TMath::Abs(input_mixing12_nh + 999) < kASmallNum); 
randomize_mixing13_nh = (TMath::Abs(input_mixing13_nh + 999) < kASmallNum); 
randomize_mixing23_nh = (TMath::Abs(input_mixing23_nh + 999) < kASmallNum); 
randomize_dcp_nh = (TMath::Abs(input_dcp_nh + 999) < kASmallNum); 
randomize_dm12sq_nh = (TMath::Abs(input_dm12sq_nh + 999) < kASmallNum); 
randomize_dm23sq_nh = (TMath::Abs(input_dm23sq_nh + 999) < kASmallNum); 
randomize_mixing12_ih = (TMath::Abs(input_mixing12_ih + 999) < kASmallNum); 
randomize_mixing13_ih = (TMath::Abs(input_mixing13_ih + 999) < kASmallNum); 
randomize_mixing23_ih = (TMath::Abs(input_mixing23_ih + 999) < kASmallNum); 
randomize_dcp_ih = (TMath::Abs(input_dcp_ih + 999) < kASmallNum); 
randomize_dm12sq_ih = (TMath::Abs(input_dm12sq_ih + 999) < kASmallNum); 
randomize_dm23sq_ih = (TMath::Abs(input_dm23sq_ih + 999) < kASmallNum); 
randomize_mixing12bar_nh = (TMath::Abs(input_mixing12bar_nh + 999) < kASmallNum); 
randomize_mixing13bar_nh = (TMath::Abs(input_mixing13bar_nh + 999) < kASmallNum); 
randomize_mixing23bar_nh = (TMath::Abs(input_mixing23bar_nh + 999) < kASmallNum); 
randomize_dcpbar_nh = (TMath::Abs(input_dcpbar_nh + 999) < kASmallNum); 
randomize_dm12sqbar_nh = (TMath::Abs(input_dm12sqbar_nh + 999) < kASmallNum); 
randomize_dm23sqbar_nh = (TMath::Abs(input_dm23sqbar_nh + 999) < kASmallNum); 
randomize_mixing12bar_ih = (TMath::Abs(input_mixing12bar_ih + 999) < kASmallNum); 
randomize_mixing13bar_ih = (TMath::Abs(input_mixing13bar_ih + 999) < kASmallNum); 
randomize_mixing23bar_ih = (TMath::Abs(input_mixing23bar_ih + 999) < kASmallNum); 
randomize_dcpbar_ih = (TMath::Abs(input_dcpbar_ih + 999) < kASmallNum); 
randomize_dm12sqbar_ih = (TMath::Abs(input_dm12sqbar_ih + 999) < kASmallNum); 
randomize_dm23sqbar_ih = (TMath::Abs(input_dm23sqbar_ih + 999) < kASmallNum); 
randomize_beta_bar = (TMath::Abs(input_beta_bar + 999) < kASmallNum); 
if(Opt::Instance()->gOscMixingParamChoice == conv::kNuMixSinsq2Theta) { 
if(randomize_mixing13_nh) input_mixing13_nh = conv::kUsed_Sinsq2Theta13; 
if(randomize_mixing23_nh) input_mixing23_nh = conv::kUsed_Sinsq2Theta23; 
if(randomize_mixing12_nh) input_mixing12_nh = conv::kUsed_Sinsq2Theta12; 
} 
else { 
if(randomize_mixing13_nh) input_mixing13_nh = conv::kUsed_SinsqTheta13; 
if(randomize_mixing23_nh) input_mixing23_nh = conv::kUsed_SinsqTheta23; 
if(randomize_mixing12_nh) input_mixing12_nh = conv::kUsed_SinsqTheta12; 
} 
if(randomize_dm23sq_nh) input_dm23sq_nh = conv::kUsed_Dm23sq; 
if(randomize_dm12sq_nh) input_dm12sq_nh = conv::kUsed_Dm12sq; 
if(randomize_dcp_nh) input_dcp_nh = conv::kUsed_DeltaCP; 
if(Opt::Instance()->gOscMixingParamChoice == conv::kNuMixSinsq2Theta) { 
if(randomize_mixing13_ih) input_mixing13_ih = conv::kUsed_Sinsq2Theta13; 
if(randomize_mixing23_ih) input_mixing23_ih = conv::kUsed_Sinsq2Theta23; 
if(randomize_mixing12_ih) input_mixing12_ih = conv::kUsed_Sinsq2Theta12; 
} 
else { 
if(randomize_mixing13_ih) input_mixing13_ih = conv::kUsed_SinsqTheta13; 
if(randomize_mixing23_ih) input_mixing23_ih = conv::kUsed_SinsqTheta23; 
if(randomize_mixing12_ih) input_mixing12_ih = conv::kUsed_SinsqTheta12; 
} 
if(randomize_dm23sq_ih) input_dm23sq_ih = conv::kUsed_Dm23sq; 
if(randomize_dm12sq_ih) input_dm12sq_ih = conv::kUsed_Dm12sq; 
if(randomize_dcp_ih) input_dcp_ih = conv::kUsed_DeltaCP; 
if(Opt::Instance()->gOscMixingParamChoice == conv::kNuMixSinsq2Theta) { 
if(randomize_mixing13bar_nh) input_mixing13bar_nh = conv::kUsed_Sinsq2Theta13; 
if(randomize_mixing23bar_nh) input_mixing23bar_nh = conv::kUsed_Sinsq2Theta23; 
if(randomize_mixing12bar_nh) input_mixing12bar_nh = conv::kUsed_Sinsq2Theta12; 
} 
else { 
if(randomize_mixing13bar_nh) input_mixing13bar_nh = conv::kUsed_SinsqTheta13; 
if(randomize_mixing23bar_nh) input_mixing23bar_nh = conv::kUsed_SinsqTheta23; 
if(randomize_mixing12bar_nh) input_mixing12bar_nh = conv::kUsed_SinsqTheta12; 
} 
if(randomize_dm23sqbar_nh) input_dm23sqbar_nh = conv::kUsed_Dm23sq; 
if(randomize_dm12sqbar_nh) input_dm12sqbar_nh = conv::kUsed_Dm12sq; 
if(randomize_dcpbar_nh) input_dcpbar_nh = conv::kUsed_DeltaCP; 
if(Opt::Instance()->gOscMixingParamChoice == conv::kNuMixSinsq2Theta) { 
if(randomize_mixing13bar_ih) input_mixing13bar_ih = conv::kUsed_Sinsq2Theta13; 
if(randomize_mixing23bar_ih) input_mixing23bar_ih = conv::kUsed_Sinsq2Theta23; 
if(randomize_mixing12bar_ih) input_mixing12bar_ih = conv::kUsed_Sinsq2Theta12; 
} 
else { 
if(randomize_mixing13bar_ih) input_mixing13bar_ih = conv::kUsed_SinsqTheta13; 
if(randomize_mixing23bar_ih) input_mixing23bar_ih = conv::kUsed_SinsqTheta23; 
if(randomize_mixing12bar_ih) input_mixing12bar_ih = conv::kUsed_SinsqTheta12; 
} 
if(randomize_dm23sqbar_ih) input_dm23sqbar_ih = conv::kUsed_Dm23sq; 
if(randomize_dm12sqbar_ih) input_dm12sqbar_ih = conv::kUsed_Dm12sq; 
if(randomize_dcpbar_ih) input_dcpbar_ih = conv::kUsed_DeltaCP; 
if(randomize_beta_bar) input_beta_bar = conv::kUsed_BetaBar; 
if(Opt::Instance()->gOscMixingParamChoice == conv::kNuMixSinsq2Theta) { 
if(input_mixing13_nh < -1 && input_mixing13_nh > -900) input_mixing13_nh = conv::kUsed_Sinsq2Theta13; 
if(input_mixing23_nh < -1 && input_mixing23_nh > -900) input_mixing23_nh = conv::kUsed_Sinsq2Theta23; 
if(input_mixing12_nh < -1 && input_mixing12_nh > -900) input_mixing12_nh = conv::kUsed_Sinsq2Theta12; 
} 
else { 
if(input_mixing13_nh < -1 && input_mixing13_nh > -900) input_mixing13_nh = conv::kUsed_SinsqTheta13; 
if(input_mixing23_nh < -1 && input_mixing23_nh > -900) input_mixing23_nh = conv::kUsed_SinsqTheta23; 
if(input_mixing12_nh < -1 && input_mixing12_nh > -900) input_mixing12_nh = conv::kUsed_SinsqTheta12; 
} 
if(input_dm23sq_nh < -1 && input_dm23sq_nh > -900) input_dm23sq_nh = conv::kUsed_Dm23sq; 
if(input_dm12sq_nh < -1 && input_dm12sq_nh > -900) input_dm12sq_nh = conv::kUsed_Dm12sq; 
if(input_dcp_nh < -90 && input_dcp_nh > -900) input_dcp_nh = conv::kUsed_DeltaCP; 
if(Opt::Instance()->gOscMixingParamChoice == conv::kNuMixSinsq2Theta) { 
if(input_mixing13_ih < -1 && input_mixing13_ih > -900) input_mixing13_ih = conv::kUsed_Sinsq2Theta13; 
if(input_mixing23_ih < -1 && input_mixing23_ih > -900) input_mixing23_ih = conv::kUsed_Sinsq2Theta23; 
if(input_mixing12_ih < -1 && input_mixing12_ih > -900) input_mixing12_ih = conv::kUsed_Sinsq2Theta12; 
} 
else { 
if(input_mixing13_ih < -1 && input_mixing13_ih > -900) input_mixing13_ih = conv::kUsed_SinsqTheta13; 
if(input_mixing23_ih < -1 && input_mixing23_ih > -900) input_mixing23_ih = conv::kUsed_SinsqTheta23; 
if(input_mixing12_ih < -1 && input_mixing12_ih > -900) input_mixing12_ih = conv::kUsed_SinsqTheta12; 
} 
if(input_dm23sq_ih < -1 && input_dm23sq_ih > -900) input_dm23sq_ih = conv::kUsed_Dm23sq; 
if(input_dm12sq_ih < -1 && input_dm12sq_ih > -900) input_dm12sq_ih = conv::kUsed_Dm12sq; 
if(input_dcp_ih < -90 && input_dcp_ih > -900) input_dcp_ih = conv::kUsed_DeltaCP; 
if(input_beta_bar < -90 && input_beta_bar > -900) input_beta_bar = conv::kUsed_BetaBar; 
if(Opt::Instance()->gOscMixingParamChoice == conv::kNuMixSinsq2Theta) { 
if(input_mixing13bar_nh < -1 && input_mixing13bar_nh > -900) input_mixing13bar_nh = conv::kUsed_Sinsq2Theta13; 
if(input_mixing23bar_nh < -1 && input_mixing23bar_nh > -900) input_mixing23bar_nh = conv::kUsed_Sinsq2Theta23; 
if(input_mixing12bar_nh < -1 && input_mixing12bar_nh > -900) input_mixing12bar_nh = conv::kUsed_Sinsq2Theta12; 
} 
else { 
if(input_mixing13bar_nh < -1 && input_mixing13bar_nh > -900) input_mixing13bar_nh = conv::kUsed_SinsqTheta13; 
if(input_mixing23bar_nh < -1 && input_mixing23bar_nh > -900) input_mixing23bar_nh = conv::kUsed_SinsqTheta23; 
if(input_mixing12bar_nh < -1 && input_mixing12bar_nh > -900) input_mixing12bar_nh = conv::kUsed_SinsqTheta12; 
} 
if(input_dm23sqbar_nh < -1 && input_dm23sqbar_nh > -900) input_dm23sqbar_nh = conv::kUsed_Dm23sq; 
if(input_dm12sqbar_nh < -1 && input_dm12sqbar_nh > -900) input_dm12sqbar_nh = conv::kUsed_Dm12sq; 
if(input_dcpbar_nh < -90 && input_dcpbar_nh > -900) input_dcpbar_nh = conv::kUsed_DeltaCP; 
if(Opt::Instance()->gOscMixingParamChoice == conv::kNuMixSinsq2Theta) { 
if(input_mixing13bar_ih < -1 && input_mixing13bar_ih > -900) input_mixing13bar_ih = conv::kUsed_Sinsq2Theta13; 
if(input_mixing23bar_ih < -1 && input_mixing23bar_ih > -900) input_mixing23bar_ih = conv::kUsed_Sinsq2Theta23; 
if(input_mixing12bar_ih < -1 && input_mixing12bar_ih > -900) input_mixing12bar_ih = conv::kUsed_Sinsq2Theta12; 
} 
else { 
if(input_mixing13bar_ih < -1 && input_mixing13bar_ih > -900) input_mixing13bar_ih = conv::kUsed_SinsqTheta13; 
if(input_mixing23bar_ih < -1 && input_mixing23bar_ih > -900) input_mixing23bar_ih = conv::kUsed_SinsqTheta23; 
if(input_mixing12bar_ih < -1 && input_mixing12bar_ih > -900) input_mixing12bar_ih = conv::kUsed_SinsqTheta12; 
} 
if(input_dm23sqbar_ih < -1 && input_dm23sqbar_ih > -900) input_dm23sqbar_ih = conv::kUsed_Dm23sq; 
if(input_dm12sqbar_ih < -1 && input_dm12sqbar_ih > -900) input_dm12sqbar_ih = conv::kUsed_Dm12sq; 
if(input_dcpbar_ih < -90 && input_dcpbar_ih > -900) input_dcpbar_ih = conv::kUsed_DeltaCP; 
if(input_mh_nh_prior < -1 && input_mh_nh_prior > -900) input_mh_nh_prior = conv::kPrior_MH; 
mixing12_nh = input_mixing12_nh; 
mixing13_nh = input_mixing13_nh; 
mixing23_nh = input_mixing23_nh; 
dcp_nh = input_dcp_nh; 
dm12sq_nh = input_dm12sq_nh; 
dm23sq_nh = input_dm23sq_nh; 
mixing12_ih = input_mixing12_ih; 
mixing13_ih = input_mixing13_ih; 
mixing23_ih = input_mixing23_ih; 
dcp_ih = input_dcp_ih; 
dm12sq_ih = input_dm12sq_ih; 
dm23sq_ih = input_dm23sq_ih; 
mixing12bar_nh = input_mixing12bar_nh; 
mixing13bar_nh = input_mixing13bar_nh; 
mixing23bar_nh = input_mixing23bar_nh; 
dcpbar_nh = input_dcpbar_nh; 
dm12sqbar_nh = input_dm12sqbar_nh; 
dm23sqbar_nh = input_dm23sqbar_nh; 
mixing12bar_ih = input_mixing12bar_ih; 
mixing13bar_ih = input_mixing13bar_ih; 
mixing23bar_ih = input_mixing23bar_ih; 
dcpbar_ih = input_dcpbar_ih; 
dm12sqbar_ih = input_dm12sqbar_ih; 
dm23sqbar_ih = input_dm23sqbar_ih; 
beta_bar = input_beta_bar; 
marginalize_mh = marginalize_MH; 
mh_nh_prior = input_mh_nh_prior; 
MH = Opt::Instance()->gMassHierarchyAssumed; 
iMH = (MH == kNmhNormal) ? 0 : 1; 
} 
void valor::util::OscParams::Randomize() { 

#ifdef __print_toys__ 
assert(1); 
assert(1); 
#endif 
if(marginalize_mh){ 
const double min = 0.; 
const double max = 1.; 
double Pnh = mh_nh_prior; 
double Pih = 1 - Pnh; 
if(Pnh < 0. || Pnh > 1.){ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(Pih < 0. || Pih > 1.){ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
double rndm = Rnd::Instance()->RndToyMCosc().Uniform(min,max); 
iMH = conv::kBadResult; 
if(rndm <= Pnh) iMH = 0; 
else iMH = 1; 
if( iMH==0 ){ 
Opt::Instance()->gMassHierarchyAssumed = util::HierarchyFromString("normal"); 
} 
else if( iMH==1 ){ 
Opt::Instance()->gMassHierarchyAssumed = util::HierarchyFromString("inverted"); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
} 
double par1 = conv::kBadResult; 
double par2 = conv::kBadResult; 
string mixmode = ""; 
string priormode = ""; 
if(iMH==0){ 
par1 = params_mixing23[0]; 
par2 = params_mixing23[1]; 
priormode = priormode_mixing23; 
mixmode = mixmode_mixing23; 
if(randomize_mixing23_nh){ 
mixing23_nh = this->ExtractParam(conv::kPhypMixing23,priormode,par1,par2,mixmode); 
} 
par1 = params_mixing13[0]; 
par2 = params_mixing13[1]; 
priormode = priormode_mixing13; 
mixmode = mixmode_mixing13; 
if(randomize_mixing13_nh){ 
mixing13_nh = this->ExtractParam(conv::kPhypMixing13,priormode,par1,par2,mixmode); 
} 
par1 = params_dcp[0]; 
par2 = params_dcp[1]; 
priormode = priormode_dcp; 
mixmode = ""; 
if(randomize_dcp_nh){ 
dcp_nh = this->ExtractParam(conv::kPhypCPV,priormode,par1,par2,mixmode); 
} 
par1 = params_dm23sq[0]; 
par2 = params_dm23sq[1]; 
priormode = priormode_dm23sq; 
mixmode = ""; 
if(randomize_dm23sq_nh){ 
dm23sq_nh = this->ExtractParam(conv::kPhypDm23sq,priormode,par1,par2,mixmode); 
} 
par1 = params_dm12sq[0]; 
par2 = params_dm12sq[1]; 
priormode = priormode_dm12sq; 
mixmode = ""; 
if(randomize_dm12sq_nh){ 
dm12sq_nh = this->ExtractParam(conv::kPhypDm12sq,priormode,par1,par2,mixmode); 
} 
par1 = params_mixing12[0]; 
par2 = params_mixing12[1]; 
priormode = priormode_mixing12; 
mixmode = mixmode_mixing12; 
if(randomize_mixing12_nh){ 
mixing12_nh = this->ExtractParam(conv::kPhypMixing12,priormode,par1,par2,mixmode); 
} 
par1 = params_mixing23[0]; 
par2 = params_mixing23[1]; 
priormode = priormode_mixing23; 
mixmode = mixmode_mixing23; 
if(randomize_mixing23bar_nh){ 
mixing23bar_nh = this->ExtractParam(conv::kPhypMixing23Bar,priormode,par1,par2,mixmode); 
} 
par1 = params_mixing13[0]; 
par2 = params_mixing13[1]; 
priormode = priormode_mixing13; 
mixmode = mixmode_mixing13; 
if(randomize_mixing13bar_nh){ 
mixing13bar_nh = this->ExtractParam(conv::kPhypMixing13Bar,priormode,par1,par2,mixmode); 
} 
par1 = params_dcp[0]; 
par2 = params_dcp[1]; 
priormode = priormode_dcp; 
mixmode = ""; 
if(randomize_dcpbar_nh){ 
dcpbar_nh = this->ExtractParam(conv::kPhypCPVBar,priormode,par1,par2,mixmode); 
} 
par1 = params_dm23sq[0]; 
par2 = params_dm23sq[1]; 
priormode = priormode_dm23sq; 
mixmode = ""; 
if(randomize_dm23sqbar_nh){ 
dm23sqbar_nh = this->ExtractParam(conv::kPhypDm23sqBar,priormode,par1,par2,mixmode); 
} 
par1 = params_dm12sq[0]; 
par2 = params_dm12sq[1]; 
priormode = priormode_dm12sq; 
mixmode = ""; 
if(randomize_dm12sqbar_nh){ 
dm12sqbar_nh = this->ExtractParam(conv::kPhypDm12sqBar,priormode,par1,par2,mixmode); 
} 
par1 = params_mixing12[0]; 
par2 = params_mixing12[1]; 
priormode = priormode_mixing12; 
mixmode = mixmode_mixing12; 
if(randomize_mixing12bar_nh){ 
mixing12bar_nh = this->ExtractParam(conv::kPhypMixing12Bar,priormode,par1,par2,mixmode); 
} 
} 
else if(iMH==1){ 
par1 = params_mixing23[0]; 
par2 = params_mixing23[1]; 
priormode = priormode_mixing23; 
mixmode = mixmode_mixing23; 
if(randomize_mixing23_ih){ 
mixing23_ih = this->ExtractParam(conv::kPhypMixing23,priormode,par1,par2,mixmode); 
} 
par1 = params_mixing13[0]; 
par2 = params_mixing13[1]; 
priormode = priormode_mixing13; 
mixmode = mixmode_mixing13; 
if(randomize_mixing13_ih){ 
mixing13_ih = this->ExtractParam(conv::kPhypMixing13,priormode,par1,par2,mixmode); 
} 
par1 = params_dcp[0]; 
par2 = params_dcp[1]; 
priormode = priormode_dcp; 
mixmode = ""; 
if(randomize_dcp_ih){ 
dcp_ih = this->ExtractParam(conv::kPhypCPV,priormode,par1,par2,mixmode); 
} 
par1 = params_dm23sq[0]; 
par2 = params_dm23sq[1]; 
priormode = priormode_dm23sq; 
mixmode = ""; 
if(randomize_dm23sq_ih){ 
dm23sq_ih = this->ExtractParam(conv::kPhypDm23sq,priormode,par1,par2,mixmode); 
} 
par1 = params_dm12sq[0]; 
par2 = params_dm12sq[1]; 
priormode = priormode_dm12sq; 
mixmode = ""; 
if(randomize_dm12sq_ih){ 
dm12sq_ih = this->ExtractParam(conv::kPhypDm12sq,priormode,par1,par2,mixmode); 
} 
par1 = params_mixing12[0]; 
par2 = params_mixing12[1]; 
priormode = priormode_mixing12; 
mixmode = mixmode_mixing12; 
if(randomize_mixing12_ih){ 
mixing12_ih = this->ExtractParam(conv::kPhypMixing12,priormode,par1,par2,mixmode); 
} 
par1 = params_mixing23[0]; 
par2 = params_mixing23[1]; 
priormode = priormode_mixing23; 
mixmode = mixmode_mixing23; 
if(randomize_mixing23bar_ih){ 
mixing23bar_ih = this->ExtractParam(conv::kPhypMixing23Bar,priormode,par1,par2,mixmode); 
} 
par1 = params_mixing13[0]; 
par2 = params_mixing13[1]; 
priormode = priormode_mixing13; 
mixmode = mixmode_mixing13; 
if(randomize_mixing13bar_ih){ 
mixing13bar_ih = this->ExtractParam(conv::kPhypMixing13Bar,priormode,par1,par2,mixmode); 
} 
par1 = params_dcp[0]; 
par2 = params_dcp[1]; 
priormode = priormode_dcp; 
mixmode = ""; 
if(randomize_dcpbar_ih){ 
dcpbar_ih = this->ExtractParam(conv::kPhypCPVBar,priormode,par1,par2,mixmode); 
} 
par1 = params_dm23sq[0]; 
par2 = params_dm23sq[1]; 
priormode = priormode_dm23sq; 
mixmode = ""; 
if(randomize_dm23sqbar_ih){ 
dm23sqbar_ih = this->ExtractParam(conv::kPhypDm23sqBar,priormode,par1,par2,mixmode); 
} 
par1 = params_dm12sq[0]; 
par2 = params_dm12sq[1]; 
priormode = priormode_dm12sq; 
mixmode = ""; 
if(randomize_dm12sqbar_ih){ 
dm12sqbar_ih = this->ExtractParam(conv::kPhypDm12sqBar,priormode,par1,par2,mixmode); 
} 
par1 = params_mixing12[0]; 
par2 = params_mixing12[1]; 
priormode = priormode_mixing12; 
mixmode = mixmode_mixing12; 
if(randomize_mixing12bar_ih){ 
mixing12bar_ih = this->ExtractParam(conv::kPhypMixing12Bar,priormode,par1,par2,mixmode); 
} 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
#ifdef __print_toys__ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
#endif 
} 
void valor::util::OscParams::FillOscToyHisto(PhysHypothesis &ph) { 
double mix12 = conv::kBadResult; 
double mix13 = conv::kBadResult; 
double mix23 = conv::kBadResult; 
double dm12 = conv::kBadResult; 
double dm23 = conv::kBadResult; 
double dcp = conv::kBadResult; 
double mix12bar = conv::kBadResult; 
double mix13bar = conv::kBadResult; 
double mix23bar = conv::kBadResult; 
double dm12bar = conv::kBadResult; 
double dm23bar = conv::kBadResult; 
double dcpbar = conv::kBadResult; 
if(ph.Contains(kPhypMixing12)) mix12 = ph.CurrValue(kPhypMixing12); 
if(ph.Contains(kPhypMixing13)) mix13 = ph.CurrValue(kPhypMixing13); 
if(ph.Contains(kPhypMixing23)) mix23 = ph.CurrValue(kPhypMixing23); 
if(ph.Contains(kPhypDm12sq)) dm12 = ph.CurrValue(kPhypDm12sq); 
if(ph.Contains(kPhypDm23sq)) dm23 = ph.CurrValue(kPhypDm23sq); 
if(ph.Contains(kPhypCPV)) dcp = ph.CurrValue(kPhypCPV); 
if(ph.Contains(kPhypMixing12Bar)) mix12bar = ph.CurrValue(kPhypMixing12Bar); 
if(ph.Contains(kPhypMixing13Bar)) mix13bar = ph.CurrValue(kPhypMixing13Bar); 
if(ph.Contains(kPhypMixing23Bar)) mix23bar = ph.CurrValue(kPhypMixing23Bar); 
if(ph.Contains(kPhypDm12sqBar)) dm12bar = ph.CurrValue(kPhypDm12sqBar); 
if(ph.Contains(kPhypDm23sqBar)) dm23bar = ph.CurrValue(kPhypDm23sqBar); 
if(ph.Contains(kPhypCPVBar)) dcpbar = ph.CurrValue(kPhypCPVBar); 
int mh = Opt::Instance()->gMassHierarchyAssumed; 
if(mh==conv::kNmhNormal){ 
hToyHisto_Mix12_nh->Fill(mix12); 
hToyHisto_Mix13_nh->Fill(mix13); 
hToyHisto_Mix23_nh->Fill(mix23); 
hToyHisto_Dm12_nh->Fill(dm12); 
hToyHisto_Dm23_nh->Fill(dm23); 
hToyHisto_dcp_nh->Fill(dcp); 
hToyHisto_Mix12Bar_nh->Fill(mix12bar); 
hToyHisto_Mix13Bar_nh->Fill(mix13bar); 
hToyHisto_Mix23Bar_nh->Fill(mix23bar); 
hToyHisto_Dm12Bar_nh->Fill(dm12bar); 
hToyHisto_Dm23Bar_nh->Fill(dm23bar); 
hToyHisto_dcpBar_nh->Fill(dcpbar); 
} 
else if(mh==conv::kNmhInverted){ 
hToyHisto_Mix12_ih->Fill(mix12); 
hToyHisto_Mix13_ih->Fill(mix13); 
hToyHisto_Mix23_ih->Fill(mix23); 
hToyHisto_Dm12_ih->Fill(dm12); 
hToyHisto_Dm23_ih->Fill(dm23); 
hToyHisto_dcp_ih->Fill(dcp); 
hToyHisto_Mix12Bar_ih->Fill(mix12bar); 
hToyHisto_Mix13Bar_ih->Fill(mix13bar); 
hToyHisto_Mix23Bar_ih->Fill(mix23bar); 
hToyHisto_Dm12Bar_ih->Fill(dm12bar); 
hToyHisto_Dm23Bar_ih->Fill(dm23bar); 
hToyHisto_dcpBar_ih->Fill(dcpbar); 
} 
hToyHisto_MH->Fill(mh); 
} 
TH1D *valor::util::OscParams::GetToyHisto(string oscparam, string MH_str) { 
if(oscparam=="hierarchy"){ 
return hToyHisto_MH; 
} 
if(MH_str=="normal"){ 
if (oscparam=="deltaCP") return hToyHisto_dcp_nh; 
else if(oscparam=="mixing23") return hToyHisto_Mix23_nh; 
else if(oscparam=="mixing13") return hToyHisto_Mix13_nh; 
else if(oscparam=="dmsq23") return hToyHisto_Dm23_nh; 
else if(oscparam=="mixing12") return hToyHisto_Mix12_nh; 
else if(oscparam=="dmsq12") return hToyHisto_Dm12_nh; 
else if(oscparam=="deltaCPBar") return hToyHisto_dcpBar_nh; 
else if(oscparam=="mixing23Bar") return hToyHisto_Mix23Bar_nh; 
else if(oscparam=="mixing13Bar") return hToyHisto_Mix13Bar_nh; 
else if(oscparam=="dmsq23Bar") return hToyHisto_Dm23Bar_nh; 
else if(oscparam=="mixing12Bar") return hToyHisto_Mix12Bar_nh; 
else if(oscparam=="dmsq12Bar") return hToyHisto_Dm12Bar_nh; 
else { 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
} 
else if(MH_str=="inverted"){ 
if (oscparam=="deltaCP") return hToyHisto_dcp_ih; 
else if(oscparam=="mixing23") return hToyHisto_Mix23_ih; 
else if(oscparam=="mixing13") return hToyHisto_Mix13_ih; 
else if(oscparam=="dmsq23") return hToyHisto_Dm23_ih; 
else if(oscparam=="mixing12") return hToyHisto_Mix12_ih; 
else if(oscparam=="dmsq12") return hToyHisto_Dm12_ih; 
else if(oscparam=="deltaCPBar") return hToyHisto_dcpBar_ih; 
else if(oscparam=="mixing23Bar") return hToyHisto_Mix23Bar_ih; 
else if(oscparam=="mixing13Bar") return hToyHisto_Mix13Bar_ih; 
else if(oscparam=="dmsq23Bar") return hToyHisto_Dm23Bar_ih; 
else if(oscparam=="mixing12Bar") return hToyHisto_Mix12Bar_ih; 
else if(oscparam=="dmsq12Bar") return hToyHisto_Dm12Bar_ih; 
else { 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
} 
else { 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
} 
double valor::util::OscParams::ExtractParam(conv::PhysParamId_t physpar,string mode,double par1,double par2,string mixmode) { 
double valrndm = conv::kBadResult; 
if(mode=="gaus") valrndm = Rnd::Instance()->RndToyMCosc().Gaus(par1,par2); 
else if(mode=="flat"){ 
if(par1>=par2){ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
valrndm = Rnd::Instance()->RndToyMCosc().Uniform(par1,par2); 
} 
else{ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
exit(1); 
} 
if(IsMixingAngle(physpar)){ 
if(Opt::Instance()->gOscMixingParamChoice == kNuMixSinsqTheta){ 
if(mixmode == "sinsqth") return valrndm; 
else if(mixmode == "sinsq2th") return util::FromSinsq2thToSinsqth(valrndm); 
else { 
assert(1); 
 cerr << "valor::util::OscParams::ExtractParam" << endl; 
assert(1); 
assert(1); 
exit(1); 
} 
} 
else if(Opt::Instance()->gOscMixingParamChoice == kNuMixSinsq2Theta){ 
if(mixmode == "sinsqth") return util::FromSinsqthToSinsq2th(valrndm); 
else if(mixmode == "sinsq2th") return valrndm; 
else { 
assert(1); 
assert(1); 
 cerr << "mixmode is not defined: " << mixmode << endl; 
assert(1); 
exit(1); 
} 
} 
} 
return valrndm; 
} 
void valor::util::OscParams::UpdatePhysHypothesis(PhysHypothesis& ph, bool print) { 
double input_mixing12_used, input_mixing13_used, input_mixing23_used; 
double input_dcp_used, input_dm12sq_used, input_dm23sq_used; 
double input_beta_bar_used; 
double input_mixing12bar_used, input_mixing13bar_used, input_mixing23bar_used; 
double input_dcpbar_used, input_dm12sqbar_used, input_dm23sqbar_used; 
if(iMH == 0) { 
input_mixing12_used = mixing12_nh; 
input_mixing13_used = mixing13_nh; 
input_mixing23_used = mixing23_nh; 
input_dcp_used = dcp_nh; 
input_dm12sq_used = dm12sq_nh; 
input_dm23sq_used = dm23sq_nh; 
input_mixing12bar_used = mixing12bar_nh; 
input_mixing13bar_used = mixing13bar_nh; 
input_mixing23bar_used = mixing23bar_nh; 
input_dcpbar_used = dcpbar_nh; 
input_dm12sqbar_used = dm12sqbar_nh; 
input_dm23sqbar_used = dm23sqbar_nh; 
} 
else if(iMH == 1) { 
input_mixing12_used = mixing12_ih; 
input_mixing13_used = mixing13_ih; 
input_mixing23_used = mixing23_ih; 
input_dcp_used = dcp_ih; 
input_dm12sq_used = dm12sq_ih; 
input_dm23sq_used = dm23sq_ih; 
input_mixing12bar_used = mixing12bar_ih; 
input_mixing13bar_used = mixing13bar_ih; 
input_mixing23bar_used = mixing23bar_ih; 
input_dcpbar_used = dcpbar_ih; 
input_dm12sqbar_used = dm12sqbar_ih; 
input_dm23sqbar_used = dm23sqbar_ih; 
} 
else { 
assert(1); 
exit(1); 
} 
input_beta_bar_used = beta_bar; 
#ifdef __print_toys__ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
#endif 
if(ph.Hypothesis() == kHypNuMuDisapp2F) { 
ph.SetCurrValue(kPhypMixing23, input_mixing23_used); 
ph.SetCurrValue(kPhypDm23sq, input_dm23sq_used); 
} 
else if(ph.Hypothesis() == kHypOsc3F) { 
ph.SetCurrValue(kPhypMixing12, input_mixing12_used); 
ph.SetCurrValue(kPhypMixing13, input_mixing13_used); 
ph.SetCurrValue(kPhypMixing23, input_mixing23_used); 
ph.SetCurrValue(kPhypCPV , input_dcp_used); 
ph.SetCurrValue(kPhypDm12sq, input_dm12sq_used); 
ph.SetCurrValue(kPhypDm23sq, input_dm23sq_used); 
} 
else if(ph.Hypothesis() == kHypOsc3FBar) { 
ph.SetCurrValue(kPhypMixing12, input_mixing12_used); 
ph.SetCurrValue(kPhypMixing13, input_mixing13_used); 
ph.SetCurrValue(kPhypMixing23, input_mixing23_used); 
ph.SetCurrValue(kPhypCPV , input_dcp_used); 
ph.SetCurrValue(kPhypDm12sq, input_dm12sq_used); 
ph.SetCurrValue(kPhypDm23sq, input_dm23sq_used); 
ph.SetCurrValue(kPhypMixing12Bar, input_mixing12bar_used); 
ph.SetCurrValue(kPhypMixing13Bar, input_mixing13bar_used); 
ph.SetCurrValue(kPhypMixing23Bar, input_mixing23bar_used); 
ph.SetCurrValue(kPhypCPVBar , input_dcpbar_used); 
ph.SetCurrValue(kPhypDm12sqBar, input_dm12sqbar_used); 
ph.SetCurrValue(kPhypDm23sqBar, input_dm23sqbar_used); 
} 
else if(ph.Hypothesis() == kHypOsc3FBarDissap) { 
ph.SetCurrValue(kPhypMixing12, input_mixing12_used); 
ph.SetCurrValue(kPhypMixing13, input_mixing13_used); 
ph.SetCurrValue(kPhypMixing23, input_mixing23_used); 
ph.SetCurrValue(kPhypCPV , input_dcp_used); 
ph.SetCurrValue(kPhypDm12sq, input_dm12sq_used); 
ph.SetCurrValue(kPhypDm23sq, input_dm23sq_used); 
ph.SetCurrValue(kPhypMixing23Bar, input_mixing23bar_used); 
ph.SetCurrValue(kPhypDm23sqBar, input_dm23sqbar_used); 
} 
else if(ph.Hypothesis() == kHypOsc3FNormBar) { 
ph.SetCurrValue(kPhypMixing12, input_mixing12_used); 
ph.SetCurrValue(kPhypMixing13, input_mixing13_used); 
ph.SetCurrValue(kPhypMixing23, input_mixing23_used); 
ph.SetCurrValue(kPhypCPV , input_dcp_used); 
ph.SetCurrValue(kPhypDm12sq, input_dm12sq_used); 
ph.SetCurrValue(kPhypDm23sq, input_dm23sq_used); 
ph.SetCurrValue(kPhypBetaBar, input_beta_bar_used); 
} 
else if(ph.Hypothesis() == kHypOsc3FBarNormBar) { 
ph.SetCurrValue(kPhypMixing12, input_mixing12_used); 
ph.SetCurrValue(kPhypMixing13, input_mixing13_used); 
ph.SetCurrValue(kPhypMixing23, input_mixing23_used); 
ph.SetCurrValue(kPhypCPV , input_dcp_used); 
ph.SetCurrValue(kPhypDm12sq, input_dm12sq_used); 
ph.SetCurrValue(kPhypDm23sq, input_dm23sq_used); 
ph.SetCurrValue(kPhypMixing12Bar, input_mixing12_used); 
ph.SetCurrValue(kPhypMixing13Bar, input_mixing13_used); 
ph.SetCurrValue(kPhypMixing23Bar, input_mixing23_used); 
ph.SetCurrValue(kPhypCPVBar , input_dcp_used); 
ph.SetCurrValue(kPhypDm12sqBar, input_dm12sq_used); 
ph.SetCurrValue(kPhypDm23sqBar, input_dm23sq_used); 
ph.SetCurrValue(kPhypBetaBar, input_beta_bar_used); 
} 
else { 
assert(1); 
exit(1); 
} 
if(print) cout << "- Physics hypothesis set: " << ph << endl; 
} 
void valor::util::OscParams::UpdateFitParamList(FitParamList* fparm, bool set_init, bool print) { 
double input_mixing12_used, input_mixing13_used, input_mixing23_used; 
double input_dcp_used, input_dm12sq_used, input_dm23sq_used; 
double input_beta_bar_used; 
double input_mixing12bar_used, input_mixing13bar_used, input_mixing23bar_used; 
double input_dcpbar_used, input_dm12sqbar_used, input_dm23sqbar_used; 
if(iMH == 0) { 
input_mixing12_used = mixing12_nh; 
input_mixing13_used = mixing13_nh; 
input_mixing23_used = mixing23_nh; 
input_dcp_used = dcp_nh; 
input_dm12sq_used = dm12sq_nh; 
input_dm23sq_used = dm23sq_nh; 
input_mixing12bar_used = mixing12bar_nh; 
input_mixing13bar_used = mixing13bar_nh; 
input_mixing23bar_used = mixing23bar_nh; 
input_dcpbar_used = dcpbar_nh; 
input_dm12sqbar_used = dm12sqbar_nh; 
input_dm23sqbar_used = dm23sqbar_nh; 
} 
else if(iMH == 1) { 
input_mixing12_used = mixing12_ih; 
input_mixing13_used = mixing13_ih; 
input_mixing23_used = mixing23_ih; 
input_dcp_used = dcp_ih; 
input_dm12sq_used = dm12sq_ih; 
input_dm23sq_used = dm23sq_ih; 
input_mixing12bar_used = mixing12bar_ih; 
input_mixing13bar_used = mixing13bar_ih; 
input_mixing23bar_used = mixing23bar_ih; 
input_dcpbar_used = dcpbar_ih; 
input_dm12sqbar_used = dm12sqbar_ih; 
input_dm23sqbar_used = dm23sqbar_ih; 
} 
else { 
assert(1); 
exit(1); 
} 
input_beta_bar_used = beta_bar; 
if(fparm->PhysicsHypothesis() == kHypNuMuDisapp2F) { 
if(set_init) { 
fparm->SetInitValue(kPhypMixing23, input_mixing23_used); 
fparm->SetInitValue(kPhypDm23sq, input_dm23sq_used); 
} 
else { 
fparm->SetCurrentValue(kPhypMixing23, input_mixing23_used); 
fparm->SetCurrentValue(kPhypDm23sq, input_dm23sq_used); 
} 
} 
else if(fparm->PhysicsHypothesis() == kHypOsc3F) { 
if(set_init) { 
fparm->SetInitValue(kPhypMixing12, input_mixing12_used); 
fparm->SetInitValue(kPhypMixing13, input_mixing13_used); 
fparm->SetInitValue(kPhypMixing23, input_mixing23_used); 
fparm->SetInitValue(kPhypCPV , input_dcp_used); 
fparm->SetInitValue(kPhypDm12sq, input_dm12sq_used); 
fparm->SetInitValue(kPhypDm23sq, input_dm23sq_used); 
} 
else { 
fparm->SetCurrentValue(kPhypMixing12, input_mixing12_used); 
fparm->SetCurrentValue(kPhypMixing13, input_mixing13_used); 
fparm->SetCurrentValue(kPhypMixing23, input_mixing23_used); 
fparm->SetCurrentValue(kPhypCPV , input_dcp_used); 
fparm->SetCurrentValue(kPhypDm12sq, input_dm12sq_used); 
fparm->SetCurrentValue(kPhypDm23sq, input_dm23sq_used); 
} 
} 
else if(fparm->PhysicsHypothesis() == kHypOsc3FBar) { 
if(set_init) { 
fparm->SetInitValue(kPhypMixing12, input_mixing12_used); 
fparm->SetInitValue(kPhypMixing13, input_mixing13_used); 
fparm->SetInitValue(kPhypMixing23, input_mixing23_used); 
fparm->SetInitValue(kPhypCPV , input_dcp_used); 
fparm->SetInitValue(kPhypDm12sq, input_dm12sq_used); 
fparm->SetInitValue(kPhypDm23sq, input_dm23sq_used); 
fparm->SetInitValue(kPhypMixing12Bar, input_mixing12bar_used); 
fparm->SetInitValue(kPhypMixing13Bar, input_mixing13bar_used); 
fparm->SetInitValue(kPhypMixing23Bar, input_mixing23bar_used); 
fparm->SetInitValue(kPhypCPVBar , input_dcpbar_used); 
fparm->SetInitValue(kPhypDm12sqBar, input_dm12sqbar_used); 
fparm->SetInitValue(kPhypDm23sqBar, input_dm23sqbar_used); 
} 
else { 
fparm->SetCurrentValue(kPhypMixing12, input_mixing12_used); 
fparm->SetCurrentValue(kPhypMixing13, input_mixing13_used); 
fparm->SetCurrentValue(kPhypMixing23, input_mixing23_used); 
fparm->SetCurrentValue(kPhypCPV , input_dcp_used); 
fparm->SetCurrentValue(kPhypDm12sq, input_dm12sq_used); 
fparm->SetCurrentValue(kPhypDm23sq, input_dm23sq_used); 
fparm->SetCurrentValue(kPhypMixing12Bar, input_mixing12bar_used); 
fparm->SetCurrentValue(kPhypMixing13Bar, input_mixing13bar_used); 
fparm->SetCurrentValue(kPhypMixing23Bar, input_mixing23bar_used); 
fparm->SetCurrentValue(kPhypCPVBar , input_dcpbar_used); 
fparm->SetCurrentValue(kPhypDm12sqBar, input_dm12sqbar_used); 
fparm->SetCurrentValue(kPhypDm23sqBar, input_dm23sqbar_used); 
} 
} 
else if(fparm->PhysicsHypothesis() == kHypOsc3FBarDissap) { 
if(set_init) { 
fparm->SetInitValue(kPhypMixing12, input_mixing12_used); 
fparm->SetInitValue(kPhypMixing13, input_mixing13_used); 
fparm->SetInitValue(kPhypMixing23, input_mixing23_used); 
fparm->SetInitValue(kPhypCPV , input_dcp_used); 
fparm->SetInitValue(kPhypDm12sq, input_dm12sq_used); 
fparm->SetInitValue(kPhypDm23sq, input_dm23sq_used); 
fparm->SetInitValue(kPhypMixing23Bar, input_mixing23bar_used); 
fparm->SetInitValue(kPhypDm23sqBar, input_dm23sqbar_used); 
} 
else { 
fparm->SetCurrentValue(kPhypMixing12, input_mixing12_used); 
fparm->SetCurrentValue(kPhypMixing13, input_mixing13_used); 
fparm->SetCurrentValue(kPhypMixing23, input_mixing23_used); 
fparm->SetCurrentValue(kPhypCPV , input_dcp_used); 
fparm->SetCurrentValue(kPhypDm12sq, input_dm12sq_used); 
fparm->SetCurrentValue(kPhypDm23sq, input_dm23sq_used); 
fparm->SetCurrentValue(kPhypMixing23Bar, input_mixing23bar_used); 
fparm->SetCurrentValue(kPhypDm23sqBar, input_dm23sqbar_used); 
} 
} 
else if(fparm->PhysicsHypothesis() == kHypOsc3FNormBar) { 
if(set_init) { 
fparm->SetInitValue(kPhypMixing12, input_mixing12_used); 
fparm->SetInitValue(kPhypMixing13, input_mixing13_used); 
fparm->SetInitValue(kPhypMixing23, input_mixing23_used); 
fparm->SetInitValue(kPhypCPV , input_dcp_used); 
fparm->SetInitValue(kPhypDm12sq, input_dm12sq_used); 
fparm->SetInitValue(kPhypDm23sq, input_dm23sq_used); 
fparm->SetInitValue(kPhypBetaBar, input_beta_bar_used); 
} 
else { 
fparm->SetCurrentValue(kPhypMixing12, input_mixing12_used); 
fparm->SetCurrentValue(kPhypMixing13, input_mixing13_used); 
fparm->SetCurrentValue(kPhypMixing23, input_mixing23_used); 
fparm->SetCurrentValue(kPhypCPV , input_dcp_used); 
fparm->SetCurrentValue(kPhypDm12sq, input_dm12sq_used); 
fparm->SetCurrentValue(kPhypDm23sq, input_dm23sq_used); 
fparm->SetCurrentValue(kPhypBetaBar, input_beta_bar_used); 
} 
} 
else if(fparm->PhysicsHypothesis() == kHypOsc3FBarNormBar) { 
if(set_init) { 
fparm->SetInitValue(kPhypMixing12, input_mixing12_used); 
fparm->SetInitValue(kPhypMixing13, input_mixing13_used); 
fparm->SetInitValue(kPhypMixing23, input_mixing23_used); 
fparm->SetInitValue(kPhypCPV , input_dcp_used); 
fparm->SetInitValue(kPhypDm12sq, input_dm12sq_used); 
fparm->SetInitValue(kPhypDm23sq, input_dm23sq_used); 
fparm->SetInitValue(kPhypMixing12Bar, input_mixing12_used); 
fparm->SetInitValue(kPhypMixing13Bar, input_mixing13_used); 
fparm->SetInitValue(kPhypMixing23Bar, input_mixing23_used); 
fparm->SetInitValue(kPhypCPVBar , input_dcp_used); 
fparm->SetInitValue(kPhypDm12sqBar, input_dm12sq_used); 
fparm->SetInitValue(kPhypDm23sqBar, input_dm23sq_used); 
fparm->SetInitValue(kPhypBetaBar, input_beta_bar_used); 
} 
else { 
fparm->SetCurrentValue(kPhypMixing12, input_mixing12_used); 
fparm->SetCurrentValue(kPhypMixing13, input_mixing13_used); 
fparm->SetCurrentValue(kPhypMixing23, input_mixing23_used); 
fparm->SetCurrentValue(kPhypCPV , input_dcp_used); 
fparm->SetCurrentValue(kPhypDm12sq, input_dm12sq_used); 
fparm->SetCurrentValue(kPhypDm23sq, input_dm23sq_used); 
fparm->SetCurrentValue(kPhypMixing12Bar, input_mixing12_used); 
fparm->SetCurrentValue(kPhypMixing13Bar, input_mixing13_used); 
fparm->SetCurrentValue(kPhypMixing23Bar, input_mixing23_used); 
fparm->SetCurrentValue(kPhypCPVBar , input_dcp_used); 
fparm->SetCurrentValue(kPhypDm12sqBar, input_dm12sq_used); 
fparm->SetCurrentValue(kPhypDm23sqBar, input_dm23sq_used); 
fparm->SetCurrentValue(kPhypBetaBar, input_beta_bar_used); 
} 
} 
else { 
assert(1); 
exit(1); 
} 
if(print) cout << "- Oscillation parameters in physics param list updated: " << fparm << endl; 
} 
void valor::util::OscParams::Print(ostream & stream) const { 
stream << " - True oscillation parameters: " << endl << " - Normal ordering: " << endl << " > " << util::RawParamAsString(kPhypMixing12) << " = "; ((randomize_mixing12_nh) ? cout << "* randomized *" : cout << mixing12_nh) << endl << " > " << util::RawParamAsString(kPhypMixing13) << " = "; ((randomize_mixing13_nh) ? cout << "* randomized *" : cout << mixing13_nh) << endl << " > " << util::RawParamAsString(kPhypMixing23) << " = "; ((randomize_mixing23_nh) ? cout << "* randomized *" : cout << mixing23_nh) << endl << " > " << util::RawParamAsString(kPhypCPV ) << " = "; ((randomize_dcp_nh) ? cout << "* randomized *" : cout << dcp_nh) << endl << " > " << util::RawParamAsString(kPhypDm12sq) << " = "; ((randomize_dm12sq_nh) ? cout << "* randomized *" : cout << dm12sq_nh ) << " eV^2/c^4" << endl << " > " << util::RawParamAsString(kPhypDm23sq) << " = "; ((randomize_dm23sq_nh) ? cout << "* randomized *" : cout << dm23sq_nh ) << " eV^2/c^4" << endl << " - Inverted ordering: " << endl << " > " << util::RawParamAsString(kPhypMixing12) << " = "; ((randomize_mixing12_ih) ? cout << "* randomized *" : cout << mixing12_ih) << endl << " > " << util::RawParamAsString(kPhypMixing13) << " = "; ((randomize_mixing13_ih) ? cout << "* randomized *" : cout << mixing13_ih) << endl << " > " << util::RawParamAsString(kPhypMixing23) << " = "; ((randomize_mixing23_ih) ? cout << "* randomized *" : cout << mixing23_ih) << endl << " > " << util::RawParamAsString(kPhypCPV ) << " = "; ((randomize_dcp_ih) ? cout << "* randomized *" : cout << dcp_ih) << endl << " > " << util::RawParamAsString(kPhypDm12sq) << " = "; ((randomize_dm12sq_ih) ? cout << "* randomized *" : cout << dm12sq_ih ) << " eV^2/c^4" << endl << " > " << util::RawParamAsString(kPhypDm23sq) << " = "; ((randomize_dm23sq_ih) ? cout << "* randomized *" : cout << dm23sq_ih ) << " eV^2/c^4" << endl << " - Normal ordering Bar: " << endl << " > " << util::RawParamAsString(kPhypMixing12Bar) << " = "; ((randomize_mixing12bar_nh) ? cout << "* randomized *" : cout << mixing12bar_nh) << endl << " > " << util::RawParamAsString(kPhypMixing13Bar) << " = "; ((randomize_mixing13bar_nh) ? cout << "* randomized *" : cout << mixing13bar_nh) << endl << " > " << util::RawParamAsString(kPhypMixing23Bar) << " = "; ((randomize_mixing23bar_nh) ? cout << "* randomized *" : cout << mixing23bar_nh) << endl << " > " << util::RawParamAsString(kPhypCPVBar ) << " = "; ((randomize_dcpbar_nh) ? cout << "* randomized *" : cout << dcpbar_nh) << endl << " > " << util::RawParamAsString(kPhypDm12sqBar) << " = "; ((randomize_dm12sqbar_nh) ? cout << "* randomized *" : cout << dm12sqbar_nh ) << " eV^2/c^4" << endl << " > " << util::RawParamAsString(kPhypDm23sqBar) << " = "; ((randomize_dm23sqbar_nh) ? cout << "* randomized *" : cout << dm23sqbar_nh ) << " eV^2/c^4" << endl << " - Inverted ordering Bar: " << endl << " > " << util::RawParamAsString(kPhypMixing12Bar) << " = "; ((randomize_mixing12bar_ih) ? cout << "* randomized *" : cout << mixing12bar_ih) << endl << " > " << util::RawParamAsString(kPhypMixing13Bar) << " = "; ((randomize_mixing13bar_ih) ? cout << "* randomized *" : cout << mixing13bar_ih) << endl << " > " << util::RawParamAsString(kPhypMixing23Bar) << " = "; ((randomize_mixing23bar_ih) ? cout << "* randomized *" : cout << mixing23bar_ih) << endl << " > " << util::RawParamAsString(kPhypCPVBar ) << " = "; ((randomize_dcpbar_ih) ? cout << "* randomized *" : cout << dcpbar_ih) << endl << " > " << util::RawParamAsString(kPhypDm12sqBar) << " = "; ((randomize_dm12sqbar_ih) ? cout << "* randomized *" : cout << dm12sqbar_ih ) << " eV^2/c^4" << endl << " > " << util::RawParamAsString(kPhypDm23sqBar) << " = "; ((randomize_dm23sqbar_ih) ? cout << "* randomized *" : cout << dm23sqbar_ih ) << " eV^2/c^4" << endl << " - Other: " << endl << " > " << util::RawParamAsString(kPhypBetaBar) << " = "; ((randomize_beta_bar) ? cout << "* randomized *" : cout << beta_bar) << endl << " > Mass hierarchy = "; ((marginalize_mh) ? cout << "Margninalized (NH prior = " << mh_nh_prior << ")" : cout << util::AsString(MH)) << endl; 
if(!priors_file.empty()) { 
if((randomize_mixing13_nh && randomize_dcp_nh) || (randomize_mixing13_ih && randomize_dcp_ih) || (randomize_mixing23_nh && randomize_dm23sq_nh) || (randomize_mixing23_ih && randomize_dm23sq_ih) || (randomize_mixing13bar_nh && randomize_dcpbar_nh) || (randomize_mixing13bar_ih && randomize_dcpbar_ih) || (randomize_mixing23bar_nh && randomize_dm23sqbar_nh) || (randomize_mixing23bar_ih && randomize_dm23sqbar_ih) ) { 
stream << " > Using priors from file: " << priors_file << " for parameters:" << endl; 
if(randomize_mixing13_nh && randomize_dcp_nh) stream << " - " << util::RawParamAsString(kPhypMixing13) << " vs " << util::RawParamAsString(kPhypCPV) << " (NH)" << endl; 
if(randomize_mixing13_ih && randomize_dcp_ih) stream << " - " << util::RawParamAsString(kPhypMixing13) << " vs " << util::RawParamAsString(kPhypCPV) << " (IH)" << endl; 
if(randomize_mixing23_nh && randomize_dm23sq_nh) stream << " - " << util::RawParamAsString(kPhypMixing23) << " vs " << util::RawParamAsString(kPhypDm23sq) << " (NH)" << endl; 
if(randomize_mixing23_ih && randomize_dm23sq_ih) stream << " - " << util::RawParamAsString(kPhypMixing23) << " vs " << util::RawParamAsString(kPhypDm23sq) << " (IH)" << endl; 
} 
} 
stream << endl; 
} 
void valor::util::OscParams::Print_Toys(ostream & stream) const { 
stream << endl; 
stream << "deltaCP (NH):" << endl; 
stream << " - Mean = " << hToyHisto_dcp_nh->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_dcp_nh->GetRMS() << endl; 
stream << "deltaCP (IH):" << endl; 
stream << " - Mean = " << hToyHisto_dcp_ih->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_dcp_ih->GetRMS() << endl; 
stream << "Mixing13 (NH):" << endl; 
stream << " - Mean = " << hToyHisto_Mix13_nh->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Mix13_nh->GetRMS() << endl; 
stream << "Mixing13 (IH):" << endl; 
stream << " - Mean = " << hToyHisto_Mix13_ih->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Mix13_ih->GetRMS() << endl; 
stream << "Mixing23 (NH):" << endl; 
stream << " - Mean = " << hToyHisto_Mix23_nh->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Mix23_nh->GetRMS() << endl; 
stream << "Mixing23 (IH):" << endl; 
stream << " - Mean = " << hToyHisto_Mix23_ih->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Mix23_ih->GetRMS() << endl; 
stream << "Dm23 (NH):" << endl; 
stream << " - Mean = " << hToyHisto_Dm23_nh->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Dm23_nh->GetRMS() << endl; 
stream << "Dm23 (IH):" << endl; 
stream << " - Mean = " << hToyHisto_Dm23_ih->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Dm23_ih->GetRMS() << endl; 
stream << "Mixing12 (NH):" << endl; 
stream << " - Mean = " << hToyHisto_Mix12_nh->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Mix12_nh->GetRMS() << endl; 
stream << "Mixing12 (IH):" << endl; 
stream << " - Mean = " << hToyHisto_Mix12_ih->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Mix12_ih->GetRMS() << endl; 
stream << "Dm12 (NH):" << endl; 
stream << " - Mean = " << hToyHisto_Dm12_nh->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Dm12_nh->GetRMS() << endl; 
stream << "Dm12 (IH):" << endl; 
stream << " - Mean = " << hToyHisto_Dm12_ih->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Dm12_ih->GetRMS() << endl; 
stream << "deltaCPBar (NH):" << endl; 
stream << " - Mean = " << hToyHisto_dcpBar_nh->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_dcpBar_nh->GetRMS() << endl; 
stream << "deltaCPBar (IH):" << endl; 
stream << " - Mean = " << hToyHisto_dcpBar_ih->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_dcpBar_ih->GetRMS() << endl; 
stream << "Mixing13Bar (NH):" << endl; 
stream << " - Mean = " << hToyHisto_Mix13Bar_nh->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Mix13Bar_nh->GetRMS() << endl; 
stream << "Mixing13Bar (IH):" << endl; 
stream << " - Mean = " << hToyHisto_Mix13Bar_ih->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Mix13Bar_ih->GetRMS() << endl; 
stream << "Mixing23Bar (NH):" << endl; 
stream << " - Mean = " << hToyHisto_Mix23Bar_nh->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Mix23Bar_nh->GetRMS() << endl; 
stream << "Mixing23Bar (IH):" << endl; 
stream << " - Mean = " << hToyHisto_Mix23Bar_ih->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Mix23Bar_ih->GetRMS() << endl; 
stream << "Dm23Bar (NH):" << endl; 
stream << " - Mean = " << hToyHisto_Dm23Bar_nh->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Dm23Bar_nh->GetRMS() << endl; 
stream << "Dm23Bar (IH):" << endl; 
stream << " - Mean = " << hToyHisto_Dm23Bar_ih->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Dm23Bar_ih->GetRMS() << endl; 
stream << "Mixing12Bar (NH):" << endl; 
stream << " - Mean = " << hToyHisto_Mix12Bar_nh->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Mix12Bar_nh->GetRMS() << endl; 
stream << "Mixing12Bar (IH):" << endl; 
stream << " - Mean = " << hToyHisto_Mix12Bar_ih->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Mix12Bar_ih->GetRMS() << endl; 
stream << "Dm12Bar (NH):" << endl; 
stream << " - Mean = " << hToyHisto_Dm12Bar_nh->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Dm12Bar_nh->GetRMS() << endl; 
stream << "Dm12Bar (IH):" << endl; 
stream << " - Mean = " << hToyHisto_Dm12Bar_ih->GetMean() << endl; 
stream << " - RMS = " << hToyHisto_Dm12Bar_ih->GetRMS() << endl; 
stream << endl; 
} 
void valor::util::OscParams::Write(TFile * f) { 
f->cd(); 
if(hPrior_th13_dcp_nh) { 
hPrior_th13_dcp_nh->SetDirectory(0); 
hPrior_th13_dcp_nh->Write(); 
} 
if(hPrior_th13_dcp_ih) { 
hPrior_th13_dcp_ih->SetDirectory(0); 
hPrior_th13_dcp_ih->Write(); 
} 
if(hPrior_23_nh) { 
hPrior_23_nh->SetDirectory(0); 
hPrior_23_nh->Write(); 
} 
if(hPrior_23_ih) { 
hPrior_23_ih->SetDirectory(0); 
hPrior_23_ih->Write(); 
} 
if(hToyHisto_dcp_nh) { 
hToyHisto_dcp_nh->SetDirectory(0); 
hToyHisto_dcp_nh->Write(); 
} 
if(hToyHisto_Mix13_nh) { 
hToyHisto_Mix13_nh->SetDirectory(0); 
hToyHisto_Mix13_nh->Write(); 
} 
if(hToyHisto_Mix23_nh) { 
hToyHisto_Mix23_nh->SetDirectory(0); 
hToyHisto_Mix23_nh->Write(); 
} 
if(hToyHisto_Dm23_nh) { 
hToyHisto_Dm23_nh->SetDirectory(0); 
hToyHisto_Dm23_nh->Write(); 
} 
if(hToyHisto_Mix12_nh) { 
hToyHisto_Mix12_nh->SetDirectory(0); 
hToyHisto_Mix12_nh->Write(); 
} 
if(hToyHisto_Dm12_nh) { 
hToyHisto_Dm12_nh->SetDirectory(0); 
hToyHisto_Dm12_nh->Write(); 
} 
if(hToyHisto_dcp_ih) { 
hToyHisto_dcp_ih->SetDirectory(0); 
hToyHisto_dcp_ih->Write(); 
} 
if(hToyHisto_Mix13_ih) { 
hToyHisto_Mix13_ih->SetDirectory(0); 
hToyHisto_Mix13_ih->Write(); 
} 
if(hToyHisto_Mix23_ih) { 
hToyHisto_Mix23_ih->SetDirectory(0); 
hToyHisto_Mix23_ih->Write(); 
} 
if(hToyHisto_Dm23_ih) { 
hToyHisto_Dm23_ih->SetDirectory(0); 
hToyHisto_Dm23_ih->Write(); 
} 
if(hToyHisto_Mix12_ih) { 
hToyHisto_Mix12_ih->SetDirectory(0); 
hToyHisto_Mix12_ih->Write(); 
} 
if(hToyHisto_Dm12_ih) { 
hToyHisto_Dm12_ih->SetDirectory(0); 
hToyHisto_Dm12_ih->Write(); 
} 
if(hToyHisto_MH) { 
hToyHisto_MH->SetDirectory(0); 
hToyHisto_MH->Write(); 
} 
if(hToyHisto_dcpBar_nh) { 
hToyHisto_dcpBar_nh->SetDirectory(0); 
hToyHisto_dcpBar_nh->Write(); 
} 
if(hToyHisto_Mix13Bar_nh) { 
hToyHisto_Mix13Bar_nh->SetDirectory(0); 
hToyHisto_Mix13Bar_nh->Write(); 
} 
if(hToyHisto_Mix23Bar_nh) { 
hToyHisto_Mix23Bar_nh->SetDirectory(0); 
hToyHisto_Mix23Bar_nh->Write(); 
} 
if(hToyHisto_Dm23Bar_nh) { 
hToyHisto_Dm23Bar_nh->SetDirectory(0); 
hToyHisto_Dm23Bar_nh->Write(); 
} 
if(hToyHisto_Mix12Bar_nh) { 
hToyHisto_Mix12Bar_nh->SetDirectory(0); 
hToyHisto_Mix12Bar_nh->Write(); 
} 
if(hToyHisto_Dm12Bar_nh) { 
hToyHisto_Dm12Bar_nh->SetDirectory(0); 
hToyHisto_Dm12Bar_nh->Write(); 
} 
if(hToyHisto_dcpBar_ih) { 
hToyHisto_dcpBar_ih->SetDirectory(0); 
hToyHisto_dcpBar_ih->Write(); 
} 
if(hToyHisto_Mix13Bar_ih) { 
hToyHisto_Mix13Bar_ih->SetDirectory(0); 
hToyHisto_Mix13Bar_ih->Write(); 
} 
if(hToyHisto_Mix23Bar_ih) { 
hToyHisto_Mix23Bar_ih->SetDirectory(0); 
hToyHisto_Mix23Bar_ih->Write(); 
} 
if(hToyHisto_Dm23Bar_ih) { 
hToyHisto_Dm23Bar_ih->SetDirectory(0); 
hToyHisto_Dm23Bar_ih->Write(); 
} 
if(hToyHisto_Mix12Bar_ih) { 
hToyHisto_Mix12Bar_ih->SetDirectory(0); 
hToyHisto_Mix12Bar_ih->Write(); 
} 
if(hToyHisto_Dm12Bar_ih) { 
hToyHisto_Dm12Bar_ih->SetDirectory(0); 
hToyHisto_Dm12Bar_ih->Write(); 
} 
} 
double valor::util::Calculate2FSterileOsc(int init_pdg, int final_pdg, double lOverE, double sinsq2thee, double sinsq2thmumu, double dmsq) { 
int ipdg = abs(init_pdg); 
int fpdg = abs(final_pdg); 
double sindm = std::sin(kOscDimensFactor * lOverE * dmsq); 
double sinsqdm = sindm * sindm; 
if (ipdg == kPdgNuE) { 
double prob = sinsq2thee * sinsqdm; 
if (fpdg == kPdgNuMu) { 
return prob; 
} 
else if (fpdg == kPdgNuE) { 
return 1-prob; 
} 
} 
if (ipdg == kPdgNuMu) { 
if (fpdg == kPdgNuMu) { 
return 1-sinsq2thmumu * sinsqdm; 
} 
else if (fpdg == kPdgNuE) { 
double sinsq2mue = sinsq2thee * sinsq2thmumu / 4.; 
return sinsq2mue * sinsqdm; 
} 
} 
LOG("Flavours not supported",pFATAL); 
util::Die(-1); 
return conv::kBadResult; 
} 
double valor::util::FlipOctantAroundMaxDisap(double sinsqth23, double sinsqth13) { 
double costh13 = std::sqrt(1-sinsqth13); 
double centre = 1./(2*costh13); 
double diff = centre - sinsqth23; 
double result = sinsqth23 + 2*diff; 
return result; 
} 
ClassImp(ConfidenceInterval) ConfidenceInterval::ConfidenceInterval() : TNamed() { 
} 
ConfidenceInterval::ConfidenceInterval(string in_file_name, string confidence, PhysParamId_t par_x, PhysParamId_t par_y, bool avg_or_min_delta_chi2, bool find_delta_chi2) : TNamed() { 
param_x = par_x; 
param_y = par_y; 
bin_low_x = conv::kALargeNum; 
bin_high_x = -conv::kALargeNum; 
bin_low_y = conv::kALargeNum; 
bin_high_y = -conv::kALargeNum; 
n_bins_x = 1; n_bins_y = 1; n_bins = 1; 
min_chi2 = 0; bin_low_x = 0; bin_high_x = 1; bin_low_y = 0; bin_high_y = 1; 
scale_limits = 0.0000000001; 
output_graphs = new TObjArray(); 
chi2_2D = new TH2D("chi2_2D", "chi2_2D", 1, 0, 1, 1, 0, 1); 
n_entries_2D = new TH2D("n_entries_2D", "n_entries_2D", 1, 0, 1, 1, 0, 1); 
chi2_1D = new TH1D; 
this->Generate(in_file_name, confidence, avg_or_min_delta_chi2, find_delta_chi2); 
} 
ConfidenceInterval::~ConfidenceInterval() { 
delete chi2_2D; 
delete n_entries_2D; 
} 
void ConfidenceInterval::Generate(string in_file_name, string confidence, bool avg_or_min_delta_chi2, bool find_delta_chi2) { 
assert(1); 
TChain* chain = new TChain("valor_dune_nd_ntp"); 
chain->Add(in_file_name.c_str()); 
if(chain->GetEntries() == 0) LOG("Messenger", pFATAL) << "No input root files detected."; 
assert(1); 
GetBinningAndData(chain); 
chi2_2D->SetBins (n_bins_x, bin_low_x, bin_high_x, n_bins_y, bin_low_y, bin_high_y); 
n_entries_2D->SetBins(n_bins_x, bin_low_x, bin_high_x, n_bins_y, bin_low_y, bin_high_y); 
FillHists(avg_or_min_delta_chi2); 
Checks(); 
if(find_delta_chi2) FindDelta(); 
if(param_y == kPhypUndefined){ 
chi2_1D = chi2_2D->ProjectionX("chi2_1D", 1, 1); 
hist_limits[2] = chi2_1D->GetMinimum(); 
hist_limits[3] = chi2_1D->GetMaximum(); 
} 
double chi2_crit = FindCriticalChi2(confidence, find_delta_chi2); 
FixFailure(chi2_crit); 
GenerateContour(chi2_crit); 
} 
void ConfidenceInterval::GetBinningAndData(TChain* chain) { 
assert(1); 
long n_entries = chain->GetEntries(); 
std::vector<double> unique_x, unique_y; 
FitParamList * best_fit_param_array = 0; 
chain->SetBranchAddress("best_fit_params", &best_fit_param_array); 
if(param_y == kPhypUndefined){ 
bin_low_y = 0; 
bin_high_y = 1; 
} 
for(long entry = 0; entry < n_entries; ++entry){ 
chain->GetEntry(entry); 
bool fit_failed = false; 
if(!best_fit_param_array->IsFixed(param_x)) LOG("Messenger", pWARN) << "X parameter is not fixed"; 
if(param_y != kPhypUndefined && !best_fit_param_array->IsFixed(param_y)) LOG("Messenger", pWARN) << "Y parameter is not fixed"; 
double x_val = best_fit_param_array->BestFitValue(param_x); 
if(x_val <= -99999999){ 
assert(1); 
fit_failed = true; 
x_val = best_fit_param_array->InitValue(param_x); 
} 
if(entry == 0) unique_x.push_back(x_val); 
else{ 
bool unique = true; 
for(unsigned int i = 0; i < unique_x.size(); ++i){ 
if(unique_x[i] == x_val) unique = false; 
} 
if(unique) unique_x.push_back(x_val); 
} 
double y_val = 0; 
if(param_y != kPhypUndefined){ 
y_val = best_fit_param_array->BestFitValue(param_y); 
if(y_val <= -99999999){ 
assert(1); 
fit_failed = true; 
y_val = best_fit_param_array->InitValue(param_y); 
} 
if(entry == 0) unique_y.push_back(y_val); 
else{ 
bool unique = true; 
for(unsigned int i = 0; i < unique_y.size(); ++i){ 
if(unique_y[i] == y_val) unique = false; 
} 
if(unique) unique_y.push_back(y_val); 
} 
} 
else if(entry == 0) unique_y.push_back(y_val); 
if(!fit_failed){ 
x_vals.push_back(x_val); 
y_vals.push_back(y_val); 
double chi2 = best_fit_param_array->GetBestFitStatistic(); 
chi2_vals.push_back(chi2); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
} 
} 
bin_low_x = unique_x[0]; 
bin_high_x = unique_x[0]; 
for(unsigned int i = 1; i < unique_x.size(); ++i){ 
bin_low_x = std::min(bin_low_x, unique_x[i]); 
bin_high_x = std::max(bin_high_x, unique_x[i]); 
} 
if(param_y != kPhypUndefined){ 
bin_low_y = unique_y[0]; 
bin_high_y = unique_y[0]; 
for(unsigned int i = 1; i < unique_y.size(); ++i){ 
bin_low_y = std::min(bin_low_y, unique_y[i]); 
bin_high_y = std::max(bin_high_y, unique_y[i]); 
} 
} 
bin_low_x *= 1 - Sign(bin_low_x) * scale_limits; 
bin_high_x *= 1 + Sign(bin_high_x) * scale_limits; 
bin_low_y *= 1 - Sign(bin_low_y) * scale_limits; 
bin_high_y *= 1 + Sign(bin_high_y) * scale_limits; 
n_bins_x = (unsigned int) unique_x.size(); 
n_bins_y = (unsigned int) unique_y.size(); 
if(n_bins_y == 0) ++n_bins_y; 
hist_limits[0] = bin_low_x; 
hist_limits[1] = bin_high_x; 
hist_limits[2] = bin_low_y; 
hist_limits[3] = bin_high_y; 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
} 
void ConfidenceInterval::FillHists(bool avg_or_min_delta_chi2) { 
assert(1); 
if(x_vals.size() < y_vals.size()) LOG("Messenger", pERROR) << "x_vals.size() < y_vals.size(). This should never happen!"; 
for(unsigned int i = 0; i < x_vals.size(); ++i){ 
n_entries_2D->Fill(x_vals[i], y_vals[i]); 
} 
if(avg_or_min_delta_chi2){ 
for(unsigned int i = 0; i < x_vals.size(); ++i){ 
chi2_2D->Fill(x_vals[i], y_vals[i], chi2_vals[i]); 
} 
n_bins = chi2_2D->GetSize(); 
if(n_bins != (unsigned int)n_entries_2D->GetSize()) LOG("Messenger", pERROR) << "Different number of bins in chi2_2D and n_entries_2D"; 
for(unsigned int bin = 1; bin < n_bins +1; ++bin){ 
if(chi2_2D->IsBinUnderflow(bin) || chi2_2D->IsBinOverflow(bin)) continue; 
double n_bin_entries = n_entries_2D->GetBinContent(bin); 
double sum = chi2_2D->GetBinContent(bin); 
if(n_bin_entries == 0 && sum != 0) LOG("Messenger", pERROR) << "n_bin_entries = 0 but sum != 0. This should never happen!"; 
if(n_bin_entries == 0) continue; 
chi2_2D->SetBinContent(bin, sum / n_bin_entries); 
} 
} 
else{ 
for(unsigned int i = 0; i < x_vals.size(); ++i) { 
int bin_x = chi2_2D->GetXaxis()->FindBin(x_vals[i]); 
int bin_y = chi2_2D->GetYaxis()->FindBin(y_vals[i]); 
if ((chi2_vals[i] < chi2_2D->GetBinContent(bin_x, bin_y)) || (chi2_2D->GetBinContent(bin_x, bin_y) <= 0)){ 
chi2_2D->SetBinContent(bin_x, bin_y, chi2_vals[i]); 
} 
} 
} 
assert(1); 
} 
void ConfidenceInterval::Checks() { 
assert(1); 
int n_entries_max = n_entries_2D->GetBinContent(n_entries_2D->GetMaximumBin()); 
bool initial_val = false; 
for(unsigned int bin = 0; bin < n_bins + 2; ++bin){ 
int content = n_entries_2D->GetBinContent(bin); 
if(!n_entries_2D->IsBinUnderflow(bin) && !n_entries_2D->IsBinOverflow(bin)) { 
if(content != n_entries_max) { 
int bin_x, bin_y, bin_z; 
n_entries_2D->GetBinXYZ(bin, bin_x, bin_y, bin_z); 
assert(1); 
} 
if(content != 0){ 
if (chi2_2D->IsBinUnderflow(bin) && chi2_2D->GetBinContent(bin) > 0 ) LOG("Messenger", pERROR) << "> 0 underflows detected in chi2_2D at global bin # " << bin; 
else if (chi2_2D->IsBinOverflow(bin) && chi2_2D->GetBinContent(bin) > 0 ) LOG("Messenger", pERROR) << "> 0 overflows detected in chi2_2D at global bin # " << bin; 
if (n_entries_2D->IsBinUnderflow(bin) && n_entries_2D->GetBinContent(bin) > 0 ) LOG("Messenger", pERROR) << "> 0 underflows detected in n_entries_2D at global bin # " << bin; 
else if (n_entries_2D->IsBinOverflow(bin) && n_entries_2D->GetBinContent(bin) > 0 ) LOG("Messenger", pERROR) << "> 0 overflows detected in n_entries_2D at global bin # " << bin; 
double chi2 = chi2_2D->GetBinContent(bin); 
if(!initial_val) { 
min_chi2 = chi2; 
initial_val = true; 
} 
else{ 
if(chi2 < min_chi2){ 
min_chi2 = chi2; 
int bin_x, bin_y, bin_z; 
chi2_2D->GetBinXYZ(bin, bin_x, bin_y, bin_z); 
best_fit_point[0] = chi2_2D->GetXaxis()->GetBinCenter(bin_x); 
best_fit_point[1] = chi2_2D->GetYaxis()->GetBinCenter(bin_y); 
best_fit_point[2] = min_chi2; 
} 
} 
} 
} 
} 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
} 
void ConfidenceInterval::FindDelta() { 
assert(1); 
for(unsigned int bin = 1; bin < n_bins + 1; ++bin){ 
int content = n_entries_2D->GetBinContent(bin); 
if(!n_entries_2D->IsBinUnderflow(bin) && !n_entries_2D->IsBinOverflow(bin) && content != 0) { 
double chi2 = chi2_2D->GetBinContent(bin); 
chi2_2D->SetBinContent(bin, chi2 - min_chi2); 
} 
} 
assert(1); 
} 
double ConfidenceInterval::FindCriticalChi2(string confidence, bool find_delta_chi2) { 
assert(1); 
double conf_level = 0.90; 
std::string conf_type = "%"; 
std::string buf; 
std::stringstream ss(confidence); 
vector<std::string> conf_info; 
while (ss >> buf) conf_info.push_back(buf); 
if(conf_info.size() != 2) LOG("Messenger", pERROR) << "Input confidence level should have 2 entries separated with whitespace"; 
bool conf_info_valid = true; 
if(conf_info[0].find_first_not_of("0123456789.") != std::string::npos) conf_info_valid = false; 
if(!((conf_info[1] == "%") || (conf_info[1] == "sigma"))) conf_info_valid = false; 
if(!conf_info_valid) LOG("Messenger", pERROR) << "Input confidence should be of the form <confidence> <% or sigma>, e.g. 0.90 %"; 
conf_level = std::atof(conf_info[0].c_str()); 
conf_type = conf_info[1]; 
if(conf_type == "sigma") conf_level = 0.5*(TMath::Erf(conf_level/sqrt(2)) - TMath::Erf(-conf_level/sqrt(2))); 
else conf_level /= 100; 
double chi2_crit = 0; 
if(param_y == kPhypUndefined) chi2_crit = TMath::ChisquareQuantile(conf_level, 1); 
else chi2_crit = TMath::ChisquareQuantile(conf_level, 2); 
if(!find_delta_chi2) chi2_crit += min_chi2; 
assert(1); 
assert(1); 
assert(1); 
return chi2_crit; 
} 
void ConfidenceInterval::FixFailure(double chi2_crit) { 
assert(1); 
double penalty = 1.01 * chi2_crit; 
vector<int> penalised_bins; 
for(unsigned int bin = 1; bin < n_bins + 1; ++bin){ 
int content = n_entries_2D->GetBinContent(bin); 
double chi2 = chi2_2D->GetBinContent(bin); 
if(!n_entries_2D->IsBinUnderflow(bin) && !n_entries_2D->IsBinOverflow(bin) && content == 0 && chi2 == 0){ 
int bins_per_row = n_bins_x + 2;  int bin_s = (int)bin; 
int check_bins[8] = {bin_s + bins_per_row, bin_s - bins_per_row, bin_s + 1, bin_s - 1, bin_s + bins_per_row - 1, bin_s + bins_per_row + 1, bin_s - bins_per_row - 1, bin_s - bins_per_row + 1};  
bool can_interpolate = true; 
for(unsigned int i = 0; i < 8; ++i){ 
int check = check_bins[i]; 
bool penalsied_adjacent = false; 
if(penalised_bins.size() != 0){ 
for(unsigned int j = 0; j < penalised_bins.size(); ++j){ 
if(penalised_bins[j] == check){ 
penalsied_adjacent = true; 
break; 
} 
} 
} 
if(chi2_2D->IsBinUnderflow(check) || chi2_2D->IsBinOverflow(check) || check < 1 || check > (int)n_bins || penalsied_adjacent || n_entries_2D->GetBinContent(check) == 0){ 
can_interpolate = false; 
break; 
} 
} 
int bin_x, bin_y, bin_z; 
chi2_2D->GetBinXYZ(bin, bin_x, bin_y, bin_z); 
double x = chi2_2D->GetXaxis()->GetBinCenter(bin_x); 
double y = chi2_2D->GetYaxis()->GetBinCenter(bin_y); 
double interpolated_val = -1; 
if(can_interpolate){ 
interpolated_val = chi2_2D->Interpolate(x ,y);  if(interpolated_val != 0){ 
chi2_2D->SetBinContent(bin, interpolated_val); 
assert(1); 
} 
else LOG("Messenger", pNOTICE) << "Interpolation failed at x = " << x << ", y = " << y; 
} 
if(!can_interpolate || interpolated_val == 0){ 
chi2_2D->SetBinContent(bin, penalty); 
penalised_bins.push_back(bin); 
assert(1); 
} 
} 
} 
assert(1); 
} 
void ConfidenceInterval::GenerateContour(double chi2_crit) { 
assert(1); 
TCanvas *c = new TCanvas("c", "Contour List", 0, 0, 600, 600); 
if(param_y != kPhypUndefined){ 
chi2_2D->SetContour(1, &chi2_crit); 
chi2_2D->Draw("CONT LIST"); 
c->Update(); 
TObjArray *conts = (TObjArray *) gROOT->GetListOfSpecials()->FindObject("contours"); 
if (conts == NULL) LOG("Messenger", pERROR) << "No Contours Found"; 
TList *contLevel = (TList *) conts->At(0); 
TGraph *curv = (TGraph *) contLevel->First(); 
TGraph *gc = NULL; 
Double_t x0, y0, z0; 
for (int j = 0; j < contLevel->GetSize(); j++) { 
curv->GetPoint(0, x0, y0); 
gc = (TGraph *) curv->Clone(); 
output_graphs->Add(gc); 
curv = (TGraph *) contLevel->After(curv); 
} 
} 
else{ 
double bin_width = (bin_high_x - bin_low_x) / n_bins_x; 
double line_x_vals [2] = {bin_low_x - bin_width, bin_high_x}; 
double line_y_vals [2] = {chi2_crit, chi2_crit}; 
TGraph *conf_limit = new TGraph(2, line_x_vals, line_y_vals); 
output_graphs->Add(conf_limit); 
} 
c->Close(); 
assert(1); 
} 
double ConfidenceInterval::Sign(double num) { 
if(num >= 0) return 1; 
return -1; 
} 
ClassImp(ConfidenceIntervalPlotter) ConfidenceIntervalPlotter::ConfidenceIntervalPlotter() : TNamed() { 
} 
ConfidenceIntervalPlotter::ConfidenceIntervalPlotter(PhysParamId_t par_x, PhysParamId_t par_y, bool avg_or_min_delta_chi2, bool find_delta_chi2, string input_titles) : TNamed() { 
param_x = par_x; 
param_y = par_y; 
avg_delta_chi2 = avg_or_min_delta_chi2; 
find_delta = find_delta_chi2; 
titles = input_titles; 
limits[0] = conv::kALargeNum; 
limits[1] = -conv::kALargeNum; 
limits[2] = conv::kALargeNum; 
limits[3] = -conv::kALargeNum; 
line_colour = 1; bf_colour = 1; hist_colour = 2; 
line_style = 1; bf_style = 29; hist_style = 1; 
bf_size = 1.5; 
label = "Confidence Limit"; hist_label = "Data"; 
bf_marker_added = false; manual_range = false; 
graphs_to_draw = new TObjArray(); 
bfp_to_draw = new TObjArray(); 
hists_to_draw = new TObjArray(); 
leg = new TLegend(0.6, 0.75, 0.9, 0.95); 
} 
ConfidenceIntervalPlotter::~ConfidenceIntervalPlotter() { 
} 
void ConfidenceIntervalPlotter::Add(string in_file_name = "", string confidence = "90 %") { 
assert(1); 
ConfidenceInterval *conf = new ConfidenceInterval(in_file_name.c_str(), confidence, param_x, param_y, avg_delta_chi2, find_delta); 
TObjArray *graph_array = new TObjArray(); 
graph_array = conf->GetConfidenceInterval(); 
if(!manual_range){ 
double *temp_limits = conf->GetLimits(); 
limits[0] = TMath::Min(limits[0], temp_limits[0]); 
limits[1] = TMath::Max(limits[1], temp_limits[1]); 
limits[2] = TMath::Min(limits[2], temp_limits[2]); 
limits[3] = TMath::Max(limits[3], temp_limits[3]); 
} 
if(param_y != conv::kPhypUndefined){ 
double *best_fit_point = conf->GetBestFitPoint(); 
TGraph *best_fit_marker = new TGraph(1, &best_fit_point[0], &best_fit_point[1]); 
best_fit_marker->SetMarkerColor(bf_colour); 
best_fit_marker->SetMarkerSize(bf_size); 
best_fit_marker->SetMarkerStyle(bf_style); 
bfp_to_draw->Add(best_fit_marker); 
if(!bf_marker_added){ 
bf_marker_added = true; 
leg->AddEntry(best_fit_marker, "Best-fit", "p"); 
} 
} 
else{ 
TH1D *chi2_1D = new TH1D(); 
chi2_1D = conf->GetChi2Data_1D(); 
TH1D *hist = new TH1D(); 
hist = (TH1D *) chi2_1D->Clone(); 
hist->SetLineColor(hist_colour); 
hist->SetLineStyle(hist_style); 
hists_to_draw->Add(hist); 
if(!CheckLegendLabel(hist_labels, hist_label)){ 
leg->AddEntry(hist, hist_label.c_str(), "l"); 
hist_labels.push_back(hist_label); 
} 
} 
TGraph *graph = (TGraph *) graph_array->First(); 
TGraph *gc = NULL; 
for (int j = 0; j < graph_array->GetSize(); j++) { 
gc = (TGraph *) graph->Clone(); 
gc->SetLineColor(line_colour); 
gc->SetLineStyle(line_style); 
graphs_to_draw->Add(gc); 
if(!CheckLegendLabel(line_labels, label)){ 
leg->AddEntry(gc, label.c_str(), "l"); 
line_labels.push_back(label); 
} 
graph = (TGraph *) graph_array->After(graph); 
if(graph == 0) break; 
} 
delete conf; 
assert(1); 
} 
void ConfidenceIntervalPlotter::Draw(TCanvas *canvas) { 
assert(1); 
canvas->cd(); 
frame = canvas->DrawFrame(limits[0], limits[2], limits[1], limits[3], titles.c_str()); 
TGraph *graph; 
TGraph *gc; 
if(param_y != conv::kPhypUndefined){ 
graph = (TGraph *) bfp_to_draw->First(); 
gc = NULL; 
for (int i = 0; i < bfp_to_draw->GetSize(); i++) { 
gc = (TGraph *) graph->Clone(); 
gc->Draw("P"); 
graph = (TGraph *) bfp_to_draw->After(graph); 
if(graph == 0) break; 
} 
} 
else{ 
TH1D *hist = (TH1D*) hists_to_draw->First(); 
TH1D *hc = NULL; 
for (int i = 0; i < hists_to_draw->GetSize(); i++) { 
hc = (TH1D *) hist->Clone(); 
hc->Draw("same"); 
hist = (TH1D *) hists_to_draw->After(hist); 
if(hist == 0) break; 
} 
} 
graph = (TGraph *) graphs_to_draw->First(); 
gc = NULL; 
for (int i = 0; i < graphs_to_draw->GetSize(); i++) { 
gc = (TGraph *) graph->Clone(); 
gc->Draw("C"); 
graph = (TGraph *) graphs_to_draw->After(graph); 
if(graph == 0) break; 
} 
leg->Draw(); 
canvas->Update(); 
assert(1); 
} 
void ConfidenceIntervalPlotter::SetRangeManually(double x_low, double y_low, double x_high, double y_high) { 
manual_range = true; 
limits[0] = x_low; 
limits[1] = x_high; 
limits[2] = y_low; 
limits[3] = y_high; 
} 
bool ConfidenceIntervalPlotter::CheckLegendLabel(vector<string> vec, string lab) { 
bool match = false; 
if(vec.size() != 0){ 
for(unsigned int i = 0; i < vec.size(); ++i){ 
if(vec[i] == lab){ 
match = true; 
break; 
} 
} 
} 
return match; 
} 
namespace valor { 
namespace util { 
Configuration* Configuration::_instance = nullptr; 
Configuration::Configuration(): Registry() { 
} 
Configuration::~Configuration() { 
} 
Configuration* Configuration::Instance() { 
if(not(_instance)) { 
_instance = new Configuration(); 
} 
return _instance; 
} 
} 
} 
namespace valor { 
namespace util { 
ConfigurationHandler::ConfigurationHandler(): _engine{new TXMLEngine()}, 
_nextParamId{1} 
{ 
} 
ConfigurationHandler::~ConfigurationHandler() { 
delete _engine; 
_nextParamId = 1; 
} 
void ConfigurationHandler::ReadAnalysis(const std::string& filename) { 
string fullFilename = file::GetConfigurationFilename(filename); 
if(fullFilename.empty()) { 
assert(1); 
util::Die(1); 
} 
XMLDocPointer_t doc = _engine->ParseFile(fullFilename.c_str()); 
if(doc == 0) { 
assert(1); 
util::Die(1); 
} 
XMLNodePointer_t rootNode = _engine->DocGetRootElement(doc); 
Configuration& config = (*Configuration::Instance()); 
config.Set("analysis.samples", util::XML2String(_engine, rootNode, "samples")); 
ReadSampleList(config.GetString("analysis.samples")); 
config.Set("analysis.parameters", util::XML2String(_engine, rootNode, "parameters")); 
ReadParameterList(config.GetString("analysis.parameters")); 
config.Set("analysis.splines", util::XML2String(_engine, rootNode, "splines")); 
ReadSplines(config.GetString("analysis.splines")); 
} 
void ConfigurationHandler::ReadSampleList(const std::string& filename) { 
string fullFilename = file::GetConfigurationFilename(filename); 
if(fullFilename.empty()) { 
assert(1); 
util::Die(1); 
} 
XMLDocPointer_t doc = _engine->ParseFile(fullFilename.c_str()); 
if(doc == 0) { 
assert(1); 
util::Die(1); 
} 
Configuration& config = (*Configuration::Instance()); 
XMLNodePointer_t rootNode = _engine->DocGetRootElement(doc); 
config.Set("sample_list.name", _engine->GetAttr(rootNode, "name")); 
ProcessSamples(rootNode); 
} 
void ConfigurationHandler::ProcessSamples(XMLNodePointer_t rootNode) { 
Configuration& config = (*Configuration::Instance()); 
auto samples = util::FindNodes(_engine, rootNode, "sample"); 
for(unsigned int i = 0; i < samples.size(); ++i) { 
auto sample = samples[i]; 
config.Set(BuildString("sample_list.sample_", i + 1, ".name"), _engine->GetAttr(sample, "name")); 
config.Set(BuildString("sample_list.sample_", i + 1, ".detector"), util::XML2String(_engine, sample, "detector")); 
config.Set(BuildString("sample_list.sample_", i + 1, ".beam"), util::XML2String(_engine, sample, "beam")); 
config.Set(BuildString("sample_list.sample_", i + 1, ".selection"), util::XML2String(_engine, sample, "selection")); 
config.Set(BuildString("sample_list.sample_", i + 1, ".data"), util::XML2String(_engine, sample, "data")); 
config.Set(BuildString("sample_list.sample_", i + 1, ".mc"), util::XML2String(_engine, sample, "mc")); 
config.Set(BuildString("sample_list.sample_", i + 1, ".data_class"), util::XML2String(_engine, sample, "data_class")); 
config.Set(BuildString("sample_list.sample_", i + 1, ".model_class"), util::XML2String(_engine, sample, "model_class")); 
ReadMC(config.GetString(BuildString("sample_list.sample_", i + 1, ".mc"))); 
} 
} 
void ConfigurationHandler::ReadMC(const std::string& filename) { 
string fullFilename = file::GetConfigurationFilename(filename); 
if(fullFilename.empty()) { 
assert(1); 
util::Die(1); 
} 
XMLDocPointer_t doc = _engine->ParseFile(fullFilename.c_str()); 
if(doc == 0) { 
assert(1); 
util::Die(1); 
} 
Configuration& config = (*Configuration::Instance()); 
XMLNodePointer_t rootNode = _engine->DocGetRootElement(doc); 
config.Set("mc.name", _engine->GetAttr(rootNode, "name")); 
config.Set("mc.version", _engine->GetAttr(rootNode, "version")); 
config.Set("mc.detector", _engine->GetAttr(rootNode, "detector")); 
config.Set("mc.exposure.fhc", util::XML2Dbl(_engine, rootNode, "data/exposure/fhc")); 
config.Set("mc.exposure.rhc", util::XML2Dbl(_engine, rootNode, "data/exposure/rhc")); 
config.Set("mc.fiducial_mass", util::XML2Dbl(_engine, rootNode, "fiducial_mass")); 
config.Set("mc.use_dst", util::XML2Bool(_engine, rootNode, "mc/using_dst_format")); 
config.Set("mc.dst.fhc.filename", util::XML2String(_engine, rootNode, "mc/dst/fhc/filename")); 
config.Set("mc.dst.fhc.objname", util::XML2String(_engine, rootNode, "mc/dst/fhc/objname")); 
config.Set("mc.dst.fhc.objtype", util::XML2String(_engine, rootNode, "mc/dst/fhc/objtype")); 
config.Set("mc.dst.rhc.filename", util::XML2String(_engine, rootNode, "mc/dst/rhc/filename")); 
config.Set("mc.dst.rhc.objname", util::XML2String(_engine, rootNode, "mc/dst/rhc/objname")); 
config.Set("mc.dst.rhc.objtype", util::XML2String(_engine, rootNode, "mc/dst/rhc/objtype")); 
config.Set("mc.template.filename", util::XML2String(_engine, rootNode, "mc/template/filename")); 
config.Set("mc.template.tag", util::XML2String(_engine, rootNode, "mc/template/tag")); 
config.Set("mc.interaction_mass", util::XML2Dbl(_engine, rootNode, "mc/interaction_mass")); 
config.Set("mc.default_binning", util::XML2String(_engine, rootNode, "default_binning")); 
ReadBinning(config.GetString("mc.default_binning")); 
} 
void ConfigurationHandler::ReadBinning(const std::string& filename) { 
string fullFilename = file::GetConfigurationFilename(filename); 
if(fullFilename.empty()) { 
assert(1); 
util::Die(1); 
} 
XMLDocPointer_t doc = _engine->ParseFile(fullFilename.c_str()); 
if(doc == 0) { 
assert(1); 
util::Die(1); 
} 
Configuration& config = (*Configuration::Instance()); 
XMLNodePointer_t rootNode = _engine->DocGetRootElement(doc); 
config.Set("binning.reco.opt", util::XML2String(_engine, rootNode, "reco_optimized")); 
ReadOptimisedBinning(config.GetString("binning.reco.opt"), "binning.reco.opt"); 
config.Set("binning.reco.smp", util::XML2String(_engine, rootNode, "reco_simple")); 
ReadSimpleBinning(config.GetString("binning.reco.smp"), "binning.reco.smp"); 
config.Set("binning.true.smp.default", util::XML2String(_engine, rootNode, "true_simple/default")); 
ReadSimpleBinning(config.GetString("binning.true.smp.default"), "binning.true.smp.default"); 
config.Set("binning.xsec.reco", util::XML2String(_engine, rootNode, "xsec_reco")); 
ReadSimpleBinning(config.GetString("binning.xsec.reco"), "binning.xsec.reco"); 
} 
void ConfigurationHandler::ReadOptimisedBinning(const std::string& filename, const std::string& key) { 
string fullFilename = file::GetConfigurationFilename(filename); 
if(fullFilename.empty()) { 
assert(1); 
util::Die(1); 
} 
XMLDocPointer_t doc = _engine->ParseFile(fullFilename.c_str()); 
if(doc == 0) { 
assert(1); 
util::Die(1); 
} 
Configuration& config = (*Configuration::Instance()); 
XMLNodePointer_t rootNode = _engine->DocGetRootElement(doc); 
config.Set(key + ".space", util::XML2String(_engine, rootNode, "space")); 
config.Set(key + ".type", util::XML2String(_engine, rootNode, "type")); 
config.Set(key + ".nbins", util::XML2Int(_engine, rootNode, "nbins")); 
for(int i = 0; i < config.GetInt(key + ".nbins"); ++i) { 
std::string list = util::XML2String(_engine, rootNode, BuildString("bin_", i, "")); 
std::vector<std::string> tokens = util::Tokens(list, ","); 
if(tokens.size() != 4) { 
assert(1); 
util::Die(1); 
} 
std::string prefix = BuildString(key, ".bin_", ""); 
config.Set(BuildString(prefix, i, ".xlow"), std::atof( util::TrimSpaces(tokens[0]).c_str())); 
config.Set(BuildString(prefix, i, ".xhigh"), std::atof( util::TrimSpaces(tokens[1]).c_str())); 
config.Set(BuildString(prefix, i, ".ylow"), std::atof( util::TrimSpaces(tokens[2]).c_str())); 
config.Set(BuildString(prefix, i, ".yhigh"), std::atof( util::TrimSpaces(tokens[3]).c_str())); 
} 
} 
void ConfigurationHandler::ReadSimpleBinning(const std::string& filename, const std::string& key) { 
string fullFilename = file::GetConfigurationFilename(filename); 
if(fullFilename.empty()) { 
assert(1); 
util::Die(1); 
} 
XMLDocPointer_t doc = _engine->ParseFile(fullFilename.c_str()); 
if(doc == 0) { 
assert(1); 
util::Die(1); 
} 
Configuration& config = (*Configuration::Instance()); 
XMLNodePointer_t rootNode = _engine->DocGetRootElement(doc); 
config.Set(key + ".space", util::XML2String(_engine, rootNode, "space")); 
config.Set(key + ".type", util::XML2String(_engine, rootNode, "type")); 
std::vector<std::string> kvs = util::Tokens(config.GetString(key + ".space"), ","); 
for(unsigned int k = 0; k < kvs.size(); ++k) { 
kvs[k] = util::TrimSpaces(kvs[k]); 
XMLNodePointer_t kvNode = util::FindNode(_engine, rootNode, kvs[k] + "_binning"); 
std::string prefix = BuildString(key + ".kv_", k + 1, ""); 
config.Set(BuildString(prefix, ".name", ""), kvs[k]); 
config.Set(BuildString(prefix, ".size", ""), util::XML2String(_engine, kvNode, "bin_size")); 
int nbins = util::XML2Int(_engine, kvNode, "nbins"); 
config.Set(BuildString(prefix, ".nbins", ""), nbins); 
std::string edges = util::XML2String(_engine, kvNode, "bin_edges"); 
for(int i = 0; i < nbins; ++i) { 
std::vector<std::string> tokens = util::Tokens(edges, ","); 
if(tokens.size() != (nbins + 1)) { 
assert(1); 
util::Die(1); 
} 
for(unsigned int j = 0; j < tokens.size(); ++j) { 
std::string edge = BuildString(prefix, ".edge_", ""); 
config.Set(BuildString(edge, j, ""), std::atof( util::TrimSpaces(tokens[j]).c_str())); 
} 
} 
} 
} 
void ConfigurationHandler::ReadParameterList(const std::string& filename) { 
string fullFilename = file::GetConfigurationFilename(filename); 
if(fullFilename.empty()) { 
assert(1); 
util::Die(1); 
} 
XMLDocPointer_t doc = _engine->ParseFile(fullFilename.c_str()); 
if(doc == 0) { 
assert(1); 
util::Die(1); 
} 
Configuration& config = (*Configuration::Instance()); 
XMLNodePointer_t rootNode = _engine->DocGetRootElement(doc); 
config.Set("param_list.name", _engine->GetAttr(rootNode, "name")); 
ProcessDefaults(rootNode); 
auto groups = util::FindNodes(_engine, rootNode, "parameter_group"); 
for(unsigned int i = 0; i < groups.size(); ++i) { 
auto group = groups[i]; 
std::string name = _engine->GetAttr(group, "name"); 
if(name == "oscillation") { 
ProcessOscillationParameters(group); 
ReadParameters(config.GetString("param_list.osc.parameters")); 
} 
else if(name == "flux" || name == "interaction" || name == "detector") { 
ProcessSystematicParameters(group, name); 
ReadParameters(config.GetString(BuildString("param_list.", name, ".parameters"))); 
} 
else { 
assert(1); 
util::Die(1); 
} 
} 
} 
void ConfigurationHandler::ReadSplines(const std::string& filename) { 
string fullFilename = file::GetConfigurationFilename(filename); 
if(fullFilename.empty()) { 
assert(1); 
util::Die(1); 
} 
XMLDocPointer_t doc = _engine->ParseFile(fullFilename.c_str()); 
if(doc == 0) { 
assert(1); 
util::Die(1); 
} 
Configuration& config = (*Configuration::Instance()); 
XMLNodePointer_t rootNode = _engine->DocGetRootElement(doc); 
config.Set("splines.folder", util::XML2String(_engine, rootNode, "folder")); 
config.Set("splines.pattern", util::XML2String(_engine, rootNode, "pattern")); 
} 
void ConfigurationHandler::ProcessOscillationParameters(XMLNodePointer_t rootNode) { 
Configuration& config = (*Configuration::Instance()); 
config.Set("param_list.osc.parameters", util::XML2String(_engine, rootNode, "parameters")); 
auto penalty = util::FindNode(_engine, rootNode, "penalty_term"); 
if(penalty != nullptr) { 
config.Set("param_list.osc.penalty.type", _engine->GetAttr(penalty, "type")); 
config.Set("param_list.osc.penalty.cov.filename", util::XML2String(_engine, penalty, "covariance_matrix/filename")); 
config.Set("param_list.osc.penalty.cov.objname", util::XML2String(_engine, penalty, "covariance_matrix/objname")); 
config.Set("param_list.osc.penalty.cov.objtype", util::XML2String(_engine, penalty, "covariance_matrix/objtype")); 
} 
} 
void ConfigurationHandler::ProcessSystematicParameters(XMLNodePointer_t rootNode, const std::string& type) { 
Configuration& config = (*Configuration::Instance()); 
config.Set(BuildString("param_list.", type, ".parameters"), util::XML2String(_engine, rootNode, "parameters")); 
auto penalty = util::FindNode(_engine, rootNode, "penalty_term"); 
if(penalty != nullptr) { 
config.Set(BuildString("param_list.", type, ".penalty.type"), _engine->GetAttr(penalty, "type")); 
config.Set(BuildString("param_list.", type, ".penalty.cov.filename"), util::XML2String(_engine, penalty, "covariance_matrix/filename")); 
config.Set(BuildString("param_list.", type, ".penalty.cov.objname"), util::XML2String(_engine, penalty, "covariance_matrix/objname")); 
config.Set(BuildString("param_list.", type, ".penalty.cov.objtype"), util::XML2String(_engine, penalty, "covariance_matrix/objtype")); 
} 
auto postfit = util::FindNode(_engine, rootNode, "postfit"); 
if(postfit != nullptr) { 
config.Set(BuildString("param_list.", type, ".postfit.filename"), util::XML2String(_engine, postfit, "filename")); 
config.Set(BuildString("param_list.", type, ".postfit.objname"), util::XML2String(_engine, postfit, "objname")); 
config.Set(BuildString("param_list.", type, ".postfit.objtype"), util::XML2String(_engine, postfit, "objtype")); 
} 
} 
void ConfigurationHandler::ReadParameters(const std::string& filename) { 
string fullFilename = file::GetConfigurationFilename(filename); 
if(fullFilename.empty()) { 
assert(1); 
util::Die(1); 
} 
XMLDocPointer_t doc = _engine->ParseFile(fullFilename.c_str()); 
if(doc == 0) { 
assert(1); 
util::Die(1); 
} 
XMLNodePointer_t rootNode = _engine->DocGetRootElement(doc); 
ProcessParameters(rootNode); 
} 
void ConfigurationHandler::ProcessDefaults(XMLNodePointer_t rootNode) { 
Configuration& config = (*Configuration::Instance()); 
auto defaults = util::FindNode(_engine, rootNode, "defaults"); 
config.Set("param_list.defaults.bestfit", util::XML2Dbl(_engine, defaults, "bestfit")); 
config.Set("param_list.defaults.init", util::XML2Dbl(_engine, defaults, "init")); 
config.Set("param_list.defaults.minimum", util::XML2Dbl(_engine, defaults, "minimum")); 
config.Set("param_list.defaults.maximum", util::XML2Dbl(_engine, defaults, "maximum")); 
config.Set("param_list.defaults.step_size", util::XML2Dbl(_engine, defaults, "step_size")); 
config.Set("param_list.defaults.scaling", util::XML2Dbl(_engine, defaults, "scaling")); 
config.Set("param_list.defaults.fixed", util::XML2Bool(_engine, defaults, "fixed")); 
config.Set("param_list.defaults.nuisance", util::XML2Bool(_engine, defaults, "nuisance")); 
config.Set("param_list.defaults.marginalise", util::XML2Bool(_engine, defaults, "marginalise")); 
} 
void ConfigurationHandler::ProcessParameters(XMLNodePointer_t rootNode) { 
Configuration& config = (*Configuration::Instance()); 
auto params = util::FindNodes(_engine, rootNode, "parameter"); 
for(unsigned int i = 0; i < params.size(); ++i) { 
auto param = params[i]; 
config.Set(BuildString("param_list.param_", _nextParamId, ".name"), _engine->GetAttr(param, "name")); 
if(util::NodeExists(_engine, param, "bestfit")) { 
config.Set(BuildString("param_list.param_", _nextParamId, ".bestfit"), util::XML2Dbl(_engine, param, "bestfit")); 
} 
else { 
config.Set(BuildString("param_list.param_", _nextParamId, ".bestfit"), config.GetDouble("param_list.defaults.bestfit")); 
} 
if(util::NodeExists(_engine, param, "init")) { 
config.Set(BuildString("param_list.param_", _nextParamId, ".init"), util::XML2Dbl(_engine, param, "init")); 
} 
else { 
config.Set(BuildString("param_list.param_", _nextParamId, ".init"), config.GetDouble("param_list.defaults.init")); 
} 
if(util::NodeExists(_engine, param, "minimum")) { 
config.Set(BuildString("param_list.param_", _nextParamId, ".minimum"), util::XML2Dbl(_engine, param, "minimum")); 
} 
else { 
config.Set(BuildString("param_list.param_", _nextParamId, ".minimum"), config.GetDouble("param_list.defaults.minimum")); 
} 
if(util::NodeExists(_engine, param, "maximum")) { 
config.Set(BuildString("param_list.param_", _nextParamId, ".maximum"), util::XML2Dbl(_engine, param, "maximum")); 
} 
else { 
config.Set(BuildString("param_list.param_", _nextParamId, ".maximum"), config.GetDouble("param_list.defaults.maximum")); 
} 
if(util::NodeExists(_engine, param, "step_size")) { 
config.Set(BuildString("param_list.param_", _nextParamId, ".step_size"), util::XML2Dbl(_engine, param, "step_size")); 
} 
else { 
config.Set(BuildString("param_list.param_", _nextParamId, ".step_size"), config.GetDouble("param_list.defaults.step_size")); 
} 
if(util::NodeExists(_engine, param, "scaling")) { 
config.Set(BuildString("param_list.param_", _nextParamId, ".scaling"), util::XML2Dbl(_engine, param, "scaling")); 
} 
else { 
config.Set(BuildString("param_list.param_", _nextParamId, ".scaling"), config.GetDouble("param_list.defaults.scaling")); 
} 
if(util::NodeExists(_engine, param, "fixed")) { 
config.Set(BuildString("param_list.param_", _nextParamId, ".fixed"), util::XML2Bool(_engine, param, "fixed")); 
} 
else { 
config.Set(BuildString("param_list.param_", _nextParamId, ".fixed"), config.GetBool("param_list.defaults.fixed")); 
} 
if(util::NodeExists(_engine, param, "nuisance")) { 
config.Set(BuildString("param_list.param_", _nextParamId, ".nuisance"), util::XML2Bool(_engine, param, "nuisance")); 
} 
else { 
config.Set(BuildString("param_list.param_", _nextParamId, ".nuisance"), config.GetBool("param_list.defaults.nuisance")); 
} 
if(util::NodeExists(_engine, param, "marginalise")) { 
config.Set(BuildString("param_list.param_", _nextParamId, ".marginalise"), util::XML2Bool(_engine, param, "marginalise")); 
} 
else { 
config.Set(BuildString("param_list.param_", _nextParamId, ".marginalise"), config.GetBool("param_list.defaults.marginalise")); 
} 
if(util::NodeExists(_engine, param, "errors")) { 
auto errors = util::FindNode(_engine, param, "errors"); 
ProcessErrors(errors); 
} 
++_nextParamId; 
} 
} 
void ConfigurationHandler::ProcessErrors(XMLNodePointer_t rootNode) { 
Configuration& config = (*Configuration::Instance()); 
if(util::NodeExists(_engine, rootNode, "migrad")) { 
config.Set(BuildString("param_list.param_", _nextParamId, ".errors.migrad.error"), util::XML2Dbl(_engine, rootNode, "migrad/error")); 
} 
else if(util::NodeExists(_engine, rootNode, "hesse")) { 
config.Set(BuildString("param_list.param_", _nextParamId, ".errors.hesse.error"), util::XML2Dbl(_engine, rootNode, "hesse/error")); 
} 
else if(util::NodeExists(_engine, rootNode, "minos")) { 
config.Set(BuildString("param_list.param_", _nextParamId, ".errors.minos.low_error"), util::XML2Dbl(_engine, rootNode, "minos/low_error")); 
config.Set(BuildString("param_list.param_", _nextParamId, ".errors.minos.high_error"), util::XML2Dbl(_engine, rootNode, "minos/high_error")); 
} 
} 
std::string ConfigurationHandler::BuildString(const std::string& prefix, const int id, const std::string& suffix) { 
std::ostringstream ss; 
ss << prefix << id << suffix; 
return ss.str(); 
} 
std::string ConfigurationHandler::BuildString(const std::string& prefix, const std::string& infix, const std::string& suffix) { 
std::ostringstream ss; 
ss << prefix << infix << suffix; 
return ss.str(); 
} 
} 
} 
namespace valor { 
ostream & operator<<(ostream & stream, const Env & env) { 
env.Print(stream); 
return stream; 
} 
} 
Env * Env::fInstance = 0; 
Env::Env() { 
fTopLevelDir = ""; 
fTopLevelDataDir = ""; 
fTopLevelConfDir = ""; 
fAppName = ""; 
fBanner = ""; 
fInstance = 0; 
} 
Env::Env(const Env &) { 
} 
Env::~Env() { 
} 
Env * Env::Instance() { 
if(fInstance == 0) { 
static Env::Cleaner cleaner; 
cleaner.DummyMethodAndSilentCompiler(); 
fInstance = new Env; 
} 
return fInstance; 
} 
void Env::AutoSet(Option_t * app) { 
string valor_app = app; 
if(valor_app.find("t2xk") != string::npos) { 
const char * topdir = gSystem->Getenv("T2KOSCANA"); 
if(topdir) { 
fTopLevelDir = topdir; 
fTopLevelDataDir = fTopLevelDir + "/inputs/"; 
fTopLevelConfDir = fTopLevelDir + "/config/"; 
fAppName = "t2xk"; 
fBanner = fTopLevelDir + "/inputs/banner/banner.dat"; 
} 
} 
else if(valor_app.find("dune") != string::npos) { 
const char * topdir = gSystem->Getenv("VALOR_DUNE"); 
if(topdir) { 
fTopLevelDir = topdir; 
fTopLevelDataDir = fTopLevelDir + "/data/"; 
fTopLevelConfDir = fTopLevelDir + "/config/"; 
fAppName = "dune"; 
fBanner = fTopLevelDir + "/data/banner/banner.dat"; 
} 
} 
else if(valor_app.find("fmwk") != string::npos) { 
const char * topdir = gSystem->Getenv("VALOR_FMWK"); 
if(topdir) { 
fTopLevelDir = topdir; 
fTopLevelDataDir = fTopLevelDir + "/data/"; 
fTopLevelConfDir = fTopLevelDir + "/config/"; 
fAppName = "fmwk"; 
fBanner = fTopLevelDir + "/data/banner/banner.dat"; 
} 
} 
else { 
assert(1); 
} 
} 
void Env::Print(ostream & stream) const { 
stream << "[Environment]" << endl; 
stream << " - top dir : " << fTopLevelDir << endl; 
stream << " - top data dir : " << fTopLevelDataDir << endl; 
stream << " - top conf dir : " << fTopLevelConfDir << endl; 
stream << " - running app : " << fAppName << endl; 
} 
namespace valor { 
namespace util { 
FitParamList* FitParamListFactory::MakeParamList(const std::string& filename) const { 
return nullptr; 
} 
FitParamList* FitParamListFactory::MakeOscillationParamList( const std::string& filename) const { 
return nullptr; 
} 
FitParamList* FitParamListFactory::MakeSystematicParamList( const std::string& filename) const { 
return nullptr; 
} 
} 
} 
#ifdef __VALOR_FMWK_GSL_ENABLED__ 
valor::util::Interpolator::Interpolator(const TSpline * spl, ROOT::Math::Interpolation::Type type) : ROOT::Math::Interpolator(0,type),fXmin(0),fXmax(0) { 
if (spl) { 
int n_knots = spl->GetNp(); 
std::vector<double> x(n_knots); 
std::vector<double> y(n_knots); 
for (int i = 0 ; i < n_knots; i++) { 
spl->GetKnot(i,x[i],y[i]); 
} 
this->SetData(n_knots,x.data(),y.data()); 
fXmin = *std::min_element(x.begin(),x.end()); 
fXmax = *std::max_element(x.begin(),x.end()); 
} 
} 
valor::util::Interpolator::Interpolator(const TSpline & spl, ROOT::Math::Interpolation::Type type) : ROOT::Math::Interpolator(0,type),fXmin(0),fXmax(0) { 
int n_knots = spl.GetNp(); 
std::vector<double> x(n_knots); 
std::vector<double> y(n_knots); 
for (int i = 0 ; i < n_knots; i++) { 
spl.GetKnot(i,x[i],y[i]); 
} 
this->SetData(n_knots,x.data(),y.data()); 
fXmin = *std::min_element(x.begin(),x.end()); 
fXmax = *std::max_element(x.begin(),x.end()); 
} 
double valor::util::Interpolator::EvalWithLimits(double x) const { 
x = std::max(x,fXmin); 
x = std::min(x,fXmax); 
return this->Eval(x); 
} 
double valor::util::Interpolator::Xmin() const { 
return fXmin; 
} 
double valor::util::Interpolator::Xmax() const { 
return fXmax; 
} 
#endif 
valor::util::NameRegistry * valor::util::NameRegistry::fInstance = 0; 
valor::util::NameRegistry::NameRegistry() { 
this->Init(); 
fInstance = 0; 
} 
const valor::util::NameRegistry * valor::util::NameRegistry::Instance() {return MutableInstance();} 
valor::util::NameRegistry * valor::util::NameRegistry::MutableInstance() { 
if(fInstance == 0) { 
static valor::util::NameRegistry::Cleaner cleaner; 
cleaner.DummyMethodAndSilentCompiler(); 
fInstance = new valor::util::NameRegistry; 
} 
return fInstance; 
} 
void valor::util::NameRegistry::Init(void) { 
for (int ip = -1 ; ip < conv::kLastNuisParam; ip++) { 
conv::PhysParamId_t p = (conv::PhysParamId_t)ip; 
fParamNames .insert(map<conv::PhysParamId_t, std::string>::value_type(p,util::RawParamAsString (p))); 
fParamNamesSimple.insert(map<conv::PhysParamId_t, std::string>::value_type(p,util::RawParamAsStringRaw(p))); 
} 
return; 
} 
std::string valor::util::NameRegistry::ParamAsString(PhysParamId_t p ) const { 
map<PhysParamId_t, string>::const_iterator iter = fParamNames.find(p); 
assert(iter != fParamNames.end()); 
return iter->second; 
} 
std::string valor::util::NameRegistry::ParamAsStringSimple(PhysParamId_t p ) const { 
map<PhysParamId_t, string>::const_iterator iter = fParamNamesSimple.find(p); 
assert(iter != fParamNamesSimple.end()); 
return iter->second; 
} 
std::string valor::util::NameRegistry::AsString (PhysParamId_t p) const { return this->ParamAsString (p); } 
std::string valor::util::NameRegistry::AsStringSimple(PhysParamId_t p) const { return this->ParamAsStringSimple(p); } 
namespace valor { 
ostream & operator<<(ostream & stream, const Rnd & rnd) { 
rnd.Print(stream); 
return stream; 
} 
} 
Rnd * Rnd::fInstance = 0; 
Rnd::Rnd() { 
this->SetSeeds(); 
fInstance = 0; 
} 
Rnd::~Rnd() { 
} 
Rnd * Rnd::Instance() { 
if(fInstance == 0) { 
static Rnd::Cleaner cleaner; 
cleaner.DummyMethodAndSilentCompiler(); 
fInstance = new Rnd; 
} 
return fInstance; 
} 
void Rnd::SetSeeds( UInt_t toymcstat, UInt_t toymcsyst, UInt_t toymcosc, UInt_t fitter, UInt_t other) { 
fSeedToyMCstat = toymcstat; 
fSeedToyMCsyst = toymcsyst; 
fSeedToyMCosc = toymcosc ; 
fSeedFitter = fitter ; 
fSeedOther = other ; 
#ifndef __SEED_TRANDOM_ZERO__ 
unsigned int randseeds[5] = {}; 
if (! (toymcstat && toymcsyst && toymcosc && fitter && other) ) { 
FILE * devrandom = fopen("/dev/urandom","r"); 
size_t ints_read = fread(randseeds, sizeof(unsigned int), 5, devrandom); 
assert(ints_read == 5); 
fclose(devrandom); 
} 
fSeedToyMCstat = ( toymcstat ? toymcstat : randseeds[0] ); 
fSeedToyMCsyst = ( toymcsyst ? toymcsyst : randseeds[1] ); 
fSeedToyMCosc = ( toymcosc ? toymcosc : randseeds[2] ); 
fSeedFitter = ( fitter ? fitter : randseeds[3] ); 
fSeedOther = ( other ? other : randseeds[4] ); 
#endif 
assert(1); 
fRndToyMCstat . SetSeed(fSeedToyMCstat); 
fRndToyMCsyst . SetSeed(fSeedToyMCsyst); 
fRndToyMCosc . SetSeed(fSeedToyMCosc); 
fRndFitter . SetSeed(fSeedFitter); 
fRndOther . SetSeed(fSeedOther); 
} 
void Rnd::Print(ostream & stream) const { 
stream << "[Random number generator seed numbers]" << endl; 
stream << " - Toy MC (Stat) : "; 
if (fSeedToyMCstat != 0) { 
stream << fRndToyMCstat.GetSeed(); 
} else { 
stream << " ** randomized ** (" << fRndToyMCstat.GetSeed() << ")"; 
} 
stream << endl; 
stream << " - Toy MC (Syst) : "; 
if (fSeedToyMCsyst != 0) { 
stream << fRndToyMCsyst.GetSeed(); 
} else { 
stream << " ** randomized ** (" << fRndToyMCsyst.GetSeed() << ")"; 
} 
stream << endl; 
stream << " - Toy MC (Osc) : "; 
if (fSeedToyMCosc != 0) { 
stream << fRndToyMCosc.GetSeed(); 
} else { 
stream << " ** randomized ** (" << fRndToyMCosc.GetSeed() << ")"; 
} 
stream << endl; 
stream << " - Fitter : "; 
if (fSeedFitter != 0) { 
stream << fRndFitter.GetSeed(); 
} else { 
stream << " ** randomized ** (" << fRndFitter.GetSeed() << ")"; 
} 
stream << endl; 
stream << " - Other : "; 
if (fSeedOther != 0) { 
stream << fRndOther.GetSeed(); 
} else { 
stream << " ** randomized ** (" << fRndOther.GetSeed() << ")"; 
} 
stream << endl; 
} 
void Rnd::SetSeeds(const CmdLnArgList & arg) { 
this->SetSeeds(arg.GetInt("seed-toys-stat"), arg.GetInt("seed-toys-syst"), arg.GetInt("seed-toys-osc" ), arg.GetInt("seed-fitter" ), arg.GetInt("seed-other" )); 
return; 
} 
namespace valor { 
namespace util { 
namespace file { 
std::string GetExpandedFilename(const std::string& filename, const std::string& altPath) { 
std::string resolved{""}; 
const char* temp = gSystem->ExpandPathName(filename.c_str()); 
FileStat_t dummy; 
if(gSystem->GetPathInfo(temp, dummy)) { 
std::ostringstream sstream; 
sstream << altPath << filename; 
delete[] temp; 
temp = gSystem->ExpandPathName(sstream.str().c_str()); 
if(not(gSystem->GetPathInfo(temp, dummy))) { 
resolved = temp; 
} 
} 
else { 
resolved = temp; 
} 
delete[] temp; 
return resolved; 
} 
std::string GetConfigurationFilename(const std::string& filename) { 
return GetExpandedFilename(filename, Env::Instance()->TopLevelConfDir()); 
} 
std::string GetDataFilename(const std::string& filename) { 
return GetExpandedFilename(filename, Env::Instance()->TopLevelDataDir()); 
} 
std::string GetFilename(const std::string& filename) { 
return GetExpandedFilename(filename, Env::Instance()->TopLevelDir()); 
} 
} 
} 
} 
std::string valor::util::FormFilePath(const char * file, const char * dir) { 
FileStat_t dummy; 
string filename(TString::Format("%s/%s/%s", Env::Instance()->TopLevelDir().c_str(), dir, file).Data()); 
if(gSystem->GetPathInfo(filename.c_str(), dummy)) { 
assert(1); 
exit(-1); 
} 
return filename; 
} 
string valor::util::SysThrowIdToString(unsigned int tweak_systematics) { 
string tweak_sys_str; 
string appname = Env::Instance()->AppName(); 
if(!appname.compare("t2xk")) { 
switch(tweak_systematics) { 
case(0):  tweak_sys_str = "None"; break; 
case(1):  tweak_sys_str = "All"; break; 
case(2):  tweak_sys_str = "Special low energy numu flux increase"; break; 
case(3):  tweak_sys_str = "Tweak all but SK and FSI"; break; 
case(4):  tweak_sys_str = "NC1pi norm = 0.5"; break; 
case(5):  tweak_sys_str = "High energy >1.5 GeV flux increase"; break; 
case(6):  tweak_sys_str = "BANFF"; break; 
case(7):  tweak_sys_str = "XSec"; break; 
case(8):  tweak_sys_str = "SK+FSI"; break; 
default:  cerr << "SysThrowIdToString() tweak_systematics = " << tweak_systematics  << " not implemented" << endl; 
 exit(-1); 
} 
} 
else { 
assert(1); 
exit(-1); 
} 
return tweak_sys_str; 
} 
TH2D * valor::util::GetTH2DFromTFile(TFile * f, const char * name) { 
TH2D * h = 0; 
f->GetObject(name, h); 
if(!h || h->IsZombie()) { 
assert(1); 
exit(1); 
} 
return h; 
} 
#ifdef __VALOR_FMWK_GSL_ENABLED__ 
#endif 
TH1D util::Make1DHistogramFromArray(const VALORArray & va, const double * bin_edges, int dimension) { 
string name (va.GetName()); 
string title(va.GetTitle()); 
if (va.GetNDim() > 1) { 
name += TString::Format("_%d",dimension).Data(); 
title += TString::Format("_%d",dimension).Data(); 
} 
int nbins = va.GetSize(dimension); 
TH1D h(name.c_str(),title.c_str(),nbins,bin_edges); 
h.GetXaxis()->SetTitle(va.GetDimensionName(dimension).c_str()); 
if (va.GetNDim()==1) { 
for (int ibin = 0 ; ibin < nbins ; ibin++) { 
h.AddBinContent(ibin+1,va.GetEntry(ibin)); 
} 
} 
else { 
const int * array_dimensions = va.GetDimensions(); 
int dimcounter[6] = {}; 
for (int ientry = 0 ; ientry < va.GetSize(); ientry++) { 
h.AddBinContent(dimcounter[dimension]+1, va.GetArray()[ientry]); 
for (int idim = va.GetNDim()-1; idim>=0 ; idim--) { 
if (dimcounter[idim] < array_dimensions[idim]-1) { 
dimcounter[idim]++; 
break; 
} 
else dimcounter[idim] = 0; 
} 
} 
} 
h.SetEntries(h.Integral()); 
return h; 
} 
TH2D util::Make2DHistogramFromArray(const VALORArray & va, double * const bin_edges_x, const double * bin_edges_y, int dimension_x, int dimension_y) { 
if (va.GetNDim()<2) return TH2D(); 
string name (va.GetName()); 
string title(va.GetTitle()); 
if (va.GetNDim() > 2) { 
name += TString::Format("_%d_%d",dimension_x, dimension_y).Data(); 
title += TString::Format("_%d_%d",dimension_x, dimension_y).Data(); 
} 
int nbins_x = va.GetSize(dimension_x); 
int nbins_y = va.GetSize(dimension_y); 
TH2D h(name.c_str(),title.c_str(), nbins_x, bin_edges_x, nbins_y, bin_edges_y); 
h.GetXaxis()->SetTitle(va.GetDimensionName(dimension_x).c_str()); 
h.GetYaxis()->SetTitle(va.GetDimensionName(dimension_y).c_str()); 
const VALORArray * curr_va = &va; 
vector<VALORArray> vec; 
while (curr_va->GetNDim() > 2) { 
for (int i = 0 ; i < curr_va->GetNDim() ; i++) { 
if (i==dimension_x || i==dimension_y) continue; 
vec.push_back( curr_va->GetSlice(i,-1,-1) ); 
curr_va = &(vec.back()); 
if (i < dimension_x) dimension_x--; 
if (i < dimension_y) dimension_y--; 
break; 
} 
} 
for (int ibin_x = 0 ; ibin_x < nbins_x ; ibin_x++) { 
for (int ibin_y = 0 ; ibin_y < nbins_y ; ibin_y++) { 
int ibin = h.GetBin(ibin_x+1,ibin_y+1); 
if (dimension_x == 0 && dimension_y == 1) { 
h.AddBinContent(ibin,curr_va->GetEntry(ibin_x,ibin_y)); 
} 
else if (dimension_x == 1 && dimension_y == 0) { 
h.AddBinContent(ibin,curr_va->GetEntry(ibin_y,ibin_x)); 
} 
else { 
assert(1); 
return h; 
} 
} 
} 
h.SetEntries(h.Integral()); 
return h; 
} 
TObjArray * valor::util::MakeHistogramsOfParameterValues(int n_entries, const PhysParamList *const* pparms, int n_bins, const FitParamList * get_limits_from) { 
if (n_entries <= 0) { return 0;} 
if (n_bins <= 0) {n_bins = TMath::CeilNint(sqrt((double)n_entries)/2);} 
const PhysParamList & pp = *(pparms[0]); 
int n_params = pp.NParams(); 
conv::PhysParamId_t params[n_params]; 
double param_mins[n_params]; 
double param_maxs[n_params]; 
const map<int,double> & m = pp.Map(); 
TObjArray * out_arr = new TObjArray(n_params); 
out_arr->SetOwner(true); 
int ip=0; 
for (map<int,double>::const_iterator it=m.begin();it!=m.end();++it) { 
conv::PhysParamId_t p = (conv::PhysParamId_t)it->first; 
params[ip] = p; 
if (get_limits_from and get_limits_from->Exists(p)) { 
param_mins[ip] = get_limits_from->MinValue(p); 
param_maxs[ip] = get_limits_from->MaxValue(p); 
} 
else { 
double min = 1E100; 
double max = -1E100; 
for (int il = 0 ; il < n_entries ; il++) { 
double v = pparms[il]->Value(p); 
if (v < min) min = v; 
if (v > max) max = v; 
} 
param_mins[ip] = min; 
param_maxs[ip] = max; 
} 
ip++; 
} 
for (ip = 0 ; ip < n_params ; ip++) { 
conv::PhysParamId_t p = params[ip]; 
TString hname = TString::Format("param_values_%s",util::RawParamAsString(p).c_str()); 
TString htitle = TString::Format("%s Values",util::RawParamAsString(p).c_str()); 
out_arr->AddAt(new TH1D(hname.Data(),htitle.Data(),n_bins,param_mins[ip],param_maxs[ip]),ip); 
} 
for (int il = 0 ; il < n_entries ; il++) { 
for (ip = 0 ; ip < n_params ; ip++) { 
conv::PhysParamId_t p = params[ip]; 
((TH1D*)out_arr->At(ip))->Fill(pparms[il]->Value(p)); 
} 
} 
return out_arr; 
} 
TH1 * valor::util::MakeFittedHistogramShowingFittedValues(const TH1* hist, const TF1* func, int npoints) { 
TH1 * fitted_hist = dynamic_cast<TH1*>(hist->Clone()); 
assert(fitted_hist); 
int nbins_in = fitted_hist->GetXaxis()->GetNbins(); 
double xmin = fitted_hist->GetXaxis()->GetBinLowEdge(1); 
double xmax = fitted_hist->GetXaxis()->GetBinUpEdge (nbins_in); 
fitted_hist->SetBins(npoints,xmin,xmax); 
for (int ibin = 1 ; ibin <= fitted_hist->GetXaxis()->GetNbins() ; ibin++) { 
double bin_centre = fitted_hist->GetXaxis()->GetBinCenter(ibin); 
double func_val = func->Eval(bin_centre); 
fitted_hist->SetBinContent(ibin, func_val); 
} 
return fitted_hist; 
} 
#ifdef __VALOR_FMWK_GSL_ENABLED__ 
TH1D valor::util::MakeHistFromGSLSpline(const ROOT::Math::Interpolator * spl, int n_points, double min_x , double max_x) { 
TH1D h_spl("h_spl","Spline histogram",n_points,min_x,max_x); 
for (int i = 0 ; i < n_points ; i++) { 
double x = min_x + (i+0.5)*(max_x-min_x)/n_points; 
h_spl.Fill(x,spl->Eval(x)); 
} 
return h_spl; 
} 
#else 
TH1D valor::util::MakeHistFromGSLSpline(const ROOT::Math::Interpolator *, int, double, double) { 
assert(!"GSL Must be enabled for this function!"); 
TH1D h; 
return h; 
} 
#endif 
TMatrixD valor::util::TH2ToTMatrix(const TH2 * hist) { 
const int nrows = hist->GetNbinsX(); 
const int ncols = hist->GetNbinsY(); 
TMatrixD m(nrows,ncols); 
for(int i = 1; i <= nrows; i++) { 
for(int j = 1; j <= ncols; j++) { 
m(i-1,j-1) = hist->GetBinContent(i,j); 
} 
} 
return m; 
} 
int valor::util::CreateRedToBlueColorPalette(int n_shades) { 
double reds [3] = {1.,1.,0}; 
double blues [3] = {0.,1.,1}; 
double greens[3] = {0.,1.,0}; 
double stops [3] = {0.0,0.5, 1.0}; 
int pal_number = TColor::CreateGradientColorTable(3,stops,reds,greens,blues,n_shades); 
return pal_number; 
} 
TObjArray valor::util::GetHistsFromCanvas(TVirtualPad * canv, const char * name) { 
TList * arr = canv->GetListOfPrimitives(); 
TObjArray output; 
for (int i = 0 ; i < arr->GetEntries(); i++) { 
TObject * obj = arr->At(i); 
if (TString(obj->ClassName()).Contains(name)) { 
TH1 * h = dynamic_cast<TH1*>(obj); 
if (h) { 
output.Add(h); 
} 
else { 
assert(1); 
} 
} 
} 
return output; 
} 
namespace valor { 
namespace util { 
namespace init { 
CmdLnArgList Init(const std::string& environment, const std::string& appArgs, const std::string& seedArgs, const int argc, const char* argv[]) { 
Env::Instance()->AutoSet(environment.c_str()); 
PrintBanner(Env::Instance()->Banner(), 500); 
CmdLnArgList arg; 
arg.Read(argc, argv, (file::GetConfigurationFilename(appArgs) + ":" + file::GetConfigurationFilename(seedArgs)).c_str()); 
Messenger::Instance()->Configure(file::GetConfigurationFilename( arg.GetString("mesg-thresholds"))); 
Rnd::Instance()->SetSeeds(arg); 
return arg; 
} 
} 
} 
} 
#ifdef __VALOR_FMWK_GSL_ENABLED__ 
#endif 
#define GSL_CHOLESKY 
double valor::util::DeltaChisquare( ConfLevel_t cl, int nfitparams) { 
switch(cl) { 
case (kCLUndefined) : { 
 return -99999; 
break; 
} 
case (kCL68) : { 
if (nfitparams == 1) { return 1.00; } 
else if (nfitparams == 2) { return 2.30; } 
else if (nfitparams == 3) { return 3.53; } 
else { return -99999; } 
break; 
} 
case (kCL90) : { 
if (nfitparams == 1) { return 2.71; } 
else if (nfitparams == 2) { return 4.61; } 
else if (nfitparams == 3) { return 6.25; } 
else { return -99999; } 
break; 
} 
case (kCL95) : { 
if (nfitparams == 1) { return 3.84; } 
else if (nfitparams == 2) { return 5.99; } 
else if (nfitparams == 3) { return 7.82; } 
else { return -99999; } 
break; 
} 
case (kCL99) : { 
if (nfitparams == 1) { return 6.63; } 
else if (nfitparams == 2) { return 9.21; } 
else if (nfitparams == 3) { return 11.34; } 
else { return -99999; } 
break; 
} 
default: return -99999; 
} 
return -99999; 
} 
double valor::util::ChisqGauss( double ndata, double nmc) { 
double chisq = 0.; 
if(nmc>0) { 
chisq = TMath::Power(ndata-nmc,2.)/nmc; 
} 
return chisq; 
} 
double valor::util::ChisqPoisson(double ndata_db, double nmc_db) { 
double chisq; 
long double ndata = ndata_db; 
long double nmc = nmc_db; 
if(nmc < conv::kSetNegEventsTo) { 
if (ndata>conv::kAVerySmallNum) { 
assert(1); 
} 
nmc = conv::kSetNegEventsTo; 
} 
if(ndata <= conv::kAVerySmallNum) { 
chisq = 2.*(nmc-ndata); 
} 
else { 
chisq = 2. * ndata * (nmc/ndata+std::log(ndata/nmc)-1.l); 
} 
#ifdef VALOR_FMWK_LOW_LEVEL_MESG_ENABLED 
if (chisq<conv.kAVerySmallNum) { 
assert(1); 
} 
#endif 
return TMath::Max(0.,chisq); 
} 
TMatrixD valor::util::CholeskyDecomposition(const TMatrixDSym& cov_matrix) { 
return util::CholeskyDecomposition(TMatrixD(cov_matrix)); 
} 
TMatrixD valor::util::CholeskyDecomposition(const TMatrixD& cov_matrix) { 
int ncols = cov_matrix.GetNcols(); 
int nrows = cov_matrix.GetNrows(); 
assert(ncols==nrows); 
int n = nrows; 
TMatrixD L(n, n); 
if (!n) {return L;} 
#ifdef GSL_CHOLESKY 
const double diag_increment = 1E-3; 
const int max_increment_attempts = 1000; 
gsl_matrix * m = gsl_matrix_alloc(nrows,ncols); 
gsl_error_handler_t * old_error_handler = gsl_set_error_handler_off (); 
int iattempt = 0; 
bool success = false; 
for (iattempt = 0 ; iattempt < max_increment_attempts+1 ; iattempt++) { 
memcpy( (double*)gsl_matrix_ptr(m,0,0), cov_matrix.GetMatrixArray(), n*n*sizeof(double) ); 
if (iattempt) { 
double factor = 1.+(double)iattempt*diag_increment; 
for (int ielem = 0 ; ielem < n; ielem++) { 
double new_val = cov_matrix(ielem,ielem)*factor; 
gsl_matrix_set(m,ielem,ielem,new_val); 
} 
} 
int status = gsl_linalg_cholesky_decomp(m); 
if (status != GSL_EDOM) { 
assert(1); 
success = true; 
break; 
} 
} 
if (!success) { 
assert(1); 
util::Die(1); return TMatrixD(); 
} 
if (iattempt) { 
assert(1); 
} 
for (int i = 0 ; i < n; i++) { 
for (int j = 0 ; j <= i ; j++) { 
L(i,j) = gsl_matrix_get(m,i,j); 
} 
} 
gsl_matrix_free(m); 
gsl_set_error_handler(old_error_handler); 
return L; 
#else 
for (int i = 0; i < n; ++i) { 
L(i,i) = cov_matrix(i,i); 
for (int k = 0; k < i; ++k) { 
double tmp = L(k,i); 
L(i,i) -= tmp*tmp; 
} 
if(L(i,i) <= 0) { 
if( fabs(L(i,i))<conv::kASmallNum ){ 
 LOG("UtlNumStat", pWARN) << "Element: " << i << "," << i << " = " << L(i,i); 
 L(i,i)=conv::kASmallNum; 
 LOG("UtlNumStat", pWARN) << "Changed to "<<L(i,i); 
} 
else{ 
 LOG("UtlNumStat", pERROR) << "Decomposed covariance matrix not positive-definite"  << "L(" << i << "," << i << ") = " << L(i,i); 
 util::Die(1); 
} 
} 
L(i,i) = TMath::Sqrt(L(i,i)); 
for (int j = i+1; j < n; ++j) { 
L(i,j) = cov_matrix(i,j); 
for (int k = 0; k < i; ++k) { 
L(i,j) -= L(k,i)*L(k,j); 
} 
L(i,j) /= L(i,i); 
} 
} 
TMatrixD LT(TMatrixD::kTransposed,L); 
#ifdef __show_cholesky_decomposition_mesg_debug__ 
assert(1); 
for(int ip=0; ip<n; ip++) { 
for(int jp=0; jp<n; jp++) { 
assert(1); 
} 
assert(1); 
} 
#endif 
return LT; 
#endif 
} 
TVectorD valor::util::CholeskyGenerateCorrelatedParams ( const TMatrixD& cholesky_triangular, TVectorD& meanparams) { 
int ncols = cholesky_triangular.GetNcols(); 
int nrows = cholesky_triangular.GetNrows(); 
int npars = meanparams.GetNrows(); 
if(ncols != nrows) { 
assert(1); 
util::Die(1); 
} 
if(npars != nrows) { 
assert(1); 
util::Die(1); 
} 
int n = nrows; 
TVectorD g(n); 
for (int k = 0; k < n; ++k) { 
g(k) = Rnd::Instance()->RndOther().Gaus(); 
} 
g *= cholesky_triangular; 
#ifdef __show_cholesky_gen_corr_param_variations_mesg_debug__ 
ofstream foutp1("cholesky_uncorrelated_params.txt",fstream::app); 
for (int i = 0; i < n; ++i) { 
foutp1 << g[i] << "\t"; 
} 
foutp1 << endl; 
foutp1.close(); 
#endif 
TVectorD correlated_params(n); 
for (int i = 0; i < n; ++i) { 
double v = meanparams[i]; 
v += g(i); 
correlated_params[i] = v; 
} 
#ifdef __show_cholesky_gen_corr_param_variations_mesg_debug__ 
ofstream foutp2("cholesky_correlated_params.txt",fstream::app); 
for (int i = 0; i < n; ++i) { 
foutp2 << correlated_params[i] << "\t"; 
} 
foutp2 << endl; 
foutp2.close(); 
#endif 
return correlated_params; 
} 
TVectorD valor::util::CholeskyGenerateCorrelatedParams ( const TMatrixD& cholesky_triangular, TVectorD& meanparams, TVectorD& g_uncorrelated) { 
int ncols = cholesky_triangular.GetNcols(); 
int nrows = cholesky_triangular.GetNrows(); 
int npars = meanparams.GetNrows(); 
int nunco = g_uncorrelated.GetNrows(); 
if(ncols != nrows) { 
assert(1); 
util::Die(1); 
} 
if(npars != nrows) { 
assert(1); 
util::Die(1); 
} 
if(nunco != nrows) { 
assert(1); 
util::Die(1); 
} 
int n = nrows; 
g_uncorrelated *= cholesky_triangular; 
#ifdef __show_cholesky_gen_corr_param_variations_mesg_debug__ 
ofstream foutp1("cholesky_uncorrelated_params.txt",fstream::app); 
for (int i = 0; i < n; ++i) { 
foutp1 << g_uncorrelated[i] << "\t"; 
} 
foutp1 << endl; 
foutp1.close(); 
#endif 
TVectorD correlated_params(n); 
for (int i = 0; i < n; ++i) { 
double v = meanparams[i]; 
v += g_uncorrelated(i); 
correlated_params[i] = v; 
} 
#ifdef __show_cholesky_gen_corr_param_variations_mesg_debug__ 
ofstream foutp2("cholesky_correlated_params.txt",fstream::app); 
for (int i = 0; i < n; ++i) { 
foutp2 << correlated_params[i] << "\t"; 
} 
foutp2 << endl; 
foutp2.close(); 
#endif 
return correlated_params; 
} 
TVectorD valor::util::CholeskyGenerateCorrelatedParamVariations ( const TMatrixD& cholesky_triangular) { 
int ncols = cholesky_triangular.GetNcols(); 
int nrows = cholesky_triangular.GetNrows(); 
assert(ncols==nrows); 
int n = nrows; 
TVectorD g(n); 
for (int k = 0; k < n; ++k) { 
g(k) = Rnd::Instance()->RndOther().Gaus(); 
} 
g *= cholesky_triangular; 
#ifdef __show_cholesky_gen_corr_param_variations_mesg_debug__ 
assert(1); 
#endif 
return g; 
} 
TVectorD valor::util::CholeskyCalculateCorrelatedParamVariations ( const TMatrixD& cholesky_triangular, TVectorD & g_uncorrelated) { 
int ncols = cholesky_triangular.GetNcols(); 
int nrows = cholesky_triangular.GetNrows(); 
int npars = g_uncorrelated.GetNrows(); 
assert(ncols==nrows); 
assert(npars==nrows); 
TVectorD g(g_uncorrelated); 
g *= cholesky_triangular; 
#ifdef __show_cholesky_gen_corr_param_variations_mesg_debug__ 
assert(1); 
#endif 
return g; 
} 
double valor::util::RandomizeParameter(conv::PhysParamId_t p) { 
switch (p) { 
case kPhypMixing23 : return util::RandomizeMixing23 (); 
case kPhypMixing13 : return util::RandomizeMixing13 (); 
case kPhypMixing12 : return util::RandomizeMixing12 (); 
case kPhypCPV : return util::RandomizeCPV (); 
case kPhypDm23sq : return util::RandomizeDm23sq (); 
case kPhypDm12sq : return util::RandomizeDm12sq (); 
case kPhypMixing23Bar : return util::RandomizeMixing23Bar(); 
case kPhypMixing13Bar : return util::RandomizeMixing13Bar(); 
case kPhypMixing12Bar : return util::RandomizeMixing12Bar(); 
case kPhypCPVBar : return util::RandomizeCPVBar (); 
case kPhypDm23sqBar : return util::RandomizeDm23sqBar (); 
case kPhypDm12sqBar : return util::RandomizeDm12sqBar (); 
case kPhypBetaBar : return util::RandomizeBetaBar (); 
case kPhypAlphaDecay : case kPhypSinsq2ThetaDecay : case kPhypMusqDecoh : case kPhypSinsq2ThetaDecoh : case kPhypMixing14 : case kPhypMixing15 : case kPhypMixing24 : case kPhypMixing25 : case kPhypMixing34 : case kPhypMixing35 : case kPhypDm41sq : case kPhypDm51sq : case kPhypDelta12 : case kPhypDelta13 : case kPhypDelta15 : case kPhypDelta34 : case kPhypDelta35 : case kPhypNSIepsMuTau : 
#ifdef __show_parameter_randomization_warnings__ 
assert(1); 
#endif 
return -999; 
default: std::cerr<<"util/RandomizeParameter > Using default for "<<util::RawParamAsString(p)<<" ("<<p<<")"<<std::endl; 
return -999; 
} 
#ifdef __show_parameter_randomization_warnings__ 
assert(1); 
#endif 
return -999; 
} 
double valor::util::RandomizeMixing12(void) { 
double mean = Opt::Instance()->GetGlobalBestFit(kPhypMixing12); 
double sigma = mean * Opt::Instance()->GetGlobalFitError(kPhypMixing12); 
double mix = Rnd::Instance()->RndToyMCosc().Gaus(mean,sigma); 
if(mix >=0. && mix <= 1.) { 
return mix; 
} 
return util::RandomizeMixing12(); 
} 
double valor::util::RandomizeMixing23(void) { 
double mean = Opt::Instance()->GetGlobalBestFit(kPhypMixing23); 
double sigma = mean * Opt::Instance()->GetGlobalFitError(kPhypMixing23); 
double mix = Rnd::Instance()->RndToyMCosc().Gaus(mean,sigma); 
if(mix >=0. && mix <= 1.) { 
return mix; 
} 
return util::RandomizeMixing23(); 
} 
double valor::util::RandomizeMixing13(void) { 
double mean = Opt::Instance()->GetGlobalBestFit(kPhypMixing13); 
double sigma = mean * Opt::Instance()->GetGlobalFitError(kPhypMixing13); 
double mix = Rnd::Instance()->RndToyMCosc().Gaus(mean,sigma); 
if(mix >=0. && mix <= 1.) { 
return mix; 
} 
return util::RandomizeMixing13(); 
} 
double valor::util::RandomizeCPV(void) { 
NuOscDeltaCP_t cpv = Opt::Instance()->gOscDeltaCP; 
switch(cpv) { 
case (kNuDeltaCPPhase) : { 
double min = -conv::kpi; 
double max = conv::kpi; 
return Rnd::Instance()->RndToyMCosc().Uniform(min,max); 
} 
break; 
case (kNuDeltaCPSin) : { 
double min = -1.; 
double max = 1.; 
return Rnd::Instance()->RndToyMCosc().Uniform(min,max); 
} 
break; 
default: return -99999; 
} 
return -99999; 
} 
double valor::util::RandomizeDm12sq(void) { 
double mean = Opt::Instance()->GetGlobalBestFit(kPhypDm12sq); 
double sigma = mean * Opt::Instance()->GetGlobalFitError(kPhypDm12sq); 
double dm = Rnd::Instance()->RndToyMCosc().Gaus(mean,sigma); 
if(dm >= 0.) { 
return dm; 
} 
return util::RandomizeDm12sq(); 
} 
double valor::util::RandomizeDm23sq(void) { 
double mean = Opt::Instance()->GetGlobalBestFit(kPhypDm23sq); 
double sigma = mean * Opt::Instance()->GetGlobalFitError(kPhypDm23sq); 
double dm = Rnd::Instance()->RndToyMCosc().Gaus(mean,sigma); 
if(dm >= 0.) { 
return dm; 
} 
return util::RandomizeDm23sq(); 
} 
double valor::util::RandomizeMixing12Bar(void) { 
double mean = Opt::Instance()->GetGlobalBestFit(kPhypMixing12Bar); 
double sigma = mean * Opt::Instance()->GetGlobalFitError(kPhypMixing12Bar); 
double mix = Rnd::Instance()->RndToyMCosc().Gaus(mean,sigma); 
if(mix >=0. && mix <= 1.) { 
return mix; 
} 
return util::RandomizeMixing12Bar(); 
} 
double valor::util::RandomizeMixing23Bar(void) { 
double mean = Opt::Instance()->GetGlobalBestFit(kPhypMixing23Bar); 
double sigma = mean * Opt::Instance()->GetGlobalFitError(kPhypMixing23Bar); 
double mix = Rnd::Instance()->RndToyMCosc().Gaus(mean,sigma); 
if(mix >=0. && mix <= 1.) { 
return mix; 
} 
return util::RandomizeMixing23Bar(); 
} 
double valor::util::RandomizeMixing13Bar(void) { 
double mean = Opt::Instance()->GetGlobalBestFit(kPhypMixing13Bar); 
double sigma = mean * Opt::Instance()->GetGlobalFitError(kPhypMixing13Bar); 
double mix = Rnd::Instance()->RndToyMCosc().Gaus(mean,sigma); 
if(mix >=0. && mix <= 1.) { 
return mix; 
} 
return util::RandomizeMixing13Bar(); 
} 
double valor::util::RandomizeCPVBar(void) { 
NuOscDeltaCP_t cpv = Opt::Instance()->gOscDeltaCP; 
switch(cpv) { 
case (kNuDeltaCPPhase) : { 
double min = -conv::kpi; 
double max = conv::kpi; 
return Rnd::Instance()->RndToyMCosc().Uniform(min,max); 
} 
break; 
case (kNuDeltaCPSin) : { 
double min = -1.; 
double max = 1.; 
return Rnd::Instance()->RndToyMCosc().Uniform(min,max); 
} 
break; 
default: return -99999; 
} 
return -99999; 
} 
double valor::util::RandomizeDm12sqBar(void) { 
double mean = Opt::Instance()->GetGlobalBestFit(kPhypDm12sqBar); 
double sigma = mean * Opt::Instance()->GetGlobalFitError(kPhypDm12sqBar); 
double dm = Rnd::Instance()->RndToyMCosc().Gaus(mean,sigma); 
if(dm >= 0.) { 
return dm; 
} 
return util::RandomizeDm12sqBar(); 
} 
double valor::util::RandomizeDm23sqBar(void) { 
double mean = Opt::Instance()->GetGlobalBestFit(kPhypDm23sqBar); 
double sigma = mean * Opt::Instance()->GetGlobalFitError(kPhypDm23sqBar); 
double dm = Rnd::Instance()->RndToyMCosc().Gaus(mean,sigma); 
if(dm >= 0.) { 
return dm; 
} 
return util::RandomizeDm23sqBar(); 
} 
double valor::util::RandomizeBetaBar(void) { 
double mean = Opt::Instance()->GetGlobalBestFit(kPhypBetaBar); 
double sigma = mean * Opt::Instance()->GetGlobalFitError(kPhypBetaBar); 
double dm = Rnd::Instance()->RndToyMCosc().Gaus(mean,sigma); 
if(dm >= 0.) { 
return dm; 
} 
return util::RandomizeBetaBar(); 
} 
double valor::util::RandomizeUser(TH1D *hPrior) { 
return hPrior->GetRandom(); 
} 
int valor::util::RandomizeMH(const double probNH) { 
const double min = 0.; 
const double max = 1.; 
double Pnh = probNH; 
double Pih = 1 - probNH; 
if(Pnh < 0. || Pnh > 1.){ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
util::Die(1); 
} 
if(Pih < 0. || Pih > 1.){ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
util::Die(1); 
} 
double rndm = Rnd::Instance()->RndToyMCosc().Uniform(min,max); 
int MH = conv::kBadResult; 
if(rndm <= Pnh) MH = 0; 
else MH = 1; 
return MH; 
} 
double valor::util::FromSinsq2thToSinsqth(const double sinsq2th){ 
if(sinsq2th<0. || sinsq2th>1.){ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
util::Die(1); 
} 
double sinsqth = 0.5 * ( 1 - sqrt(1 - sinsq2th) ); 
if(sinsqth<0. || sinsqth>1.){ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
util::Die(1); 
} 
return sinsqth; 
} 
double valor::util::FromSinsqthToSinsq2th(const double sinsqth){ 
if(sinsqth<0. || sinsqth>1.){ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
util::Die(1); 
} 
double sinsq2th = 1 - (1 - 2*sinsqth)*(1 - 2*sinsqth); 
if(sinsq2th<0. || sinsq2th>1.){ 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
assert(1); 
util::Die(1); 
} 
return sinsq2th; 
} 
int valor::util::Sign(double tweaking_dial) { 
if(fabs(tweaking_dial) < kASmallNum) return 0; 
if (tweaking_dial < 0) return -1; 
return +1; 
} 
double valor::util::Logistic(double x) { 
return 1./(1.+std::exp(-x)); 
} 
double valor::util::Logit(double p) { 
return -std::log(1./p - 1.); 
} 
int valor::util::DiagonaliseGSL( 
#ifdef __VALOR_FMWK_GSL_ENABLED__ 
int ndim, double * matrix_in, double * eigenvectors_out, double * eigenvalues_out 
#else 
int, double *, double *, double * 
#endif 
) { 

#ifdef __VALOR_FMWK_GSL_ENABLED__ 
gsl_matrix_complex * matr = gsl_matrix_complex_alloc(ndim,ndim); 
gsl_matrix_complex * eigenvectors = gsl_matrix_complex_alloc(ndim,ndim); 
gsl_vector * eigenvalues = gsl_vector_alloc(ndim); 
gsl_eigen_hermv_workspace * workspace = gsl_eigen_hermv_alloc(ndim); 
memcpy( (double*)gsl_matrix_complex_ptr(matr,0,0), matrix_in, ndim*ndim*2*sizeof(double) ); 
int status=gsl_eigen_hermv(matr, eigenvalues, eigenvectors, workspace); 
memcpy( eigenvectors_out, (const double*)gsl_matrix_complex_const_ptr(eigenvectors,0,0) , ndim*ndim*2*sizeof(double)); 
memcpy( eigenvalues_out , (const double*)gsl_vector_const_ptr (eigenvalues ,0) , ndim*sizeof(double)); 
gsl_matrix_complex_free(matr); 
gsl_matrix_complex_free(eigenvectors); 
gsl_vector_free(eigenvalues); 
gsl_eigen_hermv_free(workspace); 
return (status != GSL_SUCCESS); 
#else 
assert(1); 
util::Die(-1); 
#endif 
} 
TMatrixD valor::util::CovarianceMatrixToCorrelationMatrix(const TMatrixD & cov_m) { 
int n = cov_m.GetNrows(); 
TMatrixD corr_m(n,n); 
for (int ii = 0 ; ii < n; ii++) { 
for (int jj = 0 ; jj < n; jj++) { 
corr_m[ii][jj] = cov_m[ii][jj] / sqrt(cov_m[ii][ii] * cov_m[jj][jj]); 
} 
} 
return corr_m; 
} 
TVectorD valor::util::CovarianceMatrixToErrorVector(const TMatrixD & cov_m) { 
int n = cov_m.GetNrows(); 
TVectorD vec(n); 
for (int ii = 0 ; ii < n; ii++) { 
vec[ii] = std::sqrt(cov_m[ii][ii]); 
} 
return vec; 
} 
TMatrixD valor::util::CorrelationAndErrorToCovarianceMatrix(const TMatrixD & corr, const TVectorD & one_sigma) { 
int n = corr.GetNrows(); 
if (n!=one_sigma.GetNrows()) { 
assert(1); 
util::Die(-1); 
return TMatrixD(); 
} 
TMatrixD cov_m(n,n); 
for (int ii = 0 ; ii < n; ii++) { 
for (int jj = 0 ; jj < n; jj++) { 
cov_m[ii][jj] = corr[ii][jj] * one_sigma[ii] * one_sigma[jj]; 
} 
} 
return cov_m; 
} 
TMatrixDSym valor::util::MatrixToSymMatrix(const TMatrixD & m) { 
int n = m.GetNrows(); 
TMatrixDSym out (n); 
if (n!=m.GetNcols()) { 
assert(1); 
util::Die(-1); 
return out; 
} 
bool bad = false; 
for (int ii = 0 ; ii < n; ii++) { 
for (int jj = 0 ; jj <= ii; jj++) { 
double v1 = m[ii][jj]; 
double v2 = m[jj][ii]; 
out[ii][jj] = v1; 
out[jj][ii] = v2; 
if (std::fabs(v1) > conv::kAVerySmallNum && (std::fabs(v1/v2 - v2/v1) > conv::kASmallNum)) { 
bad = true; 
} 
} 
} 
if (bad) { 
assert(1); 
util::Die(-1); 
} 
return out; 
} 
TMatrixDSym valor::util::LowerTriangularMatrixToSymMatrix(const TMatrixD & m) { 
int n = m.GetNrows(); 
TMatrixDSym out (n); 
if (n!=m.GetNcols()) { 
assert(1); 
util::Die(-1); 
return out; 
} 
for (int ii = 0 ; ii < n; ii++) { 
for (int jj = 0 ; jj <= ii; jj++) { 
double v1 = m[ii][jj]; 
out[ii][jj] = v1; 
out[jj][ii] = v1; 
} 
} 
return out; 
} 
TMatrixD valor::util::MatrixPseudoInverted(const TMatrixD & m) { 
TDecompSVD svd(m); 
TMatrixD output(m); 
svd.Invert(output); 
return output; 
} 
TVectorD valor::util::ConcatenateTVectors ( const vector< const TVectorD * > & tvecs ) { 
unsigned int vsize = tvecs.size(); 
vector<int> edge_vec(vsize+1); 
edge_vec[0] = 0; 
for (unsigned int i = 0 ; i < vsize; i++) { 
edge_vec[i+1] = edge_vec[i] + tvecs.at(i)->GetNoElements(); 
} 
TVectorD output(edge_vec[vsize]); 
for (unsigned int i = 0 ; i < vsize; i++) { 
output.SetSub(edge_vec[i],*tvecs.at(i)); 
} 
return output; 
} 
TMatrixD valor::util::ConcatenateTMatrices ( const std::vector<const TMatrixD *> & tmats ) { 
unsigned int vsize = tmats.size(); 
vector<int> edge_vec_x(vsize+1); 
edge_vec_x[0] = 0; 
vector<int> edge_vec_y(vsize+1); 
edge_vec_y[0] = 0; 
for (unsigned int i = 0 ; i < vsize; i++) { 
edge_vec_x[i+1] = edge_vec_x[i] + tmats.at(i)->GetNrows(); 
edge_vec_y[i+1] = edge_vec_y[i] + tmats.at(i)->GetNcols(); 
} 
TMatrixD output(edge_vec_x[vsize],edge_vec_y[vsize]); 
for (unsigned int i = 0 ; i < vsize; i++) { 
output.SetSub(edge_vec_x[i],edge_vec_y[i],*tmats.at(i)); 
} 
return output; 
} 
double valor::util::SingleAngleToDoubleAngle(double sinsqtheta) { 
double sinsq2theta = 1 - (1-2*sinsqtheta)*(1-2*sinsqtheta); 
return sinsq2theta; 
} 
double valor::util::DoubleAngleToSingleAngle(double sinsq2theta) { 
double sinsqtheta = 0.5 * (1 - sqrt(1 - sinsq2theta)); 
return sinsqtheta; 
} 
TAxis valor::util::EstimateOptimalBinning(int npoints, double * points) { 
double desired_quantiles[5] = {0,0.25,0.5,0.75,1.}; 
double quantiles_out[5]; 
TMath::Quantiles(npoints,5,points,quantiles_out,desired_quantiles,false); 
double iqr = quantiles_out[3]-quantiles_out[1]; 
double bin_size = 2 * iqr * pow(npoints,-.33333333333333); 
double xmax = quantiles_out[4]; 
double xmin = quantiles_out[0]; 
int nbins = TMath::Nint((xmax-xmin)/bin_size); 
return TAxis(nbins,xmin,xmax); 
} 
int valor::util::EstimateOptimalNumberOfBinsForGaussian(int npoints, double nsigma) { 
static const double iqr = 27./20.; 
double bin_size = 2. * iqr * pow(npoints,-.33333333333333); 
int nbins = TMath::Nint(2*nsigma/bin_size); 
return nbins; 
} 
double valor::util::FractionOfBinContained(double min1, double max1, double min2, double max2) { 
double range1 = max1-min1; 
double overlap; 
if (min1 >= min2 && max1 <= max2) {overlap = max1 - min1;} 
else if(min2 >= min1 && max2 <= max1) {overlap = max2 - min2;} 
else if(max1 > max2 && min1 >= min2) {overlap = max2 - min1;} 
else if(min1 < min2 && max1 <= max2) {overlap = max1 - min2;} 
else { 
overlap = 0; 
} 
return TMath::Max(overlap/range1,0.); 
} 
bool valor::util::SplineIsFlat(const TSpline * spl) { 
bool flat = true; 
double x,y; 
for (int i = 0 ; i < spl->GetNp() ; i++) { 
spl->GetKnot(i,x,y); 
if (std::fabs(y-1) > conv::kASmallNum) {flat = false;} 
} 
return flat; 
} 
#ifdef __VALOR_FMWK_GSL_ENABLED__ 
bool valor::util::SplineIsFlat(const ROOT::Math::Interpolator * spl) { 
bool flat = true; 
static const double x[6] = {-389931,-3E-2,0.,1.,7.,123210.}; 
for (int i = 0 ; i < 6; i++) { 
double y = spl->Eval(x[i]); 
if (std::fabs(y-1) > conv::kASmallNum) {flat = false;} 
} 
return flat; 
} 
#else 
bool valor::util::SplineIsFlat(const ROOT::Math::Interpolator * ) { 
return true; 
} 
#endif 
#ifdef __VALOR_FMWK_GSL_ENABLED__ 
ROOT::Math::Interpolator * valor::util::ConvertTSplineToGSL(const TSpline & spl, Option_t * type) { 
assert(1); 
int n_knots = spl.GetNp(); 
TString type_ts(type); 
ROOT::Math::Interpolation::Type spl_type = ROOT::Math::Interpolation::kCSPLINE; 
if (type_ts.Contains("akima")) { 
spl_type = ROOT::Math::Interpolation::kAKIMA; 
assert(n_knots>=5); 
} 
vector<double> x(n_knots); 
vector<double> y(n_knots); 
for (int i = 0 ; i < n_knots; i++) { 
spl.GetKnot(i,x[i],y[i]); 
} 
ROOT::Math::Interpolator * out_interp = new ROOT::Math::Interpolator(n_knots,spl_type); 
out_interp->SetData(n_knots,x.data(),y.data()); 
return out_interp; 
} 
ROOT::Math::Interpolator * valor::util::ConvertTSplineToGSL(const TSpline & spl, double xmin, double xmax, Option_t * type) { 
assert(1); 
int n_knots = spl.GetNp(); 
TString type_ts(type); 
ROOT::Math::Interpolation::Type spl_type = ROOT::Math::Interpolation::kCSPLINE; 
if (type_ts.Contains("akima")) { 
spl_type = ROOT::Math::Interpolation::kAKIMA; 
assert(n_knots>=3); 
} 
vector<double> x(n_knots+2); 
vector<double> y(n_knots+2); 
for (int i = 0 ; i < n_knots; i++) { 
spl.GetKnot(i,x[i+1],y[i+1]); 
} 
x.front() = xmin; 
y.front() = spl.Eval(xmin); 
x.back() = xmax; 
y.back() = spl.Eval(xmax); 
ROOT::Math::Interpolator * out_interp = new ROOT::Math::Interpolator(n_knots,spl_type); 
out_interp->SetData(n_knots+2,x.data(),y.data()); 
return out_interp; 
} 
#else 
ROOT::Math::Interpolator * valor::util::ConvertTSplineToGSL(const TSpline & , Option_t * ) { 
assert(!"ConvertTSplineToGSL not available without GSL!"); 
return NULL; 
} 
ROOT::Math::Interpolator * valor::util::ConvertTSplineToGSL(const TSpline & , double, double, Option_t * ) { 
assert(!"ConvertTSplineToGSL not available without GSL!"); 
return NULL; 
} 
#endif 
bool pair_compare_by_first(const pair<double,int> & lhs, const pair<double,int> & rhs) {return lhs.first < rhs.first;} 
void valor::util::ReorderMatrixAndVector (TVectorD & sort_by, TMatrixD & matr, bool descending, bool reorder_rows, bool reorder_cols) { 
if ((sort_by.GetNoElements() != matr.GetNrows()) && (sort_by.GetNoElements() != matr.GetNcols()) ) { 
assert(1); 
return; 
} 
TMatrixD matcopy(matr); 
vector<pair<double,int> > vec_indices; 
for (int i = 0 ; i < sort_by.GetNoElements(); i++) { 
std::pair<double,int> p(sort_by[i],i); 
vec_indices.push_back(p); 
} 
if (descending) { 
std::sort(vec_indices.rbegin(),vec_indices.rend(),pair_compare_by_first); 
} 
else { 
std::sort(vec_indices.begin(),vec_indices.end(),pair_compare_by_first); 
} 
for (unsigned int i = 0 ; i < vec_indices.size() ; i++) { 
int orig_i = vec_indices[i].second; 
sort_by[i] = vec_indices[i].first; 
for (unsigned int j = 0 ; j < vec_indices.size() ; j++) { 
int orig_j = vec_indices[j].second; 
int ind_i = (reorder_rows ? orig_i : i); 
int ind_j = (reorder_cols ? orig_j : j); 
matr(i,j) = matcopy(ind_i,ind_j); 
} 
} 
return; 
} 
double valor::util::Chisq_Penalty_TH2D(TH2D* hobs, TH2D* hexp) { 
int nbins_x = hobs->GetNbinsX(); 
int nbins_y = hobs->GetNbinsY(); 
double chisq = 0; 
for(int i=1;i<= nbins_x;i++) { 
for(int j=1;j<= nbins_y;j++) { 
double obs = hobs->GetBinContent(i,j); 
double exp = hexp->GetBinContent(i,j); 
chisq += valor::util::ChisqPoisson(obs,exp); 
} 
} 
return chisq; 
} 
double valor::util::ChisqMeanLikelihood(std::vector<double> chisqs) { 
std::sort(chisqs.begin(),chisqs.end()); 
double log_a0 = -0.5 * chisqs[0]; 
double internal_sum = 1.; 
for (unsigned int ii = 1 ; ii < chisqs.size() ; ii++) { 
double log_ai = -0.5 * chisqs[ii]; 
internal_sum += std::exp(log_ai-log_a0); 
} 
double log_sum = log_a0 + std::log(internal_sum); 
double log_mean = log_sum - std::log(chisqs.size()); 
double chisq_mean = -2. * log_mean; 
return chisq_mean; 
} 
namespace valor { 
namespace util { 
namespace plotting { 
void GenericPlot(TH1* histogram, const std::string& title, const std::string& xTitle, const std::string yTitle, const std::string& filename, const std::string& options) { 
TCanvas c("Canvas", "", 800, 600); 
c.cd(); 
histogram->SetTitle(title.c_str()); 
histogram->SetStats(false); 
TAxis* x = histogram->GetXaxis(); 
x->SetTitle(xTitle.c_str()); 
x->SetTitleOffset(1.2); 
TAxis* y = histogram->GetYaxis(); 
y->SetTitle(yTitle.c_str()); 
y->SetTitleOffset(1.2); 
histogram->Draw(options.c_str()); 
c.Print(filename.c_str()); 
} 
void Plot(TH2D* histogram, const std::string& title, const std::string& xTitle, const std::string yTitle, const std::string& filename) { 
GenericPlot(histogram, title, xTitle, yTitle, filename, "colz"); 
} 
void Plot(TH1D* histogram, const std::string& title, const std::string& xTitle, const std::string yTitle, const std::string& filename) { 
GenericPlot(histogram, title, xTitle, yTitle, filename, ""); 
} 
} 
} 
} 
void valor::util::PrintVector( const TVectorD & v, int w, int prec, Option_t * option, std::ostream & stream) { 
TString opt = option; 
int np = v.GetNoElements(); 
stream << fixed; 
for(int ip = 0; ip < np; ip++) { 
stream << "> param = " << setw(3) << ip; 
stream << " - value = " << setw(w) << setprecision(prec) << v[ip] << endl; 
} 
stream.unsetf( ios::basefield | ios::floatfield); 
} 
void valor::util::PrintVectorPair( const TVectorD & current, const TVectorD & nominal, int w, int prec, Option_t * option, std::ostream & stream) { 
TString opt = option; 
int np = current.GetNoElements(); 
stream << fixed; 
for(int ip = 0; ip < np; ip++) { 
stream << "> param = " << setw(3) << ip; 
stream << " - current = " << setw(w) << setprecision(prec) << current[ip]; 
stream << " - nominal = " << setw(w) << setprecision(prec) << nominal[ip]; 
if(fabs(nominal[ip]) > conv::kASmallNum) { 
stream << " - current/nominal = " << setw(w) << setprecision(prec) << current[ip]/nominal[ip]; 
} 
stream << endl; 
} 
stream.unsetf( ios::basefield | ios::floatfield); 
} 
void valor::util::PrintMatrix( const TMatrixD & m, int w, int prec, std::ostream & stream) { 
int nc = m.GetNcols(); 
int nr = m.GetNrows(); 
stream << fixed; 
for(int ir=0; ir<nr; ir++) { 
if(ir==0) { 
stream << setw(w) << setfill(' ') << "r\\c:" << " | "; 
for(int ic=0; ic<nc; ic++) { 
stream << setw(w) << setfill(' ') << setprecision(0) << ic << " | "; 
} 
stream << endl; 
} 
stream << setw(w) << setfill(' ') << setprecision(0) << ir << " | "; 
for(int ic=0; ic<nc; ic++) { 
stream << setw(w) << setfill(' ') << setprecision(prec) << m[ir][ic] << " | "; 
} 
stream << endl; 
} 
stream.unsetf( ios::basefield | ios::floatfield); 
} 
void valor::util::PrintVector( const TVectorD & v, const PhysParamId_t * params, int w, int prec, Option_t * , std::ostream & stream) { 
int np = v.GetNoElements(); 
stream << fixed; 
for(int ip = 0; ip < np; ip++) { 
PhysParamId_t p = params[ip]; 
stream << "> param = " << setw(3) << ip; 
stream << setw(42) << NameRegistry::Instance()->AsString(p); 
stream << " ]"; 
stream << " - value = " << setw(w) << setprecision(prec) << v[ip] << endl; 
} 
stream.unsetf( ios::basefield | ios::floatfield); 
} 
void valor::util::PrintVectorPair( const TVectorD & current, const TVectorD & nominal, const PhysParamId_t * params, int w, int prec, Option_t * , std::ostream & stream) { 
int np = current.GetNoElements(); 
stream << fixed; 
for(int ip = 0; ip < np; ip++) { 
PhysParamId_t p = params[ip]; 
stream << "> param = " << setw(3) << ip; 
stream << " [ "; 
stream << setw(30) << NameRegistry::Instance()->AsString(p); 
stream << " ]"; 
stream << " - current = " << setw(w) << setprecision(prec) << current[ip]; 
stream << " - nominal = " << setw(w) << setprecision(prec) << nominal[ip]; 
if(fabs(nominal[ip]) > conv::kASmallNum) { 
stream << " - current/nominal = " << setw(w) << setprecision(prec) << current[ip]/nominal[ip]; 
} 
stream << endl; 
} 
stream.unsetf( ios::basefield | ios::floatfield); 
} 
#ifdef __VALOR_SLACK_TOKEN__ 
void valor::util::NotifySlack (std::string message, std::string channel, std::string username) { 
static const TString request_pattern("curl -X POST --data-urlencode \ \'payload={\"channel\": \"[CHANNEL]\", \"username\": \"[USERNAME]\", \"text\": \"[MESSAGE]\"}\' \ 
https://hooks.slack.com/services/[TOKEN]"); 
TString escaped_message(message); 
escaped_message.ReplaceAll("'","'\\''"); 
TString request = request_pattern; 
request = request.ReplaceAll("[MESSAGE]" ,escaped_message.Data()); 
request = request.ReplaceAll("[CHANNEL]" ,channel .c_str()); 
request = request.ReplaceAll("[USERNAME]",username.c_str()); 
request = request.ReplaceAll("[TOKEN]" ,__VALOR_SLACK_TOKEN__); 
assert(1); 
system(request.Data()); 
} 
#else 
void valor::util::NotifySlack (std::string , std::string , std::string ) {} 
#endif 
string valor::util::TrimSpaces(string input) { 
if( input.find_first_not_of(" \n") != 0) input.erase( 0, input.find_first_not_of(" \n") ); 
if( input.find_last_not_of(" \n") != input.length() ) input.erase( input.find_last_not_of(" \n")+1, input.length() ); 
return input; 
} 
vector<string> valor::util::Tokens (string input, string delimiter) { 
vector<string> tokens; 
while(input.find_first_of(delimiter) < input.length()) { 
tokens.push_back( input.substr(0, input.find_first_of(delimiter)) ); 
input = input.substr(input.find_first_of(delimiter)+1, input.length()); 
} 
tokens.push_back(input); 
return tokens; 
} 
string valor::util::ToLowerCase(string data) { 
std::transform(data.begin(), data.end(), data.begin(), ::tolower); 
return data; 
} 
string valor::util::ReplaceAll(string data,string from, string to) { 
size_t pos = 0; 
while ((pos = data.find(from, pos)) != std::string::npos) { 
data.replace(pos, from.length(), to); 
pos += to.length(); 
} 
return data; 
} 
string valor::util::PadToLengthFromLeft(string data, unsigned int length, char pad_with) { 
if(length > data.size()) { 
data.insert(0, length - data.size(), pad_with); 
} 
return data; 
} 
string valor::util::PadToLength(string data, unsigned int length, char pad_with) { 
data.append(length-data.length(),pad_with); 
return data; 
} 
void util::SetDefaultStyle(bool black_n_white) { 
gROOT->SetStyle("Plain"); 
gStyle -> SetPadTickX (1); 
gStyle -> SetPadTickY (1); 
gStyle -> SetCanvasBorderMode (0); 
gStyle -> SetFrameBorderMode (0); 
gStyle -> SetPadBorderMode (0); 
gStyle -> SetDrawBorder (0); 
gStyle -> SetCanvasBorderSize (0); 
gStyle -> SetFrameBorderSize (0); 
gStyle -> SetPadBorderSize (0); 
gStyle -> SetTitleBorderSize (0); 
gStyle -> SetCanvasDefH (600); 
gStyle -> SetCanvasDefW (730); 
gStyle -> SetCanvasDefX (10); 
gStyle -> SetCanvasDefY (10); 
gStyle -> SetMarkerStyle (20); 
gStyle -> SetMarkerSize (1); 
gStyle -> SetFrameLineWidth (1); 
gStyle -> SetFuncWidth (2); 
gStyle -> SetHistLineWidth (3); 
gStyle -> SetFuncColor (2); 
gStyle -> SetFuncWidth (3); 
gStyle -> SetPadTopMargin (0.10); 
gStyle -> SetPadBottomMargin (0.20); 
gStyle -> SetPadLeftMargin (0.15); 
gStyle -> SetPadRightMargin (0.03); 
gStyle -> SetNdivisions (505,"xyz"); 
gStyle -> SetLabelSize (0.050, "xyz"); 
gStyle -> SetLabelOffset (0.005, "x" ); 
gStyle -> SetLabelOffset (0.005, "y" ); 
gStyle -> SetLabelOffset (0.005, "z" ); 
gStyle -> SetTitleSize (0.060, "xyz"); 
gStyle -> SetTitleOffset (1.200, "xz" ); 
gStyle -> SetTitleOffset (1.000, "y" ); 
gStyle -> SetLabelFont(42, "xyz"); 
gStyle -> SetTitleFont(42, "xyz"); 
gStyle -> SetStatFont (42); 
gStyle -> SetOptDate (0); 
gStyle -> SetOptFile (0); 
gStyle -> SetOptStat (0); 
gStyle -> SetStatFormat ("6.2f"); 
gStyle -> SetFitFormat ("8.4f"); 
gStyle -> SetOptFit (1); 
gStyle -> SetStatH (0.20); 
gStyle -> SetStatStyle (0); 
gStyle -> SetStatW (0.30); 
gStyle -> SetStatX (0.845); 
gStyle -> SetStatY (0.845); 
gStyle -> SetOptTitle (0); 
gStyle -> SetTitleX (0.15); 
gStyle -> SetTitleW (0.75); 
gStyle -> SetTitleY (0.90); 
gStyle -> SetPalette (1); 
gStyle -> SetLegendBorderSize (0); 
gStyle -> SetPaperSize (TStyle::kA4); 
if(black_n_white){ 
const int ncol = 7; 
double red [ncol]; 
double green [ncol]; 
double blue [ncol]; 
double stops [ncol]; 
double dcol = -1/double(ncol); 
double gray = 1; 
for (int j = 0; j < ncol; j++) { 
stops[j] = double(j)/double(ncol-1); 
red [j] = gray; 
blue [j] = gray; 
green[j] = gray; 
gray += dcol; 
} 
UInt_t totcol=50; 
TColor::CreateGradientColorTable(ncol,stops,red,green,blue,totcol); 
gStyle -> SetFuncWidth (1); 
gStyle -> SetHistLineWidth (1); 
gStyle -> SetFuncColor (1); 
gStyle -> SetFuncWidth (1); 
} 
gROOT->ForceStyle(); 
} 
void util::Format( TGraph* gr, int lcol, int lsty, int lwid, int mcol, int msty, double msiz) { 
if(!gr) return; 
if (lcol >= 0) gr -> SetLineColor (lcol); 
if (lsty >= 0) gr -> SetLineStyle (lsty); 
if (lwid >= 0) gr -> SetLineWidth (lwid); 
if (mcol >= 0) gr -> SetMarkerColor (mcol); 
if (msty >= 0) gr -> SetMarkerStyle (msty); 
if (msiz >= 0) gr -> SetMarkerSize (msiz); 
} 
void util::Format( TH1* hst, int lcol, int lsty, int lwid, int mcol, int msty, double msiz) { 
if(!hst) return; 
if (lcol >= 0) hst -> SetLineColor (lcol); 
if (lsty >= 0) hst -> SetLineStyle (lsty); 
if (lwid >= 0) hst -> SetLineWidth (lwid); 
if (mcol >= 0) hst -> SetMarkerColor (mcol); 
if (msty >= 0) hst -> SetMarkerStyle (msty); 
if (msiz >= 0) hst -> SetMarkerSize (msiz); 
} 
void util::PrintBanner(string filename, UInt_t wait_msec) { 
ifstream banner(filename.c_str(), ios::in); 
if( banner.is_open() ) { 
banner.seekg(0, ios::end); 
int length = banner.tellg(); 
char * buffer = new char[length]; 
banner.seekg(0, ios::beg); 
banner.read(buffer, length); 
assert(1); 
cout.write(buffer,length); 
assert(1); 
delete [] buffer; 
gSystem->Sleep(wait_msec); 
} 
} 
void util::Verbosity(string filename) { 
Messenger * msg = Messenger::Instance(); 
bool ok = msg->Configure(filename); 
if(!ok) { 
assert(1); 
} 
} 
#define USE_TERMINAL_COLOR 
void valor::util::Die(int status_code) { 
if (Opt::Instance()->gDoNotDie) { 

#ifdef USE_TERMINAL_COLOR 
assert(1); 
#endif 
assert(1); 
#ifdef USE_TERMINAL_COLOR 
assert(1); 
#endif 
return; 
} 
#ifdef __VALOR_FMWK_FAULT_ON_DIE__ 
assert(1); 
((TSystem*)(NULL))->Abort(); 
#else 
assert(1); 
#endif 
exit(status_code); 
} 
void valor::util::ChangeInterpreterPrompt(std::string new_prompt) { 
TString appname = gApplication->ApplicationName(); 
if (appname.Contains("Rint")) { 
TString command = TString::Format( "((TRint*)gApplication)->SetPrompt(\"%s\");", new_prompt.c_str()); 
gROOT->ProcessLine(command.Data()); 
} 
} 
std::vector<std::string> valor::util::GetLinkedLibraries(std::string executable_path, std::string pattern) { 
TString command = TString::Format("ldd %s | grep -e %s",executable_path.c_str(),pattern.c_str()); 
FILE * f = gSystem->OpenPipe(command.Data(),"r"); 
TPRegexp re("(lib[\\w.]*) => (.*)[\\s]+(?=\\(0[xX][0-9a-fA-F]+\\))"); 
vector<string> out_lines; 
while (true) { 
TString line; 
if (!line.Gets(f)) {break;} 
TObjArray * arr = re.MatchS(line); 
if (arr->GetEntries()!=3) {util::Die(-1);} 
TObjString * os = dynamic_cast<TObjString*>(arr->At(2)); 
if (!os) {util::Die(-1);} 
std::string out_line(os->GetString().Data()); 
out_lines.push_back(out_line); 
} 
gSystem->ClosePipe(f); 
return out_lines; 
} 
std::string valor::util::CompleteConfigPath(std::string config_file) { 
TString ts_file = util::TrimSpaces(config_file.c_str()); 
if (ts_file.Length()==0) { 
assert(1); 
util::Die(-1) ; return ""; 
} 
gSystem->ExpandPathName(ts_file); 
FileStat_t dummy; 
if (gSystem->GetPathInfo(ts_file.Data(), dummy)) { 
ts_file = TString::Format("%s%s",Env::Instance()->TopLevelConfDir().c_str(),ts_file.Data()); 
if (gSystem->GetPathInfo(ts_file.Data(), dummy)) { 
assert(1); 
util::Die(1); 
} 
} 
return std::string(ts_file.Data()); 
} 
XMLNodePointer_t valor::util::FindNode( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path) { 
vector<string> node_path_vec = Tokens(node_path,"/"); 
unsigned int ndepth = node_path_vec.size(); 
unsigned int idepth = 0; 
XMLNodePointer_t curr_node = xml_eng->GetChild(top_node); 
while(curr_node) { 
string curr_node_name = xml_eng->GetNodeName(curr_node); 
if(node_path_vec[idepth] == curr_node_name) { 
idepth++; 
if(idepth == ndepth) { 
return curr_node; 
} else { 
curr_node = xml_eng->GetChild(curr_node); 
} 
} else { 
curr_node = xml_eng->GetNext(curr_node); 
} 
} 
return 0; 
} 
vector<XMLNodePointer_t> valor::util::FindNodes(TXMLEngine* xml_eng, XMLNodePointer_t top_node, const string& tag) { 
vector<XMLNodePointer_t> nodes; 
XMLNodePointer_t node = xml_eng->GetChild(top_node); 
if(node) { 
if(xml_eng->GetNodeName(node) == tag) { 
nodes.push_back(node); 
} 
while((node = xml_eng->GetNext(node))) { 
if(xml_eng->GetNodeName(node) == tag) { 
nodes.push_back(node); 
} 
} 
} 
return nodes; 
} 
bool valor::util::NodeExists( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path) { 
vector<string> node_path_vec = Tokens(node_path,"/"); 
unsigned int ndepth = node_path_vec.size(); 
unsigned int idepth = 0; 
XMLNodePointer_t curr_node = xml_eng->GetChild(top_node); 
while(curr_node) { 
string curr_node_name = xml_eng->GetNodeName(curr_node); 
if(node_path_vec[idepth] == curr_node_name) { 
idepth++; 
if(idepth == ndepth) { 
return true; 
} else { 
curr_node = xml_eng->GetChild(curr_node); 
} 
} else { 
curr_node = xml_eng->GetNext(curr_node); 
} 
} 
return false; 
} 
bool valor::util::XML2Bool( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path) { 
assert(1); 
XMLNodePointer_t found_node = FindNode(xml_eng,top_node,node_path); 
if(!found_node) { 
assert(1); 
util::Die(1); return false; 
} 
string content = TrimSpaces(xml_eng->GetNodeContent(found_node)); 
if(content == "true" || content == "TRUE" || content == "True" || content == "1" || content == "I") return true; 
if(content == "false" || content == "FALSE" || content == "False" || content == "0" || content == "O") return false; 
assert(1); 
util::Die(1); 
return false; 
} 
int valor::util::XML2Int( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path) { 
assert(1); 
XMLNodePointer_t found_node = FindNode(xml_eng,top_node,node_path); 
if(!found_node) { 
assert(1); 
util::Die(1); return -1; 
} 
string content = xml_eng->GetNodeContent(found_node); 
int value = atoi(content.c_str()); 
return value; 
} 
double valor::util::XML2Dbl( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path) { 
assert(1); 
XMLNodePointer_t found_node = FindNode(xml_eng,top_node,node_path); 
if(!found_node) { 
assert(1); 
util::Die(1); return conv::kBadResult; 
} 
string content = xml_eng->GetNodeContent(found_node); 
double value = atof(content.c_str()); 
return value; 
} 
vector<double> valor::util::XML2DblArray( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path) { 
assert(1); 
vector<double> array; 
XMLNodePointer_t found_node = FindNode(xml_eng,top_node,node_path); 
if(!found_node) { 
assert(1); 
util::Die(1); return array; 
} 
const char * nc = xml_eng->GetNodeContent(found_node); 
if (not nc) return array; 
string content = TrimSpaces(nc); 
vector<string> str_tokens = Tokens(content, ","); 
vector<string>::const_iterator str_tokens_iter = str_tokens.begin(); 
for( ; str_tokens_iter != str_tokens.end(); ++str_tokens_iter) { 
string token = TrimSpaces(*str_tokens_iter); 
if (not token.size() ) continue; 
array.push_back( atof(token.c_str()) ); 
} 
return array; 
} 
string valor::util::XML2String( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path) { 
assert(1); 
XMLNodePointer_t found_node = FindNode(xml_eng,top_node,node_path); 
if(!found_node) { 
assert(1); 
util::Die(1); return "badstring"; 
} 
const char * nc = xml_eng->GetNodeContent(found_node); 
if (not nc) return string(""); 
string content(nc); 
return TrimSpaces(content); 
} 
pair<double,double> valor::util::XML2DblDblPair( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path) { 
assert(1); 
XMLNodePointer_t found_node = FindNode(xml_eng,top_node,node_path); 
pair<double,double> pair; 
if(!found_node) { 
assert(1); 
util::Die(1); return pair; 
} 
const char * nc = xml_eng->GetNodeContent(found_node); 
if (not nc) return pair; 
string content = TrimSpaces(nc); 
vector<string> str_tokens = Tokens(content, ","); 
if(str_tokens.size() != 2) { 
assert(1); 
util::Die(1); return pair; 
} 
pair.first = atof(str_tokens[0].c_str()); 
pair.second = atof(str_tokens[1].c_str()); 
return pair; 
} 
string valor::util::XML2RootFileName( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path) { 
string filename = XML2String(xml_eng,top_node,node_path+"/filename"); 
assert(1); 
return filename; 
} 
string valor::util::XML2RootObjName ( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path) { 
string objname = XML2String(xml_eng,top_node,node_path+"/objname"); 
assert(1); 
return objname; 
} 
string valor::util::XML2RootObjType ( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path) { 
string objtype = XML2String(xml_eng,top_node,node_path+"/objtype"); 
assert(1); 
return objtype; 
} 
TFile * valor::util::XML2TFile( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir) { 
assert(1); 
string filename = XML2RootFileName(xml_eng,top_node,node_path); 
string used_base_dir = base_dir; 
if(base_dir.find("<env>") != string::npos) { 
used_base_dir = Env::Instance()->TopLevelDataDir(); 
} 
TString full_filename = TString::Format("%s/%s", used_base_dir.c_str(), filename.c_str()); 
TFile * file = new TFile(full_filename.Data(),"read"); 
if(!file) { 
assert(1); 
util::Die(1); return 0; 
} 
if(file->IsZombie()) { 
assert(1); 
util::Die(1); return 0; 
} 
return file; 
} 
TH1F * valor::util::XML2TH1F( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir) { 
assert(1); 
string filename = XML2RootFileName(xml_eng,top_node,node_path); 
string objname = XML2RootObjName (xml_eng,top_node,node_path); 
string used_base_dir = base_dir; 
if(base_dir.find("<env>") != string::npos) { 
used_base_dir = Env::Instance()->TopLevelDataDir(); 
} 
TString full_filename = TString::Format("%s/%s", used_base_dir.c_str(), filename.c_str()); 
TFile file(full_filename,"read"); 
TH1F * h = (TH1F*)file.Get(objname.c_str()); 
if(!h) { 
assert(1); 
file.Close(); 
util::Die(1); return 0; 
} 
TH1F * hcopy = new TH1F(*h); 
hcopy->SetDirectory(0); 
file.Close(); 
return hcopy; 
} 
TGraph * valor::util::XML2TGraph( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir) { 
assert(1); 
string filename = XML2RootFileName(xml_eng,top_node,node_path); 
string objname = XML2RootObjName (xml_eng,top_node,node_path); 
string used_base_dir = base_dir; 
if(base_dir.find("<env>") != string::npos) { 
used_base_dir = Env::Instance()->TopLevelDataDir(); 
} 
TString full_filename = TString::Format("%s/%s", used_base_dir.c_str(), filename.c_str()); 
TFile file(full_filename,"read"); 
TGraph * h = (TGraph*)file.Get(objname.c_str()); 
if(!h) { 
assert(1); 
file.Close(); 
util::Die(1); return 0; 
} 
TGraph * hcopy = new TGraph(*h); 
file.Close(); 
return hcopy; 
} 
TH1D * valor::util::XML2TH1D( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir) { 
assert(1); 
string filename = XML2RootFileName(xml_eng,top_node,node_path); 
string objname = XML2RootObjName (xml_eng,top_node,node_path); 
string used_base_dir = base_dir; 
if(base_dir.find("<env>") != string::npos) { 
used_base_dir = Env::Instance()->TopLevelDataDir(); 
} 
TString full_filename = TString::Format("%s/%s", used_base_dir.c_str(), filename.c_str()); 
TFile file(full_filename,"read"); 
TH1D * h = (TH1D*)file.Get(objname.c_str()); 
if(!h) { 
assert(1); 
file.Close(); 
util::Die(1); return 0; 
} 
TH1D * hcopy = new TH1D(*h); 
hcopy->SetDirectory(0); 
delete h; 
file.Close(); 
return hcopy; 
} 
TH2D * valor::util::XML2TH2D( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir) { 
assert(1); 
string filename = XML2RootFileName(xml_eng,top_node,node_path); 
string objname = XML2RootObjName (xml_eng,top_node,node_path); 
string used_base_dir = base_dir; 
if(base_dir.find("<env>") != string::npos) { 
used_base_dir = Env::Instance()->TopLevelDataDir(); 
} 
TString full_filename = TString::Format("%s/%s", used_base_dir.c_str(), filename.c_str()); 
TFile file(full_filename,"read"); 
TH2D * h2 = (TH2D*)file.Get(objname.c_str()); 
if(!h2) { 
assert(1); 
file.Close(); 
util::Die(1); return 0; 
} 
TH2D * h2copy = new TH2D(*h2); 
h2copy->SetDirectory(0); 
delete h2; 
file.Close(); 
return h2copy; 
} 
TH3D * valor::util::XML2TH3D( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir) { 
assert(1); 
string filename = XML2RootFileName(xml_eng,top_node,node_path); 
string objname = XML2RootObjName (xml_eng,top_node,node_path); 
string used_base_dir = base_dir; 
if(base_dir.find("<env>") != string::npos) { 
used_base_dir = Env::Instance()->TopLevelDataDir(); 
} 
TString full_filename = TString::Format("%s/%s", used_base_dir.c_str(), filename.c_str()); 
TFile file(full_filename,"read"); 
TH3D * h2 = (TH3D*)file.Get(objname.c_str()); 
if(!h2) { 
assert(1); 
file.Close(); 
util::Die(1); return 0; 
} 
TH3D * h2copy = new TH3D(*h2); 
h2copy->SetDirectory(0); 
delete h2; 
file.Close(); 
return h2copy; 
} 
TTree * valor::util::XML2TTree( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir) { 
assert(1); 
string filename = XML2RootFileName(xml_eng,top_node,node_path); 
string objname = XML2RootObjName (xml_eng,top_node,node_path); 
string used_base_dir = base_dir; 
if(base_dir.find("<env>") != string::npos) { 
used_base_dir = Env::Instance()->TopLevelDataDir(); 
} 
TString full_filename = TString::Format("%s/%s", used_base_dir.c_str(), filename.c_str()); 
TFile * file = new TFile(full_filename.Data(),"read"); 
TTree * tree = (TTree*)file->Get(objname.c_str()); 
if(!tree) { 
assert(1); 
util::Die(1); return 0; 
} 
return tree; 
} 
TVectorD * valor::util::XML2TVectorD( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir) { 
assert(1); 
string filename = XML2RootFileName(xml_eng,top_node,node_path); 
string objname = XML2RootObjName (xml_eng,top_node,node_path); 
string used_base_dir = base_dir; 
if(base_dir.find("<env>") != string::npos) { 
used_base_dir = Env::Instance()->TopLevelDataDir(); 
} 
TString full_filename = TString::Format("%s/%s", used_base_dir.c_str(), filename.c_str()); 
TFile file(full_filename,"read"); 
TVectorD * vec = (TVectorD*)file.Get(objname.c_str()); 
if(!vec) { 
assert(1); 
file.Close(); 
util::Die(1); return 0; 
} 
TVectorD * vec_copy = new TVectorD(*vec); 
delete vec; 
file.Close(); 
return vec_copy; 
} 
TMatrixDSym * valor::util::XML2TMatrixDSym( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir) { 
string filename = XML2RootFileName(xml_eng,top_node,node_path); 
string objname = XML2RootObjName (xml_eng,top_node,node_path); 
string used_base_dir = base_dir; 
if(base_dir.find("<env>") != string::npos) { 
used_base_dir = Env::Instance()->TopLevelDataDir(); 
} 
TString full_filename = TString::Format("%s/%s", used_base_dir.c_str(), filename.c_str()); 
TFile file(full_filename,"read"); 
TMatrixDSym * matrix = (TMatrixDSym*)file.Get(objname.c_str()); 
if(!matrix) { 
assert(1); 
file.Close(); 
util::Die(1); return 0; 
} 
TMatrixDSym * matrix_copy = new TMatrixDSym(*matrix); 
delete matrix; 
file.Close(); 
return matrix_copy; 
} 
TMatrixD * valor::util::XML2TMatrixD( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir) { 
string objtype = XML2RootObjType (xml_eng,top_node,node_path); 
if(objtype == "TH2D") return XML2TH2D2TMatrixD(xml_eng,top_node,node_path); 
string filename = XML2RootFileName(xml_eng,top_node,node_path); 
string objname = XML2RootObjName (xml_eng,top_node,node_path); 
string used_base_dir = base_dir; 
if(base_dir.find("<env>") != string::npos) { 
used_base_dir = Env::Instance()->TopLevelDataDir(); 
} 
TString full_filename = TString::Format("%s/%s", used_base_dir.c_str(), filename.c_str()); 
TFile * file = new TFile(full_filename.Data(),"read"); 
TMatrixD * matrix = (TMatrixD*) file->Get(objname.c_str()); 
if(!matrix) { 
assert(1); 
file->Close(); 
util::Die(1); return 0; 
} 
TMatrixD * matrix_copy = new TMatrixD(*matrix); 
delete matrix; 
file->Close(); 
return matrix_copy; 
} 
TMatrixD * valor::util::XML2TH2D2TMatrixD( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir) { 
assert(1); 
string filename = XML2RootFileName(xml_eng,top_node,node_path); 
string objname = XML2RootObjName (xml_eng,top_node,node_path); 
string used_base_dir = base_dir; 
if(base_dir.find("<env>") != string::npos) { 
used_base_dir = Env::Instance()->TopLevelDataDir(); 
} 
TString full_filename = TString::Format("%s/%s", used_base_dir.c_str(), filename.c_str()); 
TFile file(full_filename.Data(),"read"); 
TH2D * h2 = (TH2D*)file.Get(objname.c_str()); 
if(!h2) { 
assert(1); 
file.Close(); 
util::Die(1); return 0; 
} 
const int nrows = h2->GetNbinsX(); 
const int ncols = h2->GetNbinsY(); 
TMatrixD * matrix = new TMatrixD(nrows,ncols); 
for(int i = 1; i <= nrows; i++) { 
for(int j = 1; j <= ncols; j++) { 
(*matrix)(i-1,j-1) = h2->GetBinContent(i,j); 
assert(1); 
} 
} 
#ifdef __show_xml_mesg_debug__ 
matrix->Print(); 
#endif 
delete h2; 
file.Close(); 
return matrix; 
} 
TSpline3 * valor::util::XML2TSpline3( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path, string base_dir) { 
string filename = XML2RootFileName(xml_eng,top_node,node_path); 
string objname = XML2RootObjName (xml_eng,top_node,node_path); 
string used_base_dir = base_dir; 
if(base_dir.find("<env>") != string::npos) { 
used_base_dir = Env::Instance()->TopLevelDataDir(); 
} 
TString full_filename = TString::Format("%s/%s", used_base_dir.c_str(), filename.c_str()); 
TFile file(full_filename.Data(),"read"); 
TSpline3 * spl = (TSpline3*) file.Get(objname.c_str()); 
if(!spl) { 
assert(1); 
file.Close(); 
util::Die(1); return 0; 
} 
TSpline3 * spl_copy = new TSpline3(*spl); 
delete spl; 
file.Close(); 
return spl_copy; 
} 
TAxis * valor::util::XML2BinInfo( TXMLEngine * xml_eng, XMLNodePointer_t top_node, string node_path) { 
assert(1); 
XMLNodePointer_t found_node = FindNode(xml_eng,top_node,node_path); 
if(!found_node) { 
assert(1); 
util::Die(1); return 0; 
} 
string binsz = xml_eng->GetAttr(found_node,"bin_size"); 
if(binsz == "fixed") { 
int nbins = 0; 
double min = 0; 
double max = 0; 
XMLNodePointer_t child_node = xml_eng->GetChild(found_node); 
while(child_node) { 
string child_node_name = xml_eng->GetNodeName(child_node); 
string content = xml_eng->GetNodeContent(child_node); 
if(child_node_name == "nbins") { nbins = atoi(TrimSpaces(content).c_str()); } 
if(child_node_name == "min" ) { min = atof(TrimSpaces(content).c_str()); } 
if(child_node_name == "max" ) { max = atof(TrimSpaces(content).c_str()); } 
child_node = xml_eng->GetNext(child_node); 
} 
assert(1); 
assert(nbins>0 && min<max); 
TAxis * axis = new TAxis(nbins,min,max); 
return axis; 
} 
else if(binsz == "variable") { 
assert(1); 
util::Die(1); return 0; 
} 
else { 
assert(1); 
util::Die(1); return 0; 
} 
return 0; 
} 
valor::util::VThreadPool * valor::util::VThreadPool::fInstance = 0; 
valor::util::VThreadPool * valor::util::VThreadPool::Instance() { 
if(fInstance == 0) { 
static valor::util::VThreadPool::Cleaner cleaner; 
cleaner.DummyMethodAndSilentCompiler(); 
fInstance = new valor::util::VThreadPool; 
} 
return fInstance; 
} 
#if __cplusplus > 199711L 
valor::util::VThreadPool::VThreadPool() : fNThreads(std::thread::hardware_concurrency()), fAbort(false), fNQueuedJobs(0), fNRunningJobs(0) { 
fInstance = 0; 
} 
valor::util::VThreadPool::~VThreadPool() { 
fAbort = true; 
fJobAvailable.notify_all(); 
for( auto &t : fThreads ) { 
if( t.joinable() ) {t.join();} 
} 
} 
void valor::util::VThreadPool::AddThread() { 
fThreads.emplace_back(std::move( std::thread( [this]{ this->ThreadBody(); } ) )); 
} 
void valor::util::VThreadPool::ThreadBody(void) { 
while( !fAbort ) { 
std::function<void(void)> f = this->GetTask(); 
fNRunningJobs++; 
f(); 
fNRunningJobs--; 
fWaitVar.notify_one(); 
} 
} 
std::function<void(void)> valor::util::VThreadPool::GetTask() { 
std::unique_lock<std::mutex> job_lock( fQueueMutex ); 
fJobAvailable.wait( job_lock, [this]{ return (fAbort || fNQueuedJobs); }); 
std::function<void(void)> f = []{}; 
if (!fAbort) { 
f = fQueue.front(); 
fQueue.pop_front(); 
fNQueuedJobs--; 
} 
return f; 
} 
unsigned int util::VThreadPool::GetNTasksInQueue(void) { 
return fNQueuedJobs; 
} 
unsigned int util::VThreadPool::GetNThreads(void) const { 
return fNThreads; 
} 
void util::VThreadPool::SetNThreads(unsigned int n) { 
if (n < fNThreads) { 
fJobAvailable.notify_all(); 
this->Wait(); 
fAbort = true; 
for( auto &t : fThreads ) { 
if( t.joinable() ) {t.join();} 
} 
} 
fThreads.clear(); 
fAbort = false; 
fNThreads = n; 
while (fThreads.size() < fNThreads) { 
this->AddThread(); 
} 
} 
void util::VThreadPool::AddTask(std::function<void(void)> work) { 
if (!fThreads.size()) { 
while (fThreads.size() < fNThreads) { 
this->AddThread(); 
} 
} 
std::lock_guard<std::mutex> lock( fQueueMutex ); 
fQueue.emplace_back( work ); 
fNQueuedJobs++; 
fJobAvailable.notify_one(); 
} 
void util::VThreadPool::AddTasks(std::vector<std::function<void(void)> > work) { 
for (unsigned int i = 0 ; i < work.size() ; i++) { 
this->AddTask(work[i]); 
} 
} 
void util::VThreadPool::DoTasks(std::vector<std::function<void(void)> > work) { 
this->AddTasks(work); 
this->Wait(); 
} 
void util::VThreadPool::Wait(bool finish) { 
std::function<bool(void)> finished =[&]{ return !(fNQueuedJobs||(finish&&fNRunningJobs));}; 
while(!finished()) { 
std::unique_lock<std::mutex> lock( fWaitMutex ); 
fWaitVar.wait_for( lock, std::chrono::seconds(10), finished); 
lock.unlock(); 
} 
} 
#endif 
